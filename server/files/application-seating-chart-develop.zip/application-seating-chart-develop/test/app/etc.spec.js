var etc = require('../../src/js/etc'),

    SeatLayer = require('../../src/js/layer/seatLayer'),

    Area = require('../../src/js/model/area'),
    RSeat = require('../../src/js/model/rSeat'),
    NSeat = require('../../src/js/model/nSeat'),
    originalSeatLayerSellingTypeCode,
    originalRSeatMapCode;

describe('etc', function() {

    beforeEach(function() {
        originalRSeatMapCode = RSeat.MAP_CODE.slice(0);
        RSeat.MAP_CODE = ['층', '구역', '열', '번호'];

        originalSeatLayerSellingTypeCode = SeatLayer.SELLING_TYPE_CODE;
        SeatLayer.SELLING_TYPE_CODE = {
            TKL: '티켓링크',
            FIELD: '현장',
            TICKET: '발권',
            POSTPONE: '보류',
            CALL: '콜센터',
            AGENCY: '기획사'
        };
    });

    afterEach(function() {
        RSeat.MAP_CODE = originalRSeatMapCode.slice(0);
        SeatLayer.SELLING_TYPE_CODE = originalSeatLayerSellingTypeCode;
    });

    describe('parseRSeatInfo()', function() {
        var seat;

        beforeEach(function() {
            seat = new RSeat();
            seat.setMapInfo(['1', 'A', '1', '35']);
        });

        it('툴팁에 들어갈 문자열을 만든다', function() {
            var html = etc.parseRSeatInfo(seat);
            expect(html).toBe('층: 1<br />구역: A<br />열: 1<br />번호: 35<br />');
        });

    });

    describe('parseNSeatInfo()', function() {
        var seat;

        beforeEach(function() {
            seat = new NSeat();
            seat.setDealership({ TKL: 100, POSTPONE: 50 });
        });

        it('툴팁에 들어갈 문자열을 만든다', function() {
            var html = etc.parseNSeatInfo(seat);
            expect(html).toBe('티켓링크: 100<br />보류: 50<br />');
        });

        it('remainCount 속성이 존재할 경우 잔여석 정보를 반환한다', function () {
            seat.remainCount = 100;
            expect(function () {
                etc.parseNSeatInfo(seat);
            }).toThrowError();
        });

    });

    describe('parseAreaInfo()', function() {
        var area;

        beforeEach(function() {
            area = new Area();
            area.data = 'hello world!';
        });

        it('툴팁에 들어갈 문자열을 만든다', function() {
            expect(etc.parseAreaInfo(area)).toBe('hello world!');
        });

    });

    describe('parseSeatInfo()', function() {
        var area,
            rSeat,
            nSeat;

        beforeEach(function() {
            area = new Area();
            area.data = 'hello!';

            rSeat = new RSeat();
            rSeat.setMapInfo(['2', 'B', '1', '35']);

            nSeat = new NSeat();
            nSeat.setDealership({ TKL: 30, AGENCY: 100 });
        });

        it('name 속성이 없는 좌석은 유효하지 않은 좌석이므로 emptyString을 반환한다', function () {
            var html = etc.parseSeatInfo({});
            expect(html).toBe('');
        });


        it('툴팁에 들어갈 정보를 정확히 만들고 불필요 문자를 제거한다', function() {
            var html;

            html = etc.parseSeatInfo(area);
            expect(html).toBe('hello!');

            html = etc.parseSeatInfo(rSeat);
            expect(html).toBe('층: 2<br />구역: B<br />열: 1<br />번호: 35');

            html = etc.parseSeatInfo(nSeat);
            expect(html).toBe('티켓링크: 30<br />기획사: 100');
        });

    });

    describe('sort', function() {
        var mock = [11, 4, 19, 12, 5, 1],
            mock2 = [{ a: 7 }, { a: 11 }, { a: 1 }];

        describe('asc()', function() {

            it('배열을 오름차순 정렬한다', function() {
                var asc = mock.sort(etc.sort.asc());
                expect(asc).toEqual([1, 4, 5, 11, 12, 19]);
            });

            it('객체 배열 내 객체의 숫자 값으로 오름차순 정렬한다', function() {
                var asc = mock2.sort(etc.sort.asc('a'));
                expect(asc).toEqual([{ a: 1 }, { a: 7 }, { a: 11 }]);
            });

        });

        describe('desc()', function() {

            it('배열을 내림차순 정렬한다', function() {
                var asc = mock.sort(etc.sort.desc());
                expect(asc).toEqual([19, 12, 11, 5, 4, 1]);
            });

            it('객체 배열 내 객체의 숫자 값으로 내림차순 정렬한다', function() {
                var asc = mock2.sort(etc.sort.desc('a'));
                expect(asc).toEqual([{ a: 11 }, { a: 7 }, { a: 1 }]);
            });

        });

    });

});