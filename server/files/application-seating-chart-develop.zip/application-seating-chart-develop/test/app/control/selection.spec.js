var SeatingChart = require('../../../src/js/seatingChart'),
    SelectionControl = require('../../../src/js/control/selection');

describe('SelectionControl', function() {
    var map;
    beforeEach(function() {
        loadFixtures('map.html');
        map = new SeatingChart('map');
    });

    it('map 인스턴스에 정상적으로 추가된다', function() {
        map.addControl(new SelectionControl());

        expect(map.getControl('seat-select-control')).toBeDefined();
    });

});
