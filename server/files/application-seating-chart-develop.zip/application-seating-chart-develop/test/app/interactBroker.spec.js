var InteractBroker = require('../../src/js/interactBroker');

describe('InteractBroker', function() {
    var ib;

    beforeEach(function() {
        ib = new InteractBroker();
    });

    describe('set()', function() {
        it('데이터를 저장할수있다.', function() {
            ib.set('myid', 'myid');
            expect(ib.sessionData.get('myid')).toEqual('myid');
        });
    });

    describe('get()', function() {
        it('저장된 데이터를 가져올수있다.', function() {
            ib.set('myid', 'myid');
            expect(ib.get('myid')).toEqual('myid');
        });
    });

    describe('listen()', function() {
        it('이벤트를 걸수있다.', function() {
            var result = false;

            ib.listen('myid', function(){
                result = true;
            });

            ib.fire('myid');

            expect(result).toEqual(true);
        });
    });

    describe('stopListen()', function() {
        it('걸린이벤트를 해제한다..', function() {
            var result = false;

            ib.listen('myid', function(){
                result = true;
            });

            ib.stopListen('myid');

            ib.fire('myid');

            expect(result).toEqual(false);
        });
        it('특정컨텍스트와 이벤트타입을 넘겨 해당 컨텍스트의 이벤트만 해제할수있다...', function() {
            var result = false,
                result2 = false,
                ctx1 = {},
                ctx2 = {};

            ib.listen('myid', function(){
                result = true;
            }, ctx1);

            ib.listen('myid', function(){
                result2 = true;
            }, ctx2);

            ib.stopListen('myid', ctx1);

            ib.fire('myid');

            expect(result).toEqual(false);
            expect(result2).toEqual(true);
        });
        it('특정컨텍스트만 넘겨 해당 컨텍스트의 이벤트들을 모두 해제할수있다...', function() {
            var result = false,
                result2 = false,
                result3 = false,
                ctx1 = {},
                ctx2 = {};

            ib.listen('myid', function(){
                result = true;
            }, ctx1);

            ib.listen('myid2', function(){
                result2 = true;
            }, ctx1);

            ib.listen('myid2', function(){
                result3 = true;
            }, ctx2);

            ib.stopListen(ctx1);

            ib.fire('myid');
            ib.fire('myid2');

            expect(result).toEqual(false);
            expect(result2).toEqual(false);
            expect(result3).toEqual(true);
        });
    });

    describe('emit()', function() {
        it('이벤트를 발생시킨다.', function() {
            var result = false;

            ib.listen('myid', function(){
                result = true;
            });

            ib.emit('myid');

            expect(result).toEqual(true);
        });

        it('이벤트를 발생하면서 인자를 넘길수있다.', function() {
            var result = false;

            ib.listen('myid', function(a, b, c){
                result = a + b + c;
            });

            ib.emit('myid', 'a', 'b', 'c');

            expect(result).toEqual('abc');
        });

        it('오더가 있으면 오더를 통해서 이벤트를 발생시킬수있다..', function() {
            var result = false;

            ib.listen('myid', function(a, b, c){
                result = a + b + c;
            });

            ib.addOrder('myid', function(a, b, c) {
                ib.fire('myid', c, b, a);
            });

            ib.emit('myid', 'a', 'b', 'c');

            expect(result).toEqual('cba');
        });

        it('order메소드는 ib를 컨텍스트로 실행된다.', function() {
            var ctx = null;

            ib.addOrder('myid', function() {
                ctx = this;
            });

            ib.emit('myid');

            expect(ctx).toBe(ib);
        });
    });
});
