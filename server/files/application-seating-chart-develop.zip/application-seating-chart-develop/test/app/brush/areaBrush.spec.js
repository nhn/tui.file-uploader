var Area = require('../../../src/js/model/area'),
    AreaBrush = require('../../../src/js/brush/areaBrush');

describe('AreaBrush', function() {
    var mock,
        area,
        brush;

    beforeEach(function() {
        mock = getJSONFixture('area.json');
        area = new Area(mock[0]);
        brush = new AreaBrush({ paper: {} });
    });

    describe('generatePath()', function() {
        it('영역의 좌표를 svg string으로 뽑아낸다', function() {
            var path = brush.generatePath(area);
            expect(path).toBe('M4205,4188L4692,4188L4692,4549L4205,4549L4205,4188Z');
        });

    });

});
