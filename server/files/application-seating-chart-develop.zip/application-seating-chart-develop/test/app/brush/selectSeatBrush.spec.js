var NSeat = require('../../../src/js/model/nSeat'),
    RSeat = require('../../../src/js/model/rSeat'),
    SelectSeatBrush = require('../../../src/js/brush/selectSeatBrush');

describe('SelectSeatBrush', function() {
    var originalCode = RSeat.MAP_CODE.slice(0),
        jsonFixtures,
        mockReserved,
        mockNonReserved,
        brush,
        rSeat,
        nSeat;

    beforeEach(function() {
        RSeat.MAP_CODE = ['층', '블록', '열', '번호'];

        jsonFixtures = loadJSONFixtures('reservedSeatList.json', 'nonReservedSeatList.json');

        mockReserved = jsonFixtures['reservedSeatList.json'];
        mockNonReserved = jsonFixtures['nonReservedSeatList.json'];

        brush = new SelectSeatBrush({ paper: {} });
        rSeat = new RSeat();
        rSeat.setData(mockReserved[0]);
        nSeat = new NSeat();
        nSeat.setData(mockNonReserved[0]);
    });

    afterEach(function() {
        RSeat.MAP_CODE = originalCode.slice(0);
    });

    it('좌석의 타입에 따라 다른 path를 만들어 반환한다', function() {
        var path = brush.generatePath(rSeat),
            path2 = brush.generatePath(nSeat);

        expect(path).toBe('M1654,760L1664,760L1664,770L1654,770Z');
        expect(path2).toBe('M1433,762L1600,762L1600,1035L1454,1037Z');
    });

});
