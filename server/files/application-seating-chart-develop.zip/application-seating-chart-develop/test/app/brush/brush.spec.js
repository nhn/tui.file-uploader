var Brush = require('../../../src/js/brush/brush'),
    PathItem = require('../../../src/js/brush/pathItem');

describe('Brush', function() {
    var raphaelElementMock,
        raphaelMock,
        brush;

    raphaelElementMock = {
        attr: function() {},
        remove: function() {}
    };

    raphaelMock = {
        path: function() {
            return raphaelElementMock;
        },
        set: function(){
            return raphaelElementMock;
        }
    };

    beforeEach(function() {
        brush = new Brush({paper: raphaelMock});
        brush.setViewItem(new PathItem(brush.paper));
    });

    describe('render()', function() {
        beforeEach(function() {
            var path = 'M10 10L40 10L40 40L10 40L10 10';
            brush.viewItem.add(path);
        });

        it('패스를 그린다.', function() {
            brush.render();
            expect(brush.viewItem.pathElement).toBeDefined();
        });
    });

    describe('hide()', function() {
        beforeEach(function() {
            var path = 'M10 10L40 10L40 40L10 40L10 10';
            brush.viewItem.add(path);
            brush.render();
        });

        it('PathItem의 hide를 수행한다.', function() {
            brush.viewItem.hide = jasmine.createSpy('viewItem.hide');
            brush.hide();

            expect(brush.viewItem.hide).toHaveBeenCalled();
        });

        it('hide가 수행된 이후엔 brush.render에서 ViewItem의  render가 수행되지 않는다.', function() {
            brush.hide();
            brush.viewItem.render = jasmine.createSpy('viewItem.render');
            expect(brush.viewItem.render).not.toHaveBeenCalled();
        });

        it('hide가 수행된 이후엔 brush.status가 Brush.STATUS.HIDE', function() {
            brush.hide();
            expect(brush.status).toEqual(Brush.STATUS.HIDE);
        });
    });

    describe('show()', function() {
        beforeEach(function() {
            var path = 'M10 10L40 10L40 40L10 40L10 10';
            brush.viewItem.add(path);
            brush.render();
            brush.hide();
            brush.viewItem.render = jasmine.createSpy('viewItem.render');
        });

        it('PathItem의 render를 수행한다.', function() {
            brush.show();
            expect(brush.viewItem.render).toHaveBeenCalled();
        });

        it('show가 수행된 이후엔 brush.status가 Brush.STATUS.SHOW', function() {
            brush.show();
            expect(brush.status).toEqual(Brush.STATUS.SHOW);
        });
    });

});
