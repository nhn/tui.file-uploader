var NSeat = require('../../../src/js/model/nSeat'),
    NSeatBrush = require('../../../src/js/brush/nSeatBrush');

describe('NSeatBrush', function() {
    var seat,
        seat2,
        brush;

    beforeEach(function() {
        brush = new NSeatBrush({ paper: {} });

        seat = new NSeat('비지정석A');
        seat.setPoints([[1, 1], [3, -1], [5, 2], [3, 1], [2, 4]]);

        seat2 = new NSeat('비지정석B');
        seat2.setPoints([[7, 7], [12, 9], [10, 11], [10, 9], [7, 12], [6, 8]]);

    });

    it('비지정석의 path에 해당하는 path를 그린다', function() {
        var path = brush.generatePath(seat),
            path2 = brush.generatePath(seat2);

        expect(path).toBe('M1,1L3,-1L5,2L3,1L2,4Z');
        expect(path2).toBe('M7,7L12,9L10,11L10,9L7,12L6,8Z');
    });

});
