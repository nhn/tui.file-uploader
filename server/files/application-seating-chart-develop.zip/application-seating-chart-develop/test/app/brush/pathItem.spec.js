var PathItem = require('../../../src/js/brush/pathItem');

describe('PathItem', function() {
    var raphaelElementMock,
        raphaelMock,
        pathItem;

    raphaelElementMock = {
        attr: function() {}
    };

    raphaelMock = {
        path: function() {
            return raphaelElementMock;
        }
    };

    beforeEach(function() {
        pathItem = new PathItem(raphaelMock);
    });

    describe('add()', function() {
        it('패스를 하나 추가하면 pathStrt에 추가된다..', function() {
            var path = 'M10 10L40 10L40 40L10 40L10 10';

            pathItem.add(path);

            expect(pathItem.pathStr).toEqual(path);
        });

        it('paths 배열에 추가 패스의 내용이 정확하다.', function() {
            var path = 'M10 10L40 10L40 40L10 40L10 10';
            var path2 = 'M10 10L40 10L40 40L10 40L10 10';

            pathItem.add(path);
            pathItem.add(path2);

            expect(pathItem.pathStr).toBe(path + path2);
        });
    });

    describe('clear()', function() {
        var path,
            path2;

        beforeEach(function() {
            path = 'M10 10L40 10L40 40L10 40L10 10';
            path2 = 'M50 50L80 10L80 80L50 80L50 50';

            pathItem.add(path);
            pathItem.add(path2);
            pathItem.setAttrs({
                stroke: '1px'
            });
            pathItem.render();
            pathItem.hide = jasmine.createSpy('hide');
        });

        it('pathStr을 ""로 초기화한다.', function() {
            pathItem.clear();
            expect(pathItem.pathStr).toEqual("");
        });

        it('hide를 수횅한다.', function() {
            pathItem.clear();
            expect(pathItem.hide).toHaveBeenCalled();
        });
    });


    describe('render()', function() {
        var path,
            path2;

        beforeEach(function() {
            path = 'M10 10L40 10L40 40L10 40L10 10';
            path2 = 'M50 50L80 10L80 80L50 80L50 50';

            pathItem.add(path);
            pathItem.add(path2);
            pathItem.setAttrs({
                stroke: '1px'
            });
        });

        it('pathElement이 생성된다.', function() {
            pathItem.render();
            expect(pathItem.pathElement).toBeDefined();
        });
    });
});
