var SeatBrush = require('../../../src/js/brush/seatBrush'),
    RSeat = require('../../../src/js/model/rSeat');

describe('SeatBrush', function() {
    var raphaelElementMock,
        raphaelMock,
        seatBrush;

    raphaelElementMock = {
        attr: function() {}
    };

    raphaelMock = {
        path: function() {
            return raphaelElementMock;
        },
        set: function(){
            return raphaelElementMock;
        }
    };

    beforeEach(function() {
        seatBrush = new SeatBrush({paper: raphaelMock});
    });

    describe('addPath()', function() {
        it('패스스트링을 넘겨 바로 Path를 추가한다.', function() {
            var path = 'M10 10L40 10L40 40L10 40L10 10';
            seatBrush.addPath(path);

            expect(seatBrush.viewItem.pathStr).toEqual(path);
        });
    });

    describe('addItemBySeat()', function() {
        var seatData,
            seat;

        beforeEach(function() {
            seatData = {
                'sid': 123,
                'position': [15, 71],
                'bound': [[10, 66], [20, 76]],
                'points': [[10, 66], [20, 66], [20, 76], [10, 76]]
            };

            seat = new RSeat();
            seat.setData(seatData);
        });

        it('전달된 Seat정보를 이용해 Path를 추가한다.', function() {
            seatBrush.addItemBySeat(seat);
            expect(seatBrush.viewItem.pathStr).toEqual('M10,66L20,66L20,76L10,76Z');
        });
    });

});
