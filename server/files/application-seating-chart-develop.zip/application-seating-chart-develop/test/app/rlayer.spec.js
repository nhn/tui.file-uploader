var RLayer = require('../../src/js/rlayer');

describe('RLayer', function () {
    var mapOptions,
        Raphael,
        MockLayer,
        MockPaper,
        MockChart,
        MockElement,
        rLayer;

    beforeEach(function () {
        mapOptions = {
            seatSize: 10,
            zoomLevelInSeatSize: 4,
            mapSize: 2048
        };

        // Mock
        MockLayer = jasmine.createSpyObj('MockLayer', ['toFront', 'attachEvent']);
        MockPaper = jasmine.createSpyObj('MockPaper', ['setSize', 'setViewBox']);
        MockChart = jasmine.createSpyObj('MockChart', ['getScaleRatio']);
        MockChart.getScaleRatio.and.returnValue(1);
        MockChart.options = mapOptions;
        MockChart.layer = {};
        MockElement = { style: {} };
        Raphael = jasmine.createSpy('Raphael');
        Raphael.and.returnValue(MockPaper);

        window.Raphael = Raphael;

        rLayer = new RLayer(mapOptions);
    });

    it('맵에 추가되어 Raphael로 렌더링할 수 있는 기능을 제공한다', function () {
        spyOn(rLayer, 'toFront');
        spyOn(rLayer, 'resize');
        spyOn(rLayer, 'attachEvent');

        rLayer.initialize(MockChart, {}, MockElement);

        expect(MockChart.paper).toBe(MockPaper);
        expect(rLayer.attachEvent.calls.argsFor(0)).toEqual([{ 'afterZoom:map': rLayer._onAfterZoom }]);
    });

    it('맵이 확대/축소 될 경우 그에 맞게 paper의 스케일을 조절한다', function () {
        spyOn(rLayer, '_getPaperSize').and.returnValue(2048);
        rLayer.map = MockChart;
        rLayer.paper = MockPaper;

        rLayer.resize();

        expect(MockPaper.setSize).toHaveBeenCalledWith(2048, 2048);
    });

    it('확대/축소 이벤트 발생 시 resize를 호출하여 조절한다', function () {
        spyOn(rLayer, 'resize');

        rLayer._onAfterZoom();

        expect(rLayer.resize).toHaveBeenCalled();
    });

});
