var NSeat = require('../../../src/js/model/nSeat'),
    NSeatLayer = require('../../../src/js/layer/nSeatLayer');

describe('NSeatLayer', function() {
    var nSeatLayer;

    beforeEach(function() {
        nSeatLayer = new NSeatLayer({ paper: {} });
    });

    it('비지정석의 기본 brushID는 normal이다', function() {
        var seat = new NSeat('비지정석C');

        var brushes = nSeatLayer.getBrushIDFromSeat(seat);

        expect(brushes).toEqual(['normal']);
    });

    describe('옵션에 따라 사용불가좌석 관리하지 않아야 한다', function () {
        beforeEach(function () {
            NSeatLayer.excludeNotAvailableSeat = true;
        });

        afterEach(function () {
            NSeatLayer.excludeNotAvailableSeat = false;
        });

        it('비지정석이 사용불가이므로 데이터를 세팅하지 않아야 한다', function () {
            var mockSeat = [{
                sid: '123',
                isDisabled: true,
                points: [[1, 1], [2, 2], [3, 3], [4, 4]]
            }];

            nSeatLayer.setData(mockSeat);

            expect(nSeatLayer.seats.length).toBe(0);

            mockSeat[0].isDisabled = false;
            mockSeat[0].soldout = true;

            nSeatLayer.setData(mockSeat);

            expect(nSeatLayer.seats.length).toBe(0);
        });

    });

});
