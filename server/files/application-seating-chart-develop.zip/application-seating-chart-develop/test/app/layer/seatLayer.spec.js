var SeatLayer = require('../../../src/js/layer/seatLayer'),
    SeatBrush = require('../../../src/js/brush/seatBrush');

describe('SeatLayer', function() {
    var raphaelElementMock,
        raphaelMock,
        seatLayer,
        seat1,
        seat2;

    raphaelElementMock = {
        attr: function() {}
    };

    raphaelMock = {
        path: function() {
            return raphaelElementMock;
        },
        set: function(){
            return raphaelElementMock;
        }
    };
    function mockSeat(options) {
        options.getID = function() {
            return this.sid;
        };

        return options;
    }

    var seatBrush1, seatBrush2, seatBrush3;


    beforeEach(function() {
        seatLayer = new SeatLayer({
            paper: raphaelMock,
            slid: 'myslid'
        });

        seat1 = mockSeat({'sid': '1'});
        seat2 = mockSeat({'sid': '2'});

        seatBrush1 = new SeatBrush({paper: raphaelMock});
        seatBrush2 = new SeatBrush({paper: raphaelMock});
        seatBrush3 = new SeatBrush({paper: raphaelMock});
    });

    describe('addSeat()', function() {
        it('seat을 추가할수있다.', function() {
            seatLayer.addSeat(seat1);
            expect(seatLayer.seats.length).toEqual(1);
        });

        it('seat을 추가하면 seatLayer.slid를 seat.slid에 복사한다.', function() {
            seatLayer.addSeat(seat1);
            expect(seatLayer.seats.get('1').slid).toBeDefined();
            expect(seatLayer.seats.get('1').slid).toEqual(seatLayer.slid);
        });

        it('seat의 배열을 추가할수있다.', function() {
            seatLayer.addSeat([seat1, seat2]);
            expect(seatLayer.seats.length).toEqual(2);
        });
    });

    describe('removeSeatById()', function() {
        beforeEach(function() {
            seatLayer.addSeat([
                seat1,
                seat2
            ]);
        });

        it('seat아이디로 seat을 제거할수 있다.', function() {
            seatLayer.removeSeatById('1');
            expect(seatLayer.seats.length).toEqual(1);
        });

        it('seat아이디로 seat을 제거하면 slid가 null로 된다..', function() {
            var removedSeat = seatLayer.removeSeatById('1');
            expect(removedSeat[0].slid).toBe(null);
        });

        it('seat아이디의 배열로 seat을 제거할수있다.', function() {
            seatLayer.removeSeatById(['1', '2']);
            expect(seatLayer.seats.length).toEqual(0);
        });
    });

    describe('removeSeat()', function() {
        beforeEach(function() {
            seatLayer.addSeat([
                seat1,
                seat2
            ]);
        });

        it('seat을 제거할수 있다.', function() {
            seatLayer.removeSeat(seat1);
            expect(seatLayer.seats.length).toEqual(1);
        });

        it('seat의 배열로 seat을 제거 할수있다.', function() {
            seatLayer.removeSeat([seat1, seat2]);
            expect(seatLayer.seats.length).toEqual(0);
        });
    });

    describe('eachSeat()', function() {
        beforeEach(function() {
            seatLayer.addSeat([
                seat1,
                seat2
            ]);
        });

        it('seat목록을 순회하며 seat을 콜백에 전달받을수있다..', function() {
            var sum = '';

            seatLayer.eachSeat(function(seat) {
                sum += seat.sid;
            });

            expect(sum).toEqual('12');
        });
    });

    describe('_setBrush()', function() {
        it('id와 Brush를 전달하여 브러시를 만든다.', function() {
            seatLayer._setBrush('brush1', seatBrush1);

            expect(seatLayer.brushes.get('brush1')).toBeDefined();
        });
    });

    describe('setBrush()', function() {
        it('brush정의 객체를 전달해 brush를 생성할수있다.', function() {
            seatLayer.setBrush({
                'brush1' : seatBrush1
            });

            expect(seatLayer.brushes.get('brush1')).toBeDefined();
        });

        it('이미있는 brush를 다시 설정 할수있다.', function() {
            seatLayer.setBrush('brush1', seatBrush1);
            seatLayer.setBrush('brush1', seatBrush2);

            expect(seatLayer.brushes.get('brush1')).toBe(seatBrush2);
            expect(seatLayer.brushes.get('brush1')).not.toBe(seatBrush1);
        });

        it('brush를 셋팅하는 순서로 그려지는 순서가 결정된다.', function() {
            seatLayer.setBrush('brush1', seatBrush1);
            seatLayer.setBrush('brush2', seatBrush2);

            expect(seatLayer.brushOrder).toEqual(['brush1', 'brush2']);
        });
    });

    describe('addPath()', function() {
        beforeEach(function() {
            seatLayer.setBrush('brush1', seatBrush1);
        });

        it('pathItem에 패스스트링을 추가한다.', function() {
            seatLayer.addPath('brush1', '1');

            expect(seatLayer.brushes.get('brush1').viewItem.pathStr).toEqual('1');
        });

        it('pathItem에 패스스트링을 반복추가 할수있다..', function() {
            seatLayer.addPath('brush1', '1');
            seatLayer.addPath('brush1', '2');

            expect(seatLayer.brushes.get('brush1').viewItem.pathStr).toEqual('12');
        });

    });

    describe('useBrush', function() {
        it('Seat과 Id를 넘겨 pathItem에 path를 등록한다.', function() {
            var pointsLen = 0,
                seatMockup = {
                    points: [
                        {x: 1, y: 1},
                        {x: 1, y: 1},
                        {x: 1, y: 1},
                        {x: 1, y: 1}
                    ]
                };

            seatLayer.setBrush('brush1', seatBrush1);

            seatBrush1.generatePath = function(seat) {
                pointsLen = seat.points.length;
                return 'yes';
            };

            seatLayer.useBrush('brush1', seatMockup);

            expect(seatLayer.brushes.get('brush1').viewItem.pathStr).toEqual('yes');
            expect(pointsLen).toEqual(4);
        });
    });

    describe('initPath', function() {
        it('path목록을 넘겨 pathItem에 path를 등록한다.', function() {
            var paths = {
                    'brush1': 'M10 10L40 10L40 40L10 40L10 10',
                    'brush2': 'M10 10L40 10L40 40L10 40L10 10'
                };

            seatLayer.setBrush('brush1', seatBrush1);
            seatLayer.setBrush('brush2', seatBrush2);

            seatLayer.initPaths(paths);

            expect(seatLayer.brushes.get('brush1').viewItem.pathStr).toEqual(paths.brush1);
            expect(seatLayer.brushes.get('brush2').viewItem.pathStr).toEqual(paths.brush2);
        });
    });

    describe('render()', function() {
        beforeEach(function() {
        });
        it('', function() {
        });
    });

    describe('requestSeatsContainsPoint()', function() {
        var mockSeats;

        beforeEach(function() {
            mockSeats = getJSONFixture('');
        });
    });

});
