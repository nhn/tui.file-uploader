var ZoomReactor = require('../../../src/js/layer/zoomReactor');

describe('ZoomReactor', function() {
    var zr,
        mockBrush,
        allBrush;

    function MockBrush() {}
    MockBrush.prototype.brushName = 'Mock';
    function AllBrush() {}
    AllBrush.prototype.brushName = 'All';

    /**********
     * TC
     **********/

    beforeEach(function() {
        zr = new ZoomReactor();
        mockBrush = new MockBrush();
        allBrush = new AllBrush();
    });

    describe('setReactZoomRange()', function() {
        beforeEach(function() {
            ZoomReactor.CONFIG = {
                'Mock': [2, 4]
            };

            zr.setReactZoomRange(mockBrush);
            zr.setReactZoomRange(allBrush);
        });

        it('해당 브러시가 렌더링 될 범위를 설정한다', function() {
            var rangeItem = zr.rangeSet['2:4'],
                rangeItemAll = zr.rangeSet['all'];

            expect(rangeItem.range).toEqual([2, 4]);
            expect(rangeItem.brushes[0]).toBe(mockBrush);
            expect(rangeItemAll.range).toEqual('all');
            expect(rangeItemAll.brushes[0]).toBe(allBrush);
        });
    });

    describe('findRangeSet()', function() {
        beforeEach(function() {
            ZoomReactor.CONFIG = {
                'Mock': [2, 4]
            };

            zr.setReactZoomRange(mockBrush);
            zr.setReactZoomRange(allBrush);
        });

        it('줌 레벨에서 숨김/노출되어야 할 브러시 목록을 반환', function() {
            var on2 = zr.findRangeSet(2),
                on1 = zr.findRangeSet(1);

            expect(on2.found.length).toBe(2);
            expect(on2.found[0].range).toEqual([2, 4]);
            expect(on2.found[0].brushes[0]).toBe(mockBrush);
            expect(on2.found[1].range).toBe('all');
            expect(on2.found[1].brushes[0]).toBe(allBrush);

            expect(on1.found[0].range).toBe('all');
            expect(on1.found[0].brushes[0]).toBe(allBrush);
            expect(on1.rest[0].range).toEqual([2, 4]);
            expect(on1.rest[0].brushes[0]).toBe(mockBrush);
        });
    });

    describe('react()', function() {
        var mockSpy,
            allSpy,
            goodSpy;

        function GoodBrush() {}
        GoodBrush.prototype.brushName = 'Good';

        beforeEach(function() {
            ZoomReactor.CONFIG = {
                'Mock': [2, 4],
                'Good': [3]
            };

            mockSpy = jasmine.createSpyObj('mock', ['show', 'hide']);
            allSpy = jasmine.createSpyObj('all', ['show', 'hide']);
            goodSpy = jasmine.createSpyObj('good', ['show', 'hide']);

            MockBrush.prototype.show = mockSpy.show;
            MockBrush.prototype.hide = mockSpy.hide;

            AllBrush.prototype.show = allSpy.show;
            AllBrush.prototype.hide = allSpy.hide;

            GoodBrush.prototype.show = goodSpy.show;
            GoodBrush.prototype.hide = goodSpy.hide;

            zr.setReactZoomRange(mockBrush);
            zr.setReactZoomRange(allBrush);
            zr.setReactZoomRange(new GoodBrush());
        });

        it('0레벨에서는 MockBrush, GoodBrush 숨김', function() {
            zr.react(0);

            expect(goodSpy.hide).toHaveBeenCalled();
            expect(goodSpy.show).not.toHaveBeenCalled();

            expect(mockSpy.hide).toHaveBeenCalled();
            expect(mockSpy.show).not.toHaveBeenCalled();

            expect(allSpy.show).toHaveBeenCalled();
            expect(allSpy.hide).not.toHaveBeenCalled();
        });

        it('2레벨에서는 AllBrush, MockBrush만 노출', function() {
            zr.react(2);

            expect(goodSpy.hide).toHaveBeenCalled();
            expect(goodSpy.show).not.toHaveBeenCalled();

            expect(mockSpy.show).toHaveBeenCalled();
            expect(mockSpy.hide).not.toHaveBeenCalled();

            expect(allSpy.show).toHaveBeenCalled();
            expect(allSpy.hide).not.toHaveBeenCalled();
        });

        it('3레벨에서는 셋다 노출', function() {
            zr.react(3);

            expect(goodSpy.show).toHaveBeenCalled();
            expect(goodSpy.hide).not.toHaveBeenCalled();

            expect(mockSpy.show).toHaveBeenCalled();
            expect(mockSpy.hide).not.toHaveBeenCalled();

            expect(allSpy.show).toHaveBeenCalled();
            expect(allSpy.hide).not.toHaveBeenCalled();
        });

    });

});

