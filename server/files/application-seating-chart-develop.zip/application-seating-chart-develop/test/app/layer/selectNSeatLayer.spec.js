var NSeat = require('../../../src/js/model/nSeat'),
    SelectNSeatLayer = require('../../../src/js/layer/selectNSeatLayer');

describe('SelectNSeatLayer', function() {
    var mockSeats,
        snsl;

    beforeEach(function() {
        mockSeats = loadJSONFixtures('nonReservedSeatList.json')['nonReservedSeatList.json'];
        snsl = new SelectNSeatLayer({ paper: {} });
    });

    describe('getBrushIDFromSeat()', function() {
        var seat,
            brushes;

        beforeEach(function() {
            seat = new NSeat();
            seat.setData(mockSeats[0]);

            brushes = snsl.getBrushIDFromSeat(seat);
        });

        it('선택 좌석에 대한 브러시도 같이 반환해야 한다', function() {
            expect(brushes.pop()).toBe('select');
        });
    });

});
