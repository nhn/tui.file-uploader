var RSeat = require('../../../src/js/model/rSeat'),
    SelectSeatLayer = require('../../../src/js/layer/selectSeatLayer');

describe('SelectSeatLayer', function() {
    var originCode = RSeat.MAP_CODE.slice(0),
        mockReserved,
        ssl;

    beforeEach(function() {
        mockReserved = getJSONFixture('reservedSeatList.json');

        ssl = new SelectSeatLayer({ paper: { set: function() {} } });
        RSeat.MAP_CODE = ['층', '구역', '열', '번호'];
    });

    afterEach(function() {
        RSeat.MAP_CODE = originCode.slice(0);
    });

    describe('setData()', function() {
        beforeEach(function() {
            ssl.setData(mockReserved);
        });

        it('지정석 API데이터를 넘기면 자신의 좌석 리스트를 초기화한다', function() {
            var seats = ssl.seats;
            expect(seats.length).not.toBe(0);
        });
    });

    describe('getBrushIDFromSeat()', function() {
        var seat,
            brushes;

        beforeEach(function() {
            seat = new RSeat();
            brushes = ssl.getBrushIDFromSeat(seat);
        });

        it('선택 좌석에 대한 브러시도 같이 반환해야 한다', function() {
            expect(brushes.pop()).toBe('select');
        });
    });

});
