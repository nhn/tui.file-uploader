var GridLayer = require('../../../src/js/layer/gridLayer');

describe('GridLayer', function() {
    var grid;

    var raphaelElementMock,
        raphaelMock;

    raphaelElementMock = {
        attr: function() {}
    };

    raphaelMock = {
        path: function() {
            return raphaelElementMock;
        },
        set: function(){
            return raphaelElementMock;
        }
    };

    beforeEach(function() {
        grid = new GridLayer({
            paper: raphaelMock
        });
    });

    describe('setBrushes()', function() {
        it('Grid가 필요한 브러시를 셋팅한다.', function() {
            //이니셔라이즈에서 자동실행되어 다시 초기화
            grid.brushes.removeAll();

            expect(grid.brushes.length).toBe(0);

            grid.setBrushes();

            expect(grid.brushes.length).not.toBe(0);
        });
    });

    describe('옵션에 따라 사용불가좌석을 관리하지 않아야 한다', function () {
        beforeEach(function () {
            GridLayer.excludeNotAvailableSeat = true;
        });

        afterEach(function () {
            GridLayer.excludeNotAvailableSeat = false;
        });

        it('비지정석이 사용불가이므로 데이터를 세팅하지 않아야 한다', function () {
            var mockSeat = [{
                sid: '123',
                isDisabled: true,
                points: [[1, 1], [2, 2], [3, 3], [4, 4]]
            }];

            grid.setData(mockSeat);

            expect(grid.seats.length).toBe(0);

            mockSeat[0].isDisabled = false;
            mockSeat[0].soldout = true;

            grid.setData(mockSeat);

            expect(grid.seats.length).toBe(0);
        });

        it('soldoutMap에서 soldout이 true일 경우 역시 제외되어야 한다', function () {
            var mockSeat = [{
                    sid: '123',
                    isDisabled: false,
                    soldout: false,
                    points: [[1, 1], [2, 2], [3, 3], [4, 4]]
                }],
                mockSoldoutMap = {
                    '123': true
                };

            grid.setData(mockSeat, mockSoldoutMap);

            expect(grid.seats.length).toBe(0);
        });

    });

});
