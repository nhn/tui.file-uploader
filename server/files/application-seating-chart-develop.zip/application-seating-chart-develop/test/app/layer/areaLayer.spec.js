var AreaLayer = require('../../../src/js/layer/areaLayer');

describe('AreaLayer', function () {
    var mock,
        layer;

    beforeEach(function () {
        mock = getJSONFixture('area.json');
        layer = new AreaLayer({ paper: {} });
    });

    describe('init', function () {
        it('기본 브러시를 세팅', function () {
            expect(layer.brushes.length).toBe(1);
        });

        it('기본 브러시의 이름은 normal', function () {
            expect(layer.brushes.get('normal')).toBeDefined();
        });
    });

    describe('setData()', function() {

        beforeEach(function () {
            layer.setData(mock);
        });

        it('기본도면정보 -> areaData를 프로퍼티로 설정', function () {
            expect(layer.seats.length).not.toBe(0);
        });

    });

});
