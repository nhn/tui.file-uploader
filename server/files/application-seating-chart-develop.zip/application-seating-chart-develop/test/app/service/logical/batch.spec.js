var SeatLayer = require('../../../../src/js/layer/seatLayer'),
    batch = require('../../../../src/js/service/admin/logical/batch'),
    RSeat = require('../../../../src/js/model/rSeat'),
    NSeat = require('../../../../src/js/model/nSeat');

describe('logical/batch', function() {
    var originSellingTypeCode = SeatLayer.SELLING_TYPE_CODE,
        originMapCode = RSeat.MAP_CODE;

    var mockRSeats,
        mockNSeats;

    beforeEach(function() {
        RSeat.MAP_CODE = ['층', '블록', '열', '번호'];
        SeatLayer.SELLING_TYPE_CODE = {
            'TKL': '티켓링크',
            'AGENCY': '기획사',
            'FIELD': '현장',
            'POSTPONE': '보류',
            'TICKET': '발권'
        };

        mockRSeats = [];
        mockNSeats = [];

        ne.util.forEachArray(getJSONFixture('rSeats_3x3.json').seats, function(seatData) {
            var seat = new RSeat();
            seat.setData(seatData);
            seat.sellingType = '';
            mockRSeats.push(seat);
        });

        ne.util.forEachArray(getJSONFixture('nonReservedSeatList.json'), function(seatData) {
            var seat = new NSeat();
            seat.setData(seatData);
            mockNSeats.push(seat);
        });
    });

    afterEach(function() {
        RSeat.MAP_CODE = originMapCode;
        SeatLayer.SELLING_TYPE_CODE = originSellingTypeCode;
    });

    describe('applySellingType()', function() {
        it('지정석의 판매 할당처를 수정한다', function() {
            batch.applyDealership(mockRSeats, 'TKL');

            expect(mockRSeats[0].sellingType).toBe('TKL');
            expect(mockRSeats[4].sellingType).toBe('TKL');
        });

        it('비지정석의 판매 할당처를 수정한다', function() {
            batch.applyDealership(mockNSeats, 'TKL', 100);

            expect(mockNSeats[0].getTicket('TKL')).toBe(100);

            batch.applyDealership(mockNSeats, 'AGENCY', 30);

            expect(mockNSeats[1].getDealership()).toEqual({ 'TKL': 100, 'AGENCY': 30 });
        });
    });

    xdescribe('applyGrade()', function() {
        it('지정석, 비지정석의 등급을 수정한다', function() {
            var merge = mockRSeats.concat(mockNSeats);

            batch.applyGrade(merge, 'G01');

            expect(merge[0].grade).toBe('G01');
        });
    });

});
