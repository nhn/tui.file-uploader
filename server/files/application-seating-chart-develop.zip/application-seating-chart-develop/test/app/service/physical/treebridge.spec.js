var TreeBridge = require('../../../../lib/tree/Component-Tree');
var TreeBridge = require('../../../../src/js/service/admin/physical/treebridge');

describe('treebridge를 통한 트리 생성, 노드 편집을 할 수 있다.', function() {
    var sids1,
        sids2;
    beforeEach(function() {
        var treeHash = new ne.util.HashMap();
        // tree Element 생성 추가
        var seats_tree = document.createElement('div');
        seats_tree.id = 'seats_tree';
        document.body.appendChild(seats_tree);


        treeHash.set({
            10 : {
                sid: 10,
                mapInfo: '1,A'
            },
            11 : {
                sid: 11,
                mapInfo: '1,A'
            },
            12 : {
                sid: 12,
                mapInfo: '1,A'
            },
            13 : {
                sid: 13,
                mapInfo: '1,B'
            },
            14 : {
                sid: 14,
                mapInfo: '1,B'
            },
            15 : {
                sid: 15,
                mapInfo: '1,B'
            },
            16 : {
                sid: 16,
                mapInfo: '1,A,1'
            },
            17 : {
                sid: 17,
                mapInfo: '1,A,1'
            },
            18 : {
                sid: 18,
                mapInfo: '1,A,1'
            },
            19 : {
                sid: 19,
                mapInfo: '1,A,1'
            },
            20 : {
                sid: 20,
                mapInfo: '1,A,1'
            }
        });
        treeHash.each(function(d) {
            d.mapInfo = d.mapInfo.split(',')
        });
        TreeBridge.setTreeRenamedCallback(function(e) {
            sids1 = e.sids;
        });
        TreeBridge.setTreeSelectedCallback(function(e) {
            sids2 = e.sids;
        });
        TreeBridge.replaceTreeMap(treeHash);
        TreeBridge.notify();
        expect(TreeBridge._tree).toBeDefined();
    });


    it('생성 및 추가를 할수 있다.', function() {
        expect(TreeBridge).toBeDefined();
    });

    it('값이 중복되는지 확인', function() {
       var arr = [
               {title: 'a'},
               {title: 'b'},
               {title: 'c'},
               {title: 'd'}
           ],
           duplicate = TreeBridge._checkDuplicate('a', arr),
           notDuplicate = TreeBridge._checkDuplicate('f', arr);

        expect(duplicate).toBeTruthy();
        expect(notDuplicate).toBeFalsy();
    });

    it('아이디 추출', function() {
        var values = '1,A,1',
            depth = 2;

        var result = TreeBridge._extractSIDs(values, depth);
        expect(result.length).toBe(5);
    });
});
