var batch = require('../../../../src/js/service/admin/physical/batch');
var RSeat = ne.tkl.RSeat;

function getMockHashMap(seats) {
    var hash = new ne.util.HashMap(),
        seat,
        i,
        cnt = seats.length,
        inst;

    for (i = 0; i < cnt; i += 1) {
        seat = seats[i];

        inst = new RSeat(0, 0);
        inst.setData(seat);

        hash.set(inst.sid + '', inst);
    }

    return hash;
}

describe('physical/batch', function() {
    var originalMapCode = RSeat.MAP_CODE.slice(0);

    describe('CharIterator', function() {
        /**
         * @type {CharIterator}
         */
        var ci = new batch.CharIterator();

        describe('문자 순회 기능', function() {

            it('숫자', function() {
                ci.start(1000040);

                expect(ci.next()).toBe(1000041);
            });

            it('한글 초성', function() {
                ci.start('ㄱ');

                expect(ci.next()).toBe('ㄴ');

                ci.start('ㄷ');

                expect(ci.next()).toBe('ㄹ');
            });

            it('한글 초성 순회범위 초과 시 에러 발생', function() {
                ci.start('ㅎ');

                expect(function() {
                    ci.next();
                }).toThrow();
            });

            it('한글', function() {
                ci.start('가');

                expect(ci.next()).toBe('나');

                ci.start('사');

                expect(ci.next()).toBe('아');
            });

            it('한글 순회범위 초과 시 에러 발생', function() {
                ci.start('하');

                expect(function() {
                    ci.next();
                }).toThrow();
            });

            it('알파벳', function() {
                ci.start('C');

                expect(ci.next()).toBe('D');
            });

            it('알파벳 순회범위 초과 시 에러 발생', function() {
                ci.start('Z');

                expect(function() {
                    ci.next();
                }).toThrow();
            });

            it('reverse 옵션을 통해 역순 순회할 수 있다', function() {
                ci.start('Z', true);

                expect(ci.next()).toBe('Y');

                ci.start('가', true);

                expect(function() {
                    ci.next();
                }).toThrow();

            });
        });

        describe('setIncrement()', function() {
            it('증감되는 값을 설정할 수 있다', function() {
                ci.start('ㄱ', false, 2);
                expect(ci.next()).toBe('ㄷ');
            });
        });

    });

    describe('indexSeatsByPosition()', function() {
        var mock;

        beforeEach(function() {
            mock = getMockHashMap(getJSONFixture('rSeats_3x3.json').seats);
        });


        it('좌석 데이터들을 좌표 기준으로 인덱싱한다', function() {
            var index = batch.indexSeatsByPosition(mock),
                coord = index.coord;

            expect(coord['2:0'].sid).toBe('7');
        });

    });

    describe('getStartSeat()', function() {
        var mock,
            index;

        beforeEach(function() {
            mock = getMockHashMap(getJSONFixture('rSeats_3x3.json').seats);

            index = batch.indexSeatsByPosition(mock);
        });

        it('자동배열 타입에 따라 매핑을 시작할 첫 좌석 정보를 반환한다', function() {
            var seat = batch.getStartSeat(index, batch.MAPPING_METHOD.A);
            var seat2 = batch.getStartSeat(index, batch.MAPPING_METHOD.B);

            expect(seat.sid).toBe('1');
            expect(seat2.sid).toBe('7');
        });

    });

    describe('iterateSeats()', function() {
        var mock;

        beforeEach(function() {
            RSeat.MAP_CODE = ['층', '블록', '열', '번호'];
            RSeat.MAP_UNIT = ['GENERAL', 'GENERAL', 'ROW', 'NUMBER'];

            mock = getMockHashMap(getJSONFixture('rSeats_3x3.json').seats);
        });

        afterEach(function() {
            RSeat.MAP_CODE = originalMapCode;
        });


        describe('좌석을 좌/우 방향으로 순회하여 iteratee를 실행한다', function() {
            var index,
                log = '',
                iteratee;

            beforeEach(function() {
                log = '';
                index = batch.indexSeatsByPosition(mock);

                iteratee = jasmine.createSpyObj('iteratee', ['seat', 'row']);
            });

            it('좌석을 좌측 방향으로 순회한다', function() {
                batch.iterateSeats(index, true, false, function() {
                    log += this.sid;
                });

                expect(log).toBe('741852963');
            });

            it('좌석을 우측 방향으로 순회한다', function() {
                batch.iterateSeats(index, false, false, function() {
                    log += this.sid;
                });

                expect(log).toBe('147258369');
            });

            it('행이 바뀔 때 인자 함수를 실행한다', function() {
                batch.iterateSeats(index, false, false, iteratee.seat, iteratee.row);

                expect(iteratee.row.calls.count()).toBe(3);
            });

        });

    });

    describe('setMappingData()', function() {
        var mock;

        beforeEach(function() {
            RSeat.MAP_CODE = ['층', '블록', '열', '번호'];
            RSeat.MAP_UNIT = ['GENERAL', 'GENERAL', 'ROW', 'NUMBER'];

            mock = getMockHashMap(getJSONFixture('rSeats_3x3.json').seats);
        });
        //
        afterEach(function() {
            RSeat.MAP_CODE = originalMapCode;
        });

        it('층 매핑정보 자동입력', function() {
            batch.setMappingData(mock, batch.MAPPING_METHOD.A, '층', '1');

            expect(mock.get(1).mapInfo[0]).toBe('1');
            expect(mock.get(7).mapInfo[0]).toBe('1');
        });

        it('블록 매핑정보 입력', function() {
            batch.setMappingData(mock, batch.MAPPING_METHOD.A, '블록', '208');

            expect(mock.get(3).mapInfo[1]).toBe('208');
        });

        it('사전에 없는 매핑 레이블의 경우 무시', function() {
            batch.setMappingData(mock, batch.MAPPING_METHOD.A, '구역', 'A');

            expect(mock.get(1).mapInfo[1]).not.toBe('A');
        });

        /**********
        * 열 타입
        **********/

        describe('일정하지 않은 간격이어도 열과 좌석으로 인식한다', function() {

            it('두 번째 행에 좌석이 하나 더 있는 경우', function() {
                mock.set('10', new RSeat(1675, 775));
                batch.setMappingData(mock, batch.MAPPING_METHOD.A, '번호', '1');

                expect(mock.get(10).mapInfo[3]).toBe('7');
            });

            it('여러 열 중 특정 좌석의 y좌표가 약간 어긋나면 그 좌석도 열로 인식', function() {
                // 8번째 좌석의 y좌표가 -2만큼 어긋남
                mock.get(8).setPosition(1665, 773);

                batch.setMappingData(mock, batch.MAPPING_METHOD.A, '열', '1');

                expect(mock.get(8).mapInfo[2]).toBe('2');
            });

        });

        describe('notUseIncrement옵션을 통해 열 타입을 증감하지 않고 배열할 수 있다', function() {
            it('열 번호가 증가하지 않아야 한다', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.A, '열', '1', true);

                expect(function() {
                    mock.each(function(seat) {
                        if (seat.mapInfo[2] !== '1') {
                            throw new Error('일괄배열이 정상적으로 동작하지 않았다');
                        }
                    });
                }).not.toThrow();
            });
        });

        /**********
         * 번호 타입
         **********/

        describe('번호 자동배열', function() {
            it('A', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.A, '번호', '1');

                expect(mock.get(1).mapInfo[3]).toBe('1');
                expect(mock.get(4).mapInfo[3]).toBe('2');
            });

            it('번호 자동입력 - B', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.B, '번호', '1');

                expect(mock.get(7).mapInfo[3]).toBe('1');
                expect(mock.get(4).mapInfo[3]).toBe('2');
                expect(mock.get(1).mapInfo[3]).toBe('3');

                expect(mock.get(8).mapInfo[3]).toBe('4');
                expect(mock.get(5).mapInfo[3]).toBe('5');
                expect(mock.get(2).mapInfo[3]).toBe('6');

                expect(mock.get(9).mapInfo[3]).toBe('7');
                expect(mock.get(6).mapInfo[3]).toBe('8');
                expect(mock.get(3).mapInfo[3]).toBe('9');
            });

            it('번호 자동입력 - C', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.C, '번호', '1');

                expect(mock.get(1).mapInfo[3]).toBe('3');
                expect(mock.get(4).mapInfo[3]).toBe('2');
                expect(mock.get(7).mapInfo[3]).toBe('1');

                expect(mock.get(2).mapInfo[3]).toBe('3');
                expect(mock.get(5).mapInfo[3]).toBe('2');
                expect(mock.get(8).mapInfo[3]).toBe('1');

                expect(mock.get(3).mapInfo[3]).toBe('3');
                expect(mock.get(6).mapInfo[3]).toBe('2');
                expect(mock.get(9).mapInfo[3]).toBe('1');
            });

            it('번호 자동입력 - D', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.D, '번호', '1');

                expect(mock.get(1).mapInfo[3]).toBe('1');
                expect(mock.get(4).mapInfo[3]).toBe('2');
                expect(mock.get(7).mapInfo[3]).toBe('3');

                expect(mock.get(2).mapInfo[3]).toBe('1');
                expect(mock.get(5).mapInfo[3]).toBe('2');
                expect(mock.get(8).mapInfo[3]).toBe('3');

                expect(mock.get(3).mapInfo[3]).toBe('1');
                expect(mock.get(6).mapInfo[3]).toBe('2');
                expect(mock.get(9).mapInfo[3]).toBe('3');
            });

            it('번호 자동입력 - E', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.E, '번호', '1');

                expect(mock.get(1).mapInfo[3]).toBe('1');
                expect(mock.get(4).mapInfo[3]).toBe('2');
                expect(mock.get(7).mapInfo[3]).toBe('3');

                expect(mock.get(2).mapInfo[3]).toBe('6');
                expect(mock.get(5).mapInfo[3]).toBe('5');
                expect(mock.get(8).mapInfo[3]).toBe('4');

                expect(mock.get(3).mapInfo[3]).toBe('7');
                expect(mock.get(6).mapInfo[3]).toBe('8');
                expect(mock.get(9).mapInfo[3]).toBe('9');
            });

            it('번호 자동입력 - F', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.F, '번호', '1');

                expect(mock.get(7).mapInfo[3]).toBe('1');
                expect(mock.get(4).mapInfo[3]).toBe('2');
                expect(mock.get(1).mapInfo[3]).toBe('3');

                expect(mock.get(8).mapInfo[3]).toBe('6');
                expect(mock.get(5).mapInfo[3]).toBe('5');
                expect(mock.get(2).mapInfo[3]).toBe('4');

                expect(mock.get(9).mapInfo[3]).toBe('7');
                expect(mock.get(6).mapInfo[3]).toBe('8');
                expect(mock.get(3).mapInfo[3]).toBe('9');
            });

            it('번호 자동입력 - G', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.G, '번호', '1');

                expect(mock.get(1).mapInfo[3]).toBe('7');
                expect(mock.get(2).mapInfo[3]).toBe('8');
                expect(mock.get(3).mapInfo[3]).toBe('9');

                expect(mock.get(4).mapInfo[3]).toBe('4');
                expect(mock.get(5).mapInfo[3]).toBe('5');
                expect(mock.get(6).mapInfo[3]).toBe('6');

                expect(mock.get(7).mapInfo[3]).toBe('1');
                expect(mock.get(8).mapInfo[3]).toBe('2');
                expect(mock.get(9).mapInfo[3]).toBe('3');
            });

            it('번호 자동입력 - H', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.H, '번호', '9');

                expect(mock.get(1).mapInfo[3]).toBe('9');
                expect(mock.get(2).mapInfo[3]).toBe('10');
                expect(mock.get(3).mapInfo[3]).toBe('11');

                expect(mock.get(4).mapInfo[3]).toBe('12');
                expect(mock.get(5).mapInfo[3]).toBe('13');
                expect(mock.get(6).mapInfo[3]).toBe('14');

                expect(mock.get(7).mapInfo[3]).toBe('15');
                expect(mock.get(8).mapInfo[3]).toBe('16');
                expect(mock.get(9).mapInfo[3]).toBe('17');


            });
        });

        describe('좌석의 간격이 동일하지 않아도 배열되야 함', function() {
            var log;

            beforeEach(function() {
                var seat = new RSeat(1675, 775);
                seat.sid = 10;
                mock.set(10, seat);
                mock.get(8).setPosition(1665, 773);
                mock.remove(9);
                mock.remove(1);

                log = '';
            });

            it('자동배열 - A', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.A, '번호', '1');

                expect(mock.get(2).mapInfo[3]).toBe('4');
                expect(mock.get(3).mapInfo[3]).toBe('7');
                expect(mock.get(4).mapInfo[3]).toBe('1');

                expect(mock.get(5).mapInfo[3]).toBe('5');
                expect(mock.get(6).mapInfo[3]).toBe('8');
                expect(mock.get(7).mapInfo[3]).toBe('2');

                expect(mock.get(8).mapInfo[3]).toBe('3');
                expect(mock.get(10).mapInfo[3]).toBe('6');
            });

            it('자동배열 - B', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.B, '번호', '1');

                expect(mock.get(7).mapInfo[3]).toBe('1');
                expect(mock.get(4).mapInfo[3]).toBe('2');

                expect(mock.get(8).mapInfo[3]).toBe('3');

                expect(mock.get(10).mapInfo[3]).toBe('4');
                expect(mock.get(5).mapInfo[3]).toBe('5');
                expect(mock.get(2).mapInfo[3]).toBe('6');

                expect(mock.get(6).mapInfo[3]).toBe('7');
                expect(mock.get(3).mapInfo[3]).toBe('8');
            });

            it('자동배열 - C', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.C, '번호', '2');

                expect(mock.get(4).mapInfo[3]).toBe('3');
                expect(mock.get(7).mapInfo[3]).toBe('2');

                expect(mock.get(8).mapInfo[3]).toBe('2');

                expect(mock.get(2).mapInfo[3]).toBe('4');
                expect(mock.get(5).mapInfo[3]).toBe('3');
                expect(mock.get(10).mapInfo[3]).toBe('2');

                expect(mock.get(3).mapInfo[3]).toBe('3');
                expect(mock.get(6).mapInfo[3]).toBe('2');
            });

            it('자동배열 - D', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.D, '번호', '3');

                expect(mock.get(4).mapInfo[3]).toBe('3');
                expect(mock.get(7).mapInfo[3]).toBe('4');

                expect(mock.get(8).mapInfo[3]).toBe('3');

                expect(mock.get(2).mapInfo[3]).toBe('3');
                expect(mock.get(5).mapInfo[3]).toBe('4');
                expect(mock.get(10).mapInfo[3]).toBe('5');

                expect(mock.get(3).mapInfo[3]).toBe('3');
                expect(mock.get(6).mapInfo[3]).toBe('4');
            });

            it('자동배열 - E', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.E, '번호', '1');

                expect(mock.get(4).mapInfo[3]).toBe('1');
                expect(mock.get(7).mapInfo[3]).toBe('2');

                expect(mock.get(8).mapInfo[3]).toBe('3');

                expect(mock.get(2).mapInfo[3]).toBe('4');
                expect(mock.get(5).mapInfo[3]).toBe('5');
                expect(mock.get(10).mapInfo[3]).toBe('6');

                expect(mock.get(3).mapInfo[3]).toBe('8');
                expect(mock.get(6).mapInfo[3]).toBe('7');
            });

            it('자동배열 - F', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.F, '번호', '2');

                expect(mock.get(4).mapInfo[3]).toBe('3');
                expect(mock.get(7).mapInfo[3]).toBe('2');

                expect(mock.get(8).mapInfo[3]).toBe('4');

                expect(mock.get(2).mapInfo[3]).toBe('7');
                expect(mock.get(5).mapInfo[3]).toBe('6');
                expect(mock.get(10).mapInfo[3]).toBe('5');

                expect(mock.get(3).mapInfo[3]).toBe('8');
                expect(mock.get(6).mapInfo[3]).toBe('9');
            });

            it('자동배열 - G', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.G, '번호', '1');

                expect(mock.get(10).mapInfo[3]).toBe('1');
                expect(mock.get(7).mapInfo[3]).toBe('2');
                expect(mock.get(8).mapInfo[3]).toBe('3');

                expect(mock.get(4).mapInfo[3]).toBe('4');

                expect(mock.get(2).mapInfo[3]).toBe('7');
                expect(mock.get(5).mapInfo[3]).toBe('5');

                expect(mock.get(3).mapInfo[3]).toBe('8');
                expect(mock.get(6).mapInfo[3]).toBe('6');
            });

            it('자동배열 - H', function() {
                batch.setMappingData(mock, batch.MAPPING_METHOD.H, '번호', '8');

                expect(mock.get(10).mapInfo[3]).toBe('15');
                expect(mock.get(7).mapInfo[3]).toBe('13');
                expect(mock.get(8).mapInfo[3]).toBe('14');

                expect(mock.get(4).mapInfo[3]).toBe('10');
                expect(mock.get(5).mapInfo[3]).toBe('11');
                expect(mock.get(6).mapInfo[3]).toBe('12');

                expect(mock.get(2).mapInfo[3]).toBe('8');
                expect(mock.get(3).mapInfo[3]).toBe('9');
            });
        });
    });

});
