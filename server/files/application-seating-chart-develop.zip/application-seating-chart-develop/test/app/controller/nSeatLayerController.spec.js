var NSeatController = require('../../../src/js/controller/nSeatController');

describe('NSeatController', function() {
    var mockSeats,
        nsc;

    describe('setData()', function() {
        beforeEach(function() {
            nsc = new NSeatController({ paper: {} });

            mockSeats = getJSONFixture('nonReservedSeatList.json');

            nsc.setData(mockSeats);
        });

        it('setData로 API 내 비지정석 데이터를 초기화한다', function() {
            var seatLayer = nsc.seatLayers.get('default'),
                seat = seatLayer.seats.get(298);

            expect(seat.label).toBe('비지정석B');
        });

    });

});
