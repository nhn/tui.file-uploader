var AreaController = require('../../../src/js/controller/areaController');

describe('AreaController', function () {
    var mock,
        ctrl;

    beforeEach(function () {
        mock = getJSONFixture('area.json');
        ctrl = new AreaController({ paper: {} });
    });

    describe('setData()', function () {
        beforeEach(function () {
            ctrl.setData(mock);
        });

        it('기본도면정보 -> areaData를 내부에 세팅한다', function () {
            var layer = ctrl.seatLayers.get('normal');

            expect(layer).toBeDefined();
            expect(layer.seats.length).toBe(1);
        });

    });

    describe('requestAreaContainPoint()', function() {
        beforeEach(function() {
            ctrl.setData(mock);
        });

        it('좌표를 전달하고 그 좌표를 포함하는 영역을 반환', function () {
            var areas;

            areas = ctrl.requestAreaContainPoint(4418, 4370);

            expect(areas.length).toBe(1);
            expect(areas[0].data).toBe('54');
        });

        it('없는 영역의 좌표 전달 시는 빈배열 반환', function () {
            var areas;

            areas = ctrl.requestAreaContainPoint(5670, 1200);

            expect(areas.length).toBe(0);
        });

    });

});
