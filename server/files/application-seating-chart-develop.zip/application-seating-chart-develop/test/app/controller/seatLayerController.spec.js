var SeatLayer = require('../../../src/js/layer/seatLayer'),
    SeatLayerController = require('../../../src/js/controller/seatLayerController');

describe('seatLayerController', function() {
    var raphaelElementMock,
        raphaelMock,
        slc,
        seat1,
        seat2,
        seat3,
        seat4;

    raphaelElementMock = {
        attr: function() {}
    };

    raphaelMock = {
        path: function() {
            return raphaelElementMock;
        }
    };

    function mockSeat(options) {
        options.getID = function() {
            return this.sid;
        };

        return options;
    }

    beforeEach(function() {
        slc = new SeatLayerController({
            paper: raphaelMock
        });

        seat1 = mockSeat({'sid': '1'});
        seat2 = mockSeat({'sid': '2'});
        seat3 = mockSeat({'sid': '3'});
        seat4 = mockSeat({'sid': '4'});
    });

    describe('addSeat()', function() {
        beforeEach(function() {
            slc.addSeatLayer('default');
        });
        it('Seat 추가하면 getSeatLayerIDFromSeat로직에 따라 SeatLayer에 추가되고 seats에도 추가된다.', function() {
            slc.addSeat(seat1);

            expect(slc.seats.get('1')).toBeDefined();
            expect(slc.seatLayers.get('default').seats.length).toEqual(1);
        });
    });

    describe('removeSeat()', function() {
        beforeEach(function() {
            slc.addSeatLayer('default');
            slc.addSeat(seat1);
            slc.addSeat(seat2);
        });
        it('seat를 넘기면 seatLayerController와 연결된 SeatLayer에서 제거된다.', function() {
            slc.removeSeat(seat1);

            expect(slc.seats.get('1')).not.toBeDefined();
            expect(slc.seatLayers.get('default').seats.length).toEqual(1);
        });

        it('seat의 배열을 넘기면 seatLayerController와 연결된 SeatLayer에서 제거된다.', function() {
            seat1.slid = 'default';
            seat2.slid = 'default';

            slc.removeSeat([seat1, seat2]);
            expect(slc.seats.get('1')).not.toBeDefined();
            expect(slc.seats.get('2')).not.toBeDefined();
            expect(slc.seatLayers.get('default').seats.length).toEqual(0);
        });
    });

    describe('addSeatLayer()', function() {
        it('seatLayer를 넘겨 추가할수있다.', function() {
            slc.addSeatLayer('myId', new SeatLayer({
                paper: raphaelMock
            }));

            expect(slc.seatLayers.get('myId')).toBeDefined();
        });

        it('키로전달되는 값을 SeatLayer의 slid로 셋팅한다.', function() {
            slc.addSeatLayer('myId', new SeatLayer({
                paper: raphaelMock
            }));
            expect(slc.seatLayers.get('myId').slid).toEqual('myId');
        });

        it('seatLayer를 넘기지않으면 내부에서 새로 생성한다..', function() {
            slc.addSeatLayer('myId');
            expect(slc.seatLayers.get('myId').paper).toBe(raphaelMock);
        });

        it('옵션을 넘겨서 seatLayer를 생성할수있따.', function() {
            slc.addSeatLayer('myId', {
                paper: raphaelMock
            });
            expect(slc.seatLayers.get('myId').paper).toBeDefined();
        });

        it('SeatLayer를 추가하고 추기한 SeatLayer를 리턴한다.', function() {
            var seatLayer = slc.addSeatLayer('myId', {
                paper: raphaelMock
            });
            expect(seatLayer.slid).toEqual('myId');
        });
    });

    describe('addSeatToSeatLayer()', function() {
        it('seatLayerID로 Seat을 추가할수있다.', function() {
            slc.addSeatLayer('myId');
            slc.addSeatToSeatLayer('myId', seat1);

            expect(slc.seatLayers.get('myId').seats.length).toEqual(1);
        });

        it('seatLayeID에 해당하는 SeatLayer가 없다면 생성하고 Seat을 추가한다.', function() {
            slc.addSeatToSeatLayer('myId', seat1);

            expect(slc.seatLayers.get('myId')).toBeDefined();
            expect(slc.seatLayers.get('myId').seats.length).toEqual(1);
        });
    });

});
