var RSeat = require('../../../src/js/model/rSeat'),
    NSeat = require('../../../src/js/model/nSeat'),
    SelectSeatController = require('../../../src/js/controller/selectSeatController');

describe('SelectSeatController', function() {
    var mockRSeats,
        mockNSeats,
        ssc;

    beforeEach(function() {
        RSeat.MAP_CODE = ['층', '블럭', '열', '번호'];

        mockRSeats = getJSONFixture('reservedSeatList.json');
        mockNSeats = getJSONFixture('nonReservedSeatList.json');
        ssc = new SelectSeatController({
            paper: {
                set: function() {
                    return { clear: function() {} };
                }
            }
        });

    });

    it('reserved, nonreserved 두 SeatLayer를 항상 가지고 있다', function() {
        expect(ssc.seatLayers.get('reserved')).toBeDefined();
        expect(ssc.seatLayers.get('nonreserved')).toBeDefined();
        expect(ssc.seatLayers.get('my')).toBeUndefined();
    });

    describe('getSeatLayerID()', function() {
        var rseat,
            nseat;

        beforeEach(function() {
            rseat = new RSeat(15, 15);
            nseat = new NSeat('비지정석B');
        });

        it('비지정석 또는 지정석임만을 구분해야 한다', function() {
            expect(ssc.getSeatLayerID(rseat)).toBe('reserved');
            expect(ssc.getSeatLayerID(nseat)).toBe('nonreserved');
        });
    });

    describe('setData()', function() {
        var seatData;

        beforeEach(function() {
            seatData = mockRSeats.slice(0, 2);
            seatData.push(mockNSeats[1]);

            ssc.setData(seatData);
        });

        it('지정석/비지정석 배열을 받아 레이어를 초기화한다', function() {
            expect(ssc.getSeatLayer('reserved').seats.length).toBe(2);
            expect(ssc.getSeatLayer('nonreserved').seats.length).toBe(1);
        });
    });

    describe('addSeat()', function() {
        var seats;

        beforeEach(function() {
            seats = [];

            seats.push(new RSeat(15, 15));
            seats.push(new RSeat(55, 15));
            seats.push(new RSeat(55, 55));
            seats[0].sid = 1;
            seats[1].sid = 2;
            seats[2].sid = 3;

            ssc.addSeat(seats);
        });

        it('선택된 좌석들의 회전 중심축 좌표를 정확히 계산한다', function() {
            expect(ssc.groupBound.getCenter() + '').toBe('Point(35, 35)');
        });
    });

});
