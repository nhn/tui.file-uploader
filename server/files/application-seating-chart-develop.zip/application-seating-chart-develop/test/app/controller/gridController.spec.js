var GridController = require('../../../src/js/controller/gridController');

var Point = ne.component.SimpleMap.Point;

describe('GridController', function() {
    var mockOption,
        gc;

    beforeEach(function() {
        mockOption = {
            chart: {
                options: {
                    mapSize: 4096
                },
                zoom: 1,
                getScaleRatio: function() {
                    return 1;
                },
                getViewportOffsetByPanelName: function() {
                    return {
                        min: new Point(200, 200),
                        max: new Point(399, 399)
                    };
                }
            },
            paper: {
                set: function() {}
            }
        };

        gc = new GridController(mockOption);
    });

    describe('encodeGridID()', function() {
        it('좌표를 gridID로 변환', function() {
            expect(gc.encodeGridID(3, 5)).toBe('3:5');
        });
    });

    describe('decodeGridID()', function() {
        it('gridID를 좌표로 변환', function() {
            expect(gc.decodeGridID('3:5')).toEqual([3, 5]);
        });
    });

    describe('getScaledGridSize()', function() {
        var original,
            mockChart;

        beforeEach(function() {
            original = gc.gridSize;

            mockChart = {
                gridSize: 200,
                scale: 0.5,
                chart: {
                    getScaleRatio: function() {
                        return mockChart.scale;
                    }
                }
            };

            gc.gridSize = 200;
        });

        afterEach(function() {
            gc.gridSize = original;
        });

        it('줌 레벨 별 달라지는 그리드 크기 반환', function() {
            expect(gc.getScaledGridSize.call(mockChart)).toBe(100);

            mockChart.scale = 2;
            expect(gc.getScaledGridSize.call(mockChart)).toBe(400);
        });

    });

    describe('getGridIndexByPoint()', function() {
        it('좌표가 어떤 그리드에 해당하는지 계산', function() {
            expect(gc.getGridIndexByPoint(201, 201)).toEqual([1, 1]);
        });

        it('201, 199의 경우 1:0', function() {
            expect(gc.getGridIndexByPoint(201, 199)).toEqual([1, 0]);
        });
    });

    describe('addGrid()', function() {
        describe('index key를 받아 레이어를 생성', function() {
            beforeEach(function() {
                gc.addGrid(1, 1, mockOption);
            });

            it('레이어를 생성한다', function() {
                expect(gc.seatLayers.get('1:1')).toBeDefined();
            });
        });
    });

    describe('getSeatLayerID()', function() {
        var mockSeat;

        beforeEach(function() {
            mockSeat = {
                position: {
                    x: 201,
                    y: 201
                }
            };
        });

        it('지정석 모델을 받아 지정석이 포함되어야 할 grid 반환', function() {
            expect(gc.getSeatLayerID(mockSeat)).toBe('1:1');
        });
    });

    describe('getGridByPoints()', function() {
        beforeEach(function() {
            gc.addGrid(1, 1, mockOption);
        });

        it('좌표배열을 넘겨 그 좌표에 해당하는 gridLayer인스턴스를 반환', function() {
            var inst = gc.getGridByPoints([201, 201]);
            expect(inst[0].getID()).toBe('1:1');
        });

        it('좌표배열은 한개 이상 입력가능', function() {
            gc.addGrid(2, 2, mockOption);
            var grids = gc.getGridByPoints([[201, 201], [401, 401], [800, 950]]);
            expect(grids.length).toBe(2);
        });

        it('빈배열은 빈배열', function() {
            expect(gc.getGridByPoints([])).toEqual([]);
        });
    });

    describe('getGridsContainRect()', function() {
        beforeEach(function() {
            gc.addGrid(1, 1, mockOption);
            gc.addGrid(2, 2, mockOption);
        });

        it('사각형 영역 좌표 내에 겹치거나 포함되는 gird의 목록을 반환', function() {
            var grids = gc.getGridsContainRect(200, 200, 399, 399);

            expect(grids.length).toBe(1);
            expect(grids[0].getID()).toBe('1:1');
        });
    });

    describe('getGridsByIndexRange()', function() {
        beforeEach(function() {
            gc.addGrid(1, 1, mockOption);
            gc.addGrid(2, 2, mockOption);
        });

        it('2, 2, 4, 4 전달 시 1개 나와야함', function() {
            var grids = gc.getGridsByIndexRange(2, 2, 4, 4);
            expect(grids.length).toBe(1);
        });

        it('1, 1, 3, 3 전달 시 2개 나와야함', function() {
            var grids = gc.getGridsByIndexRange(1, 1, 3, 3);
            expect(grids.length).toBe(2);
        });
    });

    describe('getViewportGridID()', function () {
        beforeEach(function () {
            var mockRect = new ne.component.SimpleMap.Rect([0, 0], [2, 2]);
            spyOn(gc, 'getViewportGridRect').and.returnValue(mockRect);
        });

        it('화면에 노출되는 grid의 좌표 인덱스를 반환한다', function () {
            var result = gc.getViewportGridID();
            expect(result).toEqual(['0:0', '0:1', '0:2', '1:0', '1:1', '1:2', '2:0', '2:1', '2:2']);
        });

        describe('필터를 인자로 넘기면', function () {
            beforeEach(function () {
                GridController.gridsExistSeat = {
                    '0:2': true,
                    '1:1': true,
                    '2:1': true
                };
            });
            afterEach(function () {
                delete GridController.gridsExistSeat;
            });

            it('원하는 결과만 추릴 수 있다', function () {
                var result = gc.getViewportGridID(function(coords) {
                    return GridController.gridsExistSeat[coords];
                });
                expect(result).toEqual(['0:2', '1:1', '2:1']);
            });
        });
    });

    describe('getViewportGridRect()', function() {
        beforeEach(function() {
            gc.addGrid(1, 1, mockOption);
            gc.addGrid(2, 2, mockOption);
        });

        it('화면에 보이는 그리드들의 min, max Index를 반환', function() {
            var indexes = gc.getViewportGridRect();

            expect(indexes.min + '').toEqual('Point(1, 1)');
            expect(indexes.max + '').toEqual('Point(1, 1)');
        });
    });

    describe('updateGridsInViewport()', function() {
        var gridSpy,
            reactSpy;

        beforeEach(function() {
            var grid1,
                grid2;

            gridSpy = jasmine.createSpyObj('grid', ['update', 'render']);
            reactSpy = jasmine.createSpy('react');

            mockOption.chart.getViewportOffsetByPanelName = function() {
                return {
                    min: new Point(100, 100),
                    max: new Point(450, 450)
                };
            };

            gc.addGrid(1, 1, mockOption);
            gc.addGrid(2, 2, mockOption);

            grid1 = gc.seatLayers.get('1:1');
            grid2 = gc.seatLayers.get('2:2');

            grid1.zoomReactor.react = grid2.zoomReactor.react = reactSpy;

            grid1.update = gridSpy.update;
            grid1.render = gridSpy.render;

            grid2.update = gridSpy.update;
            grid2.render = gridSpy.render;
        });

        it('1:1, 2:2 그리드를 업데이트해야 한다', function() {
            gc.updateGridsInViewport();

            expect(gridSpy.update.calls.count()).toBe(2);
            expect(gridSpy.update).toHaveBeenCalledWith(true);
            expect(reactSpy.calls.count()).toBe(2);
        });
    });

    describe('refreshGridsInViewport()', function() {
        var gridSpy;

        beforeEach(function() {
            var grid1,
                grid2;

            gridSpy = jasmine.createSpyObj('grid', ['update', 'render']);

            mockOption.chart.getViewportOffsetByPanelName = function() {
                return {
                    min: new Point(100, 100),
                    max: new Point(450, 450)
                };
            };

            gc.addGrid(1, 1, mockOption);
            gc.addGrid(2, 2, mockOption);

            grid1 = gc.seatLayers.get('1:1');
            grid2 = gc.seatLayers.get('2:2');

            grid1.dirtied = true;
            grid2.dirtied = true;

            grid1.update = gridSpy.update;
            grid2.update = gridSpy.update;
        });

        it('1:1, 2:2 둘 다 업데이트됨', function() {
            gc.refreshGridsInViewport();

            expect(gridSpy.update.calls.count()).toBe(2);
        });
    });

    describe('eachGridInViewport', function() {
        var iteratee;

        beforeEach(function() {
            iteratee = jasmine.createSpy('iteratee');
            gc.addGrid(1, 1, mockOption);
            gc.addGrid(2, 2, mockOption);

            mockOption.chart.getViewportOffsetByPanelName = function() {
                return {
                    min: new Point(100, 100),
                    max: new Point(450, 450)
                };
            };

            gc.eachGridInViewport(iteratee);
        });

        it('2개의 그리드 순회', function() {
            expect(iteratee.calls.count()).toBe(2);
        });
    });

    describe('removeOtherGrids()', function() {
        beforeEach(function() {
            /*
            뷰포트 크기를 임의로 늘리고 업데이트 후
            크기를 줄인다음 테스트
             */
            gc.addGrid(1, 1, mockOption);
            gc.addGrid(2, 2, mockOption);
            gc.addGrid(3, 3, mockOption);

            mockOption.chart.getViewportOffsetByPanelName = function() {
                return {
                    min: new Point(100, 100),
                    max: new Point(600, 600)
                };
            };

            gc.eachSeatLayer(function(sl) {
                sl.render = sl.update = function() {};
            });

            gc.updateGridsInViewport();

            mockOption.chart.getViewportOffsetByPanelName = function() {
                return {
                    min: new Point(100, 100),
                    max: new Point(400, 400)
                };
            };

            gc.removeOtherGrids();
        });

        it('8:8그리드 제거되어야 함', function() {
            expect(gc.rendered['3:3']).toBe(null);
        });
    });

    describe('ensureZoom()', function() {
        beforeEach(function() {
            gc.addGrid(1, 1, mockOption);
            gc.addGrid(2, 2, mockOption);
            gc.addGrid(3, 3, mockOption);

            mockOption.chart.getViewportOffsetByPanelName = function() {
                return {
                    min: new Point(100, 100),
                    max: new Point(600, 600)
                };
            };

            gc.eachSeatLayer(function(sl) {
                sl.render = sl.update = function() {};
            });

            gc.updateGridsInViewport();

            mockOption.chart.getViewportOffsetByPanelName = function() {
                return {
                    min: new Point(100, 100),
                    max: new Point(400, 400)
                };
            };

            gc.ensureZoom(3);
        });

        it('8:8그리드 제거되어야 함', function() {
            expect(gc.rendered['3:3']).toBe(null);
        });

    });

    describe('eachGridByRange()', function() {
        var iteratee;

        beforeEach(function() {
            iteratee = jasmine.createSpy('iteratee');
            gc.addGrid(1, 1, mockOption);
            gc.addGrid(2, 2, mockOption);

            gc.eachGridByRange(1, 1, 2, 2, iteratee);
        });

        it('반복자는 2번 실행되어야 한다', function() {
            expect(iteratee.calls.count()).toBe(2);
        });
    });

    describe('eachGridsByRectRange()', function() {
        var iteratee;

        beforeEach(function() {
            iteratee = jasmine.createSpy('iteratee');
            gc.addGrid(1, 1, mockOption);
            gc.addGrid(2, 2, mockOption);

            gc.eachGridsByRectRange(100, 100, 400, 400, iteratee);
        });

        it('반복자는 2번 실행되어야 한다', function() {
            expect(iteratee.calls.count()).toBe(2);
        });
    });

    describe('getSeatsInsideRect()', function() {
        function MockSeat(sid) {
            this.sid = sid;
        }

        MockSeat.prototype.getID = function() {
            return this.sid;
        };

        beforeEach(function() {
            var seat = new MockSeat(1001),
                seat2 = new MockSeat(1002);

            gc.seats.set(1001, seat);
            gc.seats.set(1002, seat2);

            gc.addGrid(1, 1, mockOption);
            gc.addGrid(2, 2, mockOption);

            gc.seatLayers.get('1:1').getSeatsInsideRect = function() {
                return [seat];
            };
            gc.seatLayers.get('2:2').getSeatsInsideRect = function() {
                return [seat2];
            };
        });

        it('1:1, 2:2 두 그리드 내 좌석 배열을 반환한다', function() {
            var reqSeats = gc.getSeatsInsideRect(100, 100, 400, 400);

            expect(reqSeats.length).toBe(2);
            expect(reqSeats[0].sid).toBe(1001);
        });
    });

    describe('getSeatsContainPoint()', function() {
        function MockSeat(sid) {
            this.sid = sid;
        }

        MockSeat.prototype.getID = function() {
            return this.sid;
        };

        beforeEach(function() {
            var seat = new MockSeat(1001),
                seat2 = new MockSeat(1002);

            gc.seats.set(1001, seat);
            gc.seats.set(1002, seat2);

            gc.addGrid(1, 1, mockOption);
            gc.addGrid(2, 2, mockOption);

            gc.seatLayers.get('1:1').getSeatsContainPoint = function() {
                return [seat];
            };
            gc.seatLayers.get('2:2').getSeatsContainPoint = function() {
                return [seat2];
            };
        });

        it('좌석들을 반환한다', function() {
            var reqSeats = gc.getSeatsContainPoint(200, 200);

            expect(reqSeats.length).toBe(1);
            expect(reqSeats[0].sid).toBe(1001);
            expect(gc.seats.length).toBe(2);
        });
    });

});
