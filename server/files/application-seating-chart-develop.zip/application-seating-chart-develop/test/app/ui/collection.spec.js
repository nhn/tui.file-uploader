var UIModel = require('../../../src/js/ui/model'),
    UICollection = require('../../../src/js/ui/collection'),
    common = ne.util;

describe('UICollection', function() {
    var TestModel = UIModel.extend({
        init: function(data) {
            UIModel.call(this, data);
        },
        idAttribute: 'myId'
    });

    describe('extend 초기화 확인()', function() {
        it('아무 옵션이 없다면 인자 그대로 설정하는지 확인한다.', function() {
            var TestCollection = UICollection.extend({
                init: function(models) {
                    UICollection.call(this, models);
                }
            });

            var collection = new TestCollection([{value: 1}, {value: 2}]);
            expect(collection.models).toEqual([{value: 1}, {value: 2}]);
            expect(collection.length).toBe(2);
        });
        it('Model 객체를 설정할 경우 결과값을 확인한다.', function() {
            var MyTestModel = UIModel.extend({
                init: function(data) {
                    UIModel.call(this, data);
                },
                defaults: {
                    defaultValue: true
                }
            });
            var TestCollection = UICollection.extend({
                init: function(models) {
                    UICollection.call(this, models);
                },
                model: MyTestModel
            });
            var collection = new TestCollection([{value: 1}, {value: 2}, {value: 3}]);
            expect(collection.toJSON()).toEqual([{defaultValue: true, value: 1}, {defaultValue: true, value: 2}, {defaultValue: true, value: 3}]);
            expect(collection.length).toBe(3);
        });

        it('parse 로직을 잘 수행하는지 확인한다.', function() {
            var MyTestModel = UIModel.extend({
                init: function(data) {
                    UIModel.call(this, data);
                }
            });
            var TestCollection = UICollection.extend({
                init: function(models) {
                    UICollection.call(this, models, {
                        parse: true
                    });
                },
                model: MyTestModel,
                parse: function(models) {
                    common.forEachArray(models, function(model, index) {
                        models[index].auto = index;
                    });
                    return models;
                }
            });

            var collection = new TestCollection([{value: 1}, {value: 2}, {value: 3}]);
            expect(collection.toJSON()).toEqual([{value: 1, auto: 0}, {value: 2, auto: 1}, {value: 3, auto: 2}]);
            expect(collection.length).toBe(3);
        });
    });
    describe('생성자 테스트', function() {
        it('아무 옵션이 없다면 인자 그대로 설정하는지 확인한다.', function() {
            function TestCollection(models) {
                UICollection.call(this, models);
            }
            common.inherit(TestCollection, UICollection);

            var collection = new TestCollection([{value: 1}, {value: 2}]);
            expect(collection.models).toEqual([{value: 1}, {value: 2}]);
            expect(collection.length).toBe(2);
        });
        it('Model 객체를 설정할 경우 결과값을 확인한다.', function() {
            function MyTestModel(data) {
                UIModel.call(this, data, {
                    defaults: {
                        defaultValue: true
                    }
                });
            }
            common.inherit(MyTestModel, UIModel);
            function TestCollection(models) {
                UICollection.call(this, models, {
                    model: MyTestModel
                });
            }
            common.inherit(TestCollection, UICollection);
            var collection = new TestCollection([{value: 1}, {value: 2}, {value: 3}]);
            expect(collection.toJSON()).toEqual([{defaultValue: true, value: 1}, {defaultValue: true, value: 2}, {defaultValue: true, value: 3}]);
            expect(collection.length).toBe(3);
        });

        it('parse 로직을 잘 수행하는지 확인한다.', function() {
            function TestCollection(models) {
                UICollection.call(this, models, {
                    model: TestModel,
                    parse: true
                });
            }
            common.inherit(TestCollection, UICollection);

            TestCollection.prototype.parse = function(models) {
                common.forEachArray(models, function(model, index) {
                    models[index].auto = index;
                });
                return models;
            };

            var collection = new TestCollection([{value: 1}, {value: 2}, {value: 3}]);
            expect(collection.toJSON()).toEqual([{value: 1, auto: 0}, {value: 2, auto: 1}, {value: 3, auto: 2}]);
            expect(collection.length).toBe(3);
        });
    });
    describe('get, length', function() {
        function TestCollection(models) {
            UICollection.call(this, models, {
                model: TestModel
            });
        }
        common.inherit(TestCollection, UICollection);
        var collection = new TestCollection([
            {
                myId: 0,
                value: 'a'
            },
            {
                myId: 1,
                value: 'b'
            },
            {
                myId: 2,
                value: 'c'
            }
        ]);
        it('id 로 해당 모델을 잘 조회하는지 확인한다.', function() {
            expect(collection.get(0).get('value')).toBe('a');
            expect(collection.get(1).get('value')).toBe('b');
            expect(collection.get(2).get('value')).toBe('c');
        });
    });
    describe('set', function() {
        function TestCollection(models) {
            UICollection.call(this, models, {
                model: TestModel
            });
        }
        common.inherit(TestCollection, UICollection);
        var collection = new TestCollection();
        it('데이터를 잘 설정하는지 확인한다.', function() {
            var data1 = [
                    {myId: 0, value: 'a'},
                    {myId: 1, value: 'b'},
                    {myId: 2, value: 'c'},
                    {myId: 3, value: 'd'},
                    {myId: 4, value: 'e'}
                ],
                data2 = [
                    {myId: 10, value: 'A'},
                    {myId: 11, value: 'B'}
                ];

            collection.set(data1, {
                parse: true
            });
            expect(collection.length).toBe(5);
            expect(collection.get(0).get('value')).toBe('a');
            expect(collection.get(2).get('value')).toBe('c');
            expect(collection.get(4).get('value')).toBe('e');

            collection.set(data2, {
                parse: true
            });
            expect(collection.length).toBe(2);
            expect(collection.get(0)).toBeUndefined();
            expect(collection.get(2)).toBeUndefined();
            expect(collection.get(10).get('value')).toBe('A');

            expect(collection.at(0).get('value')).toBe('A');
            expect(collection.at(1).get('value')).toBe('B');
        });
    });
    describe('clear, add, remove', function() {
        var collection;
        var TestCollection = UICollection.extend({
            init: function(models) {
                UICollection.call(this, models);
            },
            model: TestModel
        });

        beforeEach(function() {
            collection = new TestCollection();
            var data1 = [
                {myId: 0, value: 'a'},
                {myId: 1, value: 'b'},
                {myId: 2, value: 'c'},
                {myId: 3, value: 'd'},
                {myId: 4, value: 'e'}
            ];

            collection.set(data1, {
                parse: true
            });
        });
        describe('clear', function() {
            it('콜렉션을 잘 제거 하는지 확인한다.', function() {
                collection.clear();
                expect(collection.length).toBe(0);
                expect(collection.at(0)).toBeUndefined();
            });
        });
        describe('add', function() {
            var adder;
            beforeEach(function() {
                adder = [
                    {myId: 10, value: 'f'},
                    {myId: 11, value: 'g'},
                    {myId: 12, value: 'h'}
                ];
            });

            it('콜렉션을 맨 끝에 잘 추가하는지 확인한다.', function() {
                collection.add(adder);
                expect(collection.length).toBe(8);
                expect(collection.at(5).toJSON()).toEqual({myId: 10, value: 'f'});
                expect(collection.at(6).toJSON()).toEqual({myId: 11, value: 'g'});
                expect(collection.at(7).toJSON()).toEqual({myId: 12, value: 'h'});
            });
            it('콜렉션을 원하는 위치에 잘 추가하는지 확인한다.', function() {
                collection.add(adder, {
                    at: 2
                });
                expect(collection.length).toBe(8);
                expect(collection.at(1).toJSON()).toEqual({myId: 1, value: 'b'});

                expect(collection.at(2).toJSON()).toEqual({myId: 10, value: 'f'});
                expect(collection.at(3).toJSON()).toEqual({myId: 11, value: 'g'});
                expect(collection.at(4).toJSON()).toEqual({myId: 12, value: 'h'});

                expect(collection.at(5).toJSON()).toEqual({myId: 2, value: 'c'});
            });
        });
        describe('remove', function() {
            it('원하는 모델을 잘 지우는지 확인한다.', function() {
                var targetModel = collection.get(1);
                expect(collection.length).toBe(5);
                collection.remove(targetModel);
                expect(collection.length).toBe(4);
                expect(collection.get(1)).toBeUndefined();
            });
            it('다수의 모델을 잘 지우는지 확인한다.', function() {
                var targetModelList = [
                    collection.get(0),
                    collection.get(2),
                    collection.get(4)
                ];
                expect(collection.length).toBe(5);
                collection.remove(targetModelList);
                expect(collection.length).toBe(2);
                expect(collection.get(0)).not.toBeDefined();
                expect(collection.get(1)).toBeDefined();
                expect(collection.get(2)).not.toBeDefined();
                expect(collection.get(3)).toBeDefined();
                expect(collection.get(4)).not.toBeDefined();

                expect(collection.at(0)).toBeDefined();
                expect(collection.at(1)).toBeDefined();
                expect(collection.at(2)).not.toBeDefined();
                expect(collection.at(3)).not.toBeDefined();
                expect(collection.at(4)).not.toBeDefined();
            });
        });

    });
    describe('이벤트 핸들러()', function() {
        var collection,
            callback,
            data1,
            data2;

        function TestCollection(models) {
            UICollection.call(this, models, {
                model: TestModel
            });
        }
        common.inherit(TestCollection, UICollection);

        beforeEach(function() {
            collection = new TestCollection();
            data1 = [
                {myId: 0, value: 'a'},
                {myId: 1, value: 'b'},
                {myId: 2, value: 'c'},
                {myId: 3, value: 'd'},
                {myId: 4, value: 'e'}
            ];
            data2 = [
                {myId: 10, value: 'f'},
                {myId: 11, value: 'g'},
                {myId: 12, value: 'h'}
            ];

            collection.set(data1, {
                parse: true
            });
            callback = jasmine.createSpy('callback');
        });
        afterEach(function() {
            collection.destroy();
        });
        it('model 에서 발생하는 change 이벤트 핸들러 테스트', function() {
            var model = collection.get(0);

            collection.on('change', callback);
            model.set('value', 'A');
            expect(callback).toHaveBeenCalledWith(model, model.attributes, 'value', 'A', {});
        });
        it('set 이벤트 핸들러 테스트', function() {
            collection.on('set', callback);
            collection.set(data2, {parse: true});
            expect(callback).toHaveBeenCalledWith(data2, collection.models, {parse: true});
        });
        it('clear 이벤트 핸들러 테스트', function() {
            collection.on('clear', callback);
            collection.clear();
            expect(callback).toHaveBeenCalledWith({});
        });
        it('add 이벤트 핸들러 테스트', function() {
            collection.on('add', callback);
            collection.add(data2);
            expect(callback.calls.count()).toBe(1);
        });
        it('remove 이벤트 핸들러 테스트', function() {
            collection.on('remove', callback);
            var targetModelList = [
                collection.get(0),
                collection.get(2),
                collection.get(4)
            ];
            collection.remove(targetModelList);
            expect(callback.calls.count()).toBe(1);
        });
        it('destroy 이벤트 핸들러 테스트', function() {
            collection.on('destroy', callback);
            collection.destroy();
            expect(callback).toHaveBeenCalled();
        });
        describe('all 이벤트 핸들러 테스트', function() {
            beforeEach(function() {
                collection.on('all', callback);
            });

            it('model 에서 발생하는 change 이벤트', function() {
                collection.get(0).set('value', 'A');
                expect(callback).toHaveBeenCalled();
            });
            it('set', function() {
                collection.set(data2, {parse: true});
                expect(callback).toHaveBeenCalled();
            });
            it('clear', function() {
                collection.clear();
                expect(callback).toHaveBeenCalled();
            });
            it('add', function() {
                collection.add(data2);
                expect(callback).toHaveBeenCalled();
            });
            it('remove', function() {
                collection.remove(collection.at(0));
                expect(callback).toHaveBeenCalled();
            });
            it('destroy', function() {
                collection.destroy();
                expect(callback).toHaveBeenCalled();
            });
        });
        it('silent 테스트', function() {
            var option = {
                silent: true
            };
            collection.on('all', callback);
            collection.get(0).set('value', 'A', option);

            expect(callback).not.toHaveBeenCalled();
            collection.set(data2, {silent:true});
            expect(callback).not.toHaveBeenCalled();
            collection.clear(option);
            expect(callback).not.toHaveBeenCalled();
            collection.add(data2, option);
            expect(callback).not.toHaveBeenCalled();
            collection.remove(collection.at(0), option);
            expect(callback).not.toHaveBeenCalled();
            collection.destroy(option);
            expect(callback).not.toHaveBeenCalled();
        });
    });
});

