var UIModel = require('../../../src/js/ui/model');

var common = ne.util;

describe('UIModel', function() {
    describe('extend 초기화 확인()', function() {
        it('extend 로 초기화 가능한지 확인한다.', function() {
            var ExtendModel = UIModel.extend({
                init: function(data) {
                    UIModel.call(this, data);
                },
                defaults: {
                    param1: 'a',
                    param2: 'b',
                    obj1: {
                        deep1: 1,
                        deep2: 2
                    }
                }
            });

            var model = new ExtendModel();

            expect(model.attributes).toEqual({
                param1: 'a',
                param2: 'b',
                obj1: {
                    deep1: 1,
                    deep2: 2
                }
            });
        });
        it('model 의 idAttribute 를 설정하면 id 가 해당 값으로 설정되는지 확인한다.', function() {
            var ExtendModel = UIModel.extend({
                init: function(data) {
                    UIModel.call(this, data);
                },
                idAttribute: 'myId'
            });

            var model1 = new ExtendModel({myId: 'a'}),
                model2 = new ExtendModel({myId: 'b'});

            expect(model1.id).toEqual('a');
            expect(model2.id).toEqual('b');
        });
        it('parse 메서드를 override 하면 제대로 파싱이 되는지 확인한다.', function() {
            var dataObj = {
                param1: 'a',
                param2: 'b'
            };
            var ExtendModel = UIModel.extend({
                init: function(data) {
                    UIModel.call(this, data, {
                        parse: true
                    });
                },
                defaults: dataObj,
                parse : function(data) {
                    var wrapper = {};
                    common.forEach(data, function(value, key) {
                        data[key] = 'override_' + value;
                    });

                    wrapper['wrap'] = data;
                    return wrapper;
                }
            });

            var model = new ExtendModel();

            expect(model.attributes).toEqual({
                wrap: {
                    param1: 'override_a',
                    param2: 'override_b'
                }
            });
        });
    });
    describe('초기화 확인', function() {
        it('생성자와 함께 값이 설정되는지 확인한다.', function() {
            function TestModel(data) {
                UIModel.call(this, data);
            }
            common.inherit(TestModel, UIModel);

            var dataObj = {
                param1: 'a',
                param2: 'b',
                obj1: {
                    deep1: 1,
                    deep2: 2
                }
            };

            var model = new TestModel(dataObj);
            expect(model.attributes).toEqual(dataObj);
        });
        it('model 의 idAttribute 를 설정하면 id 가 해당 값으로 설정되는지 확인한다.', function() {

            function TestModel(data) {
                UIModel.call(this, data, {
                    idAttribute: 'myId'
                });
            }
            common.inherit(TestModel, UIModel);

            var model1 = new TestModel({myId: 'a'}),
                model2 = new TestModel({myId: 'b'});


            expect(model1.id).toEqual('a');
            expect(model2.id).toEqual('b');
        });
        it('option 의 default 값이 설정되는지 확인한다.', function() {
            var dataObj = {
                param1: 'a',
                param2: 'b',
                obj1: {
                    deep1: 1,
                    deep2: 2
                }
            };
            function TestModel(data) {
                UIModel.call(this, data, {
                    defaults: dataObj
                });
            }
            common.inherit(TestModel, UIModel);

            var model = new TestModel();
            expect(model.attributes).toEqual(dataObj);
        });
        it('option 의 default 값이 생성자의 인자와 extend 되는지 확인한다.', function() {
            var dataObj = {
                    param1: 'a',
                    param2: 'b',
                    obj1: {
                        deep1: 1,
                        deep2: 2
                    }
                },
                expectResult = {
                    param1: 'a',
                    param2: '2',
                    param3: 'c',
                    obj1: {
                        changed: 'changed'
                    }
                };
            function TestModel(data) {
                UIModel.call(this, data, {
                    defaults: dataObj
                });
            }
            common.inherit(TestModel, UIModel);

            var model = new TestModel({
                param2: '2',
                param3: 'c',
                obj1: {
                    changed: 'changed'
                }
            });
            expect(model.attributes).toEqual(expectResult);
        });
        it('parse 메서드를 override 하면 제대로 파싱이 되는지 확인한다.', function() {
            var dataObj = {
                param1: 'a',
                param2: 'b'
            };
            function TestModel(data) {
                UIModel.call(this, data, {
                    defaults: dataObj,
                    parse: true
                });
            }
            common.inherit(TestModel, UIModel);

            TestModel.prototype.parse = function(data) {
                var wrapper = {};
                common.forEach(data, function(value, key) {
                    data[key] = 'override_' + value;
                });

                wrapper['wrap'] = data;
                return wrapper;
            };

            var model = new TestModel();

            expect(model.attributes).toEqual({
                wrap: {
                    param1: 'override_a',
                    param2: 'override_b'
                }
            });
        });
    });
    describe('get()', function() {
        var model;
        beforeEach(function() {
            function TestModel(data) {
                UIModel.call(this, data);
            }
            common.inherit(TestModel, UIModel);
            model = new TestModel({
                param1: 'a',
                param2: 'b',
                obj1: {
                    deep1: {
                        deep1_1: 1,
                        deep1_2: 2
                    },
                    deep2: 3
                }
            });
        });
        it('key 값을 넘겨 데이터를 조회할 수 있는지 확인한다.', function() {
            expect(model.get('param1')).toBe('a');
            expect(model.get('param2')).toBe('b');
            expect(model.get('param3')).toBeUndefined();
        });
        it('.연산자로 계층구조의 데이터를 조회할 수 있는지 확인한다.', function() {
            expect(model.get('obj1.deep1')).toEqual({
                deep1_1: 1,
                deep1_2: 2
            });
            expect(model.get('obj1.deep1.deep1_1')).toEqual(1);
            expect(model.get('obj1.deep1.deep1_2')).toEqual(2);
            expect(model.get('obj1.deep2')).toEqual(3);
            expect(model.get('obj1.deep2.notExist')).toBeUndefined();
            expect(model.get('obj1.deep2.deepInfinite.deep.deep.notExist')).toBeUndefined();
            expect(model.get('notExist.deep2')).toBeUndefined();

        });
    });
    describe('set()', function() {
        var model;
        beforeEach(function() {
            function TestModel(data) {
                UIModel.call(this, data);
            }
            common.inherit(TestModel, UIModel);
            model = new TestModel();
        });
        it('2개의 인자를 넘겼을 때 잘 설정되는지 확인한다.', function() {
            model.set('param1', 1);
            model.set('param2', {inner1: 'inner'});
            model.set('param3');

            expect(model.get('param1')).toEqual(1);
            expect(model.get('param2.inner1')).toEqual('inner');
            expect(model.get('param2.inner1')).toEqual('inner');
            expect(model.get('param3')).toBeUndefined();

        });
        it('1개의 object 형태의 인자를 넘겼을 때 잘 설정되는지 확인한다.', function() {
            model.set({
                'param1': 1,
                'param2': {
                    inner1: 'inner'
                },
                param3: 3
            });

            expect(model.get('param1')).toEqual(1);
            expect(model.get('param2.inner1')).toEqual('inner');
            expect(model.get('param3')).toEqual(3);
        });
    });
    describe('toJSON()', function() {
        var model;
        beforeEach(function() {
            function TestModel(data) {
                UIModel.call(this, data);
            }
            common.inherit(TestModel, UIModel);
            model = new TestModel({
                param1: 'a',
                param2: 'b',
                obj1: {
                    deep1: {
                        deep1_1: 1,
                        deep1_2: 2
                    },
                    deep2: 3
                }
            });
        });
        it('기대한 결과가 반환되는지 확인한다.', function() {
            expect(model.toJSON()).toEqual({
                param1: 'a',
                param2: 'b',
                obj1: {
                    deep1: {
                        deep1_1: 1,
                        deep1_2: 2
                    },
                    deep2: 3
                }
            });
        });
    });
    describe('이벤트 핸들러()', function() {
        var model;
        beforeEach(function() {
            function TestModel(data) {
                UIModel.call(this, data);
            }
            common.inherit(TestModel, UIModel);
            model = new TestModel({
                param1: 'a',
                param2: 'b',
                param3: 'c'
            });
        });
        it('change 이벤트 핸들러 테스트', function() {
            var callback = jasmine.createSpy('callback');
            model.on('change', callback);
            model.set('param1', 1);
            expect(callback).toHaveBeenCalledWith(model, model.attributes, 'param1',1, {});
            model.set('param2', 2);
            expect(callback).toHaveBeenCalledWith(model, model.attributes, 'param2',2, {});
            model.set('param3', 3);
            expect(callback).toHaveBeenCalledWith(model, model.attributes, 'param3',3, {});
            model.set({
                'param1': 0,
                'param2': 0,
                'param3': 0
            });
            expect(callback).toHaveBeenCalledWith(model, model.attributes, 'param1',0, {});
            expect(callback).toHaveBeenCalledWith(model, model.attributes, 'param2',0, {});
            expect(callback).toHaveBeenCalledWith(model, model.attributes, 'param3',0, {});
            expect(callback.calls.count()).toBe(6);
        });
        it('change:attribute 이벤트 핸들러 테스트', function() {
            var callback = jasmine.createSpy('callback');
            model.on('change:param3', callback);
            model.set('param1', 1);
            expect(callback).not.toHaveBeenCalled();
            model.set('param2', 2);
            expect(callback).not.toHaveBeenCalled();
            model.set('param3', 3);
            expect(callback).toHaveBeenCalledWith(model, model.attributes, 'param3',3, {});
            model.set({
                'param1': 0,
                'param2': 0,
                'param3': 0
            });
            expect(callback).toHaveBeenCalledWith(model, model.attributes, 'param3',0, {});
            expect(callback.calls.count()).toBe(2);
        });
        it('set 이벤트 핸들러 테스트', function() {
            var callback = jasmine.createSpy('callback');
            model.on('set', callback);
            model.set('param1', 1);
            expect(callback).toHaveBeenCalledWith(model, model.attributes, 'param1',1, {});
            model.set('param2', 2);
            expect(callback).toHaveBeenCalledWith(model, model.attributes, 'param2',2, {});
            model.set('param3', 3);
            expect(callback).toHaveBeenCalledWith(model, model.attributes, 'param3',3, {});
            model.set({
                'param1': 0,
                'param2': 0,
                'param3': 0
            });
            expect(callback).toHaveBeenCalledWith(model, model.attributes, {
                'param1': 0,
                'param2': 0,
                'param3': 0
            }, undefined, {});
        });
        it('destroy 이벤트 핸들러 테스트', function() {
            var callback = jasmine.createSpy('callback');
            model.on('destroy', callback);
            model.set('param1', 1);
            expect(callback).not.toHaveBeenCalled();
            model.destroy();
            expect(callback).toHaveBeenCalled();
        });
        it('all 이벤트 핸들러 테스트', function() {
            var callback = jasmine.createSpy('callback');
            model.on('all', callback);
            model.set('param1', 1);
            expect(callback).toHaveBeenCalledWith('change', model, model.attributes, 'param1',1, {});
            expect(callback).toHaveBeenCalledWith('set', model, model.attributes, 'param1',1, {});
            model.set('param2', 2);
            expect(callback).toHaveBeenCalledWith('change', model, model.attributes, 'param2',2, {});
            expect(callback).toHaveBeenCalledWith('set', model, model.attributes, 'param1',1, {});
            model.set('param3', 3);
            expect(callback).toHaveBeenCalledWith('change', model, model.attributes, 'param3',3, {});
            expect(callback).toHaveBeenCalledWith('set', model, model.attributes, 'param1',1, {});
            model.destroy();
            expect(callback.calls.count()).toBe(7);
        });

        it('silent 테스트', function() {
            var callback = jasmine.createSpy('callback'),
                option = {
                    silent: true
                };
            model.on('all', callback);
            model.set('param1', 1, option);
            model.set('param2', 2, option);
            model.set('param3', 3, option);
            model.destroy(option);
            expect(callback).not.toHaveBeenCalled();
        });

    });

});
