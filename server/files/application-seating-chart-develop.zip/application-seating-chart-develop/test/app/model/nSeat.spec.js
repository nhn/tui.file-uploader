var NSeat = require('../../../src/js/model/nSeat');
var SeatLayer = require('../../../src/js/layer/seatLayer');

describe('NSeat', function() {
    var origin = SeatLayer.SELLING_TYPE_CODE,
        mock;

    beforeEach(function() {
        mock = getJSONFixture('nonReservedSeatList.json')[0];
        SeatLayer.SELLING_TYPE_CODE = {
            'TKL': '티켓링크',
            'AGENCY': '기획사',
            'FIELD': '현장',
            'POSTPONE': '보류',
            'TICKET': '발권'
        };
    });

    afterEach(function() {
        SeatLayer.SELLING_TYPE_CODE = origin;
    });

    describe('init', function() {
        var seat;

        beforeEach(function() {
            seat = new NSeat(mock);
        });

        it('비지정석 생성자에 데이터를 인자로 전달가능', function() {
            expect(seat.label).toBe('비지정석B');
        });
    });





    //describe('setData()', function() {
    //    var seat;
    //
    //    beforeEach(function() {
    //        seat = new NSeat();
    //        seat.setData(mock);
    //    });
    //
    //    it('서버 데이터를 임포팅 가능', function() {
    //        expect(seat.label).toBe('비지정석B');
    //    });
    //});
    //
    //describe('setPoints()', function() {
    //    var seat;
    //
    //    beforeEach(function() {
    //        seat = new NSeat();
    //
    //        seat.setPoints([[5, 5], [10, 10], [15, 15], [5, 5]]);
    //    });
    //
    //    it('비지정석 path의 각 모서리의 포인트를 쉽게 초기화 할 수 있다', function() {
    //        var points = seat.points;
    //
    //        expect(points.length).toBe(4);
    //        expect(points[2] + '').toBe('Point(15, 15)');
    //    });
    //
    //});
    //
    //describe('getTicket()', function() {
    //    var seat;
    //
    //    beforeEach(function() {
    //        seat = new NSeat(mock);
    //    });
    //
    //    it('좌석 할당 매수를 설정할 수 있다', function() {
    //        expect(seat.getTicket('POSTPONE')).toBe(50);
    //    });
    //});
    //
    //describe('setTicket()', function() {
    //    var seat;
    //
    //    beforeEach(function() {
    //        seat = new NSeat();
    //
    //    });
    //
    //    it('좌석 할당 매수를 설정할 수 있다', function() {
    //        seat.setTicket('TKL', 5);
    //        expect(seat.dealership['TKL']).toBe(5);
    //    });
    //});
    //
    //describe('setDealership()', function() {
    //    var seat;
    //
    //    beforeEach(function() {
    //        seat = new NSeat(mock);
    //        seat.setDealership({
    //            'TKL': 5,
    //            'FIELD': 100
    //        });
    //    });
    //
    //    it('동시에 여러 할당매수 설정 가능', function() {
    //        expect(ne.util.keys(seat.dealership).length).toBe(2);
    //        expect(seat.dealership['TKL']).toBe(5);
    //        expect(seat.dealership['FIELD']).toBe(100);
    //    });
    //});
    //
    //describe('getDealership()', function() {
    //    var seat;
    //
    //    beforeEach(function() {
    //        seat = new NSeat(mock);
    //        seat.setTicket('AGENCY', 0);
    //    });
    //
    //    it('할당처코드:할당매수 데이터를 뽑는다', function() {
    //        var data = seat.getDealership();
    //
    //        expect(data['POSTPONE']).toBe(50);
    //        expect(data['AGENCY']).toBeUndefined();
    //    });
    //});
    //
    //describe('isContain()', function() {
    //    var seat;
    //
    //    beforeEach(function() {
    //        seat = new NSeat();
    //        seat.setPoints([[15, 15], [19, 19], [16, 18]]);
    //    });
    //
    //    it('특정 point의 충돌 여부를 검사할 수 있다', function() {
    //        expect(seat.isContain(17, 19)).toBe(false);
    //    });
    //
    //    it('포함된 point를 검출할 수 있다', function() {
    //        expect(seat.isContain(17, 18)).toBe(true);
    //    });
    //});
    //
    //describe('isContain() Concave', function() {
    //    var seat;
    //
    //    beforeEach(function() {
    //        seat = new NSeat();
    //
    //        seat.setPoints([[1, 1], [3, -1], [5, 2], [3, 1], [2, 4], [1, 1]]);
    //    });
    //
    //    it('복잡한 도형에서의 충돌 여부 테스트', function() {
    //        expect(seat.isContain(4, 2)).toBe(false);
    //    });
    //
    //    it('복잡한 도형에서의 충돌 여부 테스트2', function() {
    //        expect(seat.isContain(2, 1)).toBe(true);
    //    });
    //
    //    it('복잡한 도형에서의 충돌 여부 테스트3', function() {
    //        expect(seat.isContain(2, -1)).toBe(false);
    //    });
    //
    //    it('복잡한 도형에서의 충돌 여부 테스트4', function() {
    //        expect(seat.isContain(1, 3)).toBe(false);
    //    });
    //});
    //
    //describe('inInsideRect()', function() {
    //    var seat;
    //
    //    beforeEach(function() {
    //        seat = new NSeat();
    //        seat.setPoints([[1, 1], [3, -1], [5, 2], [3, 1], [2, 4], [1, 1]]);
    //    });
    //
    //    it('비지정석 영역이 특정 rect안에 포함되어있는지 확인할 수 있다', function() {
    //        expect(seat.isInsideRect(1, -1, 6, 4)).toBe(true);
    //    });
    //
    //    it('비지정석 영역이 특정 rect안에 포함되지 않는지 확인할 수 있다', function() {
    //        expect(seat.isInsideRect(2, -1, 5, 4)).toBe(false);
    //    });
    //});
    //
    //describe('setBound()', function() {
    //    var seat;
    //
    //    beforeEach(function() {
    //        seat = new NSeat();
    //        seat.setPoints([[1, 1], [3, -1], [5, 2], [3, 1], [2, 4], [1, 1]]);
    //        seat.setBound();
    //    });
    //
    //    it('비지정석 영역이 차지하는 사각 면젹을 계산할 수 있다', function() {
    //        var bound = seat.bound;
    //        expect(bound + '').toBe('Rect(Point(1, -1), Point(5, 4))');
    //    });
    //
    //});
    //
    //describe('clone()', function() {
    //    var seat,
    //        clone;
    //
    //    beforeEach(function() {
    //        seat = new NSeat(mock);
    //    });
    //
    //    it('좌석 모델 인스턴스의 깊은 복사 기능', function() {
    //        clone = seat.clone();
    //        clone.points.splice(0, 1);
    //        expect(seat.points.length).not.toBe(clone.points.length);
    //    });
    //
    //});

});
