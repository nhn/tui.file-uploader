var Area = require('../../../src/js/model/area');

describe('Area', function() {
    var mock,
        area;

    beforeEach(function() {
        mock = getJSONFixture('area.json');
    });

    describe('init', function() {
        beforeEach(function() {
            area = new Area(mock[0]);
        });

        it('인자로 데이터를 넘길 경우 내부 변수에 자동으로 설정', function() {
            expect(area.data).toBe('54');
            expect(area.points.length).toBe(4);
            expect(area.center).toEqual([4417, 4368.5]);
        });
    });

    describe('setData()', function() {
        beforeEach(function() {
            area = new Area();
            area.setData(mock[0]);
        });

        it('서버로부터 받은 데이터로 내부 프로퍼티를 설정', function() {
            expect(area.data).toBe('54');
            expect(area.points.length).toBe(4);
            expect(area.center).toEqual([4417, 4368.5]);
        });
    });

    describe('isContain()', function() {
        beforeEach(function() {
            area = new Area(mock[0]);
        });

        it('x, y좌표를 넘겨 이 좌표가 이 영역 안에 존재하는지 확인', function() {
            expect(area.isContain(4418, 4400)).toBe(true);
            expect(area.isContain(4204, 4117)).toBe(false);
        });
    });

    describe('getAreaCenter()', function() {
        var center;

        beforeEach(function() {
            area = new Area(mock[0]);
            center = area.getAreaCenter();
        });

        it('영역좌표들의 중심점을 계산', function() {
            expect(center).toEqual([4448.5, 4368.5]);
        });
    });

});
