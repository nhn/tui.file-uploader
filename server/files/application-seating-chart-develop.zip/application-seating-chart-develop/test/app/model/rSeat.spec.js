var RSeat = require('../../../src/js/model/rSeat');

describe('SeatModel', function() {
    var originCode = RSeat.MAP_CODE.slice(0);
    beforeEach(function() {
        RSeat.MAP_CODE = ['층', '구역', '열', '번호'];
    });

    afterEach(function() {
        RSeat.MAP_CODE = originCode.slice(0);
    });

    describe('setPosition()', function() {
        var seat;

        beforeEach(function() {
            seat = new RSeat(10, 10);

            seat.setPosition(15, 15);
        });

        it('좌석의 좌표를 position에 저장한다', function() {
            expect(seat.position + '').toBe('Point(15, 15)');
        });

        it('좌석의 4모서리 좌표를 points에 저장한다', function() {
            var mockRect = {
                nw: [10, 10],
                sw: [10, 20],
                se: [20, 20],
                ne: [20, 10]
            };

            var cPoints = $.map(seat.points, function(point) {
                return [[point.x, point.y]];
            });

            expect(cPoints).toEqual([
                mockRect.nw,
                mockRect.sw,
                mockRect.se,
                mockRect.ne
            ]);
        });

        it('좌석의 bound를 계산하여 저장한다', function() {
            expect(seat.bound + '').toBe('Rect(Point(10, 10), Point(20, 20))');
        });

    });

    describe('moveTo()', function() {
        var seat;

        beforeEach(function() {
            seat = new RSeat(100, 100);

            seat.moveTo(150, 150);
        });

        it('좌석이 이동된 후에는 isDirty 값이 true', function() {
            expect(seat.isDirty).toBe(true);
        });

        describe('좌석 이동 후에도 좌표 정보를 올바르게 계산한다', function() {

            it('좌석의 좌표를 position에 저장한다', function() {
                expect(seat.position + '').toBe('Point(150, 150)');
            });

            it('좌석의 4모서리 좌표를 points에 저장한다', function() {
                var mockRect = {
                    nw: [145, 145],
                    sw: [145, 155],
                    se: [155, 155],
                    ne: [155, 145]
                };

                var cPoints = $.map(seat.points, function(point) {
                    return [[point.x, point.y]];
                });

                expect(cPoints).toEqual([
                    mockRect.nw,
                    mockRect.sw,
                    mockRect.se,
                    mockRect.ne
                ]);
            });

            it('좌석의 bound를 계산하여 저장한다', function() {
                expect(seat.bound + '').toBe('Rect(Point(145, 145), Point(155, 155))');
            });

        });

        describe('좌석이 회전된 후에도 정상적으로 좌표를 유지한다', function() {
            var seat2;

            beforeEach(function() {
                seat2 = new RSeat(10, 10);

                seat2.rotate(90);

                seat2.moveTo(15, 15);
            });

            it('좌석의 points가 유지된다', function() {
                var mockRect = {
                    nw: [20, 10],
                    sw: [10, 10],
                    se: [10, 20],
                    ne: [20, 20]
                };

                var cPoints2 = $.map(seat2.points, function(point) {
                    return [[point.x, point.y]];
                });

                expect(cPoints2).toEqual([
                    mockRect.nw,
                    mockRect.sw,
                    mockRect.se,
                    mockRect.ne
                ]);
            });
        });

    });

    describe('setMapInfo()', function() {

        it('좌석 매핑정보를 입력할 수 있다', function() {
            var seat = new RSeat(10, 10);

            seat.setMapInfo(1, '1');

            expect(seat.mapInfo[0]).toBe('1');
        });

        it('객체를 통해 좌석 매핑정보를 설정할수도 있다', function() {
            var seat = new RSeat(15, 15);

            seat.setMapInfo(['1', 'A', '1', '1']);

            seat.setMapInfo(4, '5');

            expect(seat.mapInfo).toEqual(['1', 'A', '1', '5']);
        });

    });

    describe('isContain()', function() {

        it('특정 포인트가 points 안에 포함되어 있는지 확인가능하다', function() {

            var seat = new RSeat(10, 10);

            expect(seat.isContain(0, 0)).toBe(false);
            expect(seat.isContain(6, 6)).toBe(true);
            expect(seat.isContain(16, 16)).toBe(false);

        });

        it('회전된 좌석에 대해서도 point의 포함 여부를 계산할 수 있다', function() {
            var seat = new RSeat(5, 5);

            seat.rotate(-45);

            expect(seat.isContain(1, 1)).toBe(false);
            expect(seat.isContain(1.5, 1.5)).toBe(true);
            expect(seat.isContain(11, 5)).toBe(true);
            expect(seat.isContain(11, 7)).toBe(false);
            expect(seat.isContain(3, 11)).toBe(false);
            expect(seat.isContain(1, 8)).toBe(true);
        });

    });

    describe('setData()', function() {

        it('서버에서 제공하는 데이터를 import할 수 있다', function() {

            var seatData = {
                'sid': 30,
                'position': [85, 309],
                'bound': [[80, 304], [90, 314]],
                'points': [[80, 304], [90, 304], [90, 314], [80, 314]],
                'grade': 'A',
                'sellingType': 'spot',
                'groupId': null,
                'soldout': true,
                'mapInfo': ['1', 'A', '', '']
            };

            var seat = new RSeat(30, 30);

            seat.setData(seatData);

            expect(seat.position + '').toBe('Point(85, 309)');
            expect(seat.grade).toBe('A');
            expect(seat.mapInfo[0]).toBe('1');
            expect(seat.mapInfo[1]).toBe('A');

        });

    });

    describe('getMapInfo()', function() {
        var seat;

        beforeEach(function() {
            seat = new RSeat(10, 10);

            seat.setMapInfo(['1', 'A', '1', '1']);
        });

        it('매핑정보 값을 조회할 수 있다', function() {
            expect(seat.getMapInfo(2)).toBe('A');
        });

        it('매핑정보를 key:value 객체로 받을 수 있다', function() {
            expect(seat.getMapInfo()).toEqual({
                '층': '1',
                '구역': 'A',
                '열': '1',
                '번호': '1'
            });
        });
    });

    describe('getText()', function() {
        it('mapInfo를 토대로 Text스트링을 만들어 리턴한다.', function() {
            var seat = new RSeat(30, 30);

            seat.mapInfo = ['1', 'A', 'A', '1'];

            expect(seat.getText()).toEqual('층: 1\n구역: A\n열: A\n번호: 1');
        });
    });

    describe('clone()', function() {
        var seat1,
            seat2;

        beforeEach(function() {
            seat1 = new RSeat(15, 15);

            seat1.sid = 10050;
            seat1.slid = '8:3';
            seat1.soldout = true;
            seat1.grade = 'T01';
            seat1.sellingType = 'E01';

            seat2 = seat1.clone();
        });

        it('지정석 정보를 깊은 복제할 수 있다', function() {
            // position 복제 확인
            expect(seat1.position.toString() === seat2.position.toString()).toBe(true);
            expect(seat1.position !== seat2.position).toBe(true);

            // bound 복제 확인
            expect(seat1.bound.toString() === seat2.bound.toString()).toBe(true);
            expect(seat1.bound !== seat2.bound).toBe(true);

            // points 복제 확인
            expect(function() {
                var i = 0,
                    cnt = seat1.points.length,
                    point;

                for (; i < cnt; i += 1) {
                    point = seat1.points[i];
                    if (point.toString() !== seat2.points[i].toString()) {
                        throw new Error();
                    }

                    if (point === seat2.points[i]) {
                        throw new Error();
                    }
                }
            }).not.toThrow();
        });

    });

});
