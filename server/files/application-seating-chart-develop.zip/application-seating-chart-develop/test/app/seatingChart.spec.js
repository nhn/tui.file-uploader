var SeatingChart = require('../../src/js/seatingChart');

xdescribe('SeatingChart', function() {
    beforeEach(function() {
        loadFixtures('map.html');
    });

    it('맵 컨테이너에 브라우저에 ie브라우저 구별을 위한 특정 css를 추가한다', function() {
        var map = new SeatingChart('map');

        var hasClass = false,
            $mapContainer = $('#map');

        hasClass = $mapContainer.hasClass('seatingchart-browser-msie') ||
            $mapContainer.hasClass('seatingchart-browser-others');

        expect(hasClass).toBe(true);
    });

    describe('options', function() {
        it('특정 줌 레벨 기준의 좌석 사이즈를 지칭하는 옵션을 가진다', function() {
            var map = new SeatingChart('map');

            expect(map.options.seatSize).toBe(10);
            expect(map.options.zoomLevelInSeatSize).toBe(4);
        });
    });

});
