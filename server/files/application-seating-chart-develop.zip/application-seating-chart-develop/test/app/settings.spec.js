/**********
 * 아래 모듈들은 static 프로퍼티 확인용으로 로드했으므로
 * 절대 직접 인스턴스화 하여 사용하지 않아야 한다
 **********/
var SelectNSeatLayer = require('../../src/js/layer/selectNSeatLayer'),
    SeatLayer = require('../../src/js/layer/seatLayer'),
    NSeatLayer = require('../../src/js/layer/nSeatLayer'),
    GradeBrush = require('../../src/js/brush/gradeBrush'),
    NSeatBrush = require('../../src/js/brush/nSeatBrush'),
    SellingTypeBrush = require('../../src/js/brush/sellingTypeBrush');

describe('Settings', function() {
    var settings;

    beforeEach(function() {
        settings = require('../../src/js/settings');
    });

    it('check module works singleton object', function() {
        spyOn(settings, 'constructor').and.callThrough();
        require('../../src/js/settings');
        expect(settings.constructor.calls.count()).toBe(0);
    });

    describe('setGradeCode()', function() {
        var mockCodeInfo;

        beforeEach(function() {
            mockCodeInfo = {
                '408': ['대한석', '#1ED975'],
                '409': ['민국석', '#0FC7FF'],
                '410': ['만세석', '#FFBA19']
            };
        });

        afterEach(function() {
            SelectNSeatLayer.GRADE_CODE = null;
            SeatLayer.GRADE_CODE = null;
            NSeatLayer.GRADE_CODE = null;
            SeatLayer.GRADE_INFO = null;
            GradeBrush.STYLES = {};
            NSeatBrush.STYLES = {};
        });

        it('등급을 렌더링하는 데 필요한 정보들을 각 모듈들에게 전달한다', function() {
            settings.setGradeCode(mockCodeInfo);
            expect(SelectNSeatLayer.GRADE_CODE).toEqual(['408', '409', '410']);
            expect(SeatLayer.GRADE_INFO).toEqual(mockCodeInfo);
        });
    });

    describe('setSellingTypeCode()', function() {
        var sellingTypeCode;

        beforeEach(function() {
            sellingTypeCode = {
                'TKL': '티켓링크',
                'FIELD': '현장',
                'TICKET': '발권',
                'POSTPONE': '보류',
                'CALL': '콜센터',
                'AGENCY': '기획사'
            };
        });

        afterEach(function() {
            SeatLayer.SELLING_TYPE_CODE = null;
            SellingTypeBrush.STYLES = {};
        });

        it('판매할당처 표기를 위한 렌더링 스타일을 설정한다', function() {
            settings.setSellingTypeCode(sellingTypeCode);

            expect(SellingTypeBrush.STYLES['TKL']).toEqual(jasmine.any(Object));
        });
    });
});