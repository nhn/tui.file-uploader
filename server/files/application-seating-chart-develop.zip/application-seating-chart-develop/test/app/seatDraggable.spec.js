var simplemap = ne.component.SimpleMap,
    Point = simplemap.Point,
    Rect = simplemap.Rect;

var SeatDraggable = require('../../src/js/seatDraggable');

describe('SeatDraggable', function () {

    var sd,

        MockChart,
        MockSelectCtrl,
        MockPaper;

    beforeEach(function () {
        /**********
         * Mock
         **********/
        MockChart = jasmine.createSpyObj('Chart', [
            'getViewportOffsetByPanelName',
            'getScaleRatio',
            'panBy',
            'enablePanAndZoom',
            'disablePanAndZoom',
            'getLayerPanel',
            'searchSeats',
            'deselectSeatsByIds',
            'deselectSeats',
            'getContainer',
            'on',
            'splitSeatRN'
        ]);
        MockChart.IB = jasmine.createSpyObj('IB', ['emit']);
        MockSelectCtrl = jasmine.createSpyObj('SelectCtrl', [
            'moveSeats'
        ]);
        MockPaper = { _vbSize: 1, _viewBoxShift: { scale: 2 } };

        /**********
         * target
         **********/
        sd = new SeatDraggable(MockChart, MockPaper, MockSelectCtrl);
    });

    it('맵에 추가되어 좌석 선택해제 이벤트를 감지한다', function () {
        expect(MockChart.on).toHaveBeenCalled();
    });

    describe('_getViewportBounds()', function () {
        beforeEach(function () {
            MockChart.getViewportOffsetByPanelName.and.returnValue(new Rect([2, 2], [4, 4]));
            MockChart.getScaleRatio.and.returnValue(2);
        });

        it('화면에 보이는 영역의 좌상, 우하좌표를 실제좌표로 변환한다', function () {
            var result = sd._getViewportBounds();
            expect(result + '').toBe(Rect.n([1, 1], [2, 2]) + '');
        });
    });

    describe('_getMouseCoords()', function () {
        beforeEach(function () {
            spyOn(simplemap.domevent, 'getMousePosition').and.returnValue(new Point(4, 4));
            spyOn(simplemap.domutil, 'getPosition').and.returnValue(new Point(2, 2));
        });

        it('마우스 이벤트를 받아 실제좌표로 변환한다', function () {
            MockChart.getScaleRatio.and.returnValue(0.5);
            var result = sd._getMouseCoords({});
            expect(result + '').toBe(Point.n(4, 4) + '');
        });

        it('스케일이 달라져도 마우스 이벤트를 받아 실제좌표로 변환한다', function () {
            MockChart.getScaleRatio.and.returnValue(2);
            var result = sd._getMouseCoords({});
            expect(result + '').toBe(Point.n(1, 1) + '');
        });
    });

    describe('_onLeftOutMouseMove()', function () {
        beforeEach(function () {
            spyOn(sd, '_getViewportBounds').and.returnValue(new Rect([2, 2], [4, 4]));
            spyOn(sd, '_getMouseCoords').and.returnValue(new Point(9, 3));
        });

        it('좌석을 드래그하는 중에 드로잉 영역을 벗어났을 때 이동되어야 하는 맵의 패닝 벡터값을 기록한다', function () {
            sd._onLeftOutMouseMove({});
            var result = sd._panningVector;
            expect(result + '').toBe(Point.n(1, 0) + '');
        });
    });

    describe('_onLeftOutPanningTick()', function () {
        beforeEach(function () {
            sd._panningVector = Point.n(1, 1);
            sd._startPos = Point.n(5, 5);
            spyOn(sd, '_getMouseCoords').and.returnValue(new Point(9, 3));
            spyOn(sd, 'transform');
        });

        it('좌석드래그 중 화면 바깥으로 나갔을 때 나간 방향으로 맵을 패닝시키고, 드래그 중인 엘리먼트도 그만큼 이동시킨다', function () {
            sd._onLeftOutPanningTick();
            expect(MockChart.panBy.calls.argsFor(0)[0] + '').toBe(Point.n(1, 1) + '');
            expect(sd.transform.calls.argsFor(0)).toEqual([4, -2]);
        });
    });

    describe('_toggleLeftOutFeature()', function () {
        beforeEach(function () {
            spyOn(simplemap.domevent, 'on');
            spyOn(simplemap.domevent, 'off');
            spyOn(window, 'clearInterval');
            spyOn(window, 'setInterval').and.returnValue(10);
        });

        it('켜졌는데 또 킬수는 없다', function () {
            sd._toggleLeftOutFeature(true);
            sd._toggleLeftOutFeature(true);

            expect(simplemap.domevent.on.calls.count()).toBe(1);
        });

        it('반대로 꺼졌는데 또 끌 순 없다', function () {
            sd._toggleLeftOutFeature(true);
            sd._toggleLeftOutFeature(false);
            sd._toggleLeftOutFeature(false);

            expect(simplemap.domevent.off.calls.count()).toBe(1);
        });

        it('켜지면 마우스가 드로잉 영역 바깥으로 나갔을 때 그 방향으로 패닝시킬 준비를 한다', function () {
            sd._toggleLeftOutFeature(true);

            expect(simplemap.domevent.on.calls.argsFor(0)[1]).toBe('mousemove');
            expect(window.clearInterval).toHaveBeenCalledWith(0);
            expect(window.setInterval).toHaveBeenCalled();
        });

        it('켜진상태에서 꺼지면 패닝시킬 준비했던 것들을 취소한다', function () {
            sd._toggleLeftOutFeature(true);
            sd._toggleLeftOutFeature(false);

            expect(sd._leftOutIntervalID).toBe(0);
        });
    });

    describe('_onMouseOutTick()', function () {
        beforeEach(function () {
            sd._absoluteMousePos = true;
            spyOn(sd, '_getViewportBounds').and.returnValue(new Rect([1, 1], [4, 4]));
            spyOn(sd, '_toggleLeftOutFeature');
        });

        it('좌석 드래그를 시작해야 이 메서드가 동작한다', function () {
            delete sd._absoluteMousePos;
            sd._onMouseOutTick();
            expect(sd._toggleLeftOutFeature).not.toHaveBeenCalled();
        });

        it('마우스가 드로잉 영역 바깥으로 나가면 패닝시킬 준비를 한다', function () {
            spyOn(sd, '_getMouseCoords').and.returnValue(new Point(17, 17));

            sd._onMouseOutTick();
            expect(sd._toggleLeftOutFeature).toHaveBeenCalledWith(true);
        });

        it('마우스가 드로잉 영역 내에 있으면 패닝시킬 준비 했던것을 취소한다', function () {
            spyOn(sd, '_getMouseCoords').and.returnValue(new Point(3, 3));

            sd._onMouseOutTick();
            expect(sd._toggleLeftOutFeature).toHaveBeenCalledWith(false);
        });
    });

    describe('_onBeforeDeselectAllSeats', function () {
        beforeEach(function () {
            sd._startPos = Point.n(10, 10);
            spyOn(sd, 'reset');
            sd.setElement = jasmine.createSpyObj('setEl', ['undrag']);
            spyOn(sd, 'init');
            spyOn(sd, '_endDrag');
        });

        it('좌석 드래그 중이 아닐 경우에는 메서드는 동작하지 않는다', function () {
            delete sd._startPos;
            var result = sd._onBeforeDeselectAllSeats();
            expect(result).toBeUndefined();
        });

        it('좌석 드래그 중 메서드가 불리면 드래그 상태를 취소하고 원래 자리에 좌석을 되돌려놓는다', function () {
            var result = sd._onBeforeDeselectAllSeats();
            expect(result).toBe(false);
        });
    });

    describe('_getPaperScale', function () {
        it('Raphael렌더링의 배율을 반환한다', function () {
            expect(sd._getPaperScale()).toBe(1);
        });

        it('Raphael의 구현이 달라져 _vbSize가 없어질 경우 _viewBoxShift를 참조한다', function () {
            delete sd.paper._vbSize;
            expect(sd._getPaperScale()).toBe(1/2);
        });
    });

    describe('_getMousePosition()', function() {
        beforeEach(function () {
            spyOn(simplemap.domevent, 'getMousePosition').and.returnValue(Point.n(10, 10));
            spyOn(sd, '_getPaperScale').and.returnValue(2);
        });

        it('마우스의 좌표를 라파엘 스케일에 맞춰 변환한다', function () {
            var result = sd._getMousePosition();
            expect(result + '').toBe(Point.n(20, 20) + '');
        });
    });

    describe('processSingleSelect', function () {
        var seat1,
            seat2;

        beforeEach(function () {
            seat1 = jasmine.createSpyObj('seat1', ['getID']);
            seat1.getID.and.returnValue('10');
            seat2 = jasmine.createSpyObj('seat2', ['getID']);
            seat2.getID.and.returnValue('20');

            MockChart.searchSeats.and.returnValue({ r: [seat1, seat2] });
            MockChart.IB.constructor = {
                EVENT: {
                    MAP_DESELECT_SEAT: 'mapDeselectSeat'
                }
            };
            MockSelectCtrl.seats = jasmine.createSpyObj('seats', ['has']);
            MockSelectCtrl.seats.has.and.callFake(function (sid) {
                if (sid === '10') {
                    return true;
                }
            });
        });

        it('드래그 중 이동을 하지 않아 단일클릭이 된 경우 해당 좌표를 포함하는 선택좌석들이 있을 경우 선택해제한다', function () {
            sd.processSingleSelect();
            expect(MockSelectCtrl.seats.has).toHaveBeenCalled();
            expect(MockChart.deselectSeats).toHaveBeenCalledWith([seat1], true);
        });
    });

    describe('init()', function () {
        var setEl;

        beforeEach(function () {
            setEl = jasmine.createSpyObj('setEl', ['drag']);
        });

        it('Raphael SET엘리먼트를 넘기면 드래그할 수 있도록 준비한다', function () {
            sd.init(setEl);
            expect(setEl.drag).toHaveBeenCalledWith(
                jasmine.any(Function),
                jasmine.any(Function),
                jasmine.any(Function),
                sd,
                sd,
                sd
            );
        });

        it('인자로 SET엘리먼트를 넘기지 않으면 자신의 SET엘리먼트로 드래그를 준비한다', function () {
            sd.setElement = setEl;
            sd.init();

            expect(setEl.drag).toHaveBeenCalledWith(
                jasmine.any(Function),
                jasmine.any(Function),
                jasmine.any(Function),
                sd,
                sd,
                sd
            );
        });

        it('SET엘리먼트가 없는 상태에서 인자도 넘기지 않으면 무시한다', function () {
            sd.init();
            expect(setEl.drag).not.toHaveBeenCalled();
        });
    });

    describe('_endDrag()', function () {
        beforeEach(function () {
            spyOn(window, 'clearInterval');
        });

        it('좌석 드래그중에 사용되는 프로퍼티들을 초기화한다', function () {
            sd._startPos = Point.n(10, 10);

            sd._endDrag();

            expect(sd._mouseOutIntervalID).toBe(0);
            expect(sd._startPos).toBe(null);
            expect(sd._panningStartCenterCoords).toBe(null);
        });
    });

    describe('_onStart()', function () {
        beforeEach(function () {
            MockChart.IB = jasmine.createSpyObj('IB', ['get']);
            sd.setElement = jasmine.createSpyObj('setEl', ['undrag']);

            spyOn(simplemap.domevent, 'stopPropagation');
            spyOn(window, 'clearInterval');
            spyOn(window, 'setInterval');
            spyOn(sd, '_getMousePosition').and.returnValue(Point.n(5, 5));
            spyOn(sd, '_getViewportBounds').and.returnValue(Rect.n([1, 1], [3, 3]));
        });

        it('좌석 드래그는 맵이 비활성화된 경우 동작하지 않는다', function () {
            MockChart.disabled = true;
            MockChart.IB.get.and.returnValue(0);

            sd._onStart();
            expect(sd.setElement.undrag).toHaveBeenCalled();
        });

        it('좌석 드래그는 탭이 "좌석", "회전" 이 아닌 경우 동작하지 않는다', function () {
            MockChart.disabled = false;
            MockChart.IB.get.and.returnValue(2);

            sd._onStart();
            expect(sd.setElement.undrag).toHaveBeenCalled();
        });

        it('좌석 드래그 중에는 맵의 패닝과 줌이 제한되고 좌석이동에 대한 준비를 한다', function () {
            MockChart.IB.get.and.returnValue(0);
            sd._onStart();

            expect(MockChart.disablePanAndZoom).toHaveBeenCalled();
            expect(sd._startPos + '').toBe(Point.n(5, 5) + '');
            expect(sd._panningStartCenterCoords + '').toBe(Point.n(2, 2) + '');
        });
    });

    describe('_onMove()', function () {
        beforeEach(function () {
            spyOn(sd, '_getPaperScale').and.returnValue(5);
            spyOn(sd, '_getViewportBounds').and.returnValue(Rect.n([1, 1], [5, 5]));
            spyOn(sd, 'transform');
        });

        it('좌석을 드래그하면 드래그 한 만큼 SET엘리먼트를 css transform 처리한다', function () {
            sd._onMove(3, 3, 5, 5);
            expect(sd.transform).toHaveBeenCalledWith(15, 15);
        });

        it('좌석 드래그 중 패닝이 되었을 경우 패닝된만큼을 transform에 계산하여 반영한다', function () {
            sd._panningStartCenterCoords = Point.n(1, 1);
            sd._onMove(3, 3, 5, 5);
            expect(sd.transform).toHaveBeenCalledWith(17, 17);
        });
    });

    describe('onEnd()', function () {
        beforeEach(function () {
            spyOn(sd, '_getMousePosition').and.returnValue(Point.n(5, 5));
            spyOn(sd, '_endDrag');
            spyOn(sd, 'processSingleSelect');

            MockSelectCtrl.seats = jasmine.createSpyObj('seats', ['each']);
            MockSelectCtrl.groupBound = Rect.n([5, 5], [10, 10]);
        });

        it('드래그 중 마우스를 놓았을 때 이동 시작거리와, 끝 지점을 계산한 후 선택컨트롤러의 좌석들 위치를 갱신한다', function () {
            sd._startPos = Point.n(10, 10); // diff = -5, -5
            sd.onEnd();

            expect(MockSelectCtrl.groupBound + '').toBe(Rect.n([0, 0], [5, 5]) + '');
            expect(MockSelectCtrl.moveSeats).toHaveBeenCalledWith(-5, -5);
        });

        it('드래그 중 마우스를 움직이지 않았다면 좌석 선택 취소 처리를 한다', function () {
            sd._startPos = Point.n(5, 5);
            sd.onEnd();
            expect(sd.processSingleSelect).toHaveBeenCalledWith(5, 5);
        });
    });

    describe('transform(), reset()', function () {
        beforeEach(function () {
            sd.setElement = jasmine.createSpyObj('setEl', ['transform']);
        });

        it('자신의 set엘리먼트를 css transform처리한다', function () {
            sd.transform(5, 10);
            sd.reset();

            expect(sd.setElement.transform.calls.argsFor(0)).toEqual(['t5,10']);
            expect(sd.setElement.transform.calls.argsFor(1)).toEqual(['']);
        });
    });

});