var FnKeys = require('../../src/js/fnKeys');

describe('FnKeys', function() {
    var fnKeys;

    beforeEach(function() {
        fnKeys = new FnKeys();
        loadFixtures('fnKeys.html');
    });

    describe('_isShortcutAble()', function () {
        var target;

        it('input:text, textarea가 전달되면 false를 반환한다', function () {
            target = document.getElementById('textarea_with_display_inline');
            expect(fnKeys._isShortcutAble(target)).toBe(false);
            target = document.getElementById('plain_text');
            expect(fnKeys._isShortcutAble(target)).toBe(false);
        });

    });

    describe('_onKeyDown()', function() {
        var target,
            which,
            handler;

        beforeEach(function() {
            handler = jasmine.createSpy('handler');
            fnKeys.on('shortcut', handler);
        });

        it('body이외에 포커스가 있는 경우 동작 안함', function() {
            target = document.getElementById('textarea_with_display_inline');
            which = 46;

            fnKeys._onKeyDown({ target: target, which: which });

            expect(handler).not.toHaveBeenCalled();
        });

        it('body에 포커스가 있는 경우(focusable엘리먼트들에 포커스가 없는 경우) 동작', function() {
            target = null;
            which = 70;

            fnKeys._onKeyDown({ target: target, which: which });

            expect(handler).toHaveBeenCalled();
            expect(handler.calls.argsFor(0)).toEqual(['70', 'F']);
        });

        it('지정된 키 이외의 키에는 반응 안함', function() {
            target = document.getElementById('input_with_visibility_hidden');
            which = 120;

            fnKeys._onKeyDown({ target: target, which: which });

            expect(handler).not.toHaveBeenCalled();
        });

        it('브라우저가 낡아 which대신 keycode를 지원해도 동작한다', function () {
            fnKeys._onKeyDown({ target: {}, keyCode: 70 });
            expect(handler).toHaveBeenCalled();
        });

    });

    describe('단축키 기능 비활성화 시 동작하지 않는다', function () {
        beforeEach(function () {
            fnKeys.disabled = true;
        });

        afterEach(function () {
            fnKeys.disabled = false;
        });

        it('단축키 기능을 비활성화시키면 동작하지 않는다', function () {
            var spy = jasmine.createSpy('shortcut');
            fnKeys.on('shortcut', spy);

            fnKeys._onKeyDown({ target: {}, which: 70 });
        });
    });

});
