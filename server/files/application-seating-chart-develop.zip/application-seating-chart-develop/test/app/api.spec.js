/**
 * @fileoverview API모듈 테스트
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

var API = require('../../src/js/api');

function stringify(obj) {
    return JSON.stringify(obj);
}

function spyOnSafe(object, method) {
    try {
        if (object[method]) {
            spyOn(object, method);
        } else {
            object[method] = jasmine.createSpy(method);
        }
    } catch(e) {}
}

describe('API', function() {
    var api = new API();

    beforeEach(function() {
        jasmine.Ajax.install();
    });

    afterEach(function() {
        jasmine.Ajax.uninstall();
    });

    describe('_checkResponse()', function() {
        var mockResponse;

        beforeEach(function() {
            spyOn(window, 'alert');
        });

        it('응답에 code가 없을 경우 시스템 얼럿을 출력한다', function() {
            mockResponse = {
                'code': null
            };

            api._checkResponse(mockResponse);

            expect(window.alert).toHaveBeenCalled();
        });

        it('alert에 null, emptyString이 아닌 문자열이 내려오면 시스템 얼럿을 출력한다', function () {
            api._checkResponse({
                code: '0',
                alert: 'alert message',
                result: null
            });

            expect(window.alert).toHaveBeenCalled();
        });
    });

    describe('_processRawData()', function() {
        var origin,
            mock;

        beforeEach(function() {
            origin = { a: '123', name: 'cony' };
            mock = stringify(origin);
        });

        it('ajax 데이터를 가공한다', function() {
            var processed = api._processRawData('json', mock);
            expect(processed).toEqual(origin);
        });
    });

    describe('_onReadyStateChange()', function() {
        var spies,
            mockOption,
            mockXHR;

        beforeEach(function() {
            spies = jasmine.createSpyObj('handler', ['success', 'fail', 'error', 'complete']);
            mockOption = {
                dataType: 'json',
                success: spies.success,
                fail: spies.fail,
                error: spies.error,
                complete: spies.complete
            };
        });

        it('응답코드에 따라 success또는 fail콜백을 호출한다', function() {
            mockXHR = {
                status: 200,
                readyState: 4,
                responseText: '{"code":"0"}'
            };

            api._onReadyStateChange(mockOption, mockXHR);
            expect(spies.success).toHaveBeenCalled();

            mockXHR = {
                status: 200,
                readyState: 4,
                responseText: '{"code":"1"}'
            };

            api._onReadyStateChange(mockOption, mockXHR);
            expect(spies.fail).toHaveBeenCalled();
        });

        it('응답에 문제가 있는 경우 error를 호출한다', function() {
            mockXHR = {
                status: 500,
                readyState: 4,
                responseText: null
            };

            api._onReadyStateChange(mockOption, mockXHR);
            expect(spies.success).not.toHaveBeenCalled();
            expect(spies.error).toHaveBeenCalled();
        });

        it('success, fail, error여부와 별개로 맨 마지막에 complete를 호출한다', function() {
            mockXHR = {
                status: 200,
                readyState: 4,
                responseText: '{"code":"1"}'
            };

            api._onReadyStateChange(mockOption, mockXHR);
            expect(spies.complete).toHaveBeenCalled();
        });
    });

    describe('ajax()', function() {
        var doneFn,
            req;

        beforeEach(function() {
            doneFn = jasmine.createSpy('success');
        });

        it('ajax 요청을 보낸다', function() {
            api.ajax('/api/test', {
                success: doneFn
            });

            req = jasmine.Ajax.requests.mostRecent();

            expect(req.url).toBe('/api/test');
        });

        it('데이터를 주고 받는다', function() {
            var testResponse = {
                code: '0',
                result: {
                    name: 'cony',
                    age: 12
                }
            };

            api.ajax('/api/test', {
                data: testResponse,
                success: doneFn
            });

            req = jasmine.Ajax.requests.mostRecent();
            expect(req.params).toBe(stringify(testResponse));

            jasmine.Ajax.requests.mostRecent().respondWith({
                status: 200,
                readyState: 4,
                responseText: stringify(testResponse)
            });

            expect(doneFn).toHaveBeenCalledWith(testResponse.result);
        });

        it('http method를 설정할 수 있다', function() {
            api.ajax('/api/test', {
                method: 'GET',
                success: doneFn
            });

            req = jasmine.Ajax.requests.mostRecent();
            expect(req.method).toBe('GET');

            api.ajax('/api/test', {
                method: 'DELETE'
            });

            req = jasmine.Ajax.requests.mostRecent();
            expect(req.method).toBe('DELETE');
        });

        it('type, contentType 을 설정할 수 있다', function() {
            api.ajax('/api/test', {
                type: 'text',
                contentType: 'text/html'
            });

            req = jasmine.Ajax.requests.mostRecent();

            expect(req.requestHeaders['type']).toBe('text');
            expect(req.requestHeaders['Content-Type']).toBe('text/html');
        });

        it('beforeRequest옵션으로 ajax요청 전 특정 동작을 수행할 수 있다', function() {
            var bE = jasmine.createSpy('beforeRequest');

            api.ajax('/api/test', {
                beforeRequest: bE
            });

            jasmine.Ajax.requests.mostRecent().respondWith({
                'status': 200
            });
            expect(bE).toHaveBeenCalledWith();
        });

        it('error옵션으로 ajax요청에 문제가 발생했을 때 콜백을 수행할 수 있다', function() {
            var successFn = jasmine.createSpy('success'),
                errFn = jasmine.createSpy('error');

            api.ajax('/api/test', {
                success: successFn,
                error: errFn
            });

            jasmine.Ajax.requests.mostRecent().respondWith({
                'status': 500
            });

            expect(successFn).not.toHaveBeenCalled();
            expect(errFn).toHaveBeenCalled();

        });

        it('complete콜백은 성공/실패 유무와 상관없이 수행된다', function() {
            var spy = jasmine.createSpyObj('callback', ['success', 'error', 'complete']);

            api.ajax('/api/test', {
                success: spy.success,
                error: spy.error,
                complete: spy.complete
            });

            jasmine.Ajax.requests.mostRecent().respondWith({
                'status': 500
            });

            expect(spy.complete).toHaveBeenCalled();

        });

    });

    describe('call()', function() {
        var doneFn,
            req;

        beforeEach(function() {
            doneFn = jasmine.createSpy('success');
        });

        it('ajax요청을 보낸다', function() {
            api.call('/api/test', {
                success: doneFn
            });

            req = jasmine.Ajax.requests.mostRecent();

            expect(req.url).toBe('/api/test');
        });

        it('응답을 받았을 때 플래그를 체크하고 데이터만 콜백으로 반환', function() {
            var testResponse = {
                'code': '0',
                'alert': null,
                'result': {
                    'name': 'cony'
                }
            };

            api.call('/api/test', {
                success: doneFn
            });

            req = jasmine.Ajax.requests.mostRecent();

            req.respondWith({
                'status': 200,
                'responseText': stringify(testResponse)
            });

            expect(doneFn).toHaveBeenCalledWith(testResponse.result);
        });

    });

});
