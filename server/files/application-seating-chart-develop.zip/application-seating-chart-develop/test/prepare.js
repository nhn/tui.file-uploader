jasmine.getFixtures().fixturesPath = '/base/test/fixtures';
jasmine.getJSONFixtures().fixturesPath = '/base/test/fixtures';
