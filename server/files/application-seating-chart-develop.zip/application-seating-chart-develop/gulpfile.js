'use strict';

var pkg = JSON.parse(require('fs').readFileSync('package.json'));

var path = require('path');
var gulp = require('gulp');
var gutil = require('gulp-util');
var concat = require('gulp-concat');
var rename = require('gulp-rename');
var browserify = require('browserify');
var watchify = require('watchify');
var source = require('vinyl-source-stream');
var buffer = require('vinyl-buffer');
var sourcemaps = require('gulp-sourcemaps');
var uglify = require('gulp-uglify');
var cssmin = require('gulp-minify-css');
var connect = require('gulp-connect');
var es = require('event-stream');
var print = require('gulp-print');

/**********
 * util
 **********/

var hasOwnProp = {}.hasOwnProperty;
var DIST_PATH = './dist';
var KARMA_CONF_PATH = 'karma.conf.js';

var karma = require('karma');
var karmaParseConfig = require('karma/lib/config').parseConfig;
function runKarma(configFilePath, options, cb) {
    configFilePath = path.resolve(configFilePath);

    var server = karma.server;
    var log=gutil.log, colors=gutil.colors;
    var config = karmaParseConfig(configFilePath, {});

    Object.keys(options).forEach(function(key) {
        config[key] = options[key];
    });

    server.start(config, function(exitCode) {
        log('Karma has exited with ' + colors.red(exitCode));
        cb();
        process.exit(exitCode);
    });
}


/**********
 * test
 **********/

gulp.task('full-test', function (cb) {
    runKarma(KARMA_CONF_PATH, {
        autoWatch: false,
        singleRun: true
    }, cb);
});


gulp.task('test', function (cb) {
    runKarma(KARMA_CONF_PATH, {
        autoWatch: true,
        browsers: ['PhantomJS'],
        singleRun: false
    }, cb);
});


/**********
 * build each
 **********/


gulp.task('build-ext', function () {
     return gulp.src([
             './lib/json2/json2.js',
             './lib/code-snippet/code-snippet.js',
             './lib/raphael-ticketlink/raphael.js',
             './lib/tree/Component-Tree.js',
             './lib/simplemap/simplemap.js'
         ])
         .pipe(concat('seatingchart-ext-' + pkg.version + '.js'))
         .pipe(gulp.dest(DIST_PATH));
});


gulp.task('build-core', function () {
    return browserify('./build/core.js')
        .bundle()
        .on('error', gutil.log.bind(gutil, 'Browserify Error'))
        .pipe(source('seatingchart-core-' + pkg.version + '.js'))
        .pipe(gulp.dest(DIST_PATH));
});


gulp.task('build-physical', function () {
    return browserify('./src/js/service/admin/physical/main.js')
        .bundle()
        .on('error', gutil.log.bind(gutil, 'Browserify Error'))
        .pipe(source('seatingchart-physical-' + pkg.version + '.js'))
        .pipe(gulp.dest(path.join(DIST_PATH, 'physical')));
});


gulp.task('build-logical', function () {
    return browserify('./src/js/service/admin/logical/main.js')
        .bundle()
        .on('error', gutil.log.bind(gutil, 'Browserify Error'))
        .pipe(source('seatingchart-logical-' + pkg.version + '.js'))
        .pipe(gulp.dest(path.join(DIST_PATH, 'logical')));
});


gulp.task('build-css', function () {
    gulp.src('./lib/simplemap/simplemap.min.css')
        .pipe(gulp.dest(DIST_PATH));

    return gulp.src('./src/css/*.css')
        .pipe(cssmin())
        .pipe(rename('seatingchart.min.css'))
        .pipe(gulp.dest(DIST_PATH));
});


gulp.task('uglify', function () {
    return gulp.src(['./dist/**/*.js', '!./dist/**/*.min.js'])
        .pipe(uglify())
        .pipe(rename({ extname: '.min.js' }))
        .pipe(gulp.dest(DIST_PATH));
});


/**********
 * 예매
 **********/


gulp.task('build-user-ticketing', function () {
    var targetPath = 'src/js/service/userTicketing';

    function bundle(srcArr) {
        srcArr.forEach(function (filename) {
            var fullPath = path.join(targetPath, filename + '-main.js');
            var bundler = browserify('./' + fullPath);

            bundler.transform('stringify');

            es.merge(
                bundler.bundle()
                    .pipe(source(filename + '-' + pkg.version + '.js'))
                    .pipe(buffer()),
                gulp.src([
                    './dist/seatingchart-ext-' + pkg.version + '.js',
                    './dist/seatingchart-core-' + pkg.version + '.js',
                    './dist/component/calendar.js'
                ])
            )
            .pipe(print())
            .pipe(concat(filename + '-' + pkg.version + '.js'))
            .pipe(gulp.dest(path.join(DIST_PATH, 'userTicketing')))
            .pipe(rename({ extname: '.min.js' }))
            .pipe(uglify())
            .pipe(gulp.dest(path.join(DIST_PATH, 'userTicketing')));
        });
    }

    bundle(['userTicketing', 'userDetail']);
});

gulp.task('build-admin', function () {
    function bundleEntries(entries) {
        for (var targetPath in entries) {
            if (hasOwnProp.call(entries, targetPath)) {
                var fullPath = entries[targetPath],
                    filename = targetPath.split('/').pop(),
                    dest = './' + targetPath.split('/').slice(0, 3).join('/');

                filename = filename.replace('0.0.0', pkg.version);

                var bundler = browserify(fullPath);

                bundler.transform('stringify');

                bundler
                    .bundle()
                    .pipe(source(filename))
                    .pipe(buffer())
                    .pipe(gulp.dest(dest))
                    .pipe(rename({extname: '.min.js'}))
                    .pipe(uglify())
                    .pipe(gulp.dest(dest));
            }
        }
    }

    gulp.src('./src/js/service/ticketing/admin/config.js')
        .pipe(gulp.dest('./dist/ticketing/admin'));

    bundleEntries({
        'dist/ticketing/admin/purchase-0.0.0.js': './src/js/service/ticketing/admin/purchase/main.js',
        'dist/ticketing/admin/call-center-0.0.0.js': './src/js/service/ticketing/admin/callcenter/main.js',
        'dist/ticketing/admin/pre-purchase-0.0.0.js': './src/js/service/ticketing/admin/prePurchase/main.js',
        'dist/ticketing/user/select-seat-0.0.0.js': './src/js/service/ticketing/user/selectSeat/main.js'
    });
});


/**********
 * development
 **********/


gulp.task('connect', function () {
    connect.server({
        root: '../',
        livereload: {
            delay: 500
        }
    });
});


gulp.task('connect-reload', function () {
    return gulp.src('./demo/*.html')
        .pipe(connect.reload());
});


gulp.task('dev', ['connect'], function () {
    gulp.watch('src/js/**/*.js', ['build-core', 'build-physical', 'build-logical']);
    gulp.watch('dist/**/*.js', ['connect-reload']);
});


gulp.task('dev-test', ['connect'], function () {
    gulp.watch(['src/js/**/*.js', 'test/**/*.js'], ['test']);
    gulp.watch('report/**/index.html', ['connect-reload']);
});

/**********
 * build
 **********/

gulp.task('build-main', [
        'build-css',
        'build-ext',
        'build-core',
        'deploy-component'
    ],
    function(cb) { cb(); }
);

gulp.task('build-other', [
        'build-main',
        'build-physical',
        'build-logical',
        'build-user-ticketing',
        'build-admin'
    ],
    function() {}
);

gulp.task('deploy-component', function() {
    var through = require('through2'),
        sourcemapR = /\/\/[@#].*/g;

    function rmSourcemap() {
        var stream = through.obj(function(file, enc, cb) {
            file.contents = new Buffer(String(file.contents).replace(sourcemapR, ''));

            this.push(file);

            cb();
        });

        return stream;
    }

    return gulp.src([
        'lib/simplegrid/*.js',
        'lib/calendar/*.js'
    ]).pipe(rmSourcemap())
    .pipe(gulp.dest('dist/component'));
});

gulp.task('build', ['build-other'], function () {
    gulp.start('uglify');
});

