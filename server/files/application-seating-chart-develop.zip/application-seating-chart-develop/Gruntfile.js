var extend = require('util')._extend;
var istanbul = require('browserify-istanbul');

module.exports = function(grunt) {
    var browserify_bundle = grunt.file.readJSON('task/browserify/bundle.json');

    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),

        /**********
         * For Development
         **********/
        watchify: {
            options: {
                debug: true,
                keepalive: true,
                callback: function(b) {
                    b.transform('stringify');
                    return b;
                }
            },
            ticketingPurchase: {
                src: './src/js/service/ticketing/admin/purchase/main.js',
                dest: 'dist/ticketing/admin/purchase-0.0.0.js'
            },
            ticketingCallcenter: {
                src: './src/js/service/ticketing/admin/callcenter/main.js',
                dest: 'dist/ticketing/admin/call-center-0.0.0.js'
            },
            ticketingPrePurchase: {
                src: './src/js/service/ticketing/admin/prePurchase/main.js',
                dest: 'dist/ticketing/admin/pre-purchase-0.0.0.js'
            },
            ticketingUserSelectSeat: {
                src: './src/js/service/ticketing/user/selectSeat/main.js',
                dest: 'dist/ticketing/user/select-seat-0.0.0.js'
            }
        },

        /**********
         * 배포용
         **********/
        browserify: browserify_bundle,

        concat:  {
            core: {
                files: {
                    'dist/seatingchart-core-<%= pkg.version %>.js': [
                        'lib/json2/json2.js',
                        'lib/code-snippet/code-snippet.js',
                        'lib/raphael-ticketlink/raphael.js',
                        'lib/tree/Component-Tree.js',
                        'lib/calendar/calendar.js',
                        'lib/simplemap/simplemap.js',
                        'lib/simplegrid/simple-grid.js',
                        'dist/seatingchart-core-<%= pkg.version %>.js'
                    ]
                }
            },
            userTicketing: {
                files: {
                    'dist/userTicketing/userTicketing-<%= pkg.version %>.js': [
                        'dist/seatingchart-core-<%= pkg.version %>.js',
                        'dist/userTicketing/userTicketing-<%= pkg.version %>.js'
                    ],
                    'dist/userTicketing/userDetail-<%= pkg.version %>.js': [
                        'dist/seatingchart-core-<%= pkg.version %>.js',
                        'dist/userTicketing/userDetail-<%= pkg.version %>.js'
                    ]
                }
            }
        },

        uglify: {
            options: {
                sourceMap: true,
                drop_console: true
            },
            core: {
                files: {
                    'dist/seatingchart-core-<%= pkg.version %>.min.js': 'dist/seatingchart-core-<%= pkg.version %>.js'
                }
            },
            physical: {
                files: {
                    'dist/physical/seatingchart-physical-<%= pkg.version %>.min.js': 'dist/physical/seatingchart-physical-<%= pkg.version %>.js'
                }
            },
            logical: {
                files: {
                    'dist/logical/seatingchart-logical-<%= pkg.version %>.min.js': 'dist/logical/seatingchart-logical-<%= pkg.version %>.js'
                }
            },
            userTicketing: {
                files: [{
                    expand: true,
                    cwd: 'dist/userTicketing',
                    src: ['**/*.js', '!**/*.min.js'],
                    dest: 'dist/userTicketing',
                    ext: '.min.js',
                    extDot: 'last'
                }]
            },
            ticketing: {
                files: [{
                    expand: true,
                    cwd: 'dist/ticketing',
                    src: ['**/*.js', '!**/*.min.js'],
                    dest: 'dist/ticketing',
                    ext: '.min.js',
                    extDot: 'last'
                }]
            },
            all: {
                files: [{
                    expand: true,
                    cwd: 'dist',
                    src: ['**/*.js', '!**/*.min.js'],
                    dest: 'dist',
                    ext: '.min.js',
                    extDot: 'last'
                }]
            }
        },

        cssmin: {
            bundle: {
                files: {
                    'dist/seatingchart-<%= pkg.version %>.min.css': ['src/css/seatingchart.css']
                }
            }
        },

        /**********
         * 테스트 + 개발
         **********/
        karma: {
            test: {
                frameworks: ['browserify', 'jasmine-ajax', 'jasmine'],
                reporters: ['dots', 'coverage'],
                browsers: ['PhantomJS'],

                singleRun: false,
                autoWatch: true,

                options: {
                    files: [
                        'lib/jquery/jquery.js',
                        'node_modules/jasmine-jquery/lib/jasmine-jquery.js',
                        'lib/json2/json2.js',
                        'lib/code-snippet/code-snippet.js',
                        'lib/simplemap/simplemap.js',
                        'dist/seatingchart-core-<%= pkg.version %>.js',

                        'src/js/**/*.js',

                        'test/prepare.js',
                        { pattern: 'test/fixtures/*', included: false },
                        'test/**/*.spec.js'
                    ]
                },

                preprocessors: {
                    'src/js/**/*.js': ['browserify'],
                    'test/**/*.spec.js': ['browserify']
                },

                coverageReporter: {
                    reporters: [{ type: 'text' }]
                },

                browserify: {
                    debug: true,
                    transform: [istanbul({
                        ignore: ['**/test/**', '**/tmpl/**'],
                        defaultIgnore: true
                    }), 'stringify']
                }
            }
        },
        connect: {
            uses_defaults: {
                options: {
                    port: 8080,
                    keepalive: true,
                    base: './'
                }
            }
        },
        watch: {
            options: {
                livereload: true
            },
            all: {
                files: ['**/*','!Gruntfile.js','!**/node_modules/**']
            },

            physical_dev: {
                files: ['src/js/**/*.js'],
                tasks: ['browserify:core', 'concat:core', 'physical']
            }
        },
        copy: {
            ticketing: {
                files: [
                    {expand: true, flatten: true, src: ['src/js/service/ticketing/admin/config.js'], dest: 'dist/ticketing/admin/', filter: 'isFile'}
                ]
            }
        }
    });

    grunt.loadNpmTasks('grunt-browserify');
    grunt.loadNpmTasks('grunt-watchify');
    grunt.loadNpmTasks('grunt-karma');

    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-cssmin');

    grunt.loadNpmTasks('grunt-contrib-connect');
    grunt.loadNpmTasks('grunt-contrib-watch');

    grunt.loadNpmTasks('grunt-contrib-copy');

    grunt.registerTask('default', []);

    // 테스트
    grunt.registerTask('test', ['karma']);

    // 개별 빌드
    grunt.registerTask('core', ['browserify:core', 'concat:core', 'uglify:core']);

    // 물리, 논리
    grunt.registerTask('physical', ['browserify:physical', 'uglify:physical']);
    grunt.registerTask('logical', ['browserify:logical', 'uglify:logical']);

    // 예매창
    grunt.registerTask('userTicketing', ['browserify:userTicketing', 'concat:userTicketing', 'uglify:userTicketing']);
    grunt.registerTask('ticketing', ['browserify:ticketing', 'uglify:ticketing', 'copy:ticketing']);

    // 통합 빌드
    grunt.registerTask('build', ['core', 'physical', 'logical', 'userTicketing', 'ticketing', 'cssmin']);

};
