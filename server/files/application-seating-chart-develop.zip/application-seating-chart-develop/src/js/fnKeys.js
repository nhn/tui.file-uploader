/**
 * @fileoverciew 간단한 단축키 관리 모듈
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var common = ne.util,
    simplemap = ne.component.SimpleMap,
    domevent = simplemap.domevent;

/**
 * 단축키 모듈
 * @constructor
 */
function FnKeys() {
    /**
     * 단축키 활성화/비활성화 여부
     * @type {boolean}
     */
    this.disabled = false;

    /**
     * 단축키로 사용할 코드 정보
     *
     * Enter, Space 와 같은 폼 요소와 상호작용하는 단축키는 사용할 수 없다
     * @type {object.<string, number>}
     */
    this.keyMap = {
        'DEL': '46',
        'ESC': '27',
        'LEFT': '37',
        'UP': '38',
        'RIGHT': '39',
        'DOWN': '40',
        'F': '70',
        'EQUAL': '187|107',
        'MINUS': '189|109'
    };

    this._bindEvent();
}

common.CustomEvents.mixin(FnKeys);

/**********
 * private methods
 **********/

/**
 * 단축키 모듈에서 사용하는 기본 이벤트 핸들러를 바인딩한다
 * @private
 */
FnKeys.prototype._bindEvent = function() {
    domevent.on(document.body, 'keydown', this._onKeyDown, this);
};

/**
 * 단축키를 동작시켜도 되는 엘리먼트에 포커스가 되어있는지 여부를 확인
 *
 * input:text, textarea의 경우 false를 반환한다
 * @param {HTMLElement} [element] 확인이 필요한 엘리먼트 전달되지 않으면 true를 반환한다
 * @private
 */
FnKeys.prototype._isShortcutAble = function(element) {
    var nodeName;

    if (!common.isExisty(common.pick(element, 'nodeName'))) {
        return true;
    }

    nodeName = element.nodeName.toUpperCase();

    if (nodeName === 'INPUT' && element.type === 'text') {
        return false;
    }

    if (nodeName === 'TEXTAREA') {
        return false;
    }

    return true;
};

/**
 * 키 다운 이벤트 핸들러
 * @param {KeyboardEvent} keyDownEvent
 * @private
 */
FnKeys.prototype._onKeyDown = function(keyDownEvent) {
    if (this.disabled) {
        return;
    }

    var target = (keyDownEvent.target || keyDownEvent.srcElement),
        keyCode = (keyDownEvent.which || keyDownEvent.keyCode) + '',
        found = false,
        code,
        str;

    if (!this._isShortcutAble(target)) {
        return;
    }

    common.forEachOwnProperties(this.keyMap, function(_code, _str) {
        if (~_code.indexOf(keyCode)) {
            found = true;
            code = _code;
            str = _str;
            return false;
        }
    });

    if (found) {
        this.fire('shortcut', code, str);
        domevent.stop(keyDownEvent);
        return false;
    }
};

module.exports = FnKeys;
