/**
 * @fileoverview 라파엘의 드로잉 영역을 맵의 레이어로 사용하기 위한 모듈
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var common = ne.util,
    simplemap = ne.component.SimpleMap,
    tUtil = simplemap.util,
    Layer = simplemap.Layer;

/**
 * @constructor
 * @param {object} options
 * @param {number} options.seatSize
 * @param {number} options.zoomLevelInSeatSize
 * @extends {Layer}
 */
function RLayer(options) {
    Layer.call(this);
    this.paper = null;

    this.originalMapSize = 0;

    this.paperSize = 0;

    this.viewboxSize = 0;

    tUtil.setOptions(this, {
        seatSize: 10,
        zoomLevelInSeatSize: 2
    }, options);
}

// 상속
common.inherit(RLayer, Layer);

/**********
 * initialize method
 **********/

/**
 * 초기화 메서드
 *
 * panel은 사용하지 않지만 인터페이스이므로 남겨둠
 * @param {Map} map
 * @param {HTMLElement} panel
 * @param {HTMLElement} element
 */
RLayer.prototype.initialize = function(map, panel, element) {
    var mapSize = this.originalMapSize = map.options.mapSize;

    map.paper = this.paper = Raphael(element, mapSize.x, mapSize.y);

    element.style.position = 'absolute';

    this.toFront();

    this.resize();

    this.attachEvent({
        'afterZoom:map': this._onAfterZoom
    });
};

/**********
 * public methods
 **********/

/**
 * 현재의 줌 레벨에 맞게 paper의 크기를 변경한다
 */
RLayer.prototype.resize = function() {
    var map = this.map,
        mapSize = map.options.mapSize,
        paper = this.paper,
        paperSize = this._getPaperSize();


    paper.setSize(paperSize, paperSize);
    paper.setViewBox(0, 0, mapSize, mapSize, false);
};

/**
 * Raphael paper의 크기를 계산한다
 * @returns {number}
 * @private
 */
RLayer.prototype._getPaperSize = function() {
    var scale = this.map.getScaleRatio();

    return this.originalMapSize * scale;
};

/**********
 * event handler
 **********/

/**
 * 확대/축소 이벤트 핸들러
 * @private
 */
RLayer.prototype._onAfterZoom = function() {
    this.resize();
};

module.exports = RLayer;
