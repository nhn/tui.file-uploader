/**
 * @fileoverview 라파엘을 이용해 화면에 텍스트를 그린다
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */

'use strict';

/**
 * TextItem 클래스
 * @constructor
 * @param {Raphael} paper 라파엘 페이퍼
 * @exports TextItem
 * @class
 */
function TextItem(paper) {
    /**
     * 라파엘 페이퍼
     * @type {Raphael}
     */
    this.paper = paper;

    /**
     * text엘리먼트로 만들어져야할 데이터들
     * @type {Object[]}
     */
    this.textData = [];

    /**
     * svg 속성 값
     * @type {Object}
     */
    this.attrs = null;

    /**
     * 라파엘 엘리먼트 Set
     * @type {*}
     */
    this.pathElement = this.paper.set();
}

/**********
 * public props
 **********/

/**
 * 텍스트 데이터를 추가한다
 * @param {object} data
 */
TextItem.prototype.add = function(data) {
    this.textData.push(data);
};

/**
 * 텍스트 엘리먼트에 사용될 스타일을 지정한다
 * @param attrs
 */
TextItem.prototype.setAttrs = function(attrs) {
    this.attrs = attrs;
};

/**
 * path를 이용해 paper에 그린다.
 */
TextItem.prototype.render = function() {
    var text,
        self = this,
        paper = this.paper;

    ne.util.forEach(this.textData, function(data) {
        text = paper.text(data.x, data.y, data.str);
        self.pathElement.push(text);
    });

    self.pathElement.attr(self.attrs);
};

/**
 * Item을 초기화한다..
 */
TextItem.prototype.clear = function() {
    this.textData = [];
    this.hide();
};

/**
 * Item을 숨긴다
 */
TextItem.prototype.hide = function() {
    if(this.pathElement) {
        this.pathElement.forEach(function(text) {
            text.remove();
        });
    }
};

module.exports = TextItem;
