/**
 * @fileoverview 그리는 방법과 스타일을 관리하는 클래스
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */

'use strict';

/**
 * Brush 클래스
 * @constructor
 * @param {object} options 생성옵션
 * @param {Raphael} options.paper 라파엘 페이퍼
 * @exports Brush
 * @class
 */
function Brush(options) {
    /**
     * 라파엘 페이퍼 Path아이템에 전달하는 용도
     * @type {Raphael}
     */
    this.paper = options.paper;

    /**
     * 브러시가 노출되야하는지 여부를 저장
     * @type {(Brush.STATUS|number)}
     */
    this.status = Brush.STATUS.SHOW;

    /**
     * path가 맨 앞에 노출되야하는지 여부
     * @type {boolean}
     */
    this.isAlwaysFront = false;
}

/**
 * 브러시의 사용 여부 플래그
 * @type {{SHOW: number, HIDE: number}}
 */
Brush.STATUS = {
    SHOW: 0,
    HIDE: 1
};

/**********
 * virtual props
 **********/

/**
 * 모델 인스턴스를 통해 viewItem을 설정하는 코드
 * @virtual
 * @param {object} seat
 */
Brush.prototype.addItemBySeat = function(seat) {};

/**
 * path string을 받아 viewItem에 설정하는 코드
 * @virtual
 * @param {string} path
 */
Brush.prototype.addPath = function(path) {};

/**
 * 인스턴스를 받아 그에 해당하는 path string을 뽑아내는 코드
 * @virtual
 * @param {object} seat
 */
Brush.prototype.generatePath = function(seat) {};

/**********
 * public props
 **********/

/**
 * 브러시의 ViewItem을 설정한다
 * @param {PathItem} viewItem
 */
Brush.prototype.setViewItem = function(viewItem) {
    this.viewItem = viewItem;
};

/**
 * ViewItem을 그린다
 */
Brush.prototype.render = function() {
    if(this.getStatus() === Brush.STATUS.SHOW){
        this.viewItem.setAttrs(this.style);
        this.viewItem.render();
    }
};

/**
 * 그렸던 ViewItem엘리먼트를 제거한다
 */
Brush.prototype.clear = function() {
    this.viewItem.clear();
};

/**
 * ViewItem의 엘리먼트에 스타일을 지정한다
 * @param {object} style
 */
Brush.prototype.setStyle = function(style) {
    this.style = style;
};

/**
 * 브러시의 사용 여부를 설정한다
 *
 * 이 프로퍼티를 조작하여 특정 모습을 나타나거나 나타나지 않게 할 수 있다.
 * @param {(Brush.STATUS|number)} status
 */
Brush.prototype.setStatus = function(status) {
    this.status = status;
};

/**
 * 브러시의 사용 여부를 반환한다
 * @returns {(Brush.STATUS|number)}
 */
Brush.prototype.getStatus = function() {
    return this.status;
};

/**
 * 브러시의 엘리먼트를 그린다
 */
Brush.prototype.show = function() {
    if (this.getStatus() === Brush.STATUS.HIDE) {
        this.setStatus(Brush.STATUS.SHOW);
        this.render();
    }
};

/**
 * 브러시의 엘리먼트를 숨긴다
 */
Brush.prototype.hide = function() {
    if(this.getStatus() === Brush.STATUS.SHOW) {
        this.setStatus(Brush.STATUS.HIDE);
        this.viewItem.hide();
    }
};

/**
 * 브러시 엘리먼트의 노출순서를 맨 위로 올린다
 */
Brush.prototype.toFront = function() {
    if (this.viewItem && (ne.util.isFunction(this.viewItem.toFront))) {
        this.viewItem.toFront();
    }
};

/**
 * 브러시가 가진 ViewItem을 반환한다
 * @returns {(PathItem|*|Brush.viewItem)}
 */
Brush.prototype.getViewItem = function() {
    return this.viewItem;
};

module.exports = Brush;
