/**
 * @fileoverview Seat을이용해 Text엘리먼트를 만드는 객체
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */


'use strict';

var common = ne.util;

var Brush = require('./brush'),
    TextItem = require('./textItem'),
    RSeat = require('../model/rSeat');

// 좌석 중심좌표가 아닌 좌상단에 텍스트를 노출해야 하므로 /2
// /2만 했을 경우 좌,상 여백이 없으므로 +0.2
var textOffsetX = (RSeat.SEAT_SIZE / 2.2),
    textOffsetY = (RSeat.SEAT_SIZE / 2.2);

if (common.browser.msie && common.browser.version < 9) {
    // VML 렌더링 시 y좌표가 +2 되는 현상 해결
    textOffsetY -= 2;
}

/**
 * TextBrush 클래스
 * @constructor
 * @param {Object} options 생성옵션
 * @param {Raphael} options.paper 라파엘 페이퍼
 * @extends {Brush}
 * @exports TextBrush
 * @class
 */
function TextBrush(options) {
    Brush.call(this, options);

    this.setViewItem(options.viewItem || new TextItem(this.paper));
    this.setStyle(defaultStyle);
}

/**
 * 디폴트 스타일
 * @type {Object}
 */
var defaultStyle = {
    'font-size': 1,
    'font-family': 'gulim',
    'fill': '#000',
    'text-anchor': 'start'
};

// 상속
common.inherit(TextBrush, Brush);
TextBrush.prototype.brushName = 'Text';

/**********
 * override props
 **********/

TextBrush.prototype.toFront = function() {
    if (common.isExisty(common.pick(this.viewItem, 'pathElement', 'toFront'))) {
        this.viewItem.pathElement.toFront();
    }
};

/**
 * 지정석 인스턴스를 받아 textItem을 설정한다
 * @param {RSeat} seat
 */
TextBrush.prototype.addItemBySeat = function(seat) {
    var textData = this.generateText(seat);
    this.viewItem.add(textData);
};

/**
 * textItem을 지운다
 */
TextBrush.prototype.clear = function() {
    this.viewItem.clear();
};

/**********
 * public props
 **********/

/**
 * Seat를 이용해 Text엘리먼트에 들어갈 text를 반환한다.
 * @param {RSeat} seat
 * @return {object}
 */
TextBrush.prototype.generateText = function(seat) {
    var textData = {};

    textData.x = seat.position.x - textOffsetX;
    textData.y = seat.position.y - textOffsetY;
    textData.str = seat.getText();

    return textData;
};

module.exports = TextBrush;
