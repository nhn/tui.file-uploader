/**
 * @fileoverview 비 지정석 데이터를 path로 변환하는 객체
 * @author @author FE개발팀 김성호 sungho.kim@nhnent.com
 */

'use strict';

var SeatBrush = require('./seatBrush');

/**
 * 비 지정석 브러시 클래스
 * @constructor
 * @param {Object} options
 * @param {Raphael} options.paper 라파엘 paper 객체
 * @extends {SeatBrush}
 * @exports NSeatBrush
 * @class
 */
function NSeatBrush(options) {
    SeatBrush.call(this, options);
    this.setType(options.type);
}

// 상속
ne.util.inherit(NSeatBrush, SeatBrush);
NSeatBrush.prototype.brushName = 'NSeat';

/**********
 * static props
 **********/

NSeatBrush.STYLES = {
    'normal': {
        'stroke': '#FF0000',
        'fill': '#FFFFFF',
        'fill-opacity': 0,
        'stroke-width': 3,
        'cursor': 'pointer'
    },
    'focus': {
        'stroke': '#F0F',
        'fill': '#FFFFFF',
        'fill-opacity': 0,
        'stroke-width': 3,
        'cursor': 'pointer'
    },
    'soldout': {
        'stroke': '#000',
        'opacity': 0.5,
        'stroke-width': 3,
        'cursor': 'default'
    }
};

/**********
 * override props
 **********/

/**
 * 비 지정석의 path string을 생성하여 반환한다
 * @param {NSeat} seat 비지정석 모델 인스턴스
 * @return {string}
 */
NSeatBrush.prototype.generatePath = function(seat) {
    var points = seat.points,
        i = 1,
        cnt = points.length,
        vert = points[0],
        paths = ['M' + vert.x + ',' + vert.y];

    for (;i < cnt; i += 1) {
        vert = points[i];
        paths.push('L' + vert.x + ',' + vert.y);
    }

    return paths.join('') + 'Z';
};

/**********
 * public props
 **********/

/**
 * 브러시가 사용할 스타일을 설정한다
 * @param {string} type 브러시 스타일 코드
 */
NSeatBrush.prototype.setType = function(type) {
    this.setStyle(NSeatBrush.STYLES[type]);
};

module.exports = NSeatBrush;
