/**
 * @fileoverview Seat을이용해 Path로변환하는 객체
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */

'use strict';

var SeatBrush = require('./seatBrush');

/**
 * GradeBrush 클래스
 * @constructor
 * @param {Object} options 생성옵션
 * @param {Raphael} options.paper 라파엘 페이퍼
 * @param {String} options.type 그레이드
 * @exports GradeBrush
 * @class
 */
function GradeBrush(options) {
    SeatBrush.call(this, options);
    this.setType(options.type);
}

//SeatBrush상속
ne.util.inherit(GradeBrush, SeatBrush);
GradeBrush.prototype.brushName = 'Grade';

/**********
 * static prop
 **********/

/**
 * 그레이드의 svg속성정보를 담아두는 객체
 * 런타임에 서버를 통해 업데이트됨
 * @type {object}
 */
GradeBrush.STYLES = {};

/**********
 * method
 **********/

/**
 * 스타일을 지정한다.
 * @param {string} type 그레이드 아이디
 */
GradeBrush.prototype.setType = function(type) {
    this.setStyle(GradeBrush.STYLES[type]);
};

module.exports = GradeBrush;
