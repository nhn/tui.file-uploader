/**
 * @fileoverview Seat을이용해 Path로변환하는 객체
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */

'use strict';

var Brush = require('./brush'),
    PathItem = require('./pathItem');

/**
 * SeatBrush 클래스
 * @constructor
 * @param {Object} options 생성옵션
 * @param {Raphael} options.paper 라파엘 페이퍼
 * @extends {Brush}
 * @exports SeatBrush
 * @class
 */
function SeatBrush(options) {
    Brush.call(this, options);

    this.setViewItem(options.viewItem || new PathItem(this.paper));
    this.setStyle(defaultStyle);
}

/**
 * 디폴트 스타일
 * @type {Object}
 */
var defaultStyle = {
    'stroke-width': 0
};

// 상속
ne.util.inherit(SeatBrush, Brush);
SeatBrush.prototype.brushName = 'Seat';

/**********
 * method
 **********/

SeatBrush.prototype.addItemBySeat = function(seat) {
    var path = this.generatePath(seat);
    this.addPath(path);
};

SeatBrush.prototype.addPath = function(path) {
    this.viewItem.add(path);
};

/**
 * Seat를 이용해 기본적인 Seat패스를 반환한다.
 * @param {Seat} seat
 * @return {string}
 */
SeatBrush.prototype.generatePath = function(seat) {
    if (SeatBrush.useRSeatPathCache && seat.pathCache.normal) {
        return seat.pathCache.normal;
    }

    var points = seat.points,
        arr = [];

    arr.push(points[0].x + ',' + points[0].y);
    arr.push(points[1].x + ',' + points[1].y);
    arr.push(points[2].x + ',' + points[2].y);
    arr.push(points[3].x + ',' + points[3].y);

    var path = seat.pathCache.normal = 'M' + arr.join('L') + 'Z';

    return path;
};

module.exports = SeatBrush;
