/**
 * @fileoverview 같은 속성의 패스를 관리하고 라파엘을 이용해 화면에 그린다.
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */

'use strict';

/**
 * PathItem 클래스
 * @constructor
 * @param {Raphael} paper 라파엘 페이퍼
 * @exports PathItem
 * @class
 */
function PathItem(paper) {
    /**
     * 라파엘 페이퍼
     * @type {Raphael}
     */
    this.paper = paper;

    /**
     * 패스 스트링
     * @type {String}
     */
    this.pathStr = '';

    /**
     * 패스 엘리먼트
     * @type {HTMLElement}
     */
    this.pathElement = null;

    /**
     * svg 속성 값
     * @type {Object}
     */
    this.attrs = null;
}

/**********
 * method
 **********/

/**
 * path를 추가한다.
 * @param {String} path 그려져야할 패스스트링 추후 모와져서 한 Path로 그려짐
 */
PathItem.prototype.add = function(path) {
    this.pathStr += path;
};

/**
 * 라파엘 엘리먼트의 속성으로 지정될 객체를 셋팅한다.
 * @param {object} attrs 속성이 정의된 객체
 */
PathItem.prototype.setAttrs = function(attrs) {
    this.attrs = attrs;
};

/**
 * 라파엘의 path를 이용해 paper에 그린다.
 */
PathItem.prototype.render = function() {
    //FIXME: path 가 'null'이 되는 순간이 있다...
    if (this.pathStr === 'null') {
        return;
    }

    this.pathElement = this.paper.path(this.pathStr);
    this.pathElement.attr(this.attrs);
};

/**
 * pathItem을 초기화한다.
 */
PathItem.prototype.clear = function() {
    this.pathStr = '';
    this.hide();
};

/**
 * path엘리먼트를 지운다.
 */
PathItem.prototype.hide = function() {
    if (this.pathElement) {
        this.pathElement.remove();
    }
};

/**
 * 해당 패스 엘리먼트를 맨 위로 올린다
 */
PathItem.prototype.toFront = function() {
    if (this.pathElement) {
        this.pathElement.toFront();
    }
};

module.exports = PathItem;
