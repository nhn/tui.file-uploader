/**
 * @fileoverview 좌석선택효과 브러시
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */


'use strict';

var SeatBrush = require('./seatBrush'),
    NSeatBrush = require('./nSeatBrush');

/**
 * 좌석선택효과 브러시
 * @param {Object} options
 * @constructor
 * @extends {SeatBrush}
 * @exports SelectSeatBrush
 * @class
 */
function SelectSeatBrush(options) {
    SeatBrush.call(this, options);
    this.setStyle(SelectSeatBrush.STYLES);
}

/**
 * 상속
 */
ne.util.inherit(SelectSeatBrush, SeatBrush);
SelectSeatBrush.prototype.brushName = 'SelectSeat';

/**********
 * static props
 **********/

SelectSeatBrush.STYLES = {
    'stroke-width': 2,
    'stroke': '#000000',
    'corsor': 'pointer'
};

/**********
 * override props
 **********/

/**
 * 지정석, 비지정석의 선택효과 path를 생성하여 반환하는 메서드
 * @param {(RSeat|NSeat)} seat
 * @return {string}
 */
SelectSeatBrush.prototype.generatePath = function(seat) {
    if (seat.name === 'RSeat') {
        return SeatBrush.prototype.generatePath(seat);
    } else {
        return NSeatBrush.prototype.generatePath(seat);
    }
};

module.exports = SelectSeatBrush;
