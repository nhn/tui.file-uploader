/**
 * @fileoverview Seat을이용해 Path로변환하는 객체
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */

'use strict';

var SeatBrush = require('./seatBrush');

/**
 * SellingTypeBrush 클래스
 * @param {Object} options 생성옵션
 * @param {Raphael} options.paper 라파엘 페이퍼
 * @param {String} options.type 타입아이디
 * @constructor
 * @extends SeatBrush
 * @exports SellingTypeBrush
 * @class
 */
function SellingTypeBrush(options) {
    SeatBrush.call(this, options);
    if (ne.util.isExisty(ne.util.pick(options, 'type'))) {
        this.setStyle(SellingTypeBrush.STYLES[options.type]);
        this.setPathGenerateMethod(options.type);
    }
}

//SeatBrush상속
ne.util.inherit(SellingTypeBrush, SeatBrush);
SellingTypeBrush.prototype.brushName = 'SellingType';


/**********
 * static props
 **********/

SellingTypeBrush.STYLES = {};

/**********
 * public props
 **********/

/**
 * 좌석 타입에 따른 path 생성 메서드를 분기처리한다
 * @param {string} type 할당처코드
 */
SellingTypeBrush.prototype.setPathGenerateMethod = function(type) {
    switch (type) {
        case 'FIELD':
            this.generatePath = this.getPathField;
            break;
        case 'TICKET':
            this.generatePath = this.getPathTicket;
            break;
        case 'POSTPONE':
            this.generatePath = this.getPathPostpone;
            break;
        case 'CALL':
            this.generatePath = this.getPathCallcenter;
            break;
        case 'AGENCY':
            this.generatePath = this.getPathAgency;
            break;
        // no default
    }
};

/**
 * 기획사
 * @param {RSeat} seat
 * @return {string}
 */
SellingTypeBrush.prototype.getPathAgency = function(seat) {
    if (SeatBrush.useRSeatPathCache && seat.pathCache.agency) {
        return seat.pathCache.agency;
    }

    var nw = seat.points[0],
        sw = seat.points[1],
        se = seat.points[2],
        ne = seat.points[3],
        top,
        arr;

    top = nw.add(ne.subtract(nw)._divideBy(2));

    arr = [
        sw.x + ',' + sw.y,
        top.x + ',' + top.y,
        se.x + ',' + se.y
    ];

    var path = seat.pathCache.agency = 'M' + arr.join('L');

    return path;
};

/**
 * 현장
 * @param {RSeat} seat
 * @return {string}
 */
SellingTypeBrush.prototype.getPathField = function(seat) {
    if (SeatBrush.useRSeatPathCache && seat.pathCache.field) {
        return seat.pathCache.field;
    }

    var nw = seat.points[0],
        sw = seat.points[1],
        se = seat.points[2],
        ne = seat.points[3],
        top,
        right,
        bottom,
        left,
        arr;

    top = nw.add(ne.subtract(nw)._divideBy(2));
    right = ne.add(se.subtract(ne)._divideBy(2));
    bottom = se.add(sw.subtract(se)._divideBy(2));
    left = sw.add(nw.subtract(sw)._divideBy(2));

    arr = [
        top.x + ',' + top.y,
        right.x + ',' + right.y,
        bottom.x + ',' + bottom.y,
        left.x + ',' + left.y
    ];

    var path = seat.pathCache.field = 'M' + arr.join('L') + 'Z';

    return path;
};

/**
 * 발권
 * @param {RSeat} seat
 * @return {string}
 */
SellingTypeBrush.prototype.getPathTicket = function(seat) {
    if (SeatBrush.useRSeatPathCache && seat.pathCache.ticket) {
        return seat.pathCache.ticket;
    }

    var nw = seat.points[0],
        sw = seat.points[1],
        se = seat.points[2],
        ne = seat.points[3],
        diffWest = nw.subtract(sw)._divideBy(4),
        diffEast = ne.subtract(se)._divideBy(4),
        points = [],
        i = 1,
        arr;

    do {
        points.push(nw.subtract(diffWest.multiplyBy(i)));
        points.push(ne.subtract(diffEast.multiplyBy(i)));
        i += 1;
    }
    while (i < 4);

    arr = [
        'M',
        [
            points[0].x + ',' + points[0].y,
            points[1].x + ',' + points[1].y
        ].join('L'),
        'M',
        [
            points[4].x + ',' + points[4].y,
            points[5].x + ',' + points[5].y
        ].join('L')
    ];

    var path = seat.pathCache.ticket = arr.join('');

    return path;
};

/**
 * 보류
 * @param {RSeat} seat
 * @return {string}
 */
SellingTypeBrush.prototype.getPathPostpone = function(seat) {
    if (SeatBrush.useRSeatPathCache && seat.pathCache.postpone) {
        return seat.pathCache.postpone;
    }

    var points = seat.points,
        arr;

    arr = [
        points[0].x + ',' + points[0].y,
        points[2].x + ',' + points[2].y,
        points[1].x + ',' + points[1].y,
        points[3].x + ',' + points[3].y
    ];

    var path = seat.pathCache.postpone = 'M' + arr.join('L');

    return path;
};

/**
 * 콜센터
 * @param {RSeat} seat
 * @return {string}
 */
SellingTypeBrush.prototype.getPathCallcenter = function(seat) {
    if (SeatBrush.useRSeatPathCache && seat.pathCache.callcenter) {
        return seat.pathCache.callcenter;
    }

    var nw = seat.points[0],
        ne = seat.points[3],
        se = seat.points[2],
        top,
        right,
        arr;

    top = nw.add(ne.subtract(nw)._divideBy(2));
    right = ne.add(se.subtract(ne)._divideBy(2));

    arr = [
        top.x + ',' + top.y,
        seat.position.x + ',' + seat.position.y,
        right.x + ',' + right.y
    ];

    var path = seat.pathCache.callcenter = 'M' + arr.join('L');

    return path;
};

module.exports = SellingTypeBrush;
