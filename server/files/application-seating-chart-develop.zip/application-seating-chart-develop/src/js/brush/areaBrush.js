/**
 * @fileoverview 영역 좌표를 path로 변환하는 객체
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var Brush = require('./brush'),
    PathItem = require('./pathItem');

/**
 * 영역좌표 브러시
 * @param {object} options
 * @constructor
 * @extends {Brush}
 * @exports AreaBrush
 * @class
 */
function AreaBrush(options) {
    Brush.call(this, options);
    this.setViewItem(options.viewItem || new PathItem(this.paper));
    this.setStyle(AreaBrush.STYLES.normal);
}

/**
 * 상속
 */
ne.util.inherit(AreaBrush, Brush);
AreaBrush.prototype.brushName = 'Area';

/**********
 * static props
 **********/

AreaBrush.STYLES = {
    'normal': {
        'stroke': '#FFFFFF',
        'stroke-width': 1,
        'fill': '#FFFFFF',
        'opacity': 0,
        'cursor': 'hand'
    }
};

/**********
 * override methods
 **********/

/**
 * Seat 모델을 받아 패스를 생성한 후 viewItem에게 전달한다
 * @param {Area} seat
 */
AreaBrush.prototype.addItemBySeat = function(seat) {
    var path = this.generatePath(seat);
    this.addPath(path);
};

/**
 * path를 받아 viewItem에 세팅한다
 * @param {string} path
 */
AreaBrush.prototype.addPath = function(path) {
    this.viewItem.add(path);
};

/**
 * 인자로 넘어온 영역 모델 클래스를 토대로 path를 생성한다
 * @param {Area} area 영역 모델 클래스 인스턴스
 * @return {string}
 */
AreaBrush.prototype.generatePath = function(area) {
    var points = area.points,
        i = 1,
        cnt = points.length,
        vert = points[0],
        paths = ['M' + vert[0] + ',' + vert[1]];

    for (;i < cnt; i += 1) {
        vert = points[i];
        paths.push('L' + vert[0] + ',' + vert[1]);
    }
    vert = points[0];

    paths.push('L' + vert[0] + ',' + vert[1]);

    return paths.join('') + 'Z';
};

module.exports = AreaBrush;
