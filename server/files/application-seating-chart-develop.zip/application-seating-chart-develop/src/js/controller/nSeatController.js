/**
 * @fileoverview 비 지정석 데이터를 다루는 컨트롤러 클래스
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var SeatLayerController = require('./seatLayerController'),
    NSeatLayer = require('../layer/nSeatLayer');

/**
 * 비 지정석 데이터를 다루는 컨트롤러 클래스
 * @constructor
 * @param {Object} options
 * @param {Raphael} options.paper 라파엘 페이퍼
 * @extends {SeatLayerController}
 * @exports NSeatController
 * @class
 */
function NSeatController(options) {
    SeatLayerController.call(this, options);

    this.addSeatLayer('default');
}

// 상속
ne.util.inherit(NSeatController, SeatLayerController);

NSeatController.prototype.SeatLayerConstructor = NSeatLayer;

/**********
 * override props
 **********/

/**
 * 서버 API결과 중 비지정석 데이터 세팅
 * @param {object[]} nSeatData
 */
NSeatController.prototype.setData = function(nSeatData) {
    this.doWhenSeatLayerExist('default', function(sl) {
        sl.setData(nSeatData);
        this.seats.merge(sl.seats);
    }, this);
};

module.exports = NSeatController;
