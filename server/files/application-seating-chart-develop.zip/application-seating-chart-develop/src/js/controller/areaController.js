/**
 * @fileoverview 영역 좌표 존재 시 영역 svg를 그리는 컨트롤러
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var SeatLayerController = require('./seatLayerController'),
    AreaLayer = require('../layer/areaLayer');

/**
 *
 * @param {object} options
 * @constructor
 * @extends SeatLayerController
 */
function AreaController(options) {
    SeatLayerController.call(this, options);
}

/*
  inheritance
 */
ne.util.inherit(AreaController, SeatLayerController);

AreaController.prototype.SeatLayerConstructor = AreaLayer;

/**********
 * override props
 **********/

/**
 * 컨트롤러가 사용하는 seatLayer의 ID를 반환한다
 * @returns {string}
 */
AreaController.prototype.getSeatLayerID = function() {
    return 'normal';
};

/**
 * 기본 도면정보 중 areaData를 받아 프로퍼티를 세팅
 * @param {object} areaData
 */
AreaController.prototype.setData = function(areaData) {
    var sl = this.getSeatLayer('normal');

    if (!sl) {
        sl = this.addSeatLayer('normal');
    }

    sl.setData(areaData);
    this.seats.merge(sl.seats);
};

/**********
 * public props
 **********/

/**
 * 좌표를 인자로 받아 포함되는 영역 리스트를 반환하는 메서드
 * @param {number} x
 * @param {number} y
 */
AreaController.prototype.requestAreaContainPoint = function(x, y) {
    var layer = this.getSeatLayer('normal'),
        seats = [];

    layer.eachSeat(function(seat) {
        if (seat.isContain(x, y)) {
            seats.push(seat);
        }
    });

    return seats;
};

module.exports = AreaController;
