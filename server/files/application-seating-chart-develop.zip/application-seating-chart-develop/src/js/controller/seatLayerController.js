/**
 * @fileoverview Map에서 이벤트를 받아 SeatLayer들을 관리하는 객체가 정의 되어있다
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */

'use strict';

var etc = require('../etc'),
    SeatLayer = require('../layer/seatLayer');

var common = ne.util;

/**
 * SeatLayerController 클래스
 * @param {Object} options 생성 옵션
 * @param {Raphael} options.paper 라파엘 페이퍼
 * @param {SeatingChart} options.chart 드로잉 맵 인스턴스
 * @exports SeatLayerController
 * @class
 * @mixes CustomEvents
 */
function SeatLayerController(options) {
    /**
     * 라파엘 페이퍼
     * @type {Raphael}
     */
    this.paper = options.paper;
    this.zoomLevel = options.zoomLevel;

    /**
     * @type {HashMap}
     */
    this.seats = new common.HashMap();

    /**
     * @type {HashMap}
     */
    this.seatLayers = new common.HashMap();

    this.chart = options.chart;
}

common.CustomEvents.mixin(SeatLayerController);

/**********
 * method
 **********/

/**
 * SeatLayerController가 사용하는 SeatLayer 컨스트럭터
 * @type {*}
 */
SeatLayerController.prototype.SeatLayerConstructor = SeatLayer;

/**
 * Seat을 추가한다.
 * Seat이 들어가야할 SeatLayer선택은 getSeatLayerIDFromSeat통해 얻어진다
 * @param {(Seat|Seat[])} seats
 */
SeatLayerController.prototype.addSeat = function(seats) {
    var ownSeats = this.seats;

    seats = common.isArray(seats) ? seats : [seats];

    common.forEach(seats, function(seat) {
        var slid = this.getSeatLayerID(seat);
        this.addSeatToSeatLayer(slid, seat);
        ownSeats.set(seat.sid, seat);
    }, this);
};

/**
 * 소유하고 있는 좌석을 삭제한다
 * @param {Seat[]} seats
 */
SeatLayerController.prototype.removeSeat = function(seats) {
    var ownSeats = this.seats;

    seats = common.isArray(seats) ? seats : [seats];

    common.forEachArray(seats, function(seat) {
        if (ownSeats.has(seat.sid)) {
            var slid = this.getSeatLayerID(seat);

            this.doWhenSeatLayerExist(slid, function(sl) {
                sl.removeSeat(seat);
                ownSeats.remove(seat.getID());
            });
        }
    }, this);
};

/**
 * 소유하고 있는 모든 좌석을 삭제한다
 */
SeatLayerController.prototype.removeAllSeat = function() {
    this.eachSeatLayer(function(sl) {
        sl.removeAllSeat();
    });
    this.seats.removeAll();
};

/**
 * 소유한 좌석들을 반환
 * @param {string[]} [sid] 인자로 넘긴 sid에 해당하는 좌석만 반환
 * @returns {Array}
 */
SeatLayerController.prototype.getSeats = function(sid) {
    var ownSeats = this.seats,
        seats = [];

    if (common.isExisty(sid)) {
        sid = common.isArray(sid) ? sid : [sid];

        common.forEachArray(sid, function(_sid) {
            var seat = ownSeats.get(_sid);
            if (seat) {
                this.doWhenSeatLayerExist(seat.slid, function() {
                    seats.push(seat);
                });
            }
        }, this);
    } else {
        this.eachSeatLayer(function(sl) {
            sl.eachSeat(function(seat) {
                seats.push(seat);
            });
        });
    }

    return seats;
};

/**
 * 좌표를 받아 그 좌표를 포함하는 좌석들의 배열을 반환한다
 * @param {number} x
 * @param {number} y
 * @returns {Array}
 */
SeatLayerController.prototype.getSeatsContainPoint = function(x, y) {
    var result = [];

    this.eachSeat(function(seat) {
        if (seat.isContain(x, y)) {
            result.push(seat);
        }
    });

    return result;
};

/**
 * 사각형 좌표에 포함되는 좌석들의 배열을 반환한다
 * @param {number} x1
 * @param {number} y1
 * @param {number} x2
 * @param {number} y2
 * @returns {Array}
 */
SeatLayerController.prototype.getSeatsInsideRect = function(x1, y1, x2, y2) {
    var result = [];

    this.eachSeat(function(seat) {
        if (seat.isInsideRect(x1, y1, x2, y2)) {
            result.push(seat);
        }
    });

    return result;
};

/**
 * Seat을 판단하여 소속될 SeatLayerID를 리턴해주는 메소드
 * 일반적으로 SeatLayerController를 상속하는 객체들은 오버라이드해서 사용한다
 * SeatLayer가 한개만 필요한경우는 그대로 사용 가능
 * @abstract
 * @param {Seat} [seat]
 * @returns {String}
 */
SeatLayerController.prototype.getSeatLayerID = function(seat) {
    return 'default';
};

/**
 * SeatLayer를 추가한다.
 * @param {String} seatLayerID
 * @param {Object|SeatLayer} [options]
 * @returns {*}
 */
SeatLayerController.prototype.addSeatLayer = function(seatLayerID, options) {
    var seatLayer;

    if (!(options instanceof SeatLayer)) {
        if (!options) {
            options = {};
        }

        options.paper = options.paper || this.paper;
        options.slid = seatLayerID;
        seatLayer = new this.SeatLayerConstructor(options);
    }
    else {
        seatLayer = options;
        seatLayer.slid = seatLayerID;
    }

    seatLayer.zoomReactor.react(this.zoomLevel);
    this.seatLayers.set(seatLayerID, seatLayer);

    return seatLayer;
};

/**
 * SeatLayer를 제거한다 - 포함된 좌석 역시 전부 제거한다
 * @param {(string|string[])} seatLayerID
 */
SeatLayerController.prototype.removeSeatLayer = function(seatLayerID) {
    var ownSeats = this.seats,
        ownSeatLayers = this.seatLayers;

    if (!common.isArray(seatLayerID)) {
        seatLayerID = common.toArray(arguments);
    }

    common.forEachArray(seatLayerID, function(slid) {
        this.doWhenSeatLayerExist(slid, function(sl) {
            sl.eachSeat(function(seat) {
                ownSeats.removeByKey(seat.sid);
            });
            sl.removeAllSeat();
            sl.clear();
            ownSeatLayers.removeByKey(slid);
        });
    }, this);
};

/**
 * ID로 SeatLayer를 리턴한다.
 * @param {String} seatLayerID
 * @returns {SeatLayer}
 */
SeatLayerController.prototype.getSeatLayer = function(seatLayerID) {
    return this.seatLayers.get(seatLayerID);
};

/**
 * 인자로 넘긴 slid에 해당하는 SeatLayer존재 시 함수를 실행한다
 * @param {string} slid
 * @param {function} func
 * @param {*} [context]
 */
SeatLayerController.prototype.doWhenSeatLayerExist = function(slid, func, context) {
    var seatLayer = this.seatLayers.get(slid);

    if (common.isExisty(seatLayer)) {
        func.call(context || this, seatLayer, slid);
    }
};

/**
 * SLID와 Seat을 넘겨 SeatLayer에 Seat을 추가한다.
 * SeatLayer가 존재하지 않을때는 직접 만든뒤 Seat을 추가한다.
 * @param {String} seatLayerID
 * @param {Seat} seat
 */
SeatLayerController.prototype.addSeatToSeatLayer = function(seatLayerID, seat) {
    var seatLayer = this.getSeatLayer(seatLayerID);

    if (!seatLayer) {
        seatLayer = this.addSeatLayer(seatLayerID);
    }

    seatLayer.addSeat(seat);
};

/**
 * 콜백을 넘겨 seats를 순회한다.
 * @param {Function} func
 */
SeatLayerController.prototype.eachSeat = function(func) {
    this.seats.each(func);
};

/**
 * 콜백을 넘겨 seatLayers를 순회한다.
 * @param {Function} func
 */
SeatLayerController.prototype.eachSeatLayer = function(func) {
    this.seatLayers.each(func);
};

/**
 * 등록된 SeatLayer의 render를 수행한다.
 */
SeatLayerController.prototype.render = function() {
    this.eachSeatLayer(function(seatLayer) {
        seatLayer.render();
    });
};

/**
 * 등록된 SeatLayer의 update를 수행한다.
 * @param {boolean} [force] true일 경우 변경여부에 상관없이 강제로 업데이트한다
 */
SeatLayerController.prototype.update = function(force) {
    this.eachSeatLayer(function(seatLayer) {
        seatLayer.update(force);
    });
};

/**
 * API데이터를 토대로 SeatLayer들을 셋팅한다.
 * @param {Object} seatLayerData
 * @param {Object} [seatSoldoutMap] 좌석 판매 여부 데이터
 */
SeatLayerController.prototype.setData = function(seatLayerData, seatSoldoutMap) {
    common.forEach(seatLayerData, function(data, seatLayerID) {
        var seatLayer = this.getSeatLayer(seatLayerID);

        if (!seatLayer) {
            seatLayer = this.addSeatLayer(seatLayerID);
        }

        if (SeatLayerController.useGridCache) {
            data = JSON.parse(data);
        }

        seatLayer.setData(data, seatSoldoutMap);
        this.seats.merge(seatLayer.seats);
    }, this);
};

/**
 * 각 SeatLayer들의 ZoomReactor를 작동시킨다
 * @param {number} newZoom map의 줌 레벨
 */
SeatLayerController.prototype.ensureZoom = function(newZoom) {
    this.zoomLevel = newZoom;

    this.eachSeatLayer(function(sl) {
        sl.zoomReactor.react(newZoom);
    });
};

module.exports = SeatLayerController;
