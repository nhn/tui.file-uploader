/**
 * @fileoverview 선택된 좌석에 대한 표현계층 컨트롤러
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var SelectSeatLayer = require('../layer/selectSeatLayer'),
    SelectNSeatLayer = require('../layer/selectNSeatLayer'),

    SeatLayerController = require('./seatLayerController');

var common = ne.util,
    Rect = ne.component.SimpleMap.Rect;

/**
 * @constructor
 * @param {object} options
 * @param {Raphael} options.paper
 * @extends {SeatLayerController}
 */
function SelectSeatController(options) {
    SeatLayerController.call(this, options);

    /**
     * 선택 좌석들의 사각 면적을 저장하여 그룹회전 축 좌표로 사용하기 위한 프로퍼티
     * @type {(Rect|null)}
     */
    this.groupBound = null;

    /**
     * 선택된 비지정석 갯수
     * @type {number}
     */
    this.nSeatCount = 0;

    /**
     * 선택된 지정석 갯수
     * @type {number}
     */
    this.rSeatCount = 0;

    this.setSeatLayer();
}

var _super = SeatLayerController.prototype;

common.inherit(SelectSeatController, SeatLayerController);

/**********
 * static props
 **********/

/**
 * 좌석 수정 타입
 * @type {{ROTATE: number, POSITION: number, MAPINFO: number, GRADE: number, SELL_TYPE: number}}
 */
SelectSeatController.UPDATE = {
    ROTATE: 1,
    POSITION: 2,
    MAPINFO: 3,
    GRADE: 4,
    SELL_TYPE: 5
};

/**
 * 좌석 회전 방법
 * @type {{EACH: number, GROUP: number}}
 */
SelectSeatController.ROTATE_METHOD = {
    EACH: 1,
    GROUP: 2
};

/**********
 * override methods
 **********/

SelectSeatController.prototype.removeSeat = function(seats) {
    SeatLayerController.prototype.removeSeat.call(this, seats);

    common.forEachArray(seats, function(seat) {
        if (seat.name === 'RSeat') {
            this.rSeatCount -= 1;
        } else {
            this.nSeatCount -= 1;
        }
    }, this);
};

/**
 * 좌표와 좌석타입을 받는다
 * 인자에 해당하는 좌석타입 중 그 좌표를 포함하는 좌석들의 배열을 반환
 * @param {number} x
 * @param {number} y
 * @param {SEAT_TYPE} [seatType]
 * @returns {Seat[]}
 */
SelectSeatController.prototype.getSeatsContainPoint = function(x, y, seatType) {
    if (!common.isExisty(seatType)) {
        return _super.getSeatsContainPoint.call(this, x, y);
    }

    var result = [],
        slName = this.getSLNameByType(seatType);

    this.doWhenSeatLayerExist(slName, function(sl) {
        sl.eachSeat(function(seat) {
            if (seat.isContain(x, y)) {
                result.push(seat);
            }
        });
    });

    return result;
};

/**
 * 사각형 좌표에 포함되는 좌석들의 배열을 반환한다
 * @param {number} x1
 * @param {number} y1
 * @param {number} x2
 * @param {number} y2
 * @param {SEAT_TYPE} [seatType]
 * @returns {Array}
 */
SelectSeatController.prototype.getSeatsInsideRect = function(x1, y1, x2, y2, seatType) {
    if (!common.isExisty(seatType)) {
        return _super.getSeatsInsideRect.call(this, x1, y1, x2, y2);
    }

    var result = [],
        slName = this.getSLNameByType(seatType);

    this.doWhenSeatLayerExist(slName, function(sl) {
        sl.eachSeat(function(seat) {
            if (seat.isInsideRect(x1, y1, x2, y2)) {
                result.push(seat);
            }
        });
    });

    return result;
};

/**
 * 소유한 좌석들을 반환
 * @param {string[]} [sid] 인자로 넘긴 sid에 해당하는 좌석만 반환
 * @param {SEAT_TYPE} [seatType] 좌석 타입
 * @returns {Seat[]}
 */
SelectSeatController.prototype.getSeats = function(sid, seatType) {
    if (!common.isExisty(seatType)) {
        return _super.getSeats.call(this, sid);
    }

    var slName = this.getSLNameByType(seatType),
        result = [];

    this.doWhenSeatLayerExist(slName, function(sl) {
        var slSeats = sl.seats;

        if (common.isExisty(sid)) {
            sid = common.isArray(sid) ? sid : [sid];
            common.forEachArray(sid, function(_sid) {
                if (slSeats.has(_sid)) {
                    result.push(slSeats.get(_sid));
                }
            }, this);
        } else {
            slSeats.each(function(seat) {
                result.push(seat);
            });
        }
    });

    return result;
};

/**
 * 지정석, 비지정석 타입에 따라 seatLayer ID를 반환하는 메서드
 * @param {(RSeat|NSeat)} seat
 */
SelectSeatController.prototype.getSeatLayerID = function(seat) {
    return (seat.name === 'NSeat') ? 'nonreserved' : 'reserved';
};

/**
 * API데이터를 토대로 지정석, 비지정석 선택 레이어를 세팅한다
 * @param {(RSeat[]|NSeat[])} seats
 */
SelectSeatController.prototype.setData = function(seats) {
    var ownSeats = this.seats,
        slid,
        layer;

    seats = common.isArray(seats) ? seats : [seats];

    common.forEachArray(seats, function(seat) {
        // API 데이터이므로 name으로 구별 불가
        if ('position' in seat) {
            this.rSeatCount += 1;
        } else {
            this.nSeatCount += 1;
        }

        slid = ('position' in seat) ? 'reserved' : 'nonreserved';
        layer = this.getSeatLayer(slid);

        layer.setData([seat]);
        ownSeats.merge(layer.seats);
    }, this);

    this.updateSeatBound();
};

/**
 * 선택좌석 컨트롤러의 렌더 결과물을 다시 렌더링한다
 * @param {boolean} force 수정사항 존재 여부와 무관하게 강제로 모든 레이어를 업데이트한다
 */
SelectSeatController.prototype.update = function(force) {
    force = common.isExisty(force) ? force : false;

    var reserved = this.getSeatLayer('reserved'),
        nonreserved = this.getSeatLayer('nonreserved');

    if (force) {
        reserved.dirty();
        nonreserved.dirty();
    }

    SeatLayerController.prototype.update.call(this);

    reserved.seatDraggable();
};

SelectSeatController.prototype.ensureZoom = function(zoomLevel) {
    SeatLayerController.prototype.ensureZoom.call(this, zoomLevel);

    var rSeatLayer = this.getSeatLayer('reserved');
    if (rSeatLayer.seats.length) {
        rSeatLayer.refreshSetElement();
    }
};

SelectSeatController.prototype.addSeat = function(seats) {
    var self = this,
        seatLayerID;

    seats = common.isArray(seats) ? seats : [seats];

    common.forEach(seats, function(seat) {
        if (seat.name === 'RSeat') {
            self.rSeatCount += 1;
        } else {
            self.nSeatCount += 1;
        }

        seatLayerID = self.getSeatLayerID(seat);
        self.seats.set(seat.sid, seat);
        self.addSeatToSeatLayer(seatLayerID, seat);
    });

    this.updateSeatBound();
};

/**********
 * public methods
 **********/

SelectSeatController.prototype.getSLNameByType = function(seatType) {
    return seatType === 1 ? 'reserved' : 'nonreserved';
};

SelectSeatController.prototype.updateSeatBound = function() {
    var ownSeats = this.seats,
        seatBound = new Rect();

    ownSeats.each(function(seat) {
        if (seat.name === 'RSeat') {
            seatBound.extend(seat.position);
        } else {
            seatBound.extend(seat.bound.getCenter());
        }
    });

    this.groupBound = seatBound;
};

/**
 * 선택된 좌석 전부를 삭제하는 메서드
 */
SelectSeatController.prototype.deleteAllSeats = function() {
    var seatsToDelete = this.getSeats();
    this.removeAllSeat();

    this.groupBound = new Rect();

    this.update(true);

    this.rSeatCount = 0;
    this.nSeatCount = 0;

    return seatsToDelete;
};

/**
 * !주의! 지정석 전용
 *
 * 선택된 지정석의 선택좌석 객체를 인자 hashmap으로 변경한다
 *
 * 좌석정보 매핑 시 사용
 *
 * @param {HashMap} hashMap
 */
SelectSeatController.prototype.replaceAllRSeats = function(hashMap) {
    this.getSeatLayer('reserved').seats = hashMap;
    this.seats.removeAll();
    this.seats.merge(hashMap);
};

/**
 * 선택 효과용 표현 계층을 초기화하는 메서드
 */
SelectSeatController.prototype.setSeatLayer = function() {
    var defaultOption = { paper: this.paper };
    this.addSeatLayer('reserved', new SelectSeatLayer(defaultOption));
    this.addSeatLayer('nonreserved', new SelectNSeatLayer(defaultOption));
};

/**
 * 좌석 이동 처리를 서버에 질의한다
 * @param {number} diffX X벡터값
 * @param {number} diffY Y벡터값
 */
SelectSeatController.prototype.moveSeats = function(diffX, diffY) {
    this.chart.fire('moveSeat', SelectSeatController.UPDATE.POSITION, diffX, diffY);
};

/**
 * 선택좌석 중 사각 좌표 범위에 해당하는 지정석의ID를 반환
 * @param {number} x1
 * @param {number} y1
 * @param {number} x2
 * @param {number} y2
 */
SelectSeatController.prototype.getSIDInsideRect = function(x1, y1, x2, y2) {
    var reserved = this.getSeatLayer('reserved'),
        sid = [];

    reserved.eachSeat(function(seat) {
        if (seat.isInsideRect(x1, y1, x2, y2)) {
            sid.push(seat.getID());
        }
    });

    return sid;
};

SelectSeatController.prototype.getSIDContainPoint = function(x, y) {
    var reserved = this.getSeatLayer('reserved'),
        sid = [];

    reserved.eachSeat(function(seat) {
        if (seat.isContain(x, y)) {
            sid.push(seat.getID());
        }
    });

    sid.sort(function(a, b) {
        return a.sid - b.sid;
    });

    return sid;
};

/**
 * 좌석을 회전하는 메서드
 * @param {number} deg
 * @param {ROTATE_METHOD} method
 */
SelectSeatController.prototype.rotateSeats = function(deg, method) {
    var center = null;

    method = method || SelectSeatController.ROTATE_METHOD.EACH;

    if (method === SelectSeatController.ROTATE_METHOD.GROUP) {
        center = this.groupBound.getCenter();
    }

    this.eachSeatLayer(function(layer) {
        layer.eachSeat(function(seat) {
            seat.rotate(deg, center);
            layer.dirty();
        });
    });

    this.update();
};

module.exports = SelectSeatController;
