/**
 * @fileoverview 좌석 path의 렌더링 단위인 grid를 관리하는 컨트롤러 모듈
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */

'use strict';

var RSeat = require('../model/rSeat'),
    SeatLayerController = require('./seatLayerController'),
    GridLayer = require('../layer/gridLayer'),
    InteractBroker = require('../interactBroker');

var common = ne.util,
    simplemap = ne.component.SimpleMap,
    Point = simplemap.Point,
    Rect = simplemap.Rect,
    mfloor = Math.floor;

/**
 * @param {Object} options 생성 옵션
 * @param {number} options.gridSize 나눠서 렌더링하게 될 격자의 크기
 * @constructor
 * @extends SeatLayerController
 */
function GridController(options) {
    SeatLayerController.call(this, options);

    /**
     * 그리드의 가로세로 px
     * @type {number}
     */
    this.gridSize = options.gridSize || 200;

    /**
     * 모서리 당 최대 그리드 갯수를 저장
     * @type {number}
     */
    this.gridsInSide = Math.ceil(this.chart.options.mapSize / this.gridSize);

    /**
     * 서버로부터 지정석 정보를 받은 경우 다시 요청하는 것을 방지하기 위해 이 곳에 마킹해둔다
     *
     * 속도를 위해 배열보다 객체를 사용
     * @type {Object.<string, boolean>}
     */
    this.fetchedGridIDFromServer = {};

    /**
     * 현재 뷰포트에 보여지고 있는 grid 저장
     * @type {object.<string, GridLayer>}
     */
    this.rendered = {};
}

//SeatLayerController상속
common.inherit(GridController, SeatLayerController);

/**
 * GridController는 SeatLayer로 Grid를 사용한다.
 * @type {SeatLayer}
 */
GridController.prototype.SeatLayerConstructor = GridLayer;

/**********
 * method
 **********/
/**
 * x,y인덱스를 넘겨 해당 Grid를 받는다.
 * @param {(Number|string)} xIndex
 * @param {Number} [yIndex]
 * @returns {(SeatLayer|GridLayer)}
 */
GridController.prototype.getGrid = function(xIndex, yIndex) {
    var gridID;
    gridID = arguments.length > 1 ? this.encodeGridID(xIndex, yIndex) : xIndex;
    return this.getSeatLayer(gridID);
};

/**
 * x, y인덱스를 받아 grid를 생성한다 (좌표 계산 안함)
 * @param {Number} xIndex
 * @param {Number} yIndex
 * @param {Object} options
 * @returns {*}
 */
GridController.prototype.addGrid = function(xIndex, yIndex, options) {
    return this.addSeatLayer(this.encodeGridID(xIndex, yIndex), options);
};

 /**
 * x인덱스와 y인덱스를 입력받아 "x:y"형식의 스트링을 만들어 준다.
 * @param {Number|String} xIndex
 * @param {Number|String} yIndex
 * @returns {String}
 */
GridController.prototype.encodeGridID = function(xIndex, yIndex) {
    return xIndex + ':' + yIndex;
};

/**
 * gridID String을 입력받아 x,y인덱스를 어레이로 리턴한다.
 * @param {(string|Array)} gridID
 * @returns {Number[]} [xIndex, yIndex];
 */
GridController.prototype.decodeGridID = function(gridID) {
    gridID = gridID.split(':');
    return [parseInt(gridID[0], 10), parseInt(gridID[1], 10)];
};

/**
 * 줌 레벨 별 달라지는 grid의 실제 크기를 반환한다
 * @return {number}
 */
GridController.prototype.getScaledGridSize = function() {
    return this.gridSize * this.chart.getScaleRatio();
};

/**
* Seat으로 소속되어야할 GridID를 구한다.
* @param {RSeat} seat
* @returns {string}
* @override
*/
GridController.prototype.getSeatLayerID = function(seat) {
    return this.getGridIDByPoint(seat.position.x, seat.position.y);
};

/**
 * x,y 좌표를 넘겨 해당 좌표의 포인트를 포함하는 GridID를 리턴한다
 *
 * x, y 좌표가 grid 가장자리 (좌석사이즈 / 2)px 이내일 경우 해당 방향 그리드도 같이 반환한다
 * @param {number} x
 * @param {number} y
 * @return {string}
 */
GridController.prototype.getGridIDByPoint = function(x, y) {
    var gridIndex = this.getGridIndexByPoint(x, y);
    return this.encodeGridID(gridIndex[0], gridIndex[1]);
};

/**
* x, y좌표를 넘거 해당좌표의 포인트를 포함하는 Grid의 인덱스를 리턴한다.
* @param {Number} x
* @param {Number} y
* @returns {number[]} [xIndex, yIndex]
*/
GridController.prototype.getGridIndexByPoint = function(x, y) {
    var gridSize = this.gridSize;
    return [mfloor(x / gridSize), mfloor(y / gridSize)];
};

/**
* 포인트를 배열로 넘겨 그포인트가 속한 그리드를 반환한다
* @param {(Array|Array[])} points [x1, y1] or [[x1,y1], [x2,y2], [x3,y3], ...]
* @returns {GridLayer[]}
*/
GridController.prototype.getGridByPoints = function(points) {
    var result = [],
        self = this;

    points = common.isArray(points[0]) ? points : [points];

    if (!points.length) {
        return result;
    }

    common.forEach(points, function(point) {
        var gridId = self.getGridIDByPoint(point[0], point[1]),
            grid = self.getGrid(gridId);

        if (common.isExisty(grid)) {
            result.push(grid);
        }
    });

    return result;
};

/**
* Grid 인덱스 범위를 순회하며 각 index에 해당하는 grid 배열을 반환
* @param {Number} xIndex
* @param {Number} yIndex
* @param {Number} xEndIndex
* @param {Number} yEndIndex
* @returns {GridLayer[]}
*/
GridController.prototype.getGridsByIndexRange = function(xIndex, yIndex, xEndIndex, yEndIndex) {
    var grids = [],
        yStartIndex = yIndex,
        grid;

    for (; xIndex <= xEndIndex; xIndex += 1) {
        for (; yIndex <= yEndIndex; yIndex += 1) {
            grid = this.getGrid(xIndex, yIndex);
            if (grid) {
                grids.push(grid);
            }
        }
        yIndex = yStartIndex;
    }

    return grids;
};

/**
* 사각형의 x,y좌표를 인자로 전달하여 겹치거나 포함되는 grid의 목록을 리턴한다.
* @param {number} x
* @param {number} y
* @param {number} xEnd
* @param {number} yEnd
* @returns {GridLayer[]}
*/
GridController.prototype.getGridsContainRect = function(x, y, xEnd, yEnd) {
    var startGridIndex = this.getGridIndexByPoint(x, y),
        endGridIndex = this.getGridIndexByPoint(xEnd, yEnd);

    return this.getGridsByIndexRange(startGridIndex[0], startGridIndex[1], endGridIndex[0], endGridIndex[1]);
};

/**
* 인덱스 범위안의 grids를 순회하여 콜백에 전달.
* @param {Number} xIndex
* @param {Number} yIndex
* @param {Number} xEndIndex
* @param {Number} yEndIndex
* @param {Function} func
*/
GridController.prototype.eachGridByRange = function(xIndex, yIndex, xEndIndex, yEndIndex, func) {
    var grids = this.getGridsByIndexRange(xIndex, yIndex, xEndIndex, yEndIndex);
    common.forEach(grids, func);
};

/**
* 사각형의 x,y좌표를 넘겨 범위안의 grids를 순회하여 콜백에 전달.
* @param {number} x
* @param {number} y
* @param {number} xEnd
* @param {number} yEnd
* @param {Function} func
*/
GridController.prototype.eachGridsByRectRange = function(x, y, xEnd, yEnd, func) {
    var startGridIndex = this.getGridIndexByPoint(x, y),
        endGridIndex = this.getGridIndexByPoint(xEnd, yEnd);

    return this.eachGridByRange(startGridIndex[0], startGridIndex[1], endGridIndex[0], endGridIndex[1], func);
};

/**
 * 좌표범위안의 Seat의 배열을 반환
 * @param {number} x1
 * @param {number} y1
 * @param {number} x2
 * @param {number} y2
 * @param {boolean} [includeDisabled]
 * @param {(etc#asc|etc#desc)} [sort]
 * @returns {RSeat[]}
 */
GridController.prototype.getSeatsInsideRect = function(x1, y1, x2, y2, includeDisabled, sort) {
    var seats = [];

    this.eachGridsByRectRange(x1, y1, x2, y2, function(grid) {
        var _seats = grid.getSeatsInsideRect(x1, y1, x2, y2, includeDisabled);
        seats = seats.concat(_seats);
    });

    if (common.isFunction(sort)) {
        seats.sort(sort);
    }

    return seats;
};

/**
 * 특정 좌표를 클릭했을 때
 *
 * 검사해야하는 grid 를 반환한다
 *
 * https://github.nhnent.com/FE/Application-SeatingChart/issues/104
 * @param {number} x
 * @param {number} y
 * @reutrn {string[]}
 */
GridController.prototype.getGridIDForPoint = function(x, y) {
    var gridSize = this.gridSize,
        half = RSeat.SEAT_SIZE / 2,
        gridCoord = (new Point(x, y)).divideBy(gridSize).floor(),
        min = gridCoord.multiplyBy(gridSize),
        max = min.clone().add(new Point(gridSize, gridSize)),
        clone,
        bonus,
        result = [gridCoord];

    if (x - min.x < half) {
        // 좌측 가장자리에 인접
        clone = gridCoord.clone();
        clone.x -= 1;
        result.push(clone);
    }

    if (max.x - x < half) {
        // 우측 가장자리에 인접
        clone = gridCoord.clone();
        clone.x += 1;
        result.push(clone);
    }

    if (y - min.y < half) {
        // 상단 가장자리에 인접
        clone = gridCoord.clone();
        clone.y -= 1;
        result.push(clone);
    }

    if (max.y - y < half) {
        // 하단 가장자리에 인접
        clone = gridCoord.clone();
        clone.y += 1;
        result.push(clone);
    }

    if (result.length === 3) {
        bonus = new Point(result[1].x, result[2].y);
        result.push(bonus);
    }

    if (result.length > 4) {
        throw Error('GridController#getGridIBForPoint() 계산 결과가 올바르지 않습니다');
    }

    result = common.map(result, function(coord) {
        return this.encodeGridID(coord.x, coord.y);
    }, this);

    return result;
};

/**
 * 좌표를 포함하는 seat의 배열을 반환
 * @param {number} x
 * @param {number} y
 * @param {boolean} [includeDisabled]
 * @param {(etc#asc|etc#desc)} [sort] 정렬 함수
 * @return {RSeat[]}
 */
GridController.prototype.getSeatsContainPoint = function(x, y, includeDisabled, sort) {
    var seats = [];

    common.forEachArray(this.getGridIDForPoint(x, y), function(slid) {
        this.doWhenSeatLayerExist(slid, function(sl) {
            seats = seats.concat(sl.getSeatsContainPoint(x, y, includeDisabled));
        });
    }, this);

    if (common.isFunction(sort)) {
        seats.sort(sort);
    }

    return seats;
};

/**
 * 현재 화면에 보여지는 그리드 id 리스트를 계산하기 위한 rect 반환
 *
 * 이 부분은 화면밖으로 벗어나도 렌더링 되어야하므로 min/max 처리하지 않음
 * @returns {Rect}
 */
GridController.prototype.getViewportGridRect = function() {
    var chart = this.chart,
        viewport = chart.getViewportOffsetByPanelName('layer'),
        gridSize = this.getScaledGridSize(),
        gridRect = new Rect(
            viewport.min.divideBy(gridSize).floor(),
            viewport.max.divideBy(gridSize).floor()
        );

    return gridRect;
};

/**
 * 렌더링 여부 확인
 * @param {GridLayer} grid
 * @returns {boolean}
 */
GridController.prototype.isNotRendered = function(grid) {
    return !this.rendered[grid.getID()];
};

/**
 * 현재 뷰포트에 보이는 그리드 ID 리스트를 반환한다
 * @param {function(string)} [filter] 원하는 경우 별도의 필터를 지정 가능
 * @returns {Array}
 */
GridController.prototype.getViewportGridID = function(filter) {
    var gridID = [],
        coords,
        rect = this.getViewportGridRect(),
        x,
        maxX,
        y,
        maxY,
        useFilter = common.isExisty(filter) || false;

    for (x = rect.min.x, maxX = rect.max.x; x <= maxX; x += 1) {
        for (y = rect.min.y, maxY = rect.max.y; y <= maxY; y += 1) {
            coords = x + ':' + y;
            if (!useFilter || (useFilter && filter(coords))) {
                gridID.push(coords);
            }
        }
    }

    return gridID;
};

/**
 * 현재 뷰포트에 보이는 그리드 ID 리스트 중 X 인덱스만을 반환한다
 * @param {function(string)} [filter] 원하는 경우 별도의 필터를 지정 가능
 * @returns {Array}
 */
GridController.prototype.getViewportGridXCoords = function(filter) {
    var gridID = [],
        rect = this.getViewportGridRect(),
        x,
        maxX,
        coordX,
        useFilter = common.isExisty(filter) || false;

    for (x = rect.min.x, maxX = rect.max.x; x <= maxX; x += 1) {
        coordX = x + '';
        if (!useFilter || (useFilter && filter(coordX))) {
            gridID.push(coordX);
        }
    }

    return gridID;
};

/**
 * 현재 화면에 보이는 그리드중 이미 받아온 것을 제외한 나머지 그리드에 대한 ID를 반환한다
 * @return {string[]}
 */
GridController.prototype.getGridIDNeedRequest = function() {
    var gridIDListInViewport,
        fetchedGridIDFromServer = this.fetchedGridIDFromServer,
        gridIDListToRequest = [],

        gridsExistSeat = GridController.gridsExistSeat,
        filter;

    if (gridsExistSeat !== '') {
        filter = function(coords) {
            return gridsExistSeat[coords];
        };
    }

    if (GridController.useLoadRSeatVertical) {
        gridIDListInViewport = this.getViewportGridXCoords(filter);
    } else {
        gridIDListInViewport = this.getViewportGridID(filter);
    }

    common.forEachArray(gridIDListInViewport, function(gridID) {
        if (!common.isExisty(common.pick(fetchedGridIDFromServer, gridID))) {
            gridIDListToRequest.push(gridID);
        }
    }, this);

    return gridIDListToRequest;
};

/**
 * 렌더링할 준비가 되었을 때 렌더링하고 렌더가 완료되었다는 이벤트를 발생시킨다
 * @private
 */
GridController.prototype._postloadGrids = function() {
    this.removeOtherGrids();
    this.updateGridsInViewport();
    // 지정석 렌더링이 완료되었음을 알린다
    this.chart.IB.emit(InteractBroker.EVENT.RSEAT_RENDERED);
};

/**
 * 현재 화면에 보이는 그리드 중 이미 전부 받아온 경우엔 바로 렌더링하고 아닌 경우
 */
GridController.prototype.preloadGrids = function() {
    var gridIDListToRequest = this.getGridIDNeedRequest();

    if (gridIDListToRequest.length) {
        // 아닌 경우
        this.chart.loadRSeat(gridIDListToRequest, common.bind(this._postloadGrids, this));
    } else {
        // 이미 다 받아온 그리드의 경우 그냥 그린다
        this._postloadGrids();
    }
};

/**
 * 현재 뷰포트에 보이는 그리드 중 렌더링이 안된 그리드만 업데이트 한다
 * 인자에 따라 업데이트 대신 렌더할수도 있다
 * @param {boolean} [useRender=false] true로 전달 시 그리드를 update하지 않고 render한다
 */
GridController.prototype.updateGridsInViewport = function(useRender) {
    this.eachGridInViewport(function(grid) {
        if (this.isNotRendered(grid)) {
            grid[useRender ? 'render' : 'update'](true);
            grid.zoomReactor.react(this.zoomLevel);
            this.rendered[grid.slid] = grid;
        }
    });
};

/**
 * 현재 뷰포트에 보이는 그리드 전체를 업데이트한다
 */
GridController.prototype.refreshGridsInViewport = function() {
    this.eachGridInViewport(function(grid) {
        grid.zoomReactor.react(this.zoomLevel);
        if (grid.isDirty()) {
            grid.update();
        }
    });
};

/**
 * 현재 화면에 보이는 그리드 id들을 반환하며 반복자 실행
 * @param {function} func
 * @param {*} [context]
 */
GridController.prototype.eachGridInViewport = function(func, context) {
    context = context || this;

    common.forEachArray(this.getViewportGridID(), function(slid) {
        this.doWhenSeatLayerExist(slid, function(grid) {
            func.call(context, grid);
        });
    }, this);
};

/**
 * 렌더링 된 그리드 레이어 중 뷰포트 바깥으로 빠져나간 그리드들을 제거한다
 */
GridController.prototype.removeOtherGrids = function() {
    var gridsInViewport = this.getViewportGridID(),
        joinStr = gridsInViewport.join('|'),
        rendered = this.rendered,
        left = [];

    common.forEachOwnProperties(rendered, function(grid, id) {
        if (joinStr.indexOf(id) === -1) {
            left.push(id);
        }
    });

    if (left.length) {
        common.forEachArray(left, function(id) {
            if (this.rendered[id]) {
                this.rendered[id].clear();
                this.rendered[id] = null;
            }
        }, this);
    }
};

/**
 * 확대 축소 시 브러시 토글
 * @param {number} zoomLevel
 */
GridController.prototype.ensureZoom = function(zoomLevel) {
    this.zoomLevel = ne.util.isUndefined(zoomLevel) ? this.zoomLevel : zoomLevel;

    this.removeOtherGrids();
    this.refreshGridsInViewport();

    this.seatLayers.each(function(grid) {
        grid.zoomReactor.react(zoomLevel);
    });
};

/**
 * API데이터로 그리드를 덮어쓴다 (그리드 내 좌석들도 전부 덮어씌운다)
 * @param {object} grids 서버로부터 받은 그리드 데이터
 */
GridController.prototype.overwriteData = function(grids) {
    var fetched = this.fetchedGridIDFromServer,
        gridsIDList = common.keys(grids);

    this.removeSeatLayer(gridsIDList);
    this.setData(grids);

    common.forEachArray(gridsIDList, function(gridID) {
        this.doWhenSeatLayerExist(gridID, function(sl) {
            sl.update(true);
        });
        fetched[gridID] = true;
    }, this);
};

module.exports = GridController;
