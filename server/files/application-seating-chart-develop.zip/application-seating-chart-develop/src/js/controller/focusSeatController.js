/**
 * @fileoverview
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */

'use strict';

var SeatLayerController = require('./seatLayerController'),
    FocusNSeatLayer = require('../layer/focusNSeatLayer');

/**
 * 포커스된 비지정석을 다루는 컨트롤러 클래스
 * @param {Object} options
 * @param {Raphael} options.paper 렌더링에 사용되는 Raphael의 Paper객체
 * @exports FocusSeatController
 * @class
 * @extends SeatLayerController
 */
function FocusSeatController(options) {
    SeatLayerController.call(this, options);
}

// 상속
ne.util.inherit(FocusSeatController, SeatLayerController);

FocusSeatController.prototype.SeatLayerConstructor = FocusNSeatLayer;

/**********
 * override methods
 **********/

/**********
 * public methods
 **********/

module.exports = FocusSeatController;
