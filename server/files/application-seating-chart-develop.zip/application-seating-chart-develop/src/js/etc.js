/**
 * @fileoverview 티켓링크에서 사용하는 유틸리티 함수 모음
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */

'use strict';

var SeatLayer = require('./layer/seatLayer');

var common = ne.util;

var temp = {

};




/**
 * @name etc
 * @module etc
 * @exports etc
 */
var etc = {
    /**
     * === 비교 연산자 수행시 변수 타입을 맞추기 위한 함수
     * @param {*} target 변환할 Target
     * @returns {String} 변환된 String
     */
    toStr: function(target) {
        if (common.isExisty(target)) {
            return target.toString();
        } else {
            return '';
        }
    },

    /**
     * 숫자를 세 자릿수 마다 쉼표로 구분하여 변환한다.
     * @param {(string|number)} num 변환할 숫자
     * @return {string} 변환된 숫자
     * @example
     * var result;
     * result = formatNumber('10000000.00');    //결과 '10,000,000.00'
     * result = formatNumber('10000000');    //결과 '10,000,000'
     */
    formatNumber: function(num) {
        num = ((typeof num === 'number') ? String(num) : num) || '';

        var decimal = '',
            integer = num,
            tokens,
            formattedNumber;

        if(num.indexOf('.') > -1){
            tokens = num.split('.');
            integer = tokens[0];
            decimal = '.' + tokens[1];
        }
        formattedNumber = integer.replace(/(\d)(?=(\d{3})+$)/igm, '$1,') + decimal;
        return formattedNumber || '0';
    },

    /**
     * url을 파싱한다.
     */
    parseUrl: function() {
        var params = {},
            queryString = this.getQueryString(),
            param = queryString.split('&') || [];

        common.forEachArray(param, function(item) {
            var token = item.split('=');
            if(token.length === 2){
                params[token[0]] = decodeURIComponent(token[1].replace(/\+/gi, '%20'));
            }
        });
        return params;
    },

    /**
     * input 에 특정 정규식 패턴만 입력 가능하도록 제한한다.
     * @param {jQuery} $input 해당 input element
     * @param {regex} regex 적용할 정규식
     */
    setInputPattern: function($input, regex) {
        var event = common.browser.msie ? 'keyup' : 'input';

        $input.on(event, function(keyUpEvent) {
            var $target = $(keyUpEvent.target),
                currentValue = $target.val(),
                matchList = currentValue.match(regex),
                changeValue = matchList ? matchList.join('') : '';

            if (changeValue !== currentValue) {
                $target.blur();
                $target.val(changeValue);
                $target.focus();
            }
        });
    },

    /**
     * object 내 숫자로 이루어진 데이터를 전부 formatNumber 로 변경하여 반환한다.
     * @param {Object} data
     * @returns {Object}
     */
    formatNumberEachObject: function(data) {
        var regNum = /^[0-9]$/;
        common.forEach(data, function(value, prop) {
            if (typeof value === 'number' || regNum.test(value)) {
                data[prop] = this.formatNumber(value);
            }
        }, this);
        return data;
    },

    /**
     * queryString을 반환한다.
     */
    getQueryString: function() {
        var queryString = location.search.substring(1);
        return queryString;
    },

    /**
     * timestamp 를 받아 날짜 object 를 반환한다.
     * @param {number} timestamp
     * @returns {{year: number, month: number, date: number, hour: number, minute: number, second: number}}
     */
    getDateObject: function(timestamp) {
        var date = new Date(timestamp),
            parsedData = {};

        parsedData.year = date.getFullYear();
        parsedData.month = date.getMonth() + 1;
        parsedData.date = date.getDate();
        parsedData.hour = date.getHours();
        parsedData.minute = date.getMinutes();
        parsedData.second = date.getSeconds();

        return parsedData;
    },

    /**
     * timestamp 를 받아 날짜 문자열을 반환한다.
     * @param {Number} timestamp
     * @param {String} format
     * @returns {*}
     */
    getDateString: function(timestamp, format) {
        format = format || 'yyyy.mm.dd';

        var date = new Date(timestamp),
            dateStr;

        if (common.isString(format)) {
            //날짜 포멧팅
            dateStr = format.replace(/(yyyy|mm|dd)/gi,
                function($1) {
                    var returnVal;
                    switch ($1) {
                        case 'yyyy':
                            returnVal = date.getFullYear();
                            break;
                        case 'mm':
                            returnVal = date.getMonth() + 1;
                            break;
                        case 'dd':
                            returnVal = date.getDate();
                            break;
                    }
                    return (returnVal > 9 ? '' : '0') + returnVal;
                }
            );
        }
        return dateStr;
    },

    /**
     * 지정석 마우스 오버 시 툴팁에 들어갈 내용을 만듦
     * @param {RSeat} rSeat
     * @return {string}
     */
    parseRSeatInfo: function(rSeat) {
        var info = rSeat.getMapInfo(),
            str = '';

        common.forEachOwnProperties(info, function(value, unit) {
            if (value !== '' && common.isExisty(value)) {
                str += unit + ': ' + value + '<br />';
            }
        });

        return str;
    },

    /**
     * 비지정석 마우스 오버 시 툴팁에 들어갈 내용을 만듦
     * @param {NSeat} nSeat
     * @return {string}
     */
    parseNSeatInfo: function(nSeat) {
        var info = nSeat.getDealership(),
            str = '';

        if (common.isExisty(common.pick(nSeat, 'remainCount'))) {
            str = ['잔여석'];
            if (common.isExisty(common.pick(nSeat, 'grade'))) {
                str.push('[' + SeatLayer.GRADE_INFO[nSeat.grade][0] + '] ');
            }
            str.push(nSeat.remainCount);

            str = str.join('<br />');
        } else {
            common.forEachOwnProperties(info, function(value, code) {
                if (value !== '' && common.isExisty(value)) {
                    str += SeatLayer.SELLING_TYPE_CODE[code] + ': ' + value + '<br />';
                }
            });
        }

        return str;
    },

    /**
     * 영역 마우스 오버 시 툴팁에 들어갈 내용 만듦
     * @param {Area} area
     * @return {string}
     */
    parseAreaInfo: function(area) {
        return area.data;
    },

    /**
     * 좌석 모델을 받아 툴팁에 노출할 문자열을 반환
     * @param {(RSeat|NSeat|Area)} seat
     * @returns {string}
     */
    parseSeatInfo: function(seat) {
        var str,
            method = {
                'RSeat': this.parseRSeatInfo,
                'NSeat': this.parseNSeatInfo,
                'Area': this.parseAreaInfo
            };

        if (!common.isExisty(common.pick(seat, 'name'))) {
            return '';
        }

        str = method[seat.name](seat);
        str = str.replace(/<br \/>$/, '');
        str = str.replace(/\n/g, '<br />');

        return str;
    },

    sort: {
        /**
         * 오름차순 정렬
         * @param {string} [prop] 정렬할 프로퍼티명
         * @returns {function(a, b)}
         */
        asc: function(prop) {
            return function(a, b) {
                var _a = prop ? a[prop] : a,
                    _b = prop ? b[prop] : b;

                return _a - _b;
            };
        },

        /**
         * 내림차순 정렬
         * @param {string} [prop] 정렬할 프로퍼티명
         * @returns {function(a, b)}
         */
        desc: function(prop) {
            return function(a, b) {
                var _a = prop ? a[prop] : a,
                    _b = prop ? b[prop] : b;

                return _b - _a;
            };
        }
    },

    form: {
        /**
         * form 의 input 요소 값을 설정하기 위한 객체
         */
        setInput: {
            /**
             * 배열의 값들을 전부 String 타입으로 변환한다.
             * @private
             * @param {Array}  arr 변환할 배열
             * @return {Array} 변환된 배열 결과 값
             */
            _changeToStringInArray: function(arr) {
                common.forEach(arr, function(value, i) {
                    arr[i] = String(value);
                }, this);
                return arr;
            },

            /**
             * radio type 의 input 요소의 값을 설정한다.
             * @param {HTMLElement} targetElement
             * @param {String} formValue
             */
            'radio': function(targetElement, formValue) {
                targetElement.checked = (targetElement.value === formValue);
            },

            /**
             * radio type 의 input 요소의 값을 설정한다.
             * @param {HTMLElement} targetElement
             * @param {String} formValue
             */
            'checkbox': function(targetElement, formValue) {
                if (common.isArray(formValue)) {
                    targetElement.checked = $.inArray(targetElement.value, this._changeToStringInArray(formValue)) !== -1;
                } else {
                    targetElement.checked = (targetElement.value === formValue);
                }
            },

            /**
             * select-one type 의 input 요소의 값을 설정한다.
             * @param {HTMLElement} targetElement
             * @param {String} formValue
             */
            'select-one': function(targetElement, formValue) {
                var options = common.toArray(targetElement.options),
                    index = -1;

                common.forEach(options, function(targetOption, i) {
                    if (targetOption.value === formValue || targetOption.text === formValue) {
                        index = i;
                        return false;
                    }
                }, this);

                targetElement.selectedIndex = index;

            },

            /**
             * select-multiple type 의 input 요소의 값을 설정한다.
             * @param {HTMLElement} targetElement
             * @param {String|Array} formValue
             */
            'select-multiple': function(targetElement, formValue) {
                var options = common.toArray(targetElement.options);

                if (common.isArray(formValue)) {
                    formValue = this._changeToStringInArray(formValue);
                    common.forEach(options, function(targetOption) {
                        targetOption.selected = $.inArray(targetOption.value, formValue) !== -1 ||
                        $.inArray(targetOption.text, formValue) !== -1;
                    }, this);
                } else {
                    this['select-one'].apply(this, arguments);
                }
            },

            /**
             * input 요소의 값을 설정하는 default 로직
             * @param {HTMLElement} targetElement
             * @param {String} formValue
             */
            'defaultAction': function(targetElement, formValue) {
                targetElement.value = formValue;
            }
        },

        /**
         * $form 에 정의된 인풋 엘리먼트들의 값을 모아서 DataObject 로 구성하여 반환한다.
         * @param {jQuery} $form jQuery()로 감싼 폼엘리먼트
         * @return {object} form 내의 데이터들을 key:value 형태의 DataObject 로 반환한다.
         **/
        getFormData: function($form) {
            var result = {},
                valueList = $form.serializeArray();

            common.forEach(valueList, function(obj) {
                var value = obj.value,
                    name = obj.name;
                if (common.isExisty(common.pick(result, name))) {
                    if (!result[name].push) {
                        result[name] = [result[name]];
                    }
                    result[name].push(value || '');
                } else {
                    result[name] = value || '';
                }
            }, this);

            return result;
        },

        /**
         * 폼 안에 있는 모든 인풋 엘리먼트를 배열로 리턴하거나, elementName에 해당하는 인풋 엘리먼트를 리턴한다.
         * @method getFormElement
         * @param {jquery} $form jQuery()로 감싼 폼엘리먼트
         * @param {String} [elementName] 특정 이름의 인풋 엘리먼트만 가져오고 싶은 경우 전달하며, 생략할 경우 모든 인풋 엘리먼트를 배열 형태로 리턴한다.
         * @return {jQuery}  jQuery 로 감싼 엘리먼트를 반환한다.
         */
        getFormElement: function($form, elementName) {
            var formElement;
            if ($form && $form.length) {
                if (elementName) {
                    formElement = $form.prop('elements')[elementName + ''];
                } else {
                    formElement = $form.prop('elements');
                }
            }
            return $(formElement);
        },

        /**
         * 파라미터로 받은 데이터 객체를 이용하여 폼내에 해당하는 input 요소들의 값을 설정한다.
         *
         * @method setFormData
         * @param {jQuery} $form jQuery()로 감싼 폼엘리먼트
         * @param {Object} formData 폼에 설정할 폼 데이터 객체
         **/
        setFormData: function($form, formData) {
            common.forEachOwnProperties(formData, function(value, property) {
                this.setFormElementValue($form, property, value);
            }, this);
        },

        /**
         * elementName에 해당하는 인풋 엘리먼트에 formValue 값을 설정한다.
         * -인풋 엘리먼트의 이름을 기준으로 하기에 라디오나 체크박스 엘리먼트에 대해서도 쉽게 값을 설정할 수 있다.
         * @param {jQuery} $form jQuery()로 감싼 폼엘리먼트
         * @param {String}  elementName 값을 설정할 인풋 엘리먼트의 이름
         * @param {String|Array} formValue 인풋 엘리먼트에 설정할 값으로 체크박스나 멀티플 셀렉트박스인 경우에는 배열로 설정할 수 있다.
         **/
        setFormElementValue: function($form, elementName, formValue) {
            var type,
                elementList = this.getFormElement($form, elementName);

            if (!elementList) {
                return;
            }
            if (!common.isArray(formValue)) {
                formValue = String(formValue);
            }
            elementList = common.isHTMLTag(elementList) ? [elementList] : elementList;
            elementList = common.toArray(elementList);
            common.forEach(elementList, function(targetElement) {
                type = this.setInput[targetElement.type] ? targetElement.type : 'defaultAction';
                this.setInput[type](targetElement, formValue);
            }, this);
        },

        /**
         * input 타입의 엘리먼트의 커서를 가장 끝으로 이동한다.
         * @param {HTMLElement} target HTML input 엘리먼트
         */
        setCursorToEnd: function(target) {
            target.focus();
            var length = target.value.length;

            if (target.setSelectionRange) {
                target.setSelectionRange(length, length);
            } else if (target.createTextRange) {
                var range = target.createTextRange();
                range.collapse(true);
                range.moveEnd('character', length);
                range.moveStart('character', length);
                range.select();
            }
        }
    }
};

module.exports = etc;
