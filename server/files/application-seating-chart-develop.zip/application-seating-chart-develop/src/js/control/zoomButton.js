
/**
 * @fileoverview 프론트에서 사용하는 확대/축소 버튼
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var util = ne.util;
var simplemap = ne.component.SimpleMap;
var domutil = simplemap.domutil;
var domevent = simplemap.domevent;
var Control = simplemap.Control;

/**
 * 확대/축소 버튼
 * @constructor
 * @extends Control
 */
function ZoomButton() {
    Control.call(this, 'zoom-button');

    this.zoomButtonElement = null;

    this.minZoom = 0;

    this.maxZoom = 0;
}

util.inherit(ZoomButton, Control);

ZoomButton.markup = ['<a href="#" class="brn_zoom v2" title="{=LABEL}">{=LABEL}</a>'];

ZoomButton.prototype.isMinZoom = function() {
    var map = this.map,
        mapOptions = map.options,
        currentZoom = map.getZoom();

    return mapOptions.minZoom === currentZoom;
};

ZoomButton.prototype._onClick = function(e) {
    var map = this.map,
        toZoomOut;

    domevent.stopPropagation(e);

    toZoomOut = domutil.hasClass(this.zoomButtonElement, 'v2');

    if (toZoomOut) {
        map.reset(true);
    } else {
        map.setZoom(map.options.maxZoom);
    }

    this._refreshElement();
};

ZoomButton.prototype._refreshElement = function() {
    var el = this.zoomButtonElement;

    if (!el) {
        el = this.zoomButtonElement = document.createElement('a');
        domutil.addClass(el, 'btn_zoom');
        this.element.appendChild(el);

        domevent.on(el, 'mousedown', this._onClick, this);
    }

    if (this.isMinZoom()) {
        el.setAttribute('title', '확대보기');
        el.innerHTML = '확대보기';
        domutil.removeClass(el, 'v2');
    } else {
        el.setAttribute('title', '축소보기');
        el.innerHTML = '축소보기';
        domutil.addClass(el, 'v2');
    }
};

ZoomButton.prototype._onAdded = function(map, element) {
    this.minZoom = map.options.minZoom;
    this.maxZoom = map.options.maxZoom;

    element.style.top = '20px';
    element.style.right = '20px';

    this._refreshElement();

    this.attachEvent({
        'afterZoom:map': this._refreshElement
    }, this);
};

module.exports = ZoomButton;

