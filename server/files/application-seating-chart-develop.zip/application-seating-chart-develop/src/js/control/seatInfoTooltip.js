/**
 * @fileoverview 마우스 오버 시 좌석 정보를 노출하는 기능을 가진 컨트롤
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var etc = require('../etc');

var util = ne.util,
    simplemap = ne.component.SimpleMap,
    Control = simplemap.Control,
    domevent = simplemap.domevent;

/**
 * 툴팁이 마우스 포인터에 가리지 않게 하기 위해 주는 간격
 * @type {Number}
 */
var TOOLTIP_OFFSET_X = 11,
    TOOLTIP_OFFSET_Y = 11;

/**
 * @constructor
 * @extends {Control}
 */
function SeatInfoTooltipControl() {
    Control.call(this, 'seat-info-tooltip');

    /**
     * 좌석 툴팁을 마우스 오버 후 일정시간 이후 보여줘야 하므로 타이머 사용
     * @type {number}
     */
    this.timerID = 0;

    /**
     * 좌석 툴팁을 출력할 위치
     * @type {number[]}
     */
    this.targetPosition = [0, 0];

    /**
     * 툴팁 컨트롤 비활성화 여부
     * @type {boolean}
     */
    this.disabled = false;
}

// 상속
util.inherit(SeatInfoTooltipControl, Control);

/**********
 * static props
 **********/

SeatInfoTooltipControl.markup = ['<div id="seat-info"></div>'];
SeatInfoTooltipControl.DELAY = 150;

/**********
 * private props
 **********/

/**
 * 맵에 추가되었을 때 실행되는 일종의 초기화 메서드
 * @private
 */
SeatInfoTooltipControl.prototype._onAdded = function(map) {
    this.layerPanel = map.getLayerPanel();
    this.attachEvent({
        'beforeZoom:map': this._onBeforeZoom,
        'mousemove:container': this._onMouseMove,
        'containerMouseenter:map': this._onEnterOrLeaveMouse,
        'containerMouseleave:map': this._onEnterOrLeaveMouse,
        'seatInfo:map': this._onSeatInfo
    }, this);

    this._clearInfoElement();
};

/**
 * 함수 감속을 위해 사용하는 타이머를 초기화
 * @private
 */
SeatInfoTooltipControl.prototype._clearTimeout = function() {
    window.clearTimeout(this.timerID);
    this.timerID = 0;
};

/**
 * 마우스 위치를 읽어 비율계산된 좌표를 반환하는 메서드
 * @param {MouseEvent} mouseEvent
 * @return {Point}
 * @private
 */
SeatInfoTooltipControl.prototype._getMousePos = function(mouseEvent) {
    var ratio = this.map.getScaleRatio(),
        pos = domevent.getMousePosition(mouseEvent, this.map.getContainer());

    this.targetPosition = [pos.x, pos.y];

    return domevent.getMousePosition(mouseEvent, this.layerPanel)._divideBy(ratio);
};

/**
 * 좌석 매핑정보 툴팁 초기화 메서드
 * @private
 */
SeatInfoTooltipControl.prototype._clearInfoElement = function() {
    var el = this.element;

    el.innerHTML = '';
    el.style.left = el.style.top = '0px';
    el.style.display = 'none';
};

/**
 * 좌석 매핑정보 툴팁 노출 메서드
 * @param {string} str 툴팁에 노출할 html문자열
 * @private
 */
SeatInfoTooltipControl.prototype._showInfoElement = function(str) {
    var el = this.element,
        pos = this.targetPosition;

    if (str === '') {
        return;
    }

    el.innerHTML = str;

    el.style.left = (pos[0] + TOOLTIP_OFFSET_X) + 'px';
    el.style.top = (pos[1] + TOOLTIP_OFFSET_Y) + 'px';

    el.style.display = 'block';
};

/**
 * 좌석정보 툴팁 동작을 막는다
 */
SeatInfoTooltipControl.prototype.disable = function() {
    this._clearTimeout();
    this._clearInfoElement();

    this.disabled = true;
};

/**********
 * event handler
 **********/

/**
 * 맵의 확대/축소 시 툴팁을 숨기기 위한 구현
 */
SeatInfoTooltipControl.prototype._onBeforeZoom = function() {
    this._clearTimeout();
    this._clearInfoElement();
};

/**
 * 맵의 컨테이너 영역에 마우스가 들어가거나 나갈 때 발생하는 이벤트 핸들러
 * @private
 */
SeatInfoTooltipControl.prototype._onEnterOrLeaveMouse = function() {
    if (this.disabled) {
        return;
    }

    this._clearTimeout();
    this._clearInfoElement();
};

/**
 * 맵 컨테이너 엘리먼트의 MouseMove 이벤트 핸들러
 * @private
 */
SeatInfoTooltipControl.prototype._onMouseMove = function(mouseMoveEvent) {
    if (this.disabled) {
        return;
    }

    this._clearInfoElement();
    this._clearTimeout();

    /**
     * IE7, IE8은 이벤트 객체를 전역으로 관리하기 때문에 다른 이벤트 발생 시 프로퍼티들이 덮어써진다
     * 이를 방지하기 위해 필요 정보들을 복사하여 넘긴다
     */
    var mouseEvent = { clientX: mouseMoveEvent.clientX, clientY: mouseMoveEvent.clientY };
    this.timerID = window.setTimeout(util.bind(this._onRequestSeatInfo, this, mouseEvent), SeatInfoTooltipControl.DELAY);
};

/**
 * 맵에 현제 마우스가 위치한 곳에 있는 좌석의 정보를 요청한다
 * @param {MouseEvent} mouseMoveEvent
 * @private
 */
SeatInfoTooltipControl.prototype._onRequestSeatInfo = function(mouseMoveEvent) {
    var pos = this._getMousePos(mouseMoveEvent);
    this.map.seatInfo(pos.x, pos.y);
    this._clearTimeout();
};

/**
 * Chart에서 seatInfo이벤트 발생 시 호출되는 이벤트 메서드
 *
 * 이중에서 ID가 높은 한 좌석 데이터만 툴팁에 띄운다
 * @param {(RSeat[]|NSeat[]|Area[])} models 툴팁으로 띄워야 하는 인스턴스들의 배열
 * @private
 */
SeatInfoTooltipControl.prototype._onSeatInfo = function(models) {
    var model;

    if (models.length !== +models.length && !models.length) {
        return;
    }

    model = models[0];

    this._showInfoElement(etc.parseSeatInfo(model));
};

module.exports = SeatInfoTooltipControl;
