/**
 * @fileoverview
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */

'use strict';

var simplemap = ne.component.SimpleMap;
var Control = simplemap.Control;

/**
 * @constructor
 */
function DomControl() {
    Control.apply(this, arguments);
}

// 상속
ne.util.inherit(DomControl, Control);

/**
 * 맵에 추가되었을 때 호출된다
 * @param {Map} map
 * @private
 */
DomControl.prototype._onAdded = function(map) {
    this.map = map;
    this.layerPanel = map.getLayerPanel();
};

/**
 * 뷰포트의 포지션을 구한다.
 * 화면상의 좌측 상단에 해당되는 레이어 컨테이너의 위치
 * @returns {{x: number, y: number}}
 */
DomControl.prototype.getPositionOfViewPort = function() {
    var left = parseInt(this.layerPanel.style.left, 10) * -1,
        top = parseInt(this.layerPanel.style.top, 10) * -1,
        originalPosition = this.getOriginalPosition(left, top);

    return originalPosition;
};

/**
 * 레이어상의 좌표를 받아 뷰포트 안에서 상대적인 좌표를 리턴한다.
 * @param {number} x
 * @param {number} y
 * @returns {{x: number, y: number}}
 */
DomControl.prototype.getRelativePosition = function(x, y) {
    var pos = this.getPositionOfViewPort();

    return {
        x: x - pos.x,
        y: y - pos.y
    };
};

/**
 * 뷰포트 안에서의 상대적인 좌표를 입력받아 레이어상의 절재적인 좌표를 리턴한다.
 * @param {number} x
 * @param {number} y
 * @returns {{x: number, y: number}}
 */
DomControl.prototype.getPosition = function(x, y) {
    var pos = this.getPositionOfViewPort();

    return {
        x: x + pos.x,
        y: y + pos.y
    };
};

/**
 * 마우스 이벤틀 입력받아 뷰포트 안에서의 정확한 포지션을 리턴한다.
 * @param {MouseEvent} e
 * @returns {{x: number, y: number}}
 */
DomControl.prototype.getRefinedPositionOfEvent = function(e) {
    var containerRect = this.map.getContainer().getBoundingClientRect();

    return {
        x: e.x - containerRect.left,
        y: e.y - containerRect.top
    };
};

/**
 * 포지션을 입력받아 zoom Scale이 적용되기전 1:1비율의 좌표를 리턴한다.
 * @param {number} x
 * @param {number} y
 * @returns {{x: number, y: number}}
 */
DomControl.prototype.getOriginalPosition = function(x, y) {
    var scale = this.map.getScaleRatio();

    return {
        x: x / scale,
        y: y / scale
    };
};

module.exports = DomControl;
