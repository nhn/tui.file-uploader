/**
 * @fileoverview shift+drag 기능 사용 시 선택영역에 대한 정보를 div로 표현해주고 Map에게 이벤트로 전달하는 컨트롤 모듈
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var common = ne.util,
    simplemap = ne.component.SimpleMap,
    tUtil = simplemap.util,
    domutil = simplemap.domutil,
    domevent = simplemap.domevent,
    Control = simplemap.Control,
    Point = simplemap.Point,
    Rect = simplemap.Rect;

/**
 * 좌석 선택 이벤트 컨트롤
 * @constructor
 * @extends Control
 */
function SelectionControl() {
    Control.call(this, 'seat-select-control');

    /**
     * 점선 사각형 효과를 위한 Div엘리먼트
     * @type {HTMLElement}
     * @private
     */
    this.selectionElement = null;

    /**
     * 맵의 컨테이너 엘리먼트
     * @type {HTMLElement}
     * @private
     */
    this.container = null;

    /**
     * 좌석선택 시작 지점
     * @type {Point}
     * @private
     */
    this._selectStartPoint = null;

    /**
     * 맵이 패닝되었는지 여부를 저장
     * @type {boolean}
     * @private
     */
    this._mapMoved = false;
}

// 상속
ne.util.inherit(SelectionControl, Control);

SelectionControl.markup = ['<div class="seat-selection-area"></div>'];

/**********
 * private methods
 **********/

/**
 * 마우스 이벤트에서 버튼 클릭 속성을 정규화한다
 * 0: 우선적 마우스 버튼, 2: 두 번째 마우스 버튼, 1: 가운데 버튼
 * @param {MouseEvent} event
 * @returns {*}
 * @private
 */
SelectionControl.prototype._getButton = function(event) {
    var button,
        primary = '0,1,3,5,7',
        secondary = '2,6',
        wheel = '4';

    if (document.implementation.hasFeature('MouseEvents', '2.0')) {
        return event.button;
    } else {
        button = event.button + '';
        if (primary.indexOf(button) > -1) {
            return 0;
        } else if (secondary.indexOf(button) > -1) {
            return 2;
        } else if (wheel.indexOf(button) > -1) {
            return 1;
        }
    }
};

/**
 * Map인스턴스에 컨트롤이 추가될 경우 실행되는 핸들러 구현
 * @param {Map} map
 * @param {HTMLElement} element
 * @private
 */
SelectionControl.prototype._onAdded = function(map, element) {
    this.container = map.getContainer();

    element.innerHTML = SelectionControl.markup.join('');

    this.selectionElement = domutil.find('.seat-selection-area', element);

    this.attachEvent({
        'movestart:map': this._onMapMoveStart,
        'moveend:map': this._onMapMoveEnd,
        'zoom:map': this.clearSelection,
        'mousedown:container': this._onMouseDown
    });
};

/**
 * 드래그 관련 이벤트 바인딩을 토글하는 메서드
 * @param {boolean} toBind
 * @private
 */
SelectionControl.prototype._toggleDragEvent = function(toBind) {
    var method = toBind ? ['on', 'disable'] : ['off', 'enable'];

    domutil[method[1] + 'ImageDrag']();
    domutil[method[1] + 'TextSelection']();

    domevent[method[0]](document, {
        'mousemove': this._onMouseMove,
        'mouseup': this._onMouseUp
    }, this);
};

/**
 * 선택 효과 엘리먼트를 초기화하는 메서드
 * @private
 */
SelectionControl.prototype._clearSelectionElement = function() {
    var selectionElement = this.selectionElement;
    selectionElement.style.display = 'none';
    selectionElement.style.width = selectionElement.style.height = 'auto';
};

/**
 * 단일 좌석 선택 이벤트를 발생시키는 메서드
 * @param {MouseEvent} mouseUpEvent
 * @param {simplemap.Point} mouseUpPoint
 * @private
 */
SelectionControl.prototype._fireSingleSelectEvent = function(mouseUpEvent, mouseUpPoint) {
    var map = this.map,
        mpow = Math.pow,
        layerPanelPos = domutil.getPosition(map.getLayerPanel()),
        eventData;

    mouseUpPoint._subtract(layerPanelPos);

    eventData = {
        selectType: 'single',
        shiftKey: mouseUpEvent.shiftKey,
        range: Point.getRatio(mouseUpPoint, mpow(2, map.getZoom()), mpow(2, map.options.zoomLevelInMapSize)),
        originalEvent: mouseUpEvent
    };

    map.fire('beforeSelect', eventData);
};

/**
 * 다중 좌석 선택 이벤트를 발생시키는 메서드
 * @param {MouseEvent} mouseUpEvent
 * @private
 */
SelectionControl.prototype._fireMultipleSelectEvent = function(mouseUpEvent) {
    var map = this.map,
        mpow = Math.pow,
        layerPanelPos = domutil.getPosition(map.getLayerPanel()),
        selectionEl = this.selectionElement,
        selectionElPos,
        size,
        rect,
        eventData;

    size = domutil.getSize(selectionEl);

    if (size.x > 0 && size.y > 0) {
        selectionElPos = domutil.getPosition(selectionEl, true)._subtract(layerPanelPos);
        rect = Rect.n(selectionElPos, Point.n(selectionElPos.x + size.x, selectionElPos.y + size.y));
        eventData = {
            selectType: 'multiple',
            shiftKey: mouseUpEvent.shiftKey,
            range: Rect.getRatio(rect, mpow(2, map.getZoom()), mpow(2, map.options.zoomLevelInMapSize))
        };

        map.fire('beforeSelect', eventData);
    }
};

/**********
 * public methods
 **********/

/**
 * 선택 동작을 취소하는 메서드
 * @private
 */
SelectionControl.prototype.clearSelection = function() {
    this._clearSelectionElement();
    this._toggleDragEvent(false);
};

/**********
 * event handler
 **********/

/**
 * 맵의 패닝이 시작되었을때 이벤트 핸들러
 * @private
 */
SelectionControl.prototype._onMapMoveStart = function() {
    this._mapMoved = true;
};

/**
 * 맵 패닝이 끝났을 때 이벤트 핸들러
 * @private
 */
SelectionControl.prototype._onMapMoveEnd = function() {
    this._mapMoved = false;
};

/**
 * 마우스 다운 핸들러
 * @param {MouseEvent} mouseDownEvent
 * @private
 */
SelectionControl.prototype._onMouseDown = function(mouseDownEvent) {
    domevent.stopPropagation(mouseDownEvent);

    var map = this.map;

    if (map.disabled) {
        return;
    }

    if (this._getButton(mouseDownEvent) !== 0) {
        return;
    }

    this._selectStartPoint = domevent.getMousePosition(mouseDownEvent, this.container);

    if (mouseDownEvent.shiftKey) {
        map.disablePanAndZoom();
        this._toggleDragEvent(true);
    } else {
        domutil.disableImageDrag();
        domutil.disableTextSelection();
        domevent.on(document, 'mouseup', this._onMouseUp, this);
    }
};

/**
 * min, max가 역전된 사각형을 올바르게 수정한다
 * @param {Rect} rect
 * @private
 */
SelectionControl.prototype._revertRect = function(rect) {
    var min = rect.min,
        max = rect.max,
        newMin,
        newMax;

    if (max.x < min.x || max.y < min.y) {
        // min, max 가 역전되었을 경우 처리
        newMin = new Point(
            (max.x < min.x) ? max.x : min.x,
            (max.y < min.y) ? max.y : min.y
        );
        newMax = new Point(
            (max.x > min.x) ? max.x : min.x,
            (max.y > min.y) ? max.y : min.y
        );
    }

    return new Rect(newMin || min, newMax || max);
};

/**
 * 마우스 이동 이벤트 핸들러
 * @param {MouseEvent} mouseMoveEvent
 * @private
 */
SelectionControl.prototype._onMouseMove = function(mouseMoveEvent) {
    var selectionEl = this.selectionElement,
        min = this._selectStartPoint,
        max = domevent.getMousePosition(mouseMoveEvent, this.container);

    if (this._mapMoved) {
        return;
    }

    var rect = this._revertRect(new Rect(min, max)),
        size = rect.getSize(),
        renderFn = common.bind(this._renderCallback, this, rect.min, size, selectionEl);

    domutil.addClass(document.body, 'seat-selecting');
    tUtil.cancelAnimFrame(this._animRequest);
    this._animRequest = tUtil.requestAnimFrame(renderFn, this, true);
};

/**
 * 위치, 크기를 엘리먼트에 적용한다
 * @param {Point} position 엘리먼트의 위치 (top, left)
 * @param {Point} size 엘리먼트의 크기 (width, height)
 * @param {HTMLElement} el
 * @private
 */
SelectionControl.prototype._renderCallback = function(position, size, el) {
    if (size.x > 0 && size.y > 0) {
        el.style.display = 'block';
        el.style.width = size.x + 'px';
        el.style.height = size.y + 'px';
        domutil.setPosition(el, position);
    }
};

/**
 * 마우스 업 이벤트 핸들러
 * @param {MouseEvent} mouseUpEvent
 * @private
 */
SelectionControl.prototype._onMouseUp = function(mouseUpEvent) {
    this.map.enablePanAndZoom();

    var mouseUpPoint = domevent.getMousePosition(mouseUpEvent, this.container);

    domutil.removeClass(document.body, 'seat-selecting');

    if (!this._mapMoved) {
        if (this._selectStartPoint.equals(mouseUpPoint)) {
            this._fireSingleSelectEvent(mouseUpEvent, mouseUpPoint);
        } else {
            this._fireMultipleSelectEvent(mouseUpEvent);
        }
    }

    this.clearSelection();
    tUtil.cancelAnimFrame(this._animRequest);
};

module.exports = SelectionControl;
