/**
 * @fileoverview HTML UI, API, SeatingMAP 사이의 메세지를 전달하는 객체
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var API = require('./api'),
    Semaphore = require('./semaphore');

var common = ne.util;

/**
 * InteractBroker 클래스
 * @constructor
 */
function InteractBroker() {
    /**
     * API요청 수를 가지고 preloader를 제어하기 위해 사용하는 모듈
     * @type {Semaphore}
     * @private
     */
    this._semaphore = new Semaphore();

    /**
     * IB에서 사용할 여러 세팅 값을 저장하기 위한 프로퍼티
     * @type {ne.util.HashMap}
     */
    this.sessionData = new common.HashMap();

    /**
     * IB의 이벤트가 발생(emit)될 때 별도의 처리를 위한 함수를 등록하는 경우
     *
     * 이 곳에 저장된다.
     * @type {ne.util.HashMap}
     */
    this.ORDERLIST = new common.HashMap();
    this.api = new API();


    this._semaphore.on('lock', this._onLock, this);
    this._semaphore.on('unlock', this._onUnlock, this);
    /**
     * UI블로킹 시 딤드를 노출할 타이머
     * @type {number}
     */
    this.timerID = 0;

    /**
     * 윈도우를 닫거나 다른 url탐색할 때 confirm을 주기 위한 속성
     * @type {boolean}
     */
    this.preventCloseWindow = false;

    window.onbeforeunload = common.bind(function() {
        if (this.preventCloseWindow) {
            return '페이지를 닫거나 이동하면 지금까지 작업하신 내용을 잃어버릴 수 있습니다';
        }
    }, this);

    this.addOrder(EVENT.LOAD_RSEAT, this._loadRSeat);
    this.addOrder(EVENT.SELECT_RSEAT, this._selectRSeat);

    this.addOrder(EVENT.ENABLE_CHART, this._clearUITimer);
    this.addOrder(EVENT.DISABLE_CHART, this._setUITimer);
}

//커스텀이벤트 믹신
common.CustomEvents.mixin(InteractBroker);

var ERROR = {
    'E0': 'InteractBroker#requestToAPI 네트워크에 문제가 있습니다.'
};

/**********
 * static props
 **********/

var EVENT = {
    LOAD_RSEAT: 'loadRSeat',    // 지정석 분산 요청 시작
    LOAD_RSEAT_COMPLETED: 'loadRSeatCompleted',

    RSEAT_RENDERED: 'RSeatRendered',    // 지정석이 화면에 그려졌다는 것을 알림

    SEAT_LOADED: 'seatLoaded',  // 삭제 예정

    SELECT_RSEAT: 'selectRSeat',
    SELECT_RSEAT_COMPLETED: 'selectRSeatComplete',

    SELECT_NSEAT: 'selectNSeat',

    MAP_SELECTED_SEAT: 'selectedSeat',

    MAP_SELECT_SEAT: 'selectSeat',
    MAP_DESELECT_SEAT: 'mapDeselectSeat',    // 선택좌석 중 일부가 선택해제되었음을 알림
    MAP_DESELECT_ALL_SEAT: 'mapDeselectAllSeat',    // 선택된 좌석 전부가 선택해제되었음을 알림
    MAP_WORK_DESELECT_ALL_SEAT: 'mapWorkDeselectAllSeat',    // 선택좌석들을 모두 선택해제하도록 seatingChart에게 알림
    MAP_FOCUS_SEAT: 'mapFocusSeat',
    MAP_BLUR_SEAT: 'mapBlurSeat',
    MAP_MOVE_START: 'mapMoveStart',
    MAP_MOVE_END: 'mapMoveEnd',

    ENABLE_CHART: 'enableSeatingChart',
    DISABLE_CHART: 'disableSeatingChart',

    SHOW_DIMM_MSG: 'showDimmMsg',
    HIDE_DIMM_MSG: 'hideDimmMsg',

    SHOW_PRELOADER: 'showPreloader',
    HIDE_PRELOADER: 'hidePreloader',

    SHOW_SHRT_KEY: 'showShrtKey',

    ZOOM: 'zoom',
    ZOOM_IN: 'zoomIn',
    ZOOM_OUT: 'zoomOut',
    ZOOM_RESET: 'zoomReset'
};

InteractBroker.EVENT = EVENT;

/**
 * 로딩 지연 시 딤드레이어를 띄우기까지의 ms
 * @type {number}
 */
InteractBroker.PROGRESS_DELAY = 500;

/**********
 * common seat collection methods
 **********/

/**
 * 좌석 데이터 복제 메서드
 * @param {object} seat
 * @returns {object}
 */
function cloneSeatData(seat) {
    var clone = {};

    clone.sid = seat.sid;
    clone.mapInfo = seat.mapInfo.slice(0);

    return clone;
}

/**
 * semaphore 가 lock 될때 DISABLE CHART 이벤트를 트리거 한다.
 * @param {Object} options
 * @param {String} options.msg API요청이 지연될 때 노출할 문구
 * @param {Boolean} options.dimmImmediate true 지정 시 딤드 레이어를 지연 없이 바로 노출
 * @param {Boolean} options.noDimm true지정 시 딤드레이어 사용 안함
 * @param {Boolean} options.noDisableChart true 지정 시 API요청 중간에 차트 인터렉션을 막는다
 * @private
 */
InteractBroker.prototype._onLock = function(options) {
    this.emit(InteractBroker.EVENT.DISABLE_CHART, options);
};

/**
 * semaphore 가 unlock 될 때 ENABLE_CHART 이벤트를 트리거한다.
 * @private
 */
InteractBroker.prototype._onUnlock = function() {
    this.emit(InteractBroker.EVENT.ENABLE_CHART);
};

/**
 * 현재 semaphore 가 lock 상태인지 확인한다.
 * @returns {boolean}
 */
InteractBroker.prototype.isLocked = function() {
    return this._semaphore.get('count') > 0;
};

/**
 * 좌석 hashMap을 복제한다
 * @return {*}
 */
InteractBroker.prototype.cloneSeatHashMap = function(hashMap) {
    var result = new common.HashMap();

    hashMap.each(function(seat) {
        result.set(seat.sid, seat.clone());
    });

    return result;
};

/**
 * 현재 선택되어진 좌석들의 hashmap을 반환한다
 * @returns {HashMap}
 * @param {boolean} [clone=false] 복제 반환 여부
 */
InteractBroker.prototype.getSeatsToUpdate = function(clone) {
    clone = common.isExisty(clone) ? clone : false;

    var selectCtrl = this.get('selectCtrl'),
        seats = selectCtrl.seats;

    if (clone) {
        seats = this.cloneSeatHashMap(seats);
    }

    return seats;
};

/**
 * 서버 API의 그리드 리스트 데이터에서 좌석 배열만 별도로 뽑아 반환
 * @param {object} grids
 * @return {Array.<RSeat>}
 */
InteractBroker.prototype.getSeatDataFormGrids = function(grids) {
    var result = [];

    common.forEachOwnProperties(grids, function(grid) {
        common.forEachArray(grid.seats, function(seat) {
            result.push(cloneSeatData(seat));
        });
    });

    return result;
};

/**
 * 서버로 좌석 데이터를 보내기 전 사용.
 *
 * 좌석모델에서 필요 데이터만 추려 복제한 객체를 반환
 * @param {RSeat} seat
 * @returns {Object|*}
 * @private
 */
InteractBroker.prototype._simplify = function(seat) {
    var result = {};

    result.sid = seat.sid;

    result.bound = common.map(seat.bound, function(point) {
        return [point.x, point.y];
    });

    result.cornerPoints = common.map(seat.points, function(point) {
        return [point.x, point.y];
    });

    result.position = [seat.position.x, seat.position.y];

    result.mapInfo = seat.mapInfo.slice(0);

    return result;
};

/**********
 * order methods
 **********/

/**
 * 지정석 선택 API호출
 * @virtual
 * @param {string[]} sidList 지정석 sid배열
 * @param {boolean} [panToCenter=false] true전달 시 선택된 지정석의 중심점으로 드로잉 영역을 움직인다
 * @private
 */
InteractBroker.prototype._selectRSeat = function(sidList, panToCenter) {}; // jshint ignore:line

/**
 * gridID로 서버에 grid에 포함된 지정석에 대한 정보를 요청한다
 * @virtual
 * @param {string[]} gridIDList 요청하려는 그리드 id목록
 * @param {function} callback 요청 완료 후 호출되는 콜백
 * @private
 */
InteractBroker.prototype._loadRSeat = function(gridIDList, callback) {}; // jshint ignore:line

/**
 * 일정 시간 후에 preloader를 노출시킨다
 * @param {Object} options
 * @param {String} options.msg API요청이 지연될 때 노출할 문구
 * @param {Boolean} options.dimmImmediate true 지정 시 딤드 레이어를 지연 없이 바로 노출
 * @param {Boolean} options.noDimm true지정 시 딤드레이어 사용 안함
 * @param {Boolean} options.noDisableChart true 지정 시 API요청 중간에 차트 인터렉션을 막는다
 * @private
 */
InteractBroker.prototype._setUITimer = function(options) {
    var self = this;

    options = common.extend({
        msg: '요청을 처리하는 중입니다. 잠시만 기다려 주세요.',
        noDimm: false,
        immadiate: false,
        noDisableChart: false
    }, options);

    if (!options.noDimm) {
        if (options.immadiate) {
            self.emit(InteractBroker.EVENT.SHOW_PRELOADER, options.msg);
        } else {
            this._clearUITimer();
            this.timerID = window.setTimeout(function() {
                self.emit(InteractBroker.EVENT.SHOW_PRELOADER, options.msg);
            }, InteractBroker.PROGRESS_DELAY);
        }
    }

    if (!options.noDisableChart) {
        this.fire(EVENT.DISABLE_CHART);
    }
};

/**
 * 노출되어 있던 preloader를 숨긴다
 * @private
 */
InteractBroker.prototype._clearUITimer = function() {
    window.clearTimeout(this.timerID);
    this.timerID = 0;

    this.emit(InteractBroker.EVENT.HIDE_PRELOADER);
    this.fire(EVENT.ENABLE_CHART);
};

/**********
 * private methods
 **********/

/**
 * API요청을 보내기 전 호출
 * @param {Object} options
 * @param {String} options.msg API요청이 지연될 때 노출할 문구
 * @param {Boolean} options.dimmImmediate true 지정 시 딤드 레이어를 지연 없이 바로 노출
 * @param {Boolean} options.noDimm true지정 시 딤드레이어 사용 안함
 * @param {Boolean} options.noDisableChart true 지정 시 API요청 중간에 차트 인터렉션을 막는다
 * @private
 */
InteractBroker.prototype._beforeRequest = function(options) {
    this._semaphore.acquire(options);
};

/**
 * API요청에 문제가 발생했을 경우 (연결 오류) 호출
 * @private
 */
InteractBroker.prototype._errorRequest = function() {
    alert('예기치 못한 오류로 처리하지 못했습니다.\n 재시도 부탁드립니다.');
};

/**********
 * method
 **********/

/**
 * @param {(string|API.URL)} type
 * @param {object} options
 * @param {string} [options.msg] 요청이 2초 이상 지연될 때 노출되는 딤드 레이어의 문구
 * @param {function} [options.complete]
 */
InteractBroker.prototype.requestToAPI = function(type, options) {
    options = common.extend({
        beforeRequest: function() {},
        error: function() {
            throw new Error(ERROR.E0);
        },
        complete: function() {},
        dimmImmediate: false,
        noDimm: false,
        noDisableChart: false,
        noPreventCloseWindow: false,
        msg: '요청을 처리하는 중입니다. 잠시만 기다려 주세요'
    }, options);

    if (!options.noPreventCloseWindow) {
        this.preventCloseWindow = true;
    }

    options.beforeRequest = common.bind(function(fn) {
        this._beforeRequest.call(this, {
            msg: options.msg,
            dimmImmediate: options.dimmImmediate,
            noDimm: options.noDimm,
            noDisableChart: options.noDisableChart
        });
        fn.call(this, options);
    }, this, options.beforeRequest);

    options.complete = common.bind(function(fn) {
        this._semaphore.release();
        fn.apply(this);
    }, this, options.complete);

    options.error = common.bind(function(fn) {
        this._semaphore.reset();
        this._errorRequest();
        fn.apply(this, arguments);
    }, this, options.error);

    this.api.call(type, options);
};

/**
 * IB가 발생시키는 이벤트에 핸들러를 바인딩한다
 * @param {string} type 이벤트명
 * @param {function} fn 함수
 * @param {*} context 함수 컨텍스트
 */
InteractBroker.prototype.listen = function(type, fn, context) {
    if (type && fn) {
        this.on(type, fn, context);
    }
};

/**
 * IB에 등록된 이벤트 핸들러를 해제한다
 * @param {string} type 이벤트명
 * @param {*} context 함수 컨텍스트
 */
InteractBroker.prototype.stopListen = function(type, context) {
    if (common.isExisty(context)) {
        this.off(context, type);
    } else {
        this.off(type);
    }
};

/**
 * 이벤트를 발생시킨다
 * @param {string} type 이벤트명
 */
InteractBroker.prototype.emit = function(type) {
    var args,
        orderF;

    if (type) {
        args = Array.prototype.slice.call(arguments, 1);
        orderF = this.ORDERLIST.get(type);

        if (orderF) {
            orderF.apply(this, args);
        } else {
            this.fire.apply(this, [type].concat(args));
        }
    }
};

/**
 * IB에 임의의 데이터를 저장한다
 * @param {string} id 데이터 저장과 사용에 쓰일 키
 * @param {*} value 값
 */
InteractBroker.prototype.set = function(id, value){
    this.sessionData.set(id, value);
};

/**
 * IB에 저장된 임의의 데이터를 반환
 * @param {string} id 데이터 저장 시 지정했던 키
 * @returns {*}
 */
InteractBroker.prototype.get = function(id){
    return this.sessionData.get(id);
};

/**
 * IB 단순 이벤트 발생에 별도의 로직을 붙여야 하는 경우 사용
 * @param {string} type
 * @param {function} orderF
 */
InteractBroker.prototype.addOrder = function(type, orderF){
    this.ORDERLIST.set(type, orderF);
};

module.exports = InteractBroker;
