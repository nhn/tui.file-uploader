/**
 * @fileoverview 맵이 확대 축소될 때 등록된 Brush들의 활성 상태를 토글하는 모듈
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */
'use strict';

var util = ne.util;

/**
 * @typedef {object} RangeItem
 * @property {(string|number|Array)} range 브러시 노출 줌 범위
 * @property {Array.<Brush>} brushes 브러시 리스트
 */

/**
 * ZoomReactor 클래스
 * @constructor
 * @exports ZoomReactor
 * @class
 */
function ZoomReactor() {
    /**
     * 중복등록 방지용
     * @type {{stamp:string, exist:boolean}}
     */
    this.brushes = {};

    /**
     * @type {object.<string, RangeItem>}
     */
    this.rangeSet = {};
}

/**********
 * static props
 **********/

ZoomReactor.CONFIG = {};

/**********
 * method
 **********/

/**
 * 브러시에 해당하는 렌더링 범위를 설정한다
 * @param {T.<Brush>} brush brush instance
 */
ZoomReactor.prototype.setReactZoomRange = function(brush) {
    var stamp = util.stamp(brush),
        toggleRange,
        rangeSet,
        rangeKey;

    if (this.brushes[stamp]) {
        return;
    }

    this.brushes[stamp] = true;

    toggleRange = ZoomReactor.CONFIG[brush.brushName];

    if (util.isExisty(toggleRange)) {
        rangeKey = toggleRange.join(':');
    } else {
        rangeKey = 'all';
    }

    rangeSet = this.rangeSet[rangeKey];

    if (!util.isExisty(rangeSet)) {
        rangeSet = this.rangeSet[rangeKey] = {
            range: rangeKey === 'all' ? 'all' : toggleRange,
            brushes: []
        };
    }

    rangeSet.brushes.push(brush);
};

/**
 * zoomLevel 에 노출/숨김되어야 하는 브러시들을 찾아 반환한다
 * @param {number} zoomLevel zoom level
 * @returns {{found: Array, rest: Array}} lists need to toggle
 */
ZoomReactor.prototype.findRangeSet = function(zoomLevel) {
    var found = [],
        rest = [];

    util.forEachOwnProperties(this.rangeSet, function(data, key) {
        var range = data.range;

        if (key === 'all') {
            found.push(data);
        } else if (range.length === 1 && range[0] === zoomLevel) {
            found.push(data);
        } else if (range.length === 2 && (range[0] <= zoomLevel && zoomLevel <= range[1])) {
            found.push(data);
        } else {
            rest.push(data);
        }
    });

    return {
        found: found,
        rest: rest
    };
};

/**
 * 각 줌 레벨 단계에서 브러시를 조건에 따라 토글한다
 * @param {number} zoomLevel zoom level
 */
ZoomReactor.prototype.react = function(zoomLevel) {
    var rangeSet = this.findRangeSet(zoomLevel),
        found = rangeSet.found,
        rest = rangeSet.rest,
        front = [];

    util.forEachOwnProperties(this.rangeSet, function(set) {
        util.forEachArray(set.brushes, function(brush) {
            brush.disabled = false;
        });
    });

    util.forEachArray(found, function(setItem) {
        if (setItem.brushes) {
            util.forEachArray(setItem.brushes, function(brush) {
                if (brush.isAlwaysFront) {
                    front.push(brush);
                }
                brush.show();
            });
        }
    });

    util.forEachArray(rest, function(setItem) {
        if (setItem.brushes) {
            util.forEachArray(setItem.brushes, function(brush) {
                brush.hide();
            });
        }
    });

    util.forEachArray(front, function(brush) {
        brush.toFront();
    });
};

module.exports = ZoomReactor;

