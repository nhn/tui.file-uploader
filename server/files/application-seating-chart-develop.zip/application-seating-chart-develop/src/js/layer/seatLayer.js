/**
 * @fileoverview 특정 모델과 Brush를 관리하여 화면에 그릴 수 있도록 중간 매개체 역할을 하는 클래스
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */

'use strict';

var Seat = require('../model/seat'),
    ZoomReactor = require('./zoomReactor'),
    SeatBrush = require('../brush/seatBrush'),
    SellingTypeBrush = require('../brush/sellingTypeBrush'),
    GradeBrush = require('../brush/gradeBrush'),
    TextBrush = require('../brush/textBrush');

var common = ne.util;

/**
 * SeatLayer 클래스
 * 현재 구조 SeatLayer단위의 렌더링
 * 한Seat의 속성이 변경이되면 그 Seat속한 SeatLayer가 다시 그려지는 구조
 * @param {Object} options 생성옵션
 * @param {Raphael} options.paper 라파엘 페이퍼
 * @param {Seat[]} [options.seats] Seat배열
 * @constructor
 */
function SeatLayer(options) {
    /**
     * 라파엘 페이퍼 Path아이템에 전달하는 용도
     * @type {Raphael}
     */
    this.paper = options.paper;

    /**
     * Seat 목록
     * @type {HashMap}
     */
    this.seats = new common.HashMap();

    /**
     * SeatLayer를 사용하는 단에서 정하는 SeatLayer 고유아이디
     * @type {String}
     */
    this.slid = options.slid;

    /**
     * Brush 목록
     * @type {HashMap}
     */
    this.brushes = new common.HashMap();

    /**
     * SeatBrush가 그려질순서대로의 ID목록
     * @type {String[]}
     */
    this.brushOrder = [];

    /**
     * SeatLayer를 다시 그려야야 하는지 아닌지에대한 flag
     * @type {boolean}
     */
    this.dirtied = false;

    /**
     * ZoomReactor
     * @type {ZoomReactor}
     */
    this.zoomReactor = new ZoomReactor();

    /**
     * 패스연산의 결과를 한번에 처리하기 위한 용도로 사용
     * @type {{ brushID: string, path: string[] }}
     */
    this.pathBuffer = {};
}

/**
 * SeatLayer가 사용하는 기본 모델 생성자를 등록해둠
 */
SeatLayer.prototype.SeatConstructor = Seat;


/**********
 * static props
 **********/

/**
 * 판매등급 코드 리스트
 * @type {Array}
 */
SeatLayer.GRADE_CODE = [];

/**
 * 판매 할당처 코드 리스트
 * @type {Array}
 */
SeatLayer.SELLING_TYPE_CODE = [];


/**********
 * private props
 **********/

/**
 * SeatLayer에 Brush를 등록하고 ZoomReactor에 Brush가 노출될 줌 레벨 범위를 설정한다
 * @param {string} brushID
 * @param {Brush} brush
 * @private
 */
SeatLayer.prototype._setBrush = function(brushID, brush) {
    this.brushes.set(brushID, brush);
    this.brushOrder.push(brushID);
    this.zoomReactor.setReactZoomRange(brush);
};


/**********
 * public props
 **********/

/**
 * Seat을 추가한다
 * @param {Seat|Seat[]} seats
 */
SeatLayer.prototype.addSeat = function(seats) {
    var self = this;

    seats = common.isArray(seats) ? seats : [seats];

    common.forEach(seats, function(seat) {
        self.seats.set(seat.getID(), seat);
        seat.slid = self.getID();
    });

    this.dirty();
};

/**
 * 인자로 전달된 사각 좌표에 포함되는 모델 리스트를 반환한다
 * @param {number} x1
 * @param {number} y1
 * @param {number} x2
 * @param {number} y2
 * @param {boolean} [includeDisabled]
 * @return {Array}
 */
SeatLayer.prototype.getSeatsInsideRect = function(x1, y1, x2, y2, includeDisabled) {
    var seats = [],
        ownSeats = this.seats;

    this.eachSeat(function(seat) {
        if (seat.isInsideRect(x1, y1, x2, y2) && (!seat.disabled || includeDisabled)) {
            seats.push(ownSeats.get(seat.getID()));
        }
    });

    return seats;
};

/**
 * 인자로 전달된 좌표를 포함하는 모델 리스트를 반환한다
 * @param {number} x
 * @param {number} y
 * @param {boolean} [includeDisabled]
 * @returns {Array}
 */
SeatLayer.prototype.getSeatsContainPoint = function(x, y, includeDisabled) {
    var seats = [],
        ownSeats = this.seats;

    this.eachSeat(function(seat) {
        if (seat.isContain(x, y) && (!seat.disabled || includeDisabled)) {
            seats.push(ownSeats.get(seat.getID()));
        }
    });

    return seats;
};

/**
 * 모델의 ID를 이용해 모델을 제거한다
 * @param {String|String[]} id
 * @returns {Seat[]} 지워진 모델들
 */
SeatLayer.prototype.removeSeatById = function(id) {
    var seats = this.seats.remove(id);

    seats = common.isArray(seats) ? seats : [seats];

    common.forEach(seats, function(seat) {
        seat.slid = null;
    });

    this.dirty();

    return seats;
};

/**
 * 다수의 모델을 제거한다
 * @param {Seat|Seat[]} seats
 */
SeatLayer.prototype.removeSeat = function(seats) {
    var ids = [];

    seats = common.isArray(seats) ? seats : [seats];

    common.forEach(seats, function(seat) {
        ids.push(seat.getID());
    });

    return this.removeSeatById(ids);
};

/**
 * 레이어가 가진 모든 모델을 제거한다
 */
SeatLayer.prototype.removeAllSeat = function() {
    this.seats.removeAll();
    this.dirty();
};

/**
 * 소유한 모델들을 순회하며 반복자를 실행한다
 * @param {Function} func
 */
SeatLayer.prototype.eachSeat = function(func) {
    this.seats.each(func);
};

/**
 * Brush가 셋팅된 순서로 PathItem을 렌더링한다.
 */
SeatLayer.prototype.render = function() {
    var self = this;
    common.forEach(this.brushOrder, function(brushID) {
        self.brushes.get(brushID).render();
    });
};

/**
 * SeatLayer에 변경사항이 있을 경우 path를 생성하여 엘리먼트를 다시 그린다
 *
 * @param {boolean} [force] dirty 여부와 상관없이 무조건 그린다
 */
SeatLayer.prototype.update = function(force) {
    if (force || this.isDirty()) {
        this.clear();
        this.prepareToRender();
        this.render();
        this.notDirty();
    }
};

/**
 * 모델 렌더링에 필요한 스타일과 메소드를 등록한다.
 * @param {string} brushID
 * @param {Brush} brush Brush 인스턴스
 */
SeatLayer.prototype.setBrush = function(brushID, brush) {
    var self = this;

    if (brush) {
        self._setBrush(brushID, brush);
    } else {
        common.forEachOwnProperties(brushID, function(brush, brushID) {
            self._setBrush(brushID, brush);
        });
    }

};

/**
 * 모델을 Brush에 전달해 path를 생성한다
 * @param {String} brushID
 * @param {Seat} seat
 */
SeatLayer.prototype.useBrush = function(brushID, seat) {
    var brush = this.brushes.get(brushID);
    if(brush){
        brush.addItemBySeat(seat);
    }
};

/**
 * Brush 의 PathElement에 설정될 path를 설정한다
 * @param {String} brushID
 * @param {String} path
 */
SeatLayer.prototype.addPath = function(brushID, path) {
    var brush = this.brushes.get(brushID);

    if(brush){
        brush.addPath(path);
    }
};

/**
 * SeatLayer의 브러시를 순회하며 path와 엘리먼트를 초기화한다
 */
SeatLayer.prototype.clear = function() {
    this.brushes.each(function(brush) {
        brush.clear();
    });
};

/**
 * 모델을 순회하여 브러시가 렌더링에 필요한 path를 생성하여 PathElement를 준비하게 한다
 */
SeatLayer.prototype.prepareToRender = function() {
    var self = this,
        brushIDList,
        buffer = this.pathBuffer,
        bufferItem,
        forEachArr = common.forEachArray;

    this.eachSeat(function(seat) {
        brushIDList = self.getBrushIDFromSeat(seat);

        forEachArr(brushIDList, function(brushID) {
            bufferItem = buffer[brushID];

            if (!bufferItem) {
                bufferItem = buffer[brushID] = [];
            }

            if (!self.brushes.has(brushID)) {
                throw Error('SeatLayer#prepareToRender: 렌더링 할 브러시 코드가 없습니다');
            }

            if (brushID === 'text') {
                bufferItem.push(self.brushes.get(brushID).generateText(seat));
            } else {
                bufferItem.push(self.brushes.get(brushID).generatePath(seat));
            }
        });
    });

    this.brushes.each(function(brush, name) {
        if (name === 'text') {
            brush.getViewItem().textData = buffer[name];
        } else if (buffer[name]) {
            brush.getViewItem().pathStr = buffer[name].join('');
        }
    });

    this.pathBuffer = {};
};

/**
 * 모델의 속성을 토대로 그려질 Brush의 ID들을 반환한다
 *
 * ex) 지정석이 "A등급", "매진" 의 속성을 가지고 있을 경우 "A등급", "매진" 의 그림을 그릴 수 있는 Brush의 ID를 반환
 * @return {string[]}
 */
SeatLayer.prototype.getBrushIDFromSeat = function(seat) {
    var brushIDs = [];

    if (seat) {
        brushIDs.push('normal');
    }

    return brushIDs;
};

/**
 * 서버에서 캐시된 path를 브러시에 설정한다
 *
 * @param {Object<string, string>} paths
 */
SeatLayer.prototype.initPaths = function(paths) {
    var self = this;

    common.forEach(paths, function(path, brushID) {
        self.addPath(brushID, path);
    });
};

/**
 * SeatLayer의 ID를 반환
 * @returns {String}
 */
SeatLayer.prototype.getID = function() {
    return this.slid;
};

/**
 * SeatLayer의 변경사항 존재 여부 확인
 * @returns {boolean}
 */
SeatLayer.prototype.isDirty = function() {
    return this.dirtied;
};

/**
 * SeatLayer에 변경사항 존재 여부 표시
 */
SeatLayer.prototype.dirty = function() {
    this.dirtied = true;
};

/**
 * SeatLayer에 변경사항 존재 여부 표시
 */
SeatLayer.prototype.notDirty = function() {
    this.dirtied = false;
};

/**********
 * 기본 Brush 단축
 **********/

/**
 * 기본 Brush
 */
SeatLayer.prototype.setNormalBrush = function() {
    var normalBrush = new SeatBrush({paper: this.paper});

    normalBrush.setStyle({
        fill: '#C00000',
        'stroke-width': 0,
        cursor: 'pointer'
    });

    this.setBrush('normal', normalBrush);
};

/**
 * 좌석등급 Brush
 */
SeatLayer.prototype.setGradeBrush = function() {
    var self = this;

    common.forEach(SeatLayer.GRADE_CODE, function(type) {

        self.setBrush(type, new GradeBrush({
            paper: self.paper,
            type: type
        }));

    });
};

/**
 * 판매할당처 Brush
 */
SeatLayer.prototype.setSellingTypeBrush = function() {
    var self = this;

    common.forEachOwnProperties(SeatLayer.SELLING_TYPE_CODE, function(label, code) {

        self.setBrush(code, new SellingTypeBrush({
            paper: self.paper,
            type: code
        }));

    });
};

/**
 * 매진 Brush
 */
SeatLayer.prototype.setSoldoutBrush = function() {
    var soldoutBrush = new SeatBrush({paper: this.paper});

    soldoutBrush.setStyle({
        fill: '#fff',
        opacity: 0.8,
        'stroke-width': 0
    });

    soldoutBrush.isAlwaysFront = true;

    this.setBrush('soldout', soldoutBrush);
};

/**
 * 지정석 매핑정보 노출 Brush
 */
SeatLayer.prototype.setTextBrush = function() {
    this.setBrush('text', new TextBrush({paper: this.paper}));
};

module.exports = SeatLayer;
