/**
 * @fileoverview 영역 이미지를 그리는 역할
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var Area = require('../model/area'),
    AreaBrush = require('../brush/areaBrush'),
    SeatLayer = require('../layer/seatLayer');

var common = ne.util;

/**
 * 영역 레이어 클래스
 * @param {Object} options
 * @param {Raphael} options.paper 렌더링에 사용되는 Raphael의 paper객체
 * @param {Area[]} options.areas 기본정보에 포함된 영역좌표 정보 (서버에서 내려줌)
 * @constructor
 * @extends {SeatLayer}
 */
function AreaLayer(options) {
    SeatLayer.call(this, options);

    this.setBrushes();
}

// 상속
common.inherit(AreaLayer, SeatLayer);

/**********
 * override props
 **********/

/**
 * Area 모델이 들어가야 할 brushID를 반환한다
 */
AreaLayer.prototype.getBrushIDFromSeat = function() {
    return ['normal'];
};


/**********
 * public methods
 **********/

/**
 * AreaLayer 가 사용하는 브러시 전체를 세팅
 */
AreaLayer.prototype.setBrushes = function() {
    this.setBrush('normal', new AreaBrush({ paper: this.paper }));
};

/**
 * API데이터를 토대로 프로퍼티를 설정
 * @param {Array} areaData 기초 도면 정보에 포함된 areaData
 */
AreaLayer.prototype.setData = function(areaData) {
    common.forEachArray(areaData, function(data) {
        var area = new Area(data),
            id = area.getID();

        this.seats.set(id, area);
    }, this);

    this.dirty();
};

module.exports = AreaLayer;
