/**
 * @fileoverview 선택된 지정석들의 표현계층
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */

'use strict';

var NSeatLayer = require('./nSeatLayer'),
    NSeatBrush = require('../brush/nSeatBrush');


/**
 * 비 지정석 선택상태 표현계층
 * @param {Object} options
 * @param {Raphael} options.paper 렌더링 시 사용되는 Raphael의 Paper객체
 * @constructor
 * @extends {NSeatLayer}
 * @exports SelectNonReservedSeatLayer
 * @class
 */
function FocusNSeatLayer(options) {
    NSeatLayer.call(this, options);
}

ne.util.inherit(FocusNSeatLayer, NSeatLayer);

/**********
 * static props
 **********/

FocusNSeatLayer.GRADE_CODE = [];

/**********
 * override methods
 **********/

/**
 * 비 지정석의 path를 그릴 brushID를 반환하는 메서드
 * @return {string[]}
 */
FocusNSeatLayer.prototype.getBrushIDFromSeat = function() {
    return ['normal'];
};

/**
 * 브러시 세팅
 */
FocusNSeatLayer.prototype.setBrushes = function() {
    var paper = this.paper,
        defaultOption = { paper: paper, type: 'focus'},
        normal = new NSeatBrush(defaultOption);

    //포커스는 항상 최상단에 노출되어야한다.
    normal.isAlwaysFront = true;

    this.setBrush('normal', normal);
};

module.exports = FocusNSeatLayer;
