/**
 * @fileoverview 선택된 지정석들의 표현계층
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var RSeat = require('../model/rSeat'),
    SeatLayer = require('./seatLayer'),
    SeatBrush = require('../brush/seatBrush'),
    SellingTypeBrush = require('../brush/sellingTypeBrush'),
    GradeBrush = require('../brush/gradeBrush'),
    SelectSeatBrush = require('../brush/selectSeatBrush');

var common = ne.util;

/**
 * 선택된 지정석들에 대한 표현계층
 * @param {Object} options 생성 옵션
 * @param {Raphael} options.paper 라파엘 페이퍼
 * @constructor
 * @extends {SeatLayer}
 * @class
 */
function SelectSeatLayer(options) {
    SeatLayer.call(this, options);

    /**
     * Raphael Set
     * @type {null}
     */
    this.setElement = this.paper.set();

    this.setBrushes();
}

common.inherit(SelectSeatLayer, SeatLayer);

SelectSeatLayer.prototype.SeatConstructor = RSeat;

/**********
 * static props
 **********/

/**
 * 지정석 드래그 인스턴스를 저장하기 위한 프로퍼티
 *
 * 물리도면에서만 활용된다
 * @type {SeatDraggable}
 */
SelectSeatLayer.DRAGGABLE = null;

/**********
 * override methods
 **********/

/**
 * 인자로 전달된 좌석의 브러시 ID목록을 반환하는 메서드
 * @param seat
 * @returns {string[]}
 */
SelectSeatLayer.prototype.getBrushIDFromSeat = function(seat) {
    var brushIDs = ['normal', 'text'];

    if (seat.grade) {
        brushIDs.push(seat.grade);
    }

    if (seat.sellingType) {
        brushIDs.push(seat.sellingType);
    }

    if (seat.soldout) {
        brushIDs.push('soldout');
    }

    brushIDs.push('select');

    return brushIDs;
};

/**********
 * public methods
 **********/

/**
 * 선택된 엘리먼트들을 그룹핑한 Set엘리먼트를 설정한다
 */
SelectSeatLayer.prototype.refreshSetElement = function() {
    var setElement = this.setElement;

    setElement.clear();

    this.brushes.each(function(brush) {
        brush.toFront();
        setElement.push(brush.getViewItem().pathElement);
    });
};

/**
 * 선택된 엘리먼트를 그룹핑한 Set엘리먼트에 SeatDraggable모듈을 사용하여
 *
 * 드래그될 수 있도록 이벤트를 설정한다 {@link SeatDraggable}
 */
SelectSeatLayer.prototype.seatDraggable = function() {
    if (SelectSeatLayer.DRAGGABLE) {
        this.refreshSetElement();
        SelectSeatLayer.DRAGGABLE.init(this.setElement);
    }
};

/**
 * Set엘리먼트를 비운다
 */
SelectSeatLayer.prototype.clearSetElement = function() {
    this.setElement.clear();
};

/**
 * 브러시 세팅
 */
SelectSeatLayer.prototype.setBrushes = function() {
    this.setNormalBrush();
    this.setGradeBrush();
    this.setSellingTypeBrush();
    this.setSoldoutBrush();
    this.setTextBrush();
    this.setSelectBrush();
};

/**
 * 좌석 선택효과 브러시 초기화
 */
SelectSeatLayer.prototype.setSelectBrush = function() {
    this.setBrush('select', new SelectSeatBrush({ paper: this.paper }));
};

/**
 * API 지정석 데이터 세팅 메서드
 * @param {object} data
 */
SelectSeatLayer.prototype.setData = function(data) {
    var ownSeats = this.seats,
        seat;

    common.forEachArray(data, function(seatData) {
        seat = ownSeats.get(seatData.sid);

        if (!seat) {
            seat = new this.SeatConstructor();
        }

        seat.setData(seatData);

        this.addSeat(seat);
    }, this);
};

module.exports = SelectSeatLayer;
