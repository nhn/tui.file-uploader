/**
 * @fileoverview 비지정석을 그리는 객체
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */


'use strict';

var NSeat = require('../model/nSeat'),
    SeatLayer = require('./seatLayer'),
    NSeatBrush = require('../brush/nSeatBrush');

var common = ne.util;

/**
 * 비 지정석 드로잉 클래스
 * @param {Object} options
 * @param {Raphael} options.paper 렌더링 시 사용되는 Raphael의 Paper객체
 * @param {NSeat[]} options.seats 비지정석 모델 인스턴스 배열
 * @constructor
 * @extends {SeatLayer}
 * @exports NSeatLayer
 * @class
 */
function NSeatLayer(options) {
    SeatLayer.call(this, options);
    this.setBrushes();
}

// 상속
common.inherit(NSeatLayer, SeatLayer);

/**********
 * static props
 **********/

// 비 지정석의 등급 코드 별 외곽선 색상을 지정 (Settings 모듈에서 설정된다)
NSeatLayer.GRADE_CODE = [];

NSeatLayer.prototype.SeatConstructor = NSeat;

/**********
 * override methods
 **********/

/**
 * 비 지정석의 path를 그릴 brushID를 반환하는 메서드
 * @param {NSeat} seat
 * @return {string[]}
 */
NSeatLayer.prototype.getBrushIDFromSeat = function(seat) {
    var brushIDs = ['normal'];

    if (common.isExisty(common.pick(seat, 'grade')) && seat.grade !== '') {
        brushIDs.push(seat.grade + '');
        brushIDs.shift();
    }

    if (this.isDimmedSeat(seat) || seat.soldout) {
        brushIDs.push('soldout');
    }

    return brushIDs;
};

/**
 * Seat이 Dim상태(반투명상태)인지 아닌지를 판단한다
 * 현재 하이라이트 그레이드가 있고 Seat의 grade가 하이라이트 그레이드가 아니면 반투명
 * @param {Seat} seat
 */
NSeatLayer.prototype.isDimmedSeat = function(seat){
    return this.hlBrushID ? seat.grade !== this.hlBrushID : false;
};

/**
 * 하이라이트될 브러시아이디를 셋팅한다.
 * @param {string} brushID
 */
NSeatLayer.prototype.setHlBrushId = function(brushID){
    this.hlBrushID = +brushID;
    this.dirty();
};

/**
 * 하이라이트될 브러시아이디를 초기화한다.
 */
NSeatLayer.prototype.clearHlBrushId = function() {
    this.hlBrushID = null;
    this.dirty();
};

/**
 * 비지정석을 화면에 그릴 때 사용될 Brush를 설정
 */
NSeatLayer.prototype.setBrushes = function() {
    var paper = this.paper,
        soldoutBrush;

    this.setBrush('normal', new NSeatBrush({ paper: paper, type: 'normal' }));

    common.forEachArray(NSeatLayer.GRADE_CODE, function(type) {
        var brush = new NSeatBrush({ paper: paper, type: type });
        this.setBrush(type, brush);
    }, this);

    soldoutBrush = new NSeatBrush({ paper: paper, type: 'soldout' });
    soldoutBrush.isAlwaysFront = true;
    this.setBrush('soldout', soldoutBrush);

};

/**
 * 비지정석 데이터를 설정하는 메서드
 * @param {NSeat} data
 */
NSeatLayer.prototype.setData = function(data) {
    var excludeNotAvailSeat = NSeatLayer.excludeNotAvailableSeat,
        ownSeats = this.seats,
        seat;

    common.forEachArray(data, function(seatData) {
        if (!seatData.sid) {
            return;
        }

        if (excludeNotAvailSeat && (seatData.isDisabled || seatData.soldout)) {
            return;
        }

        seat = ownSeats.get(seatData.sid);
        if (!seat) {
            seat = new this.SeatConstructor();
        }

        seat.setData(seatData);

        this.addSeat(seat);
    }, this);
};

module.exports = NSeatLayer;
