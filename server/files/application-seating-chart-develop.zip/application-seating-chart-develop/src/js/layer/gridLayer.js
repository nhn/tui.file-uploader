/**
 * @fileoverview 화면상의 좌석을 그리는 단위인 Grid
 * @author FE개발팀 김성호 sungho.kim@nhnent.com
 */

'use strict';

var SeatLayer = require('./seatLayer'),
    RSeat = require('../model/rSeat');

var common = ne.util;

/**
 * GridLayer
 * @param {Object} options 생성 옵션
 * @param {Raphael} options.paper 렌더링 시 사용되는 Raphael의 Paper객체
 * @constructor
 * @extends {SeatLayer}
 * @exports Grid
 * @class
 */
function GridLayer(options) {
    SeatLayer.call(this, options);
    this.setBrushes();
}

// 상속
common.inherit(GridLayer, SeatLayer);

// 기본 모델 생성자
GridLayer.prototype.SeatConstructor = RSeat;

/**********
 * method
 **********/

/**
 * 그리드 레이어가 모델을 그릴 때 사용하는 브러시 조작
 * @param {RSeat} seat
 * @returns {string[]}
 */
GridLayer.prototype.getBrushIDFromSeat = function(seat) {
    var brushIDs = ['normal', 'text'];

    if (seat.grade){
        brushIDs.push(seat.grade);
        brushIDs.shift();
    }

    if (seat.sellingType) {
        brushIDs.push(seat.sellingType);
    }

    if (this.isDimmedSeat(seat) || seat.soldout) {
        brushIDs.push('soldout');
    } else if (seat.disabled) {
        brushIDs.push('soldout');
    }

    return brushIDs;
};

/**
 * Seat이 Dim상태(반투명상태)인지 아닌지를 판단한다
 * 현재 하이라이트 그레이드가 있고 Seat의 grade가 하이라이트 그레이드가 아니면 반투명
 * @param {Seat} seat
 */
GridLayer.prototype.isDimmedSeat = function(seat){
    return this.hlBrushID ? seat.grade !== this.hlBrushID : false;
};

/**
 * 하이라이트될 브러시아이디를 셋팅한다.
 * @param {string} brushID
 */
GridLayer.prototype.setHlBrushId = function(brushID){
    this.hlBrushID = +brushID;
    this.dirty();
};

/**
 * 하이라이트될 브러시아이디를 초기화한다.
 */
GridLayer.prototype.clearHlBrushId = function() {
    this.hlBrushID = null;
    this.dirty();
};

/**
 * GridLayer가 사용하는 Brush 등록
 */
GridLayer.prototype.setBrushes = function() {
    this.setNormalBrush();
    this.setGradeBrush();
    this.setSellingTypeBrush();
    this.setSoldoutBrush();
    this.setTextBrush();
};

/**
 * API응답 데이터를 토대로 모델을 생성 또는 설정
 * @param {Object} data
 * @param {Object} data.paths gridLayer가 사용하는 path모음
 * @param {Object} data.seats 좌석 모델의 속성 JSON
 * @param {object} [seatSoldoutMap] 좌석 판매여부 정보
 */
GridLayer.prototype.setData = function(data, seatSoldoutMap) {
    var excludeNotAvailSeat = GridLayer.excludeNotAvailableSeat,
        existy = common.isExisty,
        useSoldoutMap = existy(seatSoldoutMap),
        self = this;

    if (data.seats) {
        common.forEach(data.seats, function(seatData) {
            var seat,
                isSoldout;

            if (!seatData.sid) {
                return;
            }

            isSoldout = (useSoldoutMap && existy(common.pick(seatSoldoutMap, seatData.sid))) ?
                seatSoldoutMap[seatData.sid] : seatData.soldout;

            if (excludeNotAvailSeat && (isSoldout || seatData.isDisabled)) {
                return;
            }

            seat = self.seats.get(seatData.sid);
            if (!seat) {
                seat = new self.SeatConstructor();
            }

            seat.setData(seatData);
            seat.soldout = isSoldout;

            self.addSeat(seat);

            //텍스트 데이터는 바로 렌더링을 해줘야함.
            self.useBrush('text', seat);
        });
    }

};

module.exports = GridLayer;
