/**
 * @fileoverview 선택된 지정석들의 표현계층
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var NSeatLayer = require('./nSeatLayer'),
    NSeatBrush = require('../brush/nSeatBrush'),
    SelectSeatBrush = require('../brush/selectSeatBrush');

/**
 * 비 지정석 선택상태 표현계층
 * @param {Object} options
 * @param {Raphael} options.paper
 * @constructor
 * @extends {NSeatLayer}
 * @exports SelectNSeatLayer
 * @class
 */
function SelectNSeatLayer(options) {
    NSeatLayer.call(this, options);
}

ne.util.inherit(SelectNSeatLayer, NSeatLayer);

/**********
 * static props
 **********/

/**
 * 비지정석 등급 별 외곽선 색상을 저장 (Settings모듈에서 설정됨)
 * @type {Array}
 */
SelectNSeatLayer.GRADE_CODE = [];

/**********
 * override methods
 **********/

/**
 * 비 지정석의 path를 그릴 brushID를 반환하는 메서드
 * @param {NSeat} seat
 * @return {string[]}
 */
SelectNSeatLayer.prototype.getBrushIDFromSeat = function(seat) {
    var brushID = NSeatLayer.prototype.getBrushIDFromSeat(seat);
    brushID.push('select');
    return brushID;
};

/**
 * 브러시 세팅
 */
SelectNSeatLayer.prototype.setBrushes = function() {
    NSeatLayer.prototype.setBrushes.call(this);
    var select = new SelectSeatBrush({ paper: this.paper, type: 'select' });
    select.isAlwaysFront = true;
    this.setBrush('select', select);
};

module.exports = SelectNSeatLayer;
