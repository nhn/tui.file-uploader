/**
 * @fileoverview UI 에서 사용하는 Collection 클래스
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */
'use strict';

var common = ne.util;

/**
 * UICollection 클래스
 * @param {Array} models 콜랙션 데이터로 생성할 list
 * @param {object} [options]
 *      @param {object} [options.model] list 를 가공할 model
 *      @param {boolean}  [options.parse=false] 생성자로 데이터를 설정할 때, parse 로직을 수행할 지 여부를 결정한다.
 * @constructor UICollection
 */
function UICollection(models, options) {
    options = options || {};
    models = models || [];
    this.model = this.model || options.model;
    this.models = this._parseModels(models, options);
    this.length = models.length;
}

//custom event mixin
common.CustomEvents.mixin(UICollection);

/**********
 * method
 **********/

/**
 * 콜렉션에 저장될 data 를 가공한다.
 * @param {Array} models    저장될 모델 데이터
 * @param {object} [options]
 * @param {boolean}  [options.parse=false] 생성자로 데이터를 설정할 때, parse 로직을 수행할 지 여부를 결정한다.
 * @returns {Array} 가공된 모델 데이터
 */
UICollection.prototype._parseModels = function(models, options) {
    options = options || {};

    var modelMap = this.modelMap || {};

    //옵션에 parse 가 설정되어 있다면 parsing 한다.
    if (options.parse) {
        models = this.parse(models);
    }

    //model 이 설정되어 있다면 model 객체로 생성한다.
    if (common.isFunction(this.model)) {
        models = common.map(models, function(item) {
            var model;
            if (item instanceof this.model) {
                model = item;
            } else {
                model = new this.model(item);
            }
            model.collection = this;
            modelMap[model.id] = model;
            model.on('all', this._fire, this);
            return model;
        }, this);
    }
    this.modelMap = modelMap;
    return models;
};

/**
 * silent 옵션값에 따라 이벤트 trigger 하고, all 이벤트도 함께 발생한다.
 * @param {string} type 이벤트 type
 * @param {...*} data   이벤트에 인자로 넘겨줄 데이터
 * @param {object} options   옵션값
 *      @param {boolean} [options.silent=false]    silent 가 설정되어 있을 경우 이벤트 trigger 하지 않는다.
 * @private
 */
UICollection.prototype._fire = function() {
    var args = common.toArray(arguments),
        options = args[args.length - 1] || {};
    if (!options.silent) {
        this.fire.apply(this, args);
        args.unshift('all');
        this.fire.apply(this, args);
    }
};

/**
 * id에 해당하는 model 을 반환한다.
 * @param {(number|string)} id model 의 id 값
 * @return {*}  해당 model
 */
UICollection.prototype.get = function(id) {
    return this.modelMap[id];
};

/**
 * 콜렉션을 clear 하고 인자로 받은 모델 배열을 내부에 설정한다.
 * @param {Array} models   모델 리스트
 * @param {Object} [options]
 *      @param {boolean} [options.silent]   이벤트 발생 여부
 *      @param {boolean} [options.parse]    parse 로직 수행여부
 */
UICollection.prototype.set = function(models, options) {
    options = options || {};

    this.clear(options);
    this.models = this._parseModels(models, options);
    this.length = models.length;
    this._fire('set', models, this.models, options);
};

/**
 * 콜렉션을 빈 배열로 초기화 한다.
 * @param {Object} [options]
 *      @param {boolean} [options.silent]   이벤트 발생 여부
 */
UICollection.prototype.clear = function(options) {
    options = options || {};

    this.forEach(function(model) {
        model.destroy(options);
    }, this);
    this.modelMap = {};
    this.models = [];
    this.length = 0;
    this._fire('clear', options);
};

/**
 * index 에 해당하는 model 을 반환한다.
 * @param {number} index    조회할 model 의 insex
 * @returns {*}
 */
UICollection.prototype.at = function(index) {
    return this.models[index];
};

/**
 * 현재 collection 에 덧붙인다.
 * @param {Array} models   모델 리스트
 * @param {Object} [options]
 *      @param {boolean} [options.silent]   이벤트 발생 여부
 *      @param {boolean} [options.parse]    parse 로직 수행여부
 *     @param {boolean} [options.at]    추가할 위치의 index
 */
UICollection.prototype.add = function(models, options) {
    models = common.isArray(models) ? models : [models];
    options = options || {};
    var at = common.isExisty(common.pick(options, 'at')) ? options.at : this.length,
        args,
        parsedModels;

    parsedModels = this._parseModels(models, options);
    if (common.isNumber(at) && at >= 0) {
        args = common.extend([], parsedModels);
        args.unshift(at, 0);
        this.models.splice.apply(this.models, args);
    }
    this.length = this.models.length;

    this._fire('add', models, parsedModels, options);
};

/**
 * 현재 collection 에서 해당 model 리스트를 삭제한다.
 * @param {Array} models   삭제할 모델 리스트
 * @param {Object} [options]
 *      @param {boolean} [options.silent]   이벤트 발생 여부
 */
UICollection.prototype.remove = function(models, options) {
    models = common.isArray(models) ? models : [models];
    common.forEachArray(models, function(model) {
        var index = this.indexOf(model);
        this.removeAt(index, {silent: true});
    }, this);
    this._fire('remove', models, options);
};

/**
 * 현재 collection 에서 index 에 해당하는 model 을 삭제한다.
 * @param {Array} index   삭제할 모델 index
 * @param {Object} [options]
 *      @param {boolean} [options.silent]   이벤트 발생 여부
 */
UICollection.prototype.removeAt = function(index, options) {
    options = options || {};
    var model = this.at(index),
        models = [model];
    this.modelMap[model.id] = null;
    delete this.modelMap[model.id];

    this.models.splice(index, 1);
    this.length = this.models.length;

    this._fire('remove', models, options);
};

/**
 * 인자로 넘어온 모델의 index 를 반환한다.
 * @param {Object} targetModel   index 값을 조회할 모델
 * @return {number} 해당 모델의 index. 찾지 못한 경우 -1 반환.
 */
UICollection.prototype.indexOf = function(targetModel) {
    var index = -1,
        targetId = targetModel.id;
    this.forEach(function(model, i) {
        if (targetId === model.id) {
            index = i;
            return false;
        }
    });
    return index;
};

/**
 * 생성자에서 데이터 생성시, set 호출시, add 호출시 parse:true 로 설정되어 있을 경우 해당 메서드를 통해 parsing 한다.
 * 상속한 클래스에서 override 하여 구현하면 해당 로직을 수행한다.
 * @param {Array} models 파싱할 원본 데이터
 * @return {Array} 파싱된 데이터
 */
UICollection.prototype.parse = function(models) {
    return models;
};

/**
 * collection 인스턴스에 설정된 데이터를 Json 형태로 반환한다.
 * @return {Object}
 */
UICollection.prototype.toJSON = function() {
    var result;
    if (common.isFunction(this.model)) {
        result = this.map(function(model) {
            return model.toJSON();
        });
        return result;
    } else {
        return this.models;
    }
};

/**
 * common 의 map 을 이용한 map 메서드
 * @param {Function} iteratee 데이터가 전달될 콜백함수
 * @param {*} [context] 콜백함수의 컨텍스트
 * @returns {Array}
 */
UICollection.prototype.map = function(iteratee, context) {
    return common.map(this.models, iteratee, context);

};

/**
 * common 의 forEach 를 이용한 순환 메서드
 * @param {Function} iteratee 데이터가 전달될 콜백함수
 * @param {*} [context] 콜백함수의 컨텍스트
 */
UICollection.prototype.forEach = function(iteratee, context) {
    common.forEachArray(this.models, iteratee, context);
};

/**
 * 소멸자
 * @param {Object} [options]
 *      @param {boolean} [options.silent]   이벤트 발생 여부
 */
UICollection.prototype.destroy = function(options) {
    this._fire('destroy', options);
    this.off();
    this.clear(options);
};

/**
 * UICollection 확장해 새 생성자를 만든다.
 * @param {Object} props
 * @returns {*}
 */
UICollection.extend = function(props) {
    var constructor = common.defineClass(this, props);
    constructor.extend = UICollection.extend;
    return constructor;
};

module.exports = UICollection;
