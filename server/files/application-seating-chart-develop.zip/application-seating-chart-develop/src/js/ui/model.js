/**
 * @fileoverview UI 에서 사용하는 Model 클래스
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */

'use strict';

var common = ne.util;

/**********
 * method
 **********/
/**
 * 객체의 계층구조 내 데이터를 반환한다.
 * @param {object} data 탐색할 객체
 * @param {(number|string)} key 탐색할 key 값. dot 구분자로 탐색할 수 있다.
 * @return {*}
 * @example
 var obj = {
    depth1: {
        depth2: {
            depth3: {
                depth4: 'hardToFind'
            }
        }
    }
 }

 getInnerValue(obj, 'depth1.depth2.depth3.depth4');     // 'hardToFind'
 getInnerValue(obj, 'depth1.depth3.depth2.depth4');     // undefined
 */
function getInnerValue(data, key) {
    var tokens,
        target;
    if (common.isString(key)) {
        tokens = key.split('.');
        target = data;
        common.forEachArray(tokens, function(token) {
            target = target && target[token];
        });
    } else {
        target = data && data[key];
    }
    return target;
}

/**
 * Unique 한 ID 를 가져온다.
 * @param {String} [prefix]
 * @returns {string}
 */
function uniqueId(prefix) {
    var id = ++idCounter + '';
    return prefix ? prefix + id : id;
}

/**
 * idCounter 변수
 * @type {number}
 */
var idCounter = 0;

/**
 * UIModel 클래스
 * @param {object} data 생성자와 함께 할당할 데이터 값.
 * @param {object}  options
 *      @param {object}  [options.defaults={}] model 내 데이터 디폴트 값.
 *      @param {boolean}  [options.parse=false] 생성자로 데이터를 설정할 때, parse 로직을 수행할 지 여부를 결정한다.
 *      @param {String} [options.idAttribute] 모델의 id 로 사용될 필드값. 지정하지 않을 경우 내부에서 자동으로 생성한다.
 * @constructor UIModel
 * @class
 * @example
 function TestModel(data) {
    UIModel.call(this, data, {
        defaults: {
            param1: 1,
            param2: 2,
            obj1 : {
                inner1: {
                    inner2: 'hardToFind'
                }
            }
        },
        parse: true
    });
 }
 common.inherit(TestModel, UIModel);
 var model = new TestModel();
 model.get('param1'); // -> 1
 model.set('param1', 2);
 model.set('param1', 2); // -> 2

 model.get('obj1.inner1.inner2') // -> 'hardToFind'
 model.get('obj1.inner1.inner1') // -> undefined


 var ExtendModel = UIModel.extend({
    defaults: {
        param1: 1,
        param2: 2
    }
 });

 var model = new ExtendModel(data, options);

 */
function UIModel(data, options) {
    options = options || {};
    var attr = common.extend({}, this.defaults || options.defaults, data),
        idAttribute = this.idAttribute || options.idAttribute;

    if (options.parse) {
        attr = this.parse(attr);
    }
    this.id = idAttribute ? attr[idAttribute] : uniqueId();
    this.attributes = attr;
}

//custom event mixin
common.CustomEvents.mixin(UIModel);

/**
 * silent 옵션값에 따라 이벤트 trigger 하고, all 이벤트도 함께 발생한다.
 * @param {string} type 이벤트 type
 * @param {...*} data   이벤트에 인자로 넘겨줄 데이터
 * @param {object} options   옵션값
 *      @param {boolean} [options.silent=false]    silent 가 설정되어 있을 경우 이벤트 trigger 하지 않는다.
 * @private
 */
UIModel.prototype._fire = function() {
    var args = common.toArray(arguments),
        options = args[args.length - 1] || {};

    if (!options.silent) {
        this.fire.apply(this, args);
        args.unshift('all');
        this.fire.apply(this, args);
    }
};

/**
 * key 에 해당하는 데이터를 반환한다.
 * @param {(String|Number)} key 값
 * @return {*}  key 에 할당된 데이터 값
 */
UIModel.prototype.get = function(key) {
    var attr = this.attributes;
    return getInnerValue(attr, key);
};

/**
 * key 에 해당하는 데이터에 value 를 할당한다.
 * @param {*} key       데이터의 key 값. object 타입의 경우 다수의 데이터를 변경한다.
 * @param {*} [value]   key 에 할당할 value. 첫번째 파라미터가 object 일 경우, option 파라미터 역할을 한다.
 * @param {object} [options]
 *      @param {boolean} [options.silent=false]    silent 가 설정되어 있을 경우 이벤트 trigger 하지 않는다.
 */
UIModel.prototype.set = function(key, value, options) {
    options = options || {};
    this._set(key, value, options);
    this._fire('set', this, this.attributes, key, value, options);
};

/**
 * 모델의 데이터를 초기화한다.
 * @param {object} [options]
 *      @param {boolean} [options.silent=false]    silent 가 설정되어 있을 경우 이벤트 trigger 하지 않는다.
 */
UIModel.prototype.clear = function(options) {
    options = options || {};
    this.attributes = {};
    this._fire('clear', this, this.attributes, options);
};

/**
 * key 에 해당하는 데이터에 value 를 할당한다. (내부 처리 함수)
 * @param {*} key       데이터의 key 값. object 타입의 경우 다수의 데이터를 변경한다.
 * @param {*} [value]   key 에 할당할 value. 첫번째 파라미터가 object 일 경우, option 파라미터 역할을 한다.
 * @param {object} [options]
 *      @param {boolean} [options.silent=false]    silent 가 설정되어 있을 경우 이벤트 trigger 하지 않는다.
 */
UIModel.prototype._set = function(key, value, options) {
    var param;
    if (common.isString(key) || common.isNumber(key)) {
        this.attributes[key] = value;
        //trigger
        if (!options.silent) {
            this.fire('change:' + key, this, this.attributes, key, value, options);
        }
        this._fire('change', this, this.attributes, key, value, options);
    } else {
        param = key;
        options = value || {};
        common.forEach(param, function(value, key) {
            this._set(key, value, options);
        }, this);
    }
};

/**
 * Model 인스턴스에 설정된 데이터 Json 형태로 반환한다.
 * @return {Object}
 */
UIModel.prototype.toJSON = function() {
    return this.attributes || {};
};

/**
 * 생성자에서 데이터 생성시, parse:true 로 설정되어 있을 경우 해당 메서드를 통해 parsing 한다.
 * 상속한 클래스에서 override 하여 구현하면 해당 로직을 수행한다.
 * @param {object} data 파싱할 원본 데이터
 * @return {object} 파싱된 데이터
 */
UIModel.prototype.parse = function(data) {
    return data;
};

/**
 * 소멸자
 * @param {object} [options]
 *      @param {boolean} [options.silent=false]    silent 가 설정되어 있을 경우 이벤트 trigger 하지 않는다.
 */
UIModel.prototype.destroy = function(options) {
    this._fire('destroy', this, this.attributes, options);
    this.off();
    common.forEach(this, function(value, name) {
        this[name] = null;
    }, this);
};

/**
 * UIModel 확장해 새 생성자를 만든다.
 * @param {Object} props
 * @returns {*}
 */
UIModel.extend = function(props) {
    var constructor = common.defineClass(this, props);
    constructor.extend = UIModel.extend;
    return constructor;
};

module.exports = UIModel;
