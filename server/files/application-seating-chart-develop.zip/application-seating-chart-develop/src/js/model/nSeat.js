/**
 * @fileoverview 비지정석 데이터 모델
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var util = ne.util,
    simplemap = ne.component.SimpleMap,
    Point = simplemap.Point,
    Rect = simplemap.Rect,
    Seat = require('./seat'),
    SeatLayer = require('../layer/seatLayer');

/**
 * 할당처 정보와 할당 매수
 * @typedef {object.<string, number>} DealershipInfo
 */

/**
 * 비지정석 서버 데이터
 * @typedef {object} NSeatData
 * @property {string} label 비지정석 이름
 * @property {number} sid 비지정석 ID
 * @property {Array.<number[]>} points 비지정석 Path의 각 꼭지점 좌표
 * @property {Array.<number[]>} bound 비지정석이 차지하는 면적을 사각형으로 직교했을 때 좌상, 우하단의 좌표
 * @property {string} grade 등급 코드
 * @property {boolean} soldout 완판 여부
 * @property {DealershipInfo} dealership
 */

/**
 * 비지정석 데이터 모델
 * @param {NSeatData} [data]
 * @constructor
 */
function NSeat(data) {
    Seat.call(this);

    /**
     * 비지정석 이름
     * @type {string}
     */
    this.label = '';

    /**
     * 비지정석에 대한 할당처 정보와 할당매수 (전체매수)
     * @type {DealershipInfo}
     */
    this.dealership = {};

    this.remainCount = null;

    if (util.isExisty(data)) {
        this.setData(data);
    }
}

util.inherit(NSeat, Seat);

/**********
 * static props
 **********/

/**
 * 유효한 판매할당처 코드인지 검사
 * @param {string} code
 * @returns {boolean}
 */
NSeat.isValidSellingTypeCode = function(code) {
    return code in SeatLayer.SELLING_TYPE_CODE;
};

/**********
 * override methods
 **********/

/**
 * 서버 API데이터로 모델 데이터를 채운다
 * @param {NSeatData} data
 */
NSeat.prototype.setData = function(data) {
    if (!data.sid) {
        return;
    }

    Seat.prototype.setData.call(this, data);

    this.label = data.label || '';

    util.forEachOwnProperties(data.dealership || {}, function(count, code) {
        this.setTicket(code, count);
    }, this);

    this.setPoints(data.points);
    this.setBound(data.bound);
};

/**
 * 좌석이 차지하는 면적을 사각형으로 표현한 영역
 *
 * 인자를 넘기지 않을 경우 자신의 points를 돌며 계산한다
 * @param {number[]} [bound]
 */
NSeat.prototype.setBound = function(bound) {
    var points,
        point,
        minX,
        minY,
        maxX,
        maxY,
        i,
        cnt;

    if (bound) {
        this.bound = new Rect(Point.n(bound[0]), Point.n(bound[1]));
    } else {
        points = this.points;
        point = points[0];
        minX = point.x;
        minY = point.y;
        maxX = point.x;
        maxY = point.y;

        for (i = 0, cnt = points.length; i < cnt; i += 1) {
            point = points[i];

            if (minX > point.x) {
                minX = point.x;
            } else if (maxX < point.x) {
                maxX = point.x;
            }


            if (minY > point.y) {
                minY = point.y;
            } else if (maxY < point.y) {
                maxY = point.y;
            }
        }

        this.bound = new Rect(new Point(minX, minY), new Point(maxX, maxY));
    }
};

/**
 * 비 지정석 points 데이터를 Point클래스로 가공하여 저장하는 메서드
 * @param {Array.<Array>} points
 */
NSeat.prototype.setPoints = function(points) {
    var i,
        cnt,
        point;

    for (i = 0, cnt = points.length; i < cnt; i += 1) {
        point = points[i];

        this.points.push(new Point(point[0], point[1]));
    }
};

/**********
 * public methods
 **********/

NSeat.prototype.name = 'NSeat';

/**
 * 비 지정석 모델 복제
 * @returns {NSeat}
 */
NSeat.prototype.clone = function() {
    var bound = this.bound,
        points = this.points;

    var copy = new NSeat();

    copy.bound = new Rect(bound.min.clone(), bound.max.clone());

    copy.points = util.map(points, function(point) {
        return new Point(point.x, point.y);
    });

    copy.sid = this.sid;
    copy.label = this.label;
    copy.grade = this.grade;
    copy.soldout = this.soldout;

    copy.setDealership(this.dealership);

    return copy;
};

/**
 * 특정 할당처에 할당매수를 부여한다
 * @param {string} code 할당처코드
 * @param {number} [count] 할당매수
 */
NSeat.prototype.setTicket = function(code, count) {
    if (!NSeat.isValidSellingTypeCode(code)){
        return;
    }

    if (+count !== count) {
        count = parseInt(count, 10);
    }

    if (!this.dealership[code]) {
        this.dealership[code] = 0;
    }

    this.dealership[code] = count;
};

/**
 * 할당처의 할당매수를 반환
 * @param {string} code 할당처코드
 * @returns {number}
 */
NSeat.prototype.getTicket = function(code) {
    return this.dealership[code];
};

/**
 * 할당처 정보를 지우고 인자 정보로 다시 세팅한다
 * @param {DealershipInfo} info
 */
NSeat.prototype.setDealership = function(info) {
    this.dealership = {};
    util.forEachOwnProperties(info, function(count, code) {
        this.setTicket(code, count);
    }, this);
};

/**
 * 할당처코드, 할당매수 정보를 반환
 * @returns {DealershipInfo}
 */
NSeat.prototype.getDealership = function() {
    var result = {};

    util.forEachOwnProperties(this.dealership, function(count, code) {
        if (count > 0) {
            result[code] = count;
        }
    });

    return result;
};

module.exports = NSeat;
