/**
 * @fileoverview 지정석 데이터 모델 클래스
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var util = ne.util,
    simplemap = ne.component.SimpleMap,
    Point = simplemap.Point,
    Rect = simplemap.Rect,
    Seat = require('./seat');

/**
 * 지정석 클래스
 * @param {number} x
 * @param {number} y
 * @constructor
 * @extends {Seat}
 */
function RSeat(x, y) {
    Seat.call(this);

    /**
     * 좌석이 포함되는 SeatLayer ID
     * @type {string}
     */
    this.slid = '';

    /**
     * 좌석의 중심점 좌표
     * @type {Point}
     */
    this.position = null;

    /**
     * 판매 형태
     * @type {string}
     */
    this.sellingType = '';

    /**
     * 비활성화 여부
     * @type {boolean}
     */
    this.disabled = false;

    /**
     * 좌석 매핑정보를 담는 객체
     * @type {Array.<string>}
     */
    this.mapInfo = [];

    /**
     * 좌석 크기 저장
     * @type {ticketlink.Point}
     */
    var seatSize = this.seatSize = new Point(RSeat.SEAT_SIZE, RSeat.SEAT_SIZE);

    /**
     * 지정석 크키의 반 사이즈를 저장
     * @type {ticketlink.Point}
     */
    this.half = seatSize.divideBy(2);

    /**
     * @type {{brushName: string, path: string}}
     */
    this.pathCache = {};

    if (arguments.length > 0) {
        this.setPosition(x, y);
    }
}

// 상속
util.inherit(RSeat, Seat);


/**********
 * static props
 **********/

/**
 * 기본 좌석 크기
 * @type {number}
 */
RSeat.SEAT_SIZE = 10;

/**
 * 기본 좌석 간 간격
 * @type {number}
 */
RSeat.GUTTER = 5;

/**
 * 매핑기본정보
 * @type {string[]}
 */
RSeat.MAP_CODE = [];

/**
 * 매핑단위정보
 * @type {string[]}
 */
RSeat.MAP_UNIT = [];

/**********
 * override methods
 **********/

/**
 * 데이터 객체로부터 지정석 데이터를 채우는 메서드
 * @param {object} data
 */
RSeat.prototype.setData = function(data) {
    if (!util.isExisty(util.pick(data, 'sid'))) {
        return;
    }

    var pointData,
        ownPoints;

    Seat.prototype.setData.call(this, data);

    this.slid = data.gridId || '';

    if (util.isExisty(util.pick(data, 'position'))) {
        this.position = Point.n(data.position);
    }

    if (util.isExisty(util.pick(data, 'bound'))) {
        this.bound = new Rect(Point.n(data.bound[0]), Point.n(data.bound[1]));
    }

    pointData = data.points || data.cornerPoints;

    if (util.isExisty(pointData)) {
        ownPoints = this.points = [];
        util.forEachArray(pointData, function(point) {
            ownPoints.push(Point.n(point));
        });
    }

    this.sellingType = data.sellingType || '';

    if (util.isExisty(util.pick(data, 'isDisabled'))) {
        this.disabled = data.isDisabled;
    }

    if (util.isExisty(util.pick(data, 'mapInfo'))) {
        this.setMapInfo(data.mapInfo);
    }
};

/**
 * 좌석 모델 복제 메서드
 */
RSeat.prototype.clone = function() {
    var pos = this.position,
        bound = this.bound,
        points = this.points;

    var copy = new RSeat(pos.x, pos.y);

    copy.bound = new Rect(bound.min.clone(), bound.max.clone());

    copy.points = util.map(points, function(point) {
        return new Point(point.x, point.y);
    });

    copy.sid = this.sid;
    copy.sellingType = this.sellingType;
    copy.slid = this.slid;
    copy.grade = this.grade;
    copy.soldout = this.soldout;

    util.extend(copy.mapInfo, this.mapInfo);

    return copy;
};

/**********
 * private methods
 **********/

/**
 * 좌석의 좌표 설정
 * @param {number} x
 * @param {number} y
 * @private
 */
RSeat.prototype._initPosition = function(x, y) {
    this.position = new Point(x, y);
};

/**
 * 인자로 전달된 차이만큼 points를 움직인다
 * @param {number} diff
 * @private
 */
RSeat.prototype._movePoints = function(diff) {
    var points = this.points,
        i = 0;

    while(i < 4) {
        points[i]._add(diff);
        i += 1;
    }
};

/**
 * 좌석의 4지점을 계산하여 설정
 *
 * 순서대로 좌상, 좌하, 우하, 우상
 *
 * 회전이 적용된 좌석에 대해서 수행하면 오작동할 수 있다.
 */
RSeat.prototype._initPoints = function(x, y) {
    var pos = new Point(x, y),
        seatSize = this.seatSize,
        half = this.half,
        nw,
        ne,
        se,
        sw;

    nw = pos.subtract(half);

    ne = nw.clone();
    ne.x += seatSize.x;

    se = pos.add(half);

    sw = se.clone();
    sw.x -= seatSize.x;

    this.points = [nw, sw, se, ne];
};

/**
 * 좌석이 차지하는 면적을 사각형으로 계산한다
 * @private
 */
RSeat.prototype._updateBound = function() {
    var points = this.points,
        point = points[0],
        minX = point.x,
        minY = point.y,
        maxX = point.x,
        maxY = point.y,
        i = 1;

    while (i < 4) {
        point = points[i];

        if (point.x < minX) {
            minX = point.x;
        } else if (point.x > maxX) {
            maxX = point.x;
        }

        if (point.y < minY) {
            minY = point.y;
        } else if (point.y > maxY) {
            maxY = point.y;
        }
        i += 1;
    }
    this.bound = new Rect(new Point(minX, minY), new Point(maxX, maxY));
};

/**********
 * public methods
 **********/

RSeat.prototype.name = 'RSeat';

/**
 * 좌석을 이동한다
 *
 * 좌석이 이동될때는 회전된 후에 이동될수도 있으므로
 *
 * 계산했던 포인트들을 "갱신" 이 아닌 "수정"한다
 * @param {number} x
 * @param {number} y
 */
RSeat.prototype.moveTo = function(x, y) {
    var diff = (new Point(x, y)).subtract(this.position);
    this.position = new Point(x, y);
    this._movePoints(diff);
    this._updateBound();

    this.isDirty = true;
};

/**
 * 좌석을 특정 값 만큼 움직인다
 *
 * 좌석이 이동될때는 회전된 후에 이동될수도 있으므로
 *
 * 계산했던 포인트들을 "갱신" 이 아닌 "수정"한다
 * @param {number} x
 * @param {number} y
 */
RSeat.prototype.moveBy = function(x, y) {
    var by = new Point(x, y);
    this.position._add(by);
    this._movePoints(by);
    this._updateBound();

    this.isDirty = true;
};

/**
 * 좌석좌표정보를 새로 설정한다
 * @param {number} x
 * @param {number} y
 */
RSeat.prototype.setPosition = function(x, y) {
    this._initPosition(x, y);
    this._initPoints(x, y);
    this._updateBound();
};


/**
 * 좌석 매핑 정보를 업데이트하는 메서드
 * @param {(Array|number)} info
 * @param {string} [value]
 */
RSeat.prototype.setMapInfo = function(info, value) {
    var i,
        len = RSeat.MAP_CODE.length,
        arr;

    if (!this.mapInfo || this.mapInfo.length !== len) {
        arr = [];

        for (i = 0; i < len; i += 1) {
            arr.push('');
        }
        this.mapInfo = arr.slice(0);
    }

    if (util.isArray(info)) {

        util.forEachArray(info, function(value, index) {
            this.mapInfo[index] = value;
        }, this);
    } else if (+info === info) {
        this.mapInfo[info - 1] = value;
    }
};

/**
 * 좌석 매핑 정보 조회
 * @param {number} [index]
 * @returns {(string|object)}
 */
RSeat.prototype.getMapInfo = function(index) {
    var mapInfo = this.mapInfo,
        result;

    if (arguments.length) {
        result = mapInfo[index - 1];
    } else {
        result = {};
        util.forEachArray(RSeat.MAP_CODE, function(name, index) {
            result[name] = mapInfo[index];
        });
    }

    return result;
};

/**
 * 좌석의 좌표 데이터에 회전 연산을 한다.
 * @param {number} deg
 * @param {Point=} center
 */
RSeat.prototype.rotate = function(deg, center) {
    center = center || this.bound.getCenter();

    var pos = this.position;

    // 중심좌표 수정
    if (!center.equals(pos)) {
        this.position._rotate(deg, center);
    }

    // 모서리 포인트 수정
    util.forEach(this.points, function(point, index, arr) {
        arr[index]._rotate(deg, center);
    });

    // bound 계산
    this._updateBound();

    this.isDirty = true;
};

/**
 * mapInfo를 토대로 Text스트링을 만들어 리턴한다.
 * @returns {string}
 */
RSeat.prototype.getText = function() {
    var mapInfo = this.getMapInfo(),
        textArray = [];

    util.forEach(mapInfo, function(value, key) {
        textArray.push(key + ': ' + value);
    });

    return textArray.join('\n');
};

module.exports = RSeat;
