/**
* @fileoverview 좌석의 기본 데이터 모델
* @author FE개발팀 김민형 minhyeong.kim@nhnent.com
*/

'use strict';

var common = ne.util,
    simplemap = ne.component.SimpleMap,
    Rect = simplemap.Rect;

/**
 * 좌석의 기본 데이터 모델 클래스
 * @constructor
 */
function Seat() {
    /**
     * 서버 좌석 ID
     * @type {string}
     */
    this.sid = '';

    /**
     * 좌석이 차지하는 면적 Rect
     * @type {Rect}
     */
    this.bound = null;

    /**
     * 좌석이 가지는 path의 x,y 좌표 배열 리스트
     * @type {Array}
     */
    this.points = [];

    /* 부가정보 */

    /**
     * 좌석 등급
     * @type {string}
     */
    this.grade = '';

    /**
     * 좌석 판매 완료 여부
     * @type {boolean}
     */
    this.soldout = false;

    /**
     * 좌석의 path가 다시 그려져야 하는지 여부
     * @type {boolean}
     */
    this.isDirty = false;
}


/**********
 * public methods
 **********/

/**
 * 서버 좌석 ID 조회
 * @return {string}
 */
Seat.prototype.getID = function() {
    return this.sid;
};

/**
 * 좌석 기본 데이터를 초기화하는 메서드
 * @param {object} data
 */
Seat.prototype.setData = function(data) {
    this.sid = common.isExisty(data.sid) ? data.sid + '' : '';
    this.bound = data.bound || null;
    this.grade = data.grade || '';
    this.soldout = common.isExisty(common.pick(data, 'soldout')) ? data.soldout : false;
    this.isDirty = true;
};

/**
 * 좌석이 차지하는 사각 면적을 계산하여 저장한다
 * @virtual
 */
Seat.prototype.setBound = function() {};

/**
 * 좌석 path의 각 포인트를 저장하는 메서드 구현
 * @virtual
 */
Seat.prototype.setPoints = function() {};

/**
 * 특정 point 가 polygon 안에 포함되는지 계산하는 로직
 *
 * Jordan Curve Theorem http://erich.realtimerendering.com/ptinpoly/
 *
 * *주의* 다량의 데이터 연산시 성능 저하 가능
 * @param {number} x
 * @param {number} y
 * @returns {boolean}
 */
Seat.prototype.isContain = function(x, y) {
    var points = this.points,
        cnt = points.length,
        i = 0,
        j = cnt - 1,
        vert = null,
        vert2 = null,
        contain = false;

    for (; i < cnt; j = i, i += 1) {
        vert = points[i];
        vert2 = points[j];

        if ((vert.y > y !== vert2.y > y) &&
            (x < (vert2.x - vert.x) * (y - vert.y) / (vert2.y - vert.y) + vert.x)) {
            contain = !contain;
        }
    }
    return contain;
};

/**
 * 현재 point 가 특정 rect안에 포함되는지 계산하는 로직
 *
 * *주의* 다량 데이터 연산시 성능 저하 가능
 * @param {number} x
 * @param {number} y
 * @param {number} xEnd
 * @param {number} yEnd
 */
Seat.prototype.isInsideRect = function(x, y, xEnd, yEnd) {
    var rect = new Rect(x, y, xEnd, yEnd),
        points = this.points,
        i = 0,
        cnt = points.length,
        point;

    for (; i < cnt; i += 1) {
        point = points[i];

        if (!rect.isContain(point)) {
            return false;
        }
    }

    return true;
};

module.exports = Seat;
