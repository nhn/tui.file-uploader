/**
 * @fileoverview 영역 데이터 모델
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var simplemap = ne.component.SimpleMap,
    Point = simplemap.Point,
    Rect = simplemap.Rect;

var areaIDIndex = 1;

/**
 * 영역 데이터 모델 클래스
 * @param {object} data
 * @constructor
 */
function Area(data) {

    /**
     * 영역에 대한 ID
     * @type {string}
     */
    this.id = areaIDIndex + '';
    areaIDIndex += 1;

    /**
     * 영역 마우스 오버 시 말풍선에 보여줄 문자열
     * @type {string}
     */
    this.data = '';

    /**
     * @type {Array.<number[]>}
     */
    this.points = null;

    /**
     * @type {number[]}
     */
    this.center = null;

    if (data) {
        this.setData(data);
    }
}

/**********
 * public props
 **********/

Area.prototype.name = 'Area';

/**
 * 영역 ID를 반환한다
 * @return {string}
 */
Area.prototype.getID = function() {
    return this.id;
};

/**
 * 영역 데이터를 설정한다
 * @param {object} data 영역 데이터
 */
Area.prototype.setData = function(data) {
    this.data = data.data;
    this.points = data.points.slice(0);

    if (data.center) {
        this.center = data.center.slice(0);
    } else {
        this.center = this.getAreaCenter();
    }
};

/**
 * 영역좌표들의 중심점을 계산한다
 * @returns {number[]}
 */
Area.prototype.getAreaCenter = function() {
    var points = this.points,
        rect = new Rect(points[0], points[1]),
        i = 2,
        cnt = points.length,
        point,
        center;

    for(; i < cnt; i += 1) {
        point = points[i];
        rect.extend(new Point(point[0], point[1]));
    }

    center = rect.getCenter();

    return [center.x, center.y];
};

/**
 * 인자로 넘어온 좌표가 이 영역 내부에 존재하는지 확인하는 메서드
 * @param {number} x
 * @param {number} y
 */
Area.prototype.isContain = function(x, y) {
    var points = this.points,
        cnt = points.length,
        i = 0,
        j = cnt - 1,
        vert = null,
        vert2 = null,
        contain = false;

    for (; i < cnt; j = i, i += 1) {
        vert = points[i];
        vert2 = points[j];

        if ((vert[1] > y !== vert2[1] > y) &&
            (x < (vert2[0] - vert[0]) * (y - vert[1]) / (vert2[1] - vert[1]) + vert[0])) {
            contain = !contain;
        }
    }
    return contain;
};

module.exports = Area;
