/**
 * @fileovewview 선택된 좌석들을 이동할 수 있는 기능을 제공하는 모듈
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var simplemap = ne.component.SimpleMap,
    domevent = simplemap.domevent,
    domutil = simplemap.domutil;
var common = ne.util;
var TICK_INTERVAL_DETECT_LEFTOUT = 50;
var TICK_INTERVAL_PANNING = 50;

/**
 * Raphael SET 엘리먼트를 드래그 가능하도록 기능을 추가하는 클래스
 * @param {SeatingChart} chart
 * @param {Raphael} paper
 * @param {SelectSeatController} selectCtrl
 * @constructor
 */
function SeatDraggable(chart, paper, selectCtrl) {
    /**
     * @type {SeatingChart}
     */
    this.chart = chart;

    /**
     * Raphael 페이퍼
     * @type {Raphael}
     */
    this.paper = paper;

    /**
     * Raphael SET 엘리먼트
     * @type {Raphael.st}
     */
    this.setElement = null;

    /**
     * 좌석 선택 컨트롤러
     * @type {SelectSeatController}
     */
    this.selectCtrl = selectCtrl;

    /**
     * 좌석 드래그 시작 포인트
     * @type {Point}
     * @private
     */
    this._startPos = null;

    /**********
     * 패닝 관련
     **********/

    /**
     * 좌석 드래그 중 바깥으로 나갔을때 동작하는 인터벌
     * @type {number}
     * @private
     */
    this._leftOutIntervalID = 0;

    /**
     * 패닝이 시작될 때의 실제좌표를 저장
     * @type {Point}
     * @private
     */
    this._panningStartCenterCoords = null;

    /**
     * 각 패닝에 이동한 거리를 저장
     * @type {Point}
     * @private
     */
    this._panningVector = null;

    /**********
     * 드래그 중 마우스 in/out 관련
     **********/

    /**
     * 좌석 드래그 중 마우스가 드로잉 영역 안쪽 또는 바깥쪽에 있는지 체크하기 위한 인터벌
     * @type {number}
     * @private
     */
    this._mouseOutIntervalID = 0;

    chart.on('beforeDeselectAllSeats', this._onBeforeDeselectAllSeats, this);
}

/**********
 * private methods
 **********/

/**
 * 화면에 보이는 영역의 좌상, 우하 실제좌표를 구한다
 * @returns {(simplemap.Rect|Point|*)}
 * @private
 */
SeatDraggable.prototype._getViewportBounds = function () {
    var chart = this.chart;
    return chart.getViewportOffsetByPanelName('layer').divideBy(chart.getScaleRatio());
};

/**
 * 마우스 절대좌표를 실제좌표로 변환한다
 * @param {(object|MouseEvent)} mouseEvent
 * @returns {Point|*}
 * @private
 */
SeatDraggable.prototype._getMouseCoords = function (mouseEvent) {
    var chart = this.chart,
        mousePos = domevent.getMousePosition(mouseEvent, chart.getContainer());

    mousePos._subtract(domutil.getPosition(chart.getLayerPanel()))._divideBy(chart.getScaleRatio());

    return mousePos;
};

/**
 * 좌석드래그 중 드로잉 영역 바깥으로 나갔을 때 동작하는 마우스 이동 이벤트
 *
 * 맵이 패닝되어야하 하는 방향과 거리를 구한다
 * @param {MouseEvent} e
 * @private
 */
SeatDraggable.prototype._onLeftOutMouseMove = function (e) {
    var startCoord = this._getViewportBounds().getCenter(),
        mouseCoord = this._getMouseCoords(e),
        vector = startCoord.subtract(mouseCoord);

    this._panningVector = vector.divideBy(6).reverse();
};

/**
 * 좌석드래그 중 드로잉 영역 바깥으로 나갔을 때 동작하는 인터벌의 틱
 *
 * 각 틱마다 _onLeftOutMouseMove 에서 계산해준 벡터만큼 맵을 패닝하고 선택 엘리먼트의 위치를 조정한다
 * @private
 */
SeatDraggable.prototype._onLeftOutPanningTick = function () {
    var tempElOffset;

    /* istanbul ignore else */
    if (common.isExisty(this._panningVector)) {
        this.chart.panBy(this._panningVector);

        // set엘리먼트 드래그는 mouseMove 에 발생되므로 패닝이 이뤄진 당시에도 위치를 조정해주어야 한다
        tempElOffset = this._getMouseCoords(this._absoluteMousePos).subtract(this._startPos);
        this.transform(tempElOffset.x, tempElOffset.y);
    }
};

/**
 * 좌석 드래그 중 마우스가 드로잉 영역 in/out 시 관련 이벤트를 토글한다
 * @param {boolean} onOff true 시 나갔다!
 * @private
 */
SeatDraggable.prototype._toggleLeftOutFeature = function (onOff) {
    var method = onOff ? 'on' : 'off';

    if ((this._leftOutIntervalID > 0 && onOff) ||
        (!this._leftOutIntervalID && !onOff)) {
        return;
    }

    domevent[method](document.body, 'mousemove', this._onLeftOutMouseMove, this);

    window.clearInterval(this._leftOutIntervalID);
    if (onOff) {
        this._leftOutIntervalID = window.setInterval(common.bind(this._onLeftOutPanningTick, this), TICK_INTERVAL_PANNING);
    } else {
        this._leftOutIntervalID = 0;
    }
};

/**
 * 좌석 드래그 중에 인터벌을 작동시켜 마우스가 드로잉 영역 바깥으로 나갔는지 아닌지의 여부를 체크한다
 *
 * mouseMove 이벤트는 마우스를 빠르게 움직이면 스킵되는 경향이 있으므로 인터벌을 사용
 * @private
 */
SeatDraggable.prototype._onMouseOutTick = function () {
    if (!common.isExisty(this._absoluteMousePos)) {
        return;
    }

    var viewportBounds = this._getViewportBounds(),
        mouseCoords = this._getMouseCoords(this._absoluteMousePos),
        isContain = viewportBounds.isContain(mouseCoords);

    this._toggleLeftOutFeature(!isContain);
};

/**
 * 드래그 중 ESC눌렀을 때는 선택취소하지 않음
 * @returns {boolean}
 * @private
 */
SeatDraggable.prototype._onBeforeDeselectAllSeats = function () {
    var chart = this.chart;

    if (common.isExisty(this._startPos)) {
        this.reset();
        this._startPos = null;
        this.setElement.undrag();
        this.init();
        chart.enablePanAndZoom();
        this._endDrag();

        return false;
    }
};

/**
 * Raphael 엘리먼트의 현재 스케일을 반환하는 메서드
 * @return {number}
 * @private
 */
SeatDraggable.prototype._getPaperScale = function() {
    var paper = this.paper;
    return paper._vbSize || (1 / paper._viewBoxShift.scale);
};

/**
 * DOM이벤트의 마우스 좌표를 Raphael Paper스케일 기준으로 계산하여 반환하는 메서드
 * @param {MouseEvent} e
 * @return {Point}
 * @private
 */
SeatDraggable.prototype._getMousePosition = function(e) {
    var mousePos = domevent.getMousePosition(e, this.chart.getLayerPanel());
    return mousePos._multiplyBy(this._getPaperScale());
};

/**********
 * public methods
 **********/

/**
 * Raphael 드래그 이벤트에서 마우스 다운 이벤트를 취소하기 때문에 selection컨트롤의 좌석 선택기능이 동작하지 않는다.
 *
 * 그래서 이곳에서 단일선택했을 때 별도로 확인하여 처리하는 코드가 추가되었다
 * @param {number} x
 * @param {number} y
 */
SeatDraggable.prototype.processSingleSelect = function (x, y) {
    var chart = this.chart,
        selectSeats = this.selectCtrl.seats,
        seatContainPoint,
        seatToDeselect = [];

    seatContainPoint = chart.searchSeats([x, y], false, 1).r;

    common.forEachArray(seatContainPoint, function (seat) {
        var sid = seat.getID();
        if (selectSeats.has(sid)) {
            seatToDeselect.push(seat);
        }
    });

    /* istanbul ignore else */
    if (seatToDeselect.length) {
        chart.deselectSeats(seatToDeselect, true);
        chart.IB.emit(chart.IB.constructor.EVENT.MAP_DESELECT_SEAT, chart.splitSeatRN(seatContainPoint));
    }
};

/**
 * set 엘리먼트에 transform을 적용하는 메서드
 * @param {number} x
 * @param {number} y
 */
SeatDraggable.prototype.transform = function(x, y) {
    /* istanbul ignore else */
    if (this.setElement) {
        this.setElement.transform('t' + x + ',' + y);
    }
};

/**
 * 적용되었던 transform 을 취소하는 메서드
 */
SeatDraggable.prototype.reset = function() {
    /* istanbul ignore else */
    if (this.setElement) {
        this.setElement.transform('');
    }
};

/**
 * Raphael SET엘리먼트를 드래그 가능하도록 설정하는 메서드
 * @param {Raphael.st} [setObj] Raphael Set 엘리먼트
 */
SeatDraggable.prototype.init = function(setObj) {
    this.setElement = setObj || this.setElement;

    /* istanbul ignore else */
    if (common.isExisty(this.setElement)) {
        this.setElement.drag(this._onMove, this._onStart, this.onEnd, this, this, this);
    }
};

/**
 * 좌석 드래그 완료와 드래그 중 ESC눌렀을 때 공통으로 수행해야 하는 로직 모음
 * @private
 */
SeatDraggable.prototype._endDrag = function () {
    window.clearInterval(this._mouseOutIntervalID);
    this._mouseOutIntervalID = 0;

    this._startPos = null;
    this._panningStartCenterCoords = null;
};

/**********
 * drag event handler
 **********/

/**
 * Raphael SET 드래그 시작 이벤트 핸들러
 * @param {number} x
 * @param {number} y
 * @param {MouseEvent} e
 */
SeatDraggable.prototype._onStart = function(x, y, e) {
    var map = this.chart,
        currentTabIndex = map.IB.get('currentTabIndex');

    if (map.disabled || (currentTabIndex !== 0 && currentTabIndex !== 4)) {
        this.setElement.undrag();
        return;
    }

    domevent.stopPropagation(e);

    window.clearInterval(this._mouseOutIntervalID);
    this._mouseOutIntervalID = window.setInterval(common.bind(this._onMouseOutTick, this), TICK_INTERVAL_DETECT_LEFTOUT);

    map.disablePanAndZoom();

    this._startPos = this._getMousePosition(e);
    this._panningStartCenterCoords = this._getViewportBounds().getCenter();
};

/**
 * Raphael SET 드래그 이벤트 핸들러
 * @param {number} dx
 * @param {number} dy
 * @param {number} x
 * @param {number} y
 */
SeatDraggable.prototype._onMove = function(dx, dy, x, y) {
    this._absoluteMousePos = { clientX: x, clientY: y };

    var scale = this._getPaperScale();

    dx *= scale;
    dy *= scale;

    /**
     * 패닝이 이뤄진 경우 패닝된만큼 transform 할 수치를 연산해준다
     */
    if (common.isExisty(this._panningStartCenterCoords)) {
        var offset = this._getViewportBounds().getCenter().subtract(this._panningStartCenterCoords);
        dx += offset.x;
        dy += offset.y;
    }

    this.transform(dx, dy);
};

/**
 * Raphael SET 드래그 끝 이벤트 핸들러
 * @param {MouseEvent} e
 */
SeatDraggable.prototype.onEnd = function(e) {
    var chart = this.chart;

    chart.enablePanAndZoom();

    var selectCtrl = this.selectCtrl,
        endPos = this._getMousePosition(e),
        diff = endPos.subtract(this._startPos),
        groupBound = selectCtrl.groupBound;

    if (diff.x === 0 && diff.y === 0) {
        this.processSingleSelect(endPos.x, endPos.y);
        return;
    }

    // 그룹회전 축 좌표도 연산해준다
    groupBound.min._add(diff);
    groupBound.max._add(diff);

    selectCtrl.moveSeats(diff.x, diff.y);
    this._endDrag();
};

module.exports = SeatDraggable;
