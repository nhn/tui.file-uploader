/**
 * @fileoverview API호출과 관련된 로직을 관리하는 클래스
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var common = ne.util;

/**
 * @constructor
 */
function API() {}

/**********
 * static props
 **********/

API.URL = {
    /**********
     * 물리도면
     **********/
    PHYSICAL_LOAD_RSEAT: '/api/physicalPlan/makeSeatAreaPaging.nhn',    // 지정석 페이징
    PHYSICAL_SELECT_SEAT: '/api/physicalPlan/selectSeatPath.nhn',
    CREATE_SEAT: '/api/physicalPlan/makeSeatPath.nhn',
    DELETE_SEAT: '/api/physicalPlan/deleteSeatPath.nhn',
    UPDATE_SEAT: '/api/physicalPlan/updateSeatPath.nhn',
    ROTATE_SEAT: '/api/physicalPlan/updateRotationSeatPath.nhn ',    // 좌석 회전 + 선택좌석 불충족조건 검사
    PHYSICAL_SAVE_TEMPORARY: '/api/physicalPlan/tempStorage.nhn',
    PHYSICAL_WORK_COMPLETE: '/api/physicalPlan/workComplete.nhn',
    CHECK_IMPERFECTION: '/api/physicalPlan/checkSeatList.nhn',

    /**********
     * 논리도면
     **********/
    CHECK_IMPERFECTION_LOGICAL: '/api/logicalPlan/checkSeatList.nhn',
    SEAT_STATUS: '/api/logicalPlan/selectSeatCurrent.nhn',
    LOGICAL_LOAD_RSEAT: '/api/logicalPlan/makeSeatAreaPaging.nhn',    // 지정석 페이징
    LOGICAL_SELECT_SEAT: '/api/logicalPlan/selectSeatAndZone.nhn',    // 지정석/비지정석 선택
    LOGICAL_UPDATE_SELLING_TYPE_RSEAT: '/api/logicalPlan/updateLogicSeat.nhn',    // 지정석 좌석할당처 수정
    LOGICAL_UPDATE_SELLING_TYPE_NSEAT: '/api/logicalPlan/updateLogicZone.nhn',    // 비지정석 좌석할당처 수정
    LOGICAL_UPDATE_GRADE: '/api/logicalPlan/updateLogicGrade.nhn',    // 좌석 등급 수정
    LOGICAL_CHECK_ENABLE_SCHEDULE: '/api/logicalPlan/checkCopySchedule.nhn', // 회차적용 체크
    LOGICAL_APPLY_ALL_SCHEDULE: '/api/logicalPlan/copyScheduleAll.nhn',    // 선택영역 전회차 저장
    LOGICAL_SAVE_TEMPORARY: '/api/logicalPlan/tempStorage.nhn',
    LOGICAL_WORK_COMPLETE: '/api/logicalPlan/workComplete.nhn',

    /**********
     * 어드민, 사용자 예매 API
     **********/
    RESERVE_DATES: '/api/reserve/dates.nhn',    //좌석 예매 가능날짜
    RESERVE_ROUND: '/api/reserve/round.nhn',    //회차정보
    RESERVE_GRADE: '/api/reserve/grade.nhn',    //잔여석 등급 정보
    RESERVE_DATES_PC: '/api/reserve/dates.nhn',    //좌석 예매 가능날짜
    RESERVE_ROUND_PC: '/api/reserve/round.nhn',    //회차정보
    RESERVE_GRADE_PC: '/api/reserve/grade.nhn',    //잔여석 등급 정보
    RESERVE_SEAT: '/api/reserve/seat.nhn',    //좌석 정보
    RESERVE_PRICE: '/api/reserve/price.nhn',    //권종 정보
    RESERVE_ADDITIONAL: '/api/reserve/additional.nhn',    //부가상품
    RESERVE_ADDITIONAL_COUNT: '/api/reserve/additionalOrderCnt.nhn', //부가상품 잔여개수 조회
    RESERVE_PRODUCT: '/api/reserve/product.nhn', //상품정보
    RESERVE_PREOCCUPACY_LIST: '/api/reserve/preoccupancyList.nhn',  //지정석 선점
    RESERVE_PREOCCUPACY_ZONE: '/api/reserve/preoccupancyZone.nhn',   //비지정석 선점
    RESERVE_PREOCCUPACY_ONLY_ZONE: '/api/reserve/preoccupancyExhibit.nhn',
    RESERVE_CANCEL_PREOCCUPACY_LIST: '/api/reserve/cancelPreoccupancyList.nhn', //지정석 선점 해제
    RESERVE_CANCEL_PREOCCUPACY_ZONE: '/api/reserve/cancelPreoccupancyZone.nhn', //비지정석 선점 해제
    RESERVE_CANCEL_PREOCCUPACY_ONLY_ZONE: '/api/reserve/cancelPreoccupancyExhibit.nhn',
    RESERVE_CANCEL_ALL: '/api/reserve/cancelAllPreoccupancy.nhn', //전체 선점 해제
    RESERVE_GET_ALL_PREOCCUPANCY: '/api/reserve/getAllPreoccupancy.nhn', //좌석 선점 조회
    RESERVE_GET_ALL_PREOCCUPANCY_ONLY_ZONE: '/api/reserve/getPreoccupancyExhibit.nhn',  //전시 상품 선점 조회
    RESERVE_GET_GRADE_REMAIN_ALL_LIST: '/api/reserve/getGradeRemainAllList.nhn',    //(공연)등급별 (발권할당)잔여좌석 조회
    RESERVE_EXHIBITION_ALL_SELECT: '/api/reserve/exhibitionAllSelectAndPre.nhn',   //(전시)등급별 (발권할당)잔여좌석 조회
    RESERVE_GET_ONLY_ZONE_DATA: '/api/reserve/getOneZoneData.nhn',   //비지정석 1개인 좌석 기타 정보 조회
    RESERVE_GET_MEMBER_INFO: '/api/reserve/getMemberInfo.nhn',
    RESERVE_COMPLETE: '/api/reserve/selectComplete.nhn',     //좌석 선택 완료
    RESERVE_GET_PRODUCT_LIMIT_CNT: '/api/reserve/getProductLimitCnt.nhn', //상품 구매개수 제한 조회

    /********
     * 어드민, 사용자 예매 도면 로드 API
     ********/
    TICKETING_LOAD_RSEAT: '/api/reserve/makeSeatAreaReservePaging.nhn'
};

API.METHOD = 'POST';

//@todo 목업용
/*
API.URL = {
    RESERVE_DATES_PC: '/mock/api/reserve/dates.nhn',    //좌석 예매 가능날짜
    RESERVE_ROUND_PC: '/mock/api/reserve/round.nhn',    //회차정보
    RESERVE_GRADE_PC: '/mock/api/reserve/grade.nhn'    //잔여석 등급 정보
};

API.METHOD = 'GET';
*/

API.RETURN_CODE = {
    'SUCCESS': '0'
};

/**********
 * private methods
 **********/

/**
 * 서버의 공통 응답 포멧을 선처리한다
 * @param {object} response 서버 응답 내용
 * @private
 */
API.prototype._checkResponse = function(response) {
    if (!common.isExisty(common.pick(response, 'code'))) {
        window.alert('서버 요청 처리중 문제가 발생했습니다.\n잠시 후 다시 시도하세요');
    } else if (common.isString(response.alert) && response.alert.length) {
        window.alert(response.alert);
    }
};

/**********
 * public methods
 **********/

/**
 * 티켓링크 API포멧을 자동으로 처리하는 래핑 메서드
 * @param  {string} url     요청API
 * @param  {object} options ajax요청 시 사용할 옵션
 */
API.prototype.call = function(url, options) {
    this.ajax(url, options);
};

/**********
 * ajax
 **********/

/**
 * 비동기 요청을 위한 객체를 만들어 반환한다
 * @return {(XMLHttpRequest|ActiveXObject)}
 */
API.prototype._createXHR = function() {
    if (common.isExisty(common.pick(window, 'XMLHttpRequest'))) {
        return new XMLHttpRequest();
    } else if (common.isExisty(common.pick(window, 'ActiveXObject'))) {
        return new ActiveXObject('Microsoft.XMLHTTP'); // jshint ignore:line
    } else {
        throw Error('사용하시는 브라우저가 서비스 이용의 필수 기능을 지원하지 않습니다. 최신 버전의 브라우저를 사용해 주세요.');
    }
};

/**
 * 타입에 따라 데이터를 추가 가공한다
 *
 * TODO: 현재는 JSON데이터만 처리중이고 필요에 따라 늘어나야 한다
 * @param {string} dataType 데이터 타입
 * @param {*} data 가공할 데이터
 * @return {*}
 */
API.prototype._processRawData = function(dataType, data) {
    var result = data;
    if (dataType === 'json') {
        try {
            result = JSON.parse(data);
        } catch(e) {
            result = data;
        }
    }

    return result;
};

/**
 * XHR의 응답 데이터를 처리한다
 * @param {object} options ajax옵션 객체
 * @param {(XMLHttpRequest|ActiveXObject)} xhr     비동기 요청 객체
 */
API.prototype._onReadyStateChange = function(options, xhr) {
    var status,
        response;

    if (xhr.readyState === 4) {
        status = xhr.status;

        // 정상적으로 응답을 받은 경우
        if ((status >= 200 && status < 300) || status === 304) {
            // 응답이 문제없는 경우
            response = this._processRawData(options.dataType, xhr.responseText);

            this._checkResponse(response);

            if (response.code === API.RETURN_CODE.SUCCESS) {
                options.success(response.result);
            } else {
                options.fail(response.result, response.code);
            }
        } else if (status !== 0) {
            options.error();
        }

        options.complete();
    }
};


/**
 * ajax 요청
 * @param {string} url ajax요청 할 url
 * @param {Object} options
 * @param {string} [options.method='POST'] 요청 시 사용할 http methods
 * @param {boolean} [options.async=true] 비동기 요청 사용 여부
 * @param {string} [options.type='application/json; charset=utf-8'] type 헤더 값
 * @param {string} [options.contentType='application/json'] Content-Type 헤더 값
 * @param {function()} [options.beforeRequest] 요청 전 수행할 콜백
 * @param {function()} [options.error] 요청에 대한 에러 발생 시 수행할 콜백
 * @param {function()} [options.complete] 요청이 끝났을 때 (성공, 실패 여부와 무관) 수행하는 콜백
 */
API.prototype.ajax = function(url, options) {
    var xhr,
        defaultOptions = {
            method: API.METHOD,
            async: true,
            type: 'application/json; charset=utf-8',
            contentType: 'application/json',
            dataType: 'json',
            beforeRequest: function() {},
            success: function() {},
            fail: function() {},
            error: function() {},
            complete: function() {}
        };

    options = common.extend(defaultOptions, options);
    options.beforeRequest();   // beforeRequest

    xhr = this._createXHR();
    xhr.open(options.method, url, options.async);
    xhr.setRequestHeader('type', options.type);
    xhr.setRequestHeader('Content-Type', options.contentType);
    xhr.onreadystatechange = common.bind(this._onReadyStateChange, this, options, xhr);

    xhr.send(common.isExisty(common.pick(options, 'data')) ? JSON.stringify(options.data) : null);
};

module.exports = API;
