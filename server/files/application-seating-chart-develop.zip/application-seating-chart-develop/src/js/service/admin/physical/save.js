/**
 * @fileoverview 작업완료, 임시저장 for 물리도면
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var PhysicalIB = require('./physicalIb');

var UIController = ne.tkl.UIController;

var SaveUI = UIController.extend(/** @lends SaveUI.prototype */{
    rootElement: $('#save_btn_area'),
    /**
     * @constructs
     * @exports SaveUI
     * @class
     */
    init: function() {
        UIController.call(this);
        this.attachEvents();
    },

    events: {
        'click button.fin': '_onClickFinish'
    },

    _onClickFinish: function(e) {
        e.preventDefault();
        this.emit(PhysicalIB.EVENT.WORK_COMPLETE);
    }

});

module.exports = SaveUI;
