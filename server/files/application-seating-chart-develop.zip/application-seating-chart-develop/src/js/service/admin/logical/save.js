/**
 * @fileoverview 작업완료 for 논리도면
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var LogicalIB = require('./logicalIb');

var Settings = ne.tkl.Settings;

var UIController = ne.tkl.UIController;

var SaveUI = UIController.extend(/** @lends SaveUI.prototype */{
    rootElement: $('#save_btn_area'),
    /**
     * @constructs
     * @exports SaveUI
     * @class
     */
    init: function() {
        UIController.call(this);
        if(Settings.isClosedEvent/* || Settings.isSellerSystem 캐시개발 완료 되면 사용*/) {
            this.$el.hide();
        } else {
            this.attachEvents();
        }
    },

    events: {
        'click button.fin': '_onClickFinish'
    },

    _onClickFinish: function(e) {
        e.preventDefault();
        this.emit(LogicalIB.EVENT.WORK_COMPLETE);
    }

});

module.exports = SaveUI;
