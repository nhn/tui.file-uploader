/**
 * @fileoverview 좌석정보 입력 팝업
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var common = ne.util,
    UIController = ne.tkl.UIController;

var AllocSeatMarkUI = UIController.extend({
    rootElement: $('#pop_wrap'),

    static: {
        styles: {
            padding_number: '30px 50px',
            padding_row: '67px 50px',
            padding_general: '85px 50px'
        },
        placeholderText: '시작{=TYPE}을(를) 입력해주세요',
        REGEX: {
            number: /^\d+$/,
            row: /^[a-z|A-Z|ㄱㄴㄷㄹㅁㅂㅅㅇㅈㅊㅌㅋㅍㅎ|가나다라마바사아자차타카파하]{1}$/
        }
    },

    init: function(options) {
        UIController.call(this, options);

        var $el = this.$el;

        this.seatCount = common.isExisty(common.pick(options, 'seatCount')) ? options.seatCount : 0;

        if (!this.seatCount) {
            window.alert('잘못된 요청입니다');
            common.popup.close();
        }

        this.currentUnit = '';
        this.mappingType = '';

        this.$select = $el.find('.flr_sel');
        this.$tab = $el.find('.tab_arr');
        this.$tabCon = $el.find('.tab_con');
        this.$mapping = $el.find('.seat_arr_lst');
        this.$input = $el.find('.start_arr_num');

        this.attachEvents();

        this._onSelectChanged();
        this.setMappingType();
        this.setPlaceholderText(true);
    },

    events: {
        'change select.flr_sel': '_onSelectChanged',
        'click .btn_conf': '_onConfirm',
        'click .tab_arr': '_onClickTab',
        'focus .start_arr_num': '_onFocusNum',
        'blur .start_arr_num': '_onBlurNum'
    },

    /**
     * 매핑정보 타입을 받아 그에 맞게 폼을 구성해준다
     * @param {string} unit 매핑정보 타입
     */
    setForm: function(unit) {
        var tabCon = this.$tabCon;

        tabCon.css('padding', 'auto');

        if (unit === 'ROW') {
            this.$tab.show();
            tabCon.css('padding', AllocSeatMarkUI.styles.padding_row);
        } else {
            this.$tab.hide();
        }

        if (unit === 'NUMBER') {
            this.$mapping.show();
            tabCon.css('padding', AllocSeatMarkUI.styles.padding_number);
        } else {
            this.$mapping.hide();
        }

        if (unit === 'GENERAL') {
            tabCon.css('padding', AllocSeatMarkUI.styles.padding_general);
            this.$tab.hide();
        }
    },

    /**
     * 선택된 탭을 참조하여 자동배열인지, 일괄적용인지 상태값을 설정한다
     */
    setMappingType: function() {
        var $a = this.$tab.find('li.on a');
        this.mappingType = $a.hasClass('mapping_auto') ? 'AUTO' : 'BATCH';
    },

    /**
     * 셀렉트박스를 참조하여 선택된 매핑정보의 타입을 상태값으로 저장한다
     */
    getUnit: function() {
        var $select = this.$select,
            value = $select.val();

        if (value === 'NUMBER' && this.seatCount < 2) {
            value = 'GENERAL';
        }

        this.currentUnit = value;

        return value;
    },

    /**
     * 현재 선택된 매핑정보 단위의 텍스트를 반환한다
     */
    getUnitStr: function() {
        return this.$select.find(':selected').text();
    },

    /**
     * 번호 입력 텍스트박스에 placeholder를 설정한다
     * @param {boolean} force 사용자가 값을 입력했으면 placeholder 를 갱신하는 것을 미루는데 이를 강제로 덮어씀
     */
    setPlaceholderText: function(force) {
        var unit = this.getUnitStr(),
            old = this.placeholderText;

        this.placeholderText = AllocSeatMarkUI.placeholderText.replace('{=TYPE}', unit);
        if (force || this.$input.val() === old) {
            this.setNumberValue(this.placeholderText);
        }
    },

    /**
     * 현재 입력된 번호 값을 반환
     */
    getNumberValue: function() {
        return this.$input.val();
    },

    /**
     * 인자로 넘어온 번호 값을 세팅
     * @param {string} str
     */
    setNumberValue: function(str) {
        this.$input.val(str);
    },

    /**
     * placeholder 에 영향받지 않는 입력값을 받아온다.
     */
    getNumberData: function() {
        var value = this.$input.val();

        if (value === this.placeholderText) {
            value = '';
        }

        return value.replace(/\s/g, '');
    },

    getMethodStr: function() {
        return this.$select.find(':selected').text();
    },

    /**
     * 번호 배열 방법 값을 반환한다
     */
    getMappingMethod: function() {
        return this.$mapping.find(':checked').val();
    },

    /**
     * 번호 입력 텍스트박스 내용을 선택 처리한다
     */
    focusNumber: function() {
        this.$input.select();
    },

    /**
     * 셀렉트박스 변경 시 이벤트 핸들러
     */
    _onSelectChanged: function() {
        this.setForm(this.getUnit());
        this.setPlaceholderText(true);
    },

    /**
     * 자동배열/일괄적용 탭이 변경될 때 핸들러
     * @param {MouseEvent} e
     */
    _onClickTab: function(e) {
        e.preventDefault();
        var target = $(e.target);

        this.$tab.find('li.on').removeClass('on');
        target.closest('li').addClass('on');

        this.setMappingType();
    },

    /**
     * 확인 버튼 클릭 시 처리
     * @param {MouseEvent} e
     */
    _onConfirm: function(e) {
        e.preventDefault();

        var data = {
            type: this.currentUnit,
            str: this.getMethodStr(),
            mappingType: this.mappingType,
            mappingMethod: this.getMappingMethod(),
            startNumber: this.getNumberData()
        };

        if (data.startNumber === '') {
            this.focusNumber();
            window.alert('값을 입력해주세요');
            return;
        }

        if (!data.startNumber) {
            this.focusNumber();
            alert(this.placeholderText);
            return;
        }

        if (data.type === 'NUMBER' &&
            !AllocSeatMarkUI.REGEX.number.test(data.startNumber)) {
            this.focusNumber();
            alert('번호는 숫자만 입력 가능합니다');
            return;
        }

        if (data.type === 'ROW' && data.mappingType === 'AUTO' &&
            !(AllocSeatMarkUI.REGEX.number.test(data.startNumber) || AllocSeatMarkUI.REGEX.row.test(data.startNumber))
            ) {
            this.focusNumber();
            alert('열은 ㄱ~ㅎ,가~하 중 한글자나 숫자만 입력 가능합니다');
            return;
        }

        data.startNumber = window.encodeURIComponent(data.startNumber);
        data.str = window.encodeURIComponent(data.str);

        opener.ne.tkl.callback.allocSeatMark(data);

        window.close();
    },

    /**
     * 번호 입력 텍스트박스 포커스 시 이벤트 핸들러
     */
    _onFocusNum: function() {
        var value = this.getNumberValue();

        if (value === this.placeholderText) {
            this.setNumberValue('');
        }
    },

    /**
     * 번호 입력 텍스트박스 블러 시 이벤트 핸들러
     */
    _onBlurNum: function() {
        var value = this.getNumberValue();

        if (value === '') {
            this.setNumberValue(this.placeholderText);
        }
    }

});

module.exports = AllocSeatMarkUI;
