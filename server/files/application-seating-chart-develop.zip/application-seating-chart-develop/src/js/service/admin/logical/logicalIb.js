/**
 * @fileoverview 논리도면 IB
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var common = ne.util;
var tkl = ne.tkl,
    API = tkl.API,
    InteractBroker = tkl.InteractBroker,
    RSeat = tkl.RSeat;

/**
 * @constructor
 * @extends {InteractBroker}
 */
function LogicalIB() {
    InteractBroker.call(this);

    //this.addOrder(EVENT.LOAD_SEAT_DATA, this._loadSeatData);
    this.addOrder(EVENT.CHECK_IMPERFECTION_SEATS, this._checkImperfection);

    this.addOrder(EVENT.UPDATE_SELLING_TYPE, this.updateSellingType);
    this.addOrder(EVENT.UPDATE_GRADE, this.updateGrade);
    this.addOrder(EVENT.APPLY_ALL_SCHEDULE, this.applyAllSchedule);
    this.addOrder(EVENT.MAP_SELECT_SEAT, this.selectSeat);

    this.addOrder(EVENT.SHOW_SELECTED_LIST, this._popupSelectedSeatList);
    this.addOrder(EVENT.SHOW_SELLINGTYPE_LIST, this._popupSellingTypeList);

    this.addOrder(EVENT.SET_SEATSTATUS, this._setSeatStatus);
    this.addOrder(EVENT.UPDATE_SELECTED_SEATSLIST, this._setSelectedSeatList);

    this.addOrder(EVENT.SAVE_TEMPORARY, this._saveTemporary);
    this.addOrder(EVENT.WORK_COMPLETE, this._workComplete);
}

common.inherit(LogicalIB, InteractBroker);

/**********
 * static props
 **********/

var EVENT = {
    UPDATE_SEAT_GRADE: 'updateSeatGrade',
    UPDATED_SEAT_GRADE: 'updatedSeatGrade',

    MAP_TOGGLE_SELECT_MODE: 'mapToggleSelectMode',

    UPDATE_SEAT_DEALERSHIP: 'updateSeatDealership',
    UPDATED_SEAT_DEALERSHIP: 'updatedSeatDealership',

    CHECK_IMPERFECTION_SEATS: 'checkImperfectionSeats',
    CHECKED_IMPERFECTION_SEATS: 'checkedImperfectionSeats',
    UPDATE_SELECTED_SEATSLIST: 'updateSelectedSEatsList',

    SHOW_SELECTED_LIST: 'showSelectedListDetail',
    SHOW_SELLINGTYPE_LIST: 'showSelectTypeDetail',

    RESET_SELLINGTAB: 'resetSellingTab',

    /* 좌석 할당처 수정 */
    UPDATE_SELLING_TYPE: 'updateSellingType',
    UPDATED_SELLING_TYPE: 'updatedSellingType',

    /* 좌석 등급 수정 */
    UPDATE_GRADE: 'updateGrade',
    UPDATED_GRADE: 'updatedGrade',

    /* 선택영역 전회차 저장 */
    APPLY_ALL_SCHEDULE: 'applyAllSchedule',

    SET_SEATSTATUS: 'setSeatStatus',
    UPDATE_SEATSTATUS: 'updateSeatStatus',

    SAVE_TEMPORARY: 'saveTemporary',
    WORK_COMPLETE: 'workComplete',
    WORK_COMPLETED: 'workCompleted'
};

LogicalIB.EVENT = common.extend(EVENT, InteractBroker.EVENT);

/**
 * 지정석 비지정석 구분 플래그
 * @enum
 * @type {{RSEAT: string, NSEAT: string}}
 */
LogicalIB.SEAT_TYPE = {
    RSEAT: 'reserved',
    NSEAT: 'nonreserved'
};

LogicalIB.ERROR = {
    E01: '논리도면 - 비지정석 할당처 수정: 한번에 한 비지정석에 대한 할당처 수정이 가능합니다'
};

/**********
 * order methods
 **********/

LogicalIB.prototype._selectRSeat = function (sidList, panToCenter) {
    var self = this;

    if (!sidList.length && !sidList.length) {
        return;
    }

    this.requestToAPI(API.URL.LOGICAL_SELECT_SEAT, {
        data: {
            logicalPlanId: this.get('venueID'),
            selectedSeats: sidList,
            selectedZone: []
        },
        dimmImmediate: true,
        noPreventCloseWindow: true,
        success: function(result) {
            self.emit(EVENT.SELECT_RSEAT_COMPLETED, result, panToCenter);
        }
    });
};

LogicalIB.prototype.selectSeat = function(e) {
    var self = this,
        selectCtrl = this.get('selectCtrl'),
        rSeat = common.map(e.r, function(seat) { return seat.sid; }),
        nSeat = common.map(e.n, function(seat) { return seat.sid; }),

    slidListToUpdate = [];

    selectCtrl.seats.each(function(seat) {
        if (seat.name === 'RSeat') {
            rSeat.push(seat.sid);
            slidListToUpdate.push(seat.slid);
        } else {
            nSeat.push(seat.sid);
        }
    });

    if (!rSeat.length && !nSeat.length) {
        return;
    }

    var param = {
        logicalPlanId: this.get('venueID'),
        selectedSeats: rSeat,
        selectedZone: nSeat
    };

    this.requestToAPI(API.URL.LOGICAL_SELECT_SEAT, {
        data: param,
        noDimm: true,
        success: function(response) {
            self.fire(InteractBroker.EVENT.MAP_SELECTED_SEAT, response, e, slidListToUpdate);
        }
    });
};

LogicalIB.prototype._loadRSeat = function(gridIDList, callback) {
    var self = this,
        inProgress = this.get('load-rseat-in-progress');

    if (inProgress) {
        return;
    }

    this.set('load-rseat-in-progress', true);

    this.requestToAPI(API.URL.LOGICAL_LOAD_RSEAT, {
        data: {
            logicalPlanId: this.get('venueID'),
            areaList: gridIDList
        },
        dimmImmediate: true,
        noPreventCloseWindow: true,
        success: function(result) {
            self.emit(EVENT.LOAD_RSEAT_COMPLETED, result.grids, result.seatSoldoutMap, gridIDList, common.keys(result.grids));
            callback();
        },
        complete: function() {
            self.set('load-rseat-in-progress', false);
        }
    });
};

/**
 * 임시저장
 * @private
 */
LogicalIB.prototype._saveTemporary = function() {
    var self = this,
        param = {
            logicalPlanId: this.get('venueID')
        };

    this.requestToAPI(API.URL.LOGICAL_SAVE_TEMPORARY, {
        data: param,
        success: function() {
            self.emit(LogicalIB.EVENT.CHECK_IMPERFECTION_SEATS, { type: 'all' });
            self.preventCloseWindow = false;
        }
    });
};

/**
 * 작업완료
 * @private
 */
LogicalIB.prototype._workComplete = function() {
    var self = this,
        param = {
            logicalPlanId: this.get('venueID')
        };

    this.requestToAPI(API.URL.LOGICAL_WORK_COMPLETE, {
        data: param,
        fail: function(response) {
            self.fire(LogicalIB.EVENT.CHECKED_IMPERFECTION_SEATS, response, false);
        },
        success: function() {
            self.emit(LogicalIB.EVENT.WORK_COMPLETED);
        },
        complete: function() {
            self.preventCloseWindow = false;
        }
    });
};

/**
 * 좌석등급 수정
 * @param {string} gradeCode 등급코드
 */
LogicalIB.prototype.updateGrade = function(gradeCode) {
    var self = this,
        seats = this.getSeatsToUpdate(true),
        split = this.getSplitedSIDBySeatType(seats),
        param;

    param = {
        logicalPlanId: this.get('venueID'),
        selectedSeats: split.r,
        selectedZone: split.n,
        grade: gradeCode
    };

    this.requestToAPI(API.URL.LOGICAL_UPDATE_GRADE, {
        data:param,
        success: function(response) {
            var ownSeats = self.getSeatsToUpdate();
            self.emit(LogicalIB.EVENT.UPDATED_GRADE, response);
            // 좌석 등급 갱신 시, 좌석 상태 정보영역 갱신
            self.emit(LogicalIB.EVENT.SET_SEATSTATUS);
            seats.each(function(s) {
                ownSeats.get(s.sid).grade = gradeCode;
            });

            self.get('nSeatCtrl').update(true);
            self.get('selectCtrl').update(true);
        }
    });
};

/**
 * 선택영역 전회차 저장
 */
LogicalIB.prototype.applyAllSchedule = function() {
    var seats = this.getSeatsToUpdate(true),
        split = this.getSplitedSIDBySeatType(seats),
        url = '/product/popup/logical-plan/selectCopySchedule.nhn?logicalPlanId=' + this.get('venueID'),
        param;

    param = {
        logicalPlanId: this.get('venueID'),
        productId: this.get('productID'),
        selectedSeats: split.r,
        selectedZone: split.n
    };

    this.requestToAPI(API.URL.LOGICAL_APPLY_ALL_SCHEDULE, {
        data: param,
        dimmedImmediate: true,
        success: function(result) {
            if (result.possible) {
                return;
            }

            if (common.isExisty(common.pick(result, 'reservedScheduleId'))) {
                common.popup.openPopup(url, {
                    popupOptionStr: 'top=50,left=50,width=950,height=875',
                    method: 'post',
                    postDataBridgeUrl: '/resources/js/postDataBridge.html',
                    param: {
                        reservedScheduleId: result.reservedScheduleId,
                        searchSeat: split.r,
                        searchZone: split.n
                    }
                });
            }
        }
    });
};

/**
 * 좌석 할당처를 수정한다
 * @example
 * // 비지정석
 * logical.IB.emit('updateSellingType', 'nonreserved', {
 *     'TKL': 100,
 *     'AGENCY': 20 // 0 장으로 지정할 경우 삭제된다
 * });
 *
 * // 지정석
 * logical.IB.emit('updateSellingType', 'reserved', 'AGENCY');
 *
 * @param {SEAT_TYPE} seatType
 * @param {(string|object)} data 할당처코드 및 할당처별 할당매수 데이터 객체
 */
LogicalIB.prototype.updateSellingType = function(seatType, data) {
    var self = this;
    var seats = this.getSeatsToUpdate(true);
    var param = this._getSellingTypeParam(seatType, seats, data);

    var url = (seatType === LogicalIB.SEAT_TYPE.RSEAT) ?
        API.URL.LOGICAL_UPDATE_SELLING_TYPE_RSEAT : API.URL.LOGICAL_UPDATE_SELLING_TYPE_NSEAT;

    this.requestToAPI(url, {
        data:param,
        success: function(response) {
            var ownSeats = self.getSeatsToUpdate();
            self.emit(LogicalIB.EVENT.UPDATED_SELLING_TYPE, response);
            seats.each(function(s) {
                if (s.name === 'RSeat') {
                    ownSeats.get(s.sid).sellingType = data;
                } else {
                    ownSeats.get(s.sid).setDealership(s.getDealership());
                }
            });

            self.get('selectCtrl').update(true);
        }
    });
};



/**
 * 할당처를 저장한다.
 * @param {SEAT_TYPE} seatType 지정석 비지정석 여부
 * @param {object} data 할당처 갱신 데이터
 * @param {HashMap} seats 선택좌석
 * @param {(string|object)} [data] 할당처 타입(지정석의 경우)
 * @private
 */
LogicalIB.prototype._getSellingTypeParam = function(seatType, seats, data) {
    var seat,
        venueID = this.get('venueID'),
        param;

    seat = [];
    seats.each(function(s) {
        seat.push(s.sid);
    });

    param = {
        logicalPlanId: venueID,
        selectedSeats: seat
    };

    if (seatType === LogicalIB.SEAT_TYPE.RSEAT) {
        if (seats.length < 1) {
            return;
        }
        common.extend(param, { sellingType: data });
    } else {
        if (seats.length > 1) {
            throw new Error(LogicalIB.ERROR.E01);
        }
        common.extend(param, this._getNSeatSellingTypeUpdateParam(seats.get(seat[0]), data));
    }

    return param;
};

/**********
 * private methods
 **********/

/**
 * 좌석 타입별로 나눠 배열로 sid를 반환한다
 * @param {HashMap} hashMap
 * @returns {{r: Array, n: Array}}
 */
LogicalIB.prototype.getSplitedSIDBySeatType = function(hashMap) {
    var rSeat = [],
        nSeat = [];

    hashMap.each(function(seat) {
        if (seat.name === 'RSeat') {
            rSeat.push(seat.sid);
        } else {
            nSeat.push(seat.sid);
        }
    });

    return { r: rSeat, n: nSeat };
};

/**
 * @typedef {{code:string, ticket:number}} DealershipInfo
 */

/**
 * 비지정석 모델과 업데이트하려는 판매할당처를 보고 삭제해야할 할당처를 반환
 * @param {NSeat} nSeat
 * @param {DealershipInfo} dataToUpdate
 * @return {object}
 * @private
 */
LogicalIB.prototype._getNSeatSellingTypeUpdateParam = function(nSeat, dataToUpdate) {
    var origin = nSeat.getDealership(),
        codeToRemove = [],
        codeToUpdate = {},
        result = {};

    common.forEachOwnProperties(origin, function(cnt, code) {
        var cntToUpdate = dataToUpdate[code];
        if (cntToUpdate === '0' || cntToUpdate === '') {
            codeToRemove.push(code);
        }
    });

    common.forEachOwnProperties(dataToUpdate, function(cnt, code) {
        if ((cnt === '' || cnt === '0')) {
            codeToRemove.push(code);
        } else if ((origin[code] + '') !== cnt) {
            codeToUpdate[code] = cnt;
        }
    });

    nSeat.setDealership(codeToUpdate);

    result.dealerShip = codeToUpdate;
    if (codeToRemove.length) {
        result.removeDealerShip = codeToRemove;
    }

    return result;
};

/**
 * 불충족 조건 체크
 * @param {object} data 전체/선택 여
 * @private
 */
LogicalIB.prototype._checkImperfection = function(data) {

    var self = this,
        param,
        selectCtrl = this.get('selectCtrl'),
        selectList = selectCtrl.seats,
        selectedrSeatID = [],
        selectednSeatID =[],
        type = data.type;

    if (type === 'selected') {
        selectList.each(function(seat) {
            if (seat.constructor === RSeat) {
                selectedrSeatID.push(seat.sid);
            } else {
                selectednSeatID.push(seat.sid);
            }

        });
    }
    // 선택좌석 체크시, 선택된 좌석이 없으면 리턴
    if (type === 'selected' && common.isEmpty(selectedrSeatID) && common.isEmpty(selectednSeatID)) {
        alert('선택된 좌석이 없습니다.');
        return;
    }

    param = {
        logicalPlanId: this.get('venueID'),
        selectedSeats: common.isNotEmpty(selectedrSeatID) ? selectedrSeatID : undefined,
        selectedZone: common.isNotEmpty(selectednSeatID) ? selectednSeatID : undefined
    };

    this.requestToAPI(API.URL.CHECK_IMPERFECTION_LOGICAL, {
        data: param,
        success: function(response) {
            self.fire(LogicalIB.EVENT.CHECKED_IMPERFECTION_SEATS, response);
        }
    });
};
/**
 * 선택좌석정보 자세히보기 팝업
 * @private
 */
LogicalIB.prototype._popupSelectedSeatList = function() {
    var selectCtrl = this.get('selectCtrl'),
        url = '/product/popup/logical-plan/selectedSeatsInfo.nhn',
        selectedSeats = [],
        selectedZone = [];

    selectCtrl.seats.each(function(seat) {
        if (seat.slid === 'reserved') {
            selectedSeats.push(seat.sid);
        } else {
            selectedZone.push(seat.sid);
        }
    });
    if(common.isEmpty(selectedSeats) && common.isEmpty(selectedZone)) {
        return;
    }
    common.popup.openPopup(url, {
        popupOptionStr: 'width=660,height=342',
        method: 'POST',
        param: {
            logicalPlanId: this.get('venueID'),
            searchSeat: selectedSeats,
            searchZone: selectedZone
        }
    });
};


LogicalIB.prototype._popupSellingTypeList = function() {
    var url = '/product/popup/logical-plan/getAllotmentSeats.nhn';
    common.popup.openPopup(url, {
        popupOptionStr: 'width=900,height=548',
        method: 'GET',
        param: {
            logicalPlanId: this.get('venueID')
        }
    });
};

LogicalIB.prototype._setSelectedSeatList = function() {
    var selectCtrl = this.get('selectCtrl');
    this.set('selectedList', selectCtrl.seats);
};

/**
 * 좌석등급 정보 갱신
 * @private
 */
LogicalIB.prototype._setSeatStatus = function() {
    var self = this;
    this.requestToAPI(API.URL.SEAT_STATUS, {
        data: {
            logicalPlanId: this.get('venueID')
        },
        noPreventCloseWindow: true,
        success: function(response) {
            self.fire(LogicalIB.EVENT.UPDATE_SEATSTATUS, response);
        }
    });
};

module.exports = LogicalIB;
