/**
 * @fileoverview 탭 UI 컨트롤러
 * @author FE개발팀
 */

'use strict';

var LogicalIB = require('./logicalIb'),
    HeaderUI = require('../../common/header');

var LogicalHeader = HeaderUI.extend({
    /**
     * @constructs
     * @extends HeaderUI
     * @exports LogicalHeader
     * @class
     * @param {jQuery} $el
     * @param {object} options
     */
    init: function($el, options) {
        HeaderUI.call(this, $el, options);

        this.$select = this.$el.find('select');
    },

    /**
     * 회차 셀렉트박스 변경 시 사용하는 redirect url
     */
    logicalPlanPageUrl: '/product/popup/logical-plan/drawing.nhn?logicalPlanId={=logicalPlanId}&code=',

    events: {
        'click .shrtkey': '_onClickShrtKey',
        'click .seatinfo': '_onClickSearchSeatInfo',
        'change select': '_onScheduleChanged'
    },

    changeSelectboxValue: function($sel, val) {
        var $opt = $sel.find('option[value=' + val + ']');

        $sel.find('option:selected').prop('selected', false);

        if ($opt) {
            $opt.prop('selected', true);
        }
    },

    /**
     * 할당처별 좌석정보 조회 클릭시 이벤트
     * @private
     */
    _onClickSearchSeatInfo: function() {
        this.emit(LogicalIB.EVENT.SHOW_SELLINGTYPE_LIST);
    },

    /**
     * 회차 변경 셀렉트박스
     * @private
     */
    _onScheduleChanged: function() {
        var $select = this.$select,
            logicalPlanId = $select.find(':selected').val(),
            url = this.logicalPlanPageUrl.replace('{=logicalPlanId}', logicalPlanId),
            self = this;

        window.location.replace(url);
        window.setTimeout(function() {
            self.detachEvents();
            self.changeSelectboxValue($select, self.IB.get('venueID'));
            self.attachEvents();
        }, 0);
    }
});

module.exports = LogicalHeader;
