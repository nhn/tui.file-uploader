/**
 * @fileoverview 물리도면 -> 좌석탭 UI 모듈
 * @author minhyeong.kim
 */

'use strict';

var Physical = require('./physical'),
    PhysicalIB = require('./physicalIb');

var UIController = ne.tkl.UIController;

var CreateSeatUI = UIController.extend({
    rootElement: $('.tab-ui .con1'),

    init: function(options) {
        UIController.call(this, options);

        var $el = this.$el;

        this.$col = $el.find('#s_col');
        this.$row = $el.find('#s_row');
        this.$gCol = $el.find('#g_col');
        this.$gRow = $el.find('#g_row');
        this.$type = $el.find('input[name=arr]');

        this.attachEvents();
    },

    /**********
     * static props
     **********/

    events: {
        'click #create_seat': '_onClickCreateSeat',
        'click #create_seat_group': '_onClickCreateSeatGroup'
    },

    /**********
     * private methods
     **********/

    /**
     * 좌석 그룹배치에 대한 데이터를 반환
     * @returns {{col: *, row: *, gCol: *, gRow: *, type: *}}
     * @private
     */
    _getPlaceData: function() {
        var rNum = /^\d+$/;
        var data = {
                col: this.$col.val(),
                row: this.$row.val(),
                gCol: this.$gCol.val(),
                gRow: this.$gRow.val(),
                mode: this.$type.filter(':checked').val()
            },
            valid = true;

        ne.util.forEachOwnProperties(data, function(value) {
            if (!rNum.test(value)) {
                valid = false;
                return false;
            }
        });

        if (!valid) {
            alert('좌석의 열, 행 또는 간격은 숫자만 입력 가능합니다');
            return;
        }

        return data;
    },

    /**********
     * event handler
     **********/

    _onClickCreateSeat: function() {
        this.emit(PhysicalIB.EVENT.ENABLE_SEATING, Physical.PLACE_TYPE.SINGLE);
    },

    _onClickCreateSeatGroup: function() {
        var seatPlaceData = this._getPlaceData();

        if (seatPlaceData) {
            this.emit(PhysicalIB.EVENT.ENABLE_SEATING, Physical.PLACE_TYPE.GROUP, seatPlaceData);
        }
    }


});

module.exports = CreateSeatUI;
