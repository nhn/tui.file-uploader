/**
 * @fileoverview 논리도면 서비스페이지 entry point
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var common = global.ne.util;

var Logical = require('./logical'),
    LogicalTabUI = require('./tab'),
    FloatingUI = require('../../common/floating'),
    HeaderUI = require('./header'),
    ApplyScheduleUI = require('./applySchedule'),
    TopMenuUI = require('./topMenu'),
    SelectedListUI = require('./selectedList'),
    SellingType = require('./sellingtype'),
    Grade = require('./grade'),
    ImperfectionSeats = require('./imperfectionSeats'),
    SeatStatus = require('./seatstatus'),
    SaveUI = require('./save');

function init(options) {
    if (!common.isExisty(options) ||
        !common.isObject(options)) {
        throw Error('도면 기본정보가 없습니다. 관리자에게 문의 바랍니다.');
    }

    var chart = ne.tkl.instance.chart = new Logical('map', options);
    var tab = new LogicalTabUI('.tab-ui', { IB: chart.IB });

    chart.addUIC(new FloatingUI());
    chart.addUIC(new TopMenuUI({ IB: chart.IB, zoom: chart.options.zoom }));
    chart.addUIC(new HeaderUI());
    chart.addUIC(new ApplyScheduleUI({ IB: chart.IB }));
    chart.addUIC(new SelectedListUI($('.selectedList'), {IB: chart.IB}));
    chart.addUIC(new SellingType($('.con2'), {IB: chart.IB, tab: tab}));
    chart.addUIC(new Grade($('.con1'), {IB: chart.IB}));
    chart.addUIC(new ImperfectionSeats($('.con5'), {IB: chart.IB, tab: tab}));
    chart.addUIC(new SeatStatus($('#seats_status'), {IB:chart.IB}));
    chart.addUIC(new SaveUI());

    return chart;
}

ne.tkl.logical = init;
