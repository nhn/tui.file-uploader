/**
 * @fileoverview 물리도면모듈이 UI와 연동되는 중간 매개체 역할을 하는 모듈
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */
'use strict';

var common = ne.util;
var tkl = ne.tkl;
var API = tkl.API;
var Settings = tkl.Settings;
var InteractBroker = tkl.InteractBroker;
var SelectSeatController = tkl.SelectSeatController;
var EVENT;

/**
 * @constructor
 * @extends {InteractBroker}
 */
function PhysicalIB() {
    InteractBroker.call(this);

    this.addOrder(EVENT.CREATE_SEAT, this._createSeat);
    this.addOrder(EVENT.UPDATE_SEAT, this._updateSeat);
    this.addOrder(EVENT.ROTATE_SEAT, this._rotateSeat);
    this.addOrder(EVENT.DELETE_SEAT, this._deleteSeat);
    this.addOrder(EVENT.MAP_SELECT_SEAT, this._selectSeat);

    this.addOrder(EVENT.SET_SEAT_NUMBER, this._setSeatNumber);
    this.addOrder(EVENT.CHECK_IMPERFECTION_SEATS, this._checkImperfection);
    this.addOrder(EVENT.UPDATE_SELECTED_SEATSLIST, this._setSelectedSeatList);

    this.addOrder(EVENT.SAVE_TEMPORARY, this._saveTemporary);
    this.addOrder(EVENT.WORK_COMPLETE, this._workComplete);

    this.addOrder(EVENT.RESERVE_CURRENT_STATUS, this._reserveSeatStatus);

    /**
     * for function throttling
     * @type {number}
     */
    this.throttleTimerID = 0;
}

common.inherit(PhysicalIB, InteractBroker);

/**********
 * static props
 **********/

EVENT = {
    ENABLE_SEATING: 'enableSeating',
    DISABLE_SEATING: 'disableSeating',

    CREATE_SEAT: 'createSeat',
    CREATED_SEAT: 'createdSeat',

    UPDATE_SEAT: 'updateSeat',
    UPDATED_SEAT: 'updatedSeat',

    ROTATE_SEAT: 'rotateSeat',    // 좌석회전 + 선택좌석불충족조건검사
    ROTATED_SEAT: 'rotatedSeat',

    DELETE_SEAT: 'deleteSeat',
    DELETED_SEAT: 'deletedSeat',

    SET_SEAT_NUMBER: 'setSeatsNumbers',
    SET_SEAT_NUMBER_END: 'setSeatsNumbersComplete',

    RENDER_IMMEDIATE_SELECTED: 'renderImmediateSelected',
    ROLLBACK_UPDATE_SEAT: 'rollbackUpdateSeat',

    GET_SELECTED_SEAT: 'getSelectedSeat',
    SELECT_TREE: 'selectTree',

    RENAME_TREE: 'renameTree',
    SET_ALLSEATS: 'setAllSeats',

    CHECK_IMPERFECTION_SEATS: 'checkImperfectionSeats',
    CHECKED_IMPERFECTION_SEATS: 'checkedImperfectionSeats',
    UPDATE_SELECTED_SEATSLIST: 'updateSelectedSeatsList',

    SAVE_TEMPORARY: 'saveTemporary',
    WORK_COMPLETE: 'workComplete',

    CHANGE_TAB_INDEX: 'changeTabIndex',
    RESERVE_CURRENT_STATUS: 'reserveCurrentStatus'
};

PhysicalIB.EVENT = common.extend(EVENT, InteractBroker.EVENT);

PhysicalIB.THROTTLING_DELAY = 500;

/**********
 * private methods
 **********/

/**
 * 함수 감속을 수행한다
 * @param {Function} fn 감속을 수행할 함수
 */
PhysicalIB.prototype._throttleRequest = function(fn) {
    window.clearTimeout(this.throttleTimerID);
    this.throttleTimerID = window.setTimeout(fn, PhysicalIB.THROTTLING_DELAY);
};

/**********
 * order methods
 **********/

PhysicalIB.prototype._loadRSeat = function(gridIDList, callback) {
    var self = this,
        inProgress = this.get('load-rseat-in-progress');

    if (inProgress) {
        return;
    }

    this.set('load-rseat-in-progress', true);

    this.requestToAPI(API.URL.PHYSICAL_LOAD_RSEAT, {
        data: {
            physicalPlanId: this.get('venueID'),
            areaList: gridIDList
        },
        dimmImmediate: true,
        noPreventCloseWindow: true,
        success: function(result) {
            self.emit(EVENT.LOAD_RSEAT_COMPLETED, result.grids, result.seatSoldoutMap, gridIDList, common.keys(result.grids));
            callback();
        },
        complete: function() {
            self.set('load-rseat-in-progress', false);
        }
    });
};

PhysicalIB.prototype._selectRSeat = function (sidList, panToCenter) {
    var self = this;

    this.requestToAPI(API.URL.PHYSICAL_SELECT_SEAT, {
        data: {
            physicalPlanId: this.get('venueID'),
            selectedSeats: sidList
        },
        dimmImmediate: true,
        noPreventCloseWindow: true,
        success: function(result) {
            self.set('selectedList', result.selectedSeats);
            self.emit(EVENT.SELECT_RSEAT_COMPLETED, result, panToCenter);
        }
    });
};

PhysicalIB.prototype._selectSeat = function(e) {
    var self = this,
        param;

    if (!e.r.length) {
        return;
    }

    param = {
        physicalPlanId: this.get('venueID'),
        selectedSeats: common.map(e.r, function(seat) { return seat.sid; })
    };

    this.requestToAPI(API.URL.PHYSICAL_SELECT_SEAT, {
        data: param,
        success: function(response) {
            self.fire(InteractBroker.EVENT.MAP_SELECTED_SEAT, response, e);
        }
    });
};

/**
 * 좌석생성
 * @param {number} x
 * @param {number} y
 * @param {object} place
 */
PhysicalIB.prototype._createSeat = function(x, y, place) {
    var self = this,
        param = this._getAPIDataForCreateSeat(x, y, place);

    this.requestToAPI(API.URL.CREATE_SEAT, {
        method: 'POST',
        data: param,
        msg: '좌석 생성 요청을 처리하는 중입니다.',
        success: function(response) {
            self.fire(PhysicalIB.EVENT.CREATED_SEAT, response);
        },
        error: function() {
            self.fire(PhysicalIB.EVENT.DISABLE_SEATING);
        }
    });
};

/**
 * 선택 좌석 수정
 *
 * - 좌석 매핑정보 수정
 * - 좌석 선택 해제
 * @param {string} type 업데이트 타입
 * @param {boolean} [throttle=false] 함수 감속 사용 여부
 * @private
 */
PhysicalIB.prototype._updateSeat = function(type, throttle) {
    throttle = common.isExisty(throttle) ? throttle : false;

    var self = this,
        args = Array.prototype.slice.call(arguments, 2),
        UPDATE_TYPE = SelectSeatController.UPDATE,
        seatsToUpdate = this.getSeatsToUpdate(),
        center,
        requestFn,
        rollbackFn = function() {
            self.fire(PhysicalIB.EVENT.ROLLBACK_UPDATE_SEAT, self.originalSeats);
        };

    this._reserveSeatStatus();

    switch (type) {
        case UPDATE_TYPE.POSITION:
            this._seatPosition(seatsToUpdate, args[0], args[1]);
            break;
        case UPDATE_TYPE.MAPINFO:
            seatsToUpdate = args[0];
            break;
    }

    requestFn = (function(seats) {
        return function() {
            var param = {
                physicalPlanId: self.get('venueID'),
                seatInfoList: self.parameterizeSeatHash(seats)
            };

            self.requestToAPI(API.URL.UPDATE_SEAT, {
                method: 'POST',
                data: param,
                dimmImmediate: type !== UPDATE_TYPE.MAPINFO,
                msg: '좌석 데이터를 수정하는 중입니다.',
                beforeRequest: function(options) {
                    if (type === UPDATE_TYPE.MAPINFO) {
                        ne.util.forEachArray(options.data.seatInfoList, function(seat) {
                            delete seat.position;
                            delete seat.cornerPoints;
                            delete seat.bound;
                        });
                    }
                },
                success: function(response) {
                    if (!throttle) {
                        self.fire(PhysicalIB.EVENT.UPDATED_SEAT, response);
                    }
                },
                error: rollbackFn,
                fail: rollbackFn,
                complete: function() {
                    self.originalSeats = null;
                }
            });
        };
    })(seatsToUpdate);

    if (throttle) {
        this._throttleRequest(requestFn);
    } else {
        requestFn();
    }
};

/**
 * save selected seat clones for revert changes when error, fail on apis.
 */
PhysicalIB.prototype._reserveSeatStatus = function() {
    if (!this.originalSeats) {
        this.originalSeats = this.getSeatsToUpdate(true);
    }
};

/**
 * rotate reserved seats.
 * @param {SelectSeatController.ROTATE_METHOD} method rotate method ex) each, group
 * @param {Number} deg rotate degree
 */
PhysicalIB.prototype._rotateSeat = function(method, deg) {
    var self = this,
        center,
        seatsToUpdate = this.getSeatsToUpdate(),
        param,
        rollbackFn = function() {
            self.fire(PhysicalIB.EVENT.ROLLBACK_UPDATE_SEAT, self.originalSeats);
            self.emit(PhysicalIB.EVENT.CHECK_IMPERFECTION_SEATS, {type: 'selected', silent: true});
        };

    if (method === SelectSeatController.ROTATE_METHOD.GROUP) {
        center = self.get('selectCtrl').groupBound.getCenter();
    }

    self._seatRotate(seatsToUpdate, deg, center);

    param = {
        physicalPlanId: self.get('venueID'),
        seatInfoList: self.parameterizeSeatHash(seatsToUpdate, function(seat) { seat.mapInfo = []; })
    };

    self._throttleRequest(function() {
        self.requestToAPI(API.URL.ROTATE_SEAT, {
            data: param,
            dimmImmediate: true,
            msg: '좌석 데이터를 수정하는 중입니다.',
            error: rollbackFn,
            fail: rollbackFn,
            complete: function() {
                self.originalSeats = null;
            }
        });
    });
};

PhysicalIB.prototype._deleteSeat = function(sidList) {
    var self = this,
        param;

    param = {
        physicalPlanId: this.get('venueID'),
        selectedSeats: sidList
    };

    this.requestToAPI(API.URL.DELETE_SEAT, {
        method: 'POST',
        data: param,
        success: function() {
            self.fire(PhysicalIB.EVENT.DELETED_SEAT, sidList);
        }
    });
};

/**
 * 좌석번호 입력 버튼 클릭 시 처리
 * @private
 */
PhysicalIB.prototype._setSeatNumber = function() {
    var selectCtrl = this.get('selectCtrl'),
        url = '/base/physicalPlan/allocSeatMark.nhn',
        selectedSeatID = [];

    selectCtrl.seats.each(function(seat) {
        selectedSeatID.push(seat.sid);
    });

    if(common.isEmpty(selectedSeatID)) {
        return;
    }

    common.popup.openPopup(url, {
        popupOptionStr: 'left=50,top=50,width=400,height=440',
        method: 'POST',
        popupName: 'allocSeatMark',
        postDataBridgeUrl: '/resources/js/postDataBridge.html',
        param: {
            physicalPlanId: this.get('venueID'),
            selectedSeats: selectedSeatID
        }
    });
};

PhysicalIB.prototype._checkImperfection = function(data) {
    var self = this,
        param,
        selectCtrl = this.get('selectCtrl'),
        selectedSeats = [],
        selectedZone = [],
        type = data.type,
        silent = common.isExisty(common.pick(data, 'silent')) ? data.silent : false;

    // 선택좌석 체크시, 선택된 좌석이 없으면 리턴
    if (type === 'selected') {
        selectCtrl.seats.each(function(seat) {
            if (seat.name === 'RSeat') {
                selectedSeats.push(seat.sid);
            } else {
                selectedZone.push(seat.sid);
            }
        });
    }
    // 선택좌석 체크시, 선택된 좌석이 없으면 리턴
    if (type === 'selected' && common.isEmpty(selectedSeats) && common.isEmpty(selectedZone)) {
        alert('선택된 좌석이 없습니다.');
        return;
    }

    param = {
        physicalPlanId: this.get('venueID'),
        selectedSeats: common.isNotEmpty(selectedSeats) ? selectedSeats : undefined,
        selectedZone: common.isNotEmpty(selectedZone) ? selectedZone : undefined
    };

    this.requestToAPI(API.URL.CHECK_IMPERFECTION, {
        data: param,
        success: function(response) {
            self.fire(PhysicalIB.EVENT.CHECKED_IMPERFECTION_SEATS, response, silent);
        }
    });
};

/**
 * 임시저장
 * @private
 */
PhysicalIB.prototype._saveTemporary = function() {
    var self = this,
        param = {
            physicalPlanId: this.get('venueID'),
            modifyMemberNo: Settings.MODIFY_MEMBER_NO
        };

    this.requestToAPI(API.URL.PHYSICAL_SAVE_TEMPORARY, {
        data: param,
        success: function() {
            self.emit(PhysicalIB.EVENT.CHECK_IMPERFECTION_SEATS, { type: 'all' });
            self.preventCloseWindow = false;
        }
    });
};

/**
 * 작업완료
 * @private
 */
PhysicalIB.prototype._workComplete = function() {
    var self = this,
        param = {
            physicalPlanId: this.get('venueID'),
            modifyMemberNo: Settings.MODIFY_MEMBER_NO
        };

    this.requestToAPI(API.URL.PHYSICAL_WORK_COMPLETE, {
        data: param,
        fail: function(response) {
            self.fire(PhysicalIB.EVENT.CHECKED_IMPERFECTION_SEATS, response, false);
        },
        complete: function() {
            self.preventCloseWindow = false;
        }
    });
};


/**********
 * private methods
 **********/

/**
 * 좌석 정보를 요청하기 위해 가공하는 메서드
 * @param {HashMap} seats
 * @param {Function} iteratee
 * @returns {Array}
 */
PhysicalIB.prototype.parameterizeSeatHash = function(seats, iteratee) {
    var self = this,
        obj,
        result = [];

    seats.each(function(seat) {
        obj = self._simplify(seat.clone());
        iteratee && iteratee(obj);
        result.push(obj);
    });

    return result;
};

/**
 * 좌석 hashMap의 좌석들을 diff만큼 이동처리하는 메서드
 * @param {HashMap} seats
 * @param {number} diffX
 * @param {number} diffY
 * @private
 */
PhysicalIB.prototype._seatPosition = function(seats, diffX, diffY) {
    seats.each(function(seat) {
        seat.moveBy(diffX, diffY);
    });
};

/**
 * 좌석 hashMap의 좌석들에 deg, center의 회전을 적용하는 메서드
 * @param {HashMap} seats
 * @param {number} deg
 * @param {Point} center
 * @private
 */
PhysicalIB.prototype._seatRotate = function(seats, deg, center) {
    seats.each(function(seat) {
        seat.rotate(deg, center);
    });
};

/**
 * 좌석 생성 API의 요청 데이터 구조를 만든다
 * @param {number} x
 * @param {number} y
 * @param {object} place
 * @returns {{physicalPlanId: *, seatInfoList: Array}}
 * @private
 */
PhysicalIB.prototype._getAPIDataForCreateSeat = function(x, y, place) {
    var isGroup = common.isExisty(place),
        param = {
            physicalPlanId: this.get('venueID'),
            seatInfoList: []
        };

    if (isGroup) {
        param.seatInfoList.push({
            position: [x, y],
            cols: place.col,
            rows: place.row,
            gutter: [place.gCol, place.gRow],
            mode: place.mode
        });
    } else {
        param.seatInfoList.push({
            position: [x, y],
            mode: 1
        });
    }

    return param;
};

PhysicalIB.prototype._setSelectedSeatList = function() {
    var selectCtrl = this.get('selectCtrl');
    this.set('selectedList', selectCtrl.seats);
};

module.exports = PhysicalIB;
