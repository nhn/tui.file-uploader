/**
 * @fileoverview 트리컴포넌트와 번호가 입력된 좌석들을 연계하여 사용할수 있는 객체
 * @author FE개발팀 이제인 jein-yi@nhnent.com
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */


'use strict';

var common = ne.util;
var RSeat = ne.tkl.RSeat;

/**
 * 트리컴포넌트를 조작하기 위한 데이터 가공 및, 트리조작을 한다.
 * @constructor
 * @exports {TreeBridge}
 */
function TreeBridge() {
    this._tree = null;
    /**
     * 트리좌석과 패스정보를, 트리뎁스정보와 매핑시킨 맵 데이터.
     * @type {{}}
     * @private
     * @example
     * {
     *   '1,A,4' : {
     *       seats: [10, 11, 12, 13, 14, 15], path: 0
     *   }
     * };
     */
    this._treemap = {};
    /**
     * 트리좌석의 위치
     * @type {{}}
     * @private
     * @example { '10': 'A,1,A', '11': 'A,1,A' }
     */
    this._seatmap = {};
    /**
     * 트리에 입력할 데이터
     * @type {{}}
     * @private
     * @example { children: [{ title:'t1', children: [] }] }
     *
     */
    this._treemodel = {};
    /**
     * 기본 콜백 값.
     * @type {function}
     */
    this._callback = function() {
        return;
    };
}

var TREE_CONFIG = {
    viewId: 'seats_tree',
    defaultState: 'open',
    openSet: ['unfold', '-'],
    closeSet: ['fold', '+'],
    template: {
        hasChild:
        '<li class="sub {{State}}" path={{Path}}>' +
            '<button type="button" class="sp_flr">{{StateLabel}}</button>' +
            '<span id="{{NodeID}}" class="depth{{Depth}} value">{{Title}}</span><em>{{DepthLabel}}</em>' +
            '<ul class="depth">' +
            '{{ChildNodes}}' +
            '</ul>' +
        '</li>',
        leapNode:
        '<li class="leap" path={{Path}}>' +
            '<button type="button" class="sp_flr"></button>' +
            '<span id="{{NodeID}}" class="depth{{Depth}} value">{{Title}}</span><em>{{DepthLabel}}</em>' +
            '<ul></ul>' +
        '</li>'
    },
    inputElementClass: 'flr_modi'
};

/**
 * 트리 생성
 */
TreeBridge.prototype._makeTree = function() {
    this._tree = new ne.component.Tree({
        data: this._treemodel.children,
        config: TREE_CONFIG
    });
    this.setLabel(RSeat.MAP_CODE.slice(0));
    this._tree.on('click', common.bind(this._selectedCallback, this));
    this._tree.on('rename', common.bind(this._renamedCallBack, this));
};

/**
 * 클릭시 콜백값을 변경한다.
 * @param {function} fnc 클릭시 동작할 콜백함수
 */
TreeBridge.prototype.setTreeSelectedCallback = function(fnc) {
    this._callback = fnc;
};

TreeBridge.prototype.setTreeRenamedCallback = function(fnc) {
    this._renameCallback = fnc;
};

/**
 * 트리 클릭시에 사용되는 콜백함수
 * @param {event} data 합성된 이벤트 객체
 * @private
 */
TreeBridge.prototype._selectedCallback = function(data) {
    var modSet = this._getSelectedInfo(data);
    this._callback({ sids: modSet.sids, map: modSet.map });
};

/**
 * 트리 이름 변경시에 사용되는 콜백함수
 * @param {event} data 합성된 이벤트 객체
 * @returns {boolean}
 * @private
 */
TreeBridge.prototype._renamedCallBack = function(data) {
    var modSet = this._getSelectedInfo(data),
        target = this._tree.model.findNode(data.path),
        temp = target.parent,
        changeText = this._tree.inputElement.value;

    // 중복되는 값이 있는지 비교한다. 중복되는 값이 있으면 수행하지 않는다.
    if (!this._checkDuplicate(changeText, temp.childNodes )) {
        this._renameCallback({ sids: modSet.sids, map: modSet.map, rename: changeText });
        return true;
    } else {
        return false;
    }
};

/**
 * 선택된 노드에 매칭되는 좌석과 패스를 가져온다.
 * @param {event} data 합성된 이벤트 객체
 * @returns {{sids: *, map: number}}
 * @private
 */
TreeBridge.prototype._getSelectedInfo = function(data) {
    var path = data.paths || data.path,
        map = path.split(',').length - 1,
        target = this._tree.model.findNode(path),
        value = target.title,
        key = [],
        temp = target.parent,
        sids,
        i;

    // 전체 키를 찾기 위한 for문
    for ( i = 0, key.push(value); i < map; i++ ) {
        key.unshift(temp.title);
        temp = temp.parent;
    }

    sids = this._extractSIDs(key.join(), path.split(',').length);

    return { sids : sids, map: map };
};

/**
 * 값이 중복되는지 확인한다.
 * @param {string} text 중복되는지 확인할 텍스트
 * @param {Array} arr 확인할 배열
 * @return {boolean}
 * @private
 */
TreeBridge.prototype._checkDuplicate = function(text, arr) {
    var node = common.filter(arr, function(el) {
        return el.title === text;
    });
    return common.isNotEmpty(node);
};
/**
 * 선택된 트리노드에 매칭되는 아이디를 추출한다
 * @param {string} values 비교값
 * @param {number} depth 선택된 노드의 깊이
 * @returns {*}
 * @private
 */
TreeBridge.prototype._extractSIDs = function(values, depth) {

    var seatmap = this._seatmap,
        elSpl,
        valSpl = values.split(','),
        last,
        sids;
    sids = common.filter(seatmap, function(el) {
        if(el && el.indexOf(values) === 0) {
            elSpl = el.split(',');
            last = valSpl.length - 1;

            if(elSpl[last] === valSpl[last]) {
                return true;
            } else {
                return false;
            }
        }
    });

    sids = common.map(sids, function(el, key) {
        return key;
    });

    return sids;
};

/**
 * 트리해시 생성 or 추가
 * {
 *   '1,A,4' : {
 *       seats: [10, 11, 12, 13, 14, 15], path: 0
 *   }
 * };
 */
TreeBridge.prototype.insertTreeMap = function(data) {
    var seats = data;

    //FIXME: 좌석 선택 후 화면밖으로 드래그하면 data가 다른 형태로 와 문제 발생
    if ('seats' in seats) {
        seats = seats.seats;
    }
    this._seatmap = {};
    this._treemap = {};
    common.forEach(seats, function(seat) {
        var mapinfo = seat.mapInfo,
            sid = seat.sid,
            key;

        if (!common.isObject(seat) || !mapinfo.join('')) {
            return;
        }

        if (RSeat.MAP_CODE.length === seat.mapInfo.length) {
            mapinfo.length = mapinfo.length - 1;
        }

        key = common.filter(mapinfo, function(el) {
            return el;
        });
        key = key.join();
        this._seatmap[sid] = key;
        if (!this._treemap[key]) {
            this._treemap[key] = {
                seats: []
            };
        }
        this._treemap[key].seats.push(sid);
    }, this);
};
/**
 * 내부에 존재하는지 확인, 존재하며 존재하는 값을 리턴
 * @param {string} key 비교할 데이터
 * @param {array} arr 비교할 트리데이터 집합
 * @returns {(false|object)}
 */
function isIn(key, arr) {
    var has = false;
    common.forEach(arr, function(obj) {
        if(obj.title === key) {
            has = obj;
        }
    });
    return has;
}

/**
 * 정렬 조건함수
 * @param {object} a
 * @param {object} b
 * @returns {number}
 */
function sortByTitle(a, b) {
    var at = a.title,
        bt = b.title;
    if (!isNaN(at) && !isNaN(bt)) {
        at = parseInt(at);
        bt = parseInt(bt);
    }
    if (at < bt) {
        return -1;
    } else if (at > bt) {
        return 1;
    } else {
        return 0;
    }
}
/**
 * 트리 데이터 생성
 * 트리 폼에 맞춘 데이터 생성
 * [children: {title: 't1', children: [{title: 't1-1'}] }]
 */
TreeBridge.prototype.makeTreeData = function() {

    this._treemodel = {};

    var keys = common.keys(this._treemap),
        self = this;
    common.forEach(keys, function(key) {
        var before = self._treemodel,
            prefix = [],
            branch = key.split(',');
        branch.unshift(self._treemodel);
        common.reduce(branch, function(val, k) {
            // 존재하지 않을 경우만 새로 생성
            var children = before.children,
                obj,
                has;
            if (!children) {
                children = before.children = [];
            }
            has = isIn(k, children);
            if (!has) {
                /**
                 * value : 실제 패스 값
                 * prefix : 이전데이터
                 * @type {{parent: ({}|*), label: *, value: string, prefix: string}}
                 */
                obj = { parent : before, title : k, prefix: prefix.join() };
                children.push(obj);
            } else {
                obj = has;
            }
            before = obj;
            prefix.push(k);
            // 타이틀에 따른 정렬
            children.sort(sortByTitle);
            return before;
        });
        prefix = [];
    });
};

/**
 * 트리데이터 갱신
 */
TreeBridge.prototype.updateTreeData = function() {
    this._tree.model.nodes.childNodes = [];
    this._tree.model.setData(this._treemodel.children);
    this._tree.view.action('refresh', this._tree.getModelData());
};


/**
 * 트리 노드에 자동으로 붙는 레이블을 설정한다.
 * @param {Array} labels
 */
TreeBridge.prototype.setLabel = function(labels) {
    this._tree.setDepthLabels(labels);
};

/**
 * 트리맵을 갱신한다.
 *
 * @param {HashMap} data 갱신(추가)할 데이터 값
 */
TreeBridge.prototype.replaceTreeMap = function(data) {
    this.insertTreeMap(data);
    this.makeTreeData();
};
/**
 * 변경된 데이터를 비교하여 생성될 노드와 제거될 노드를 판단
 */
TreeBridge.prototype.notify = function() {
    if (!this._tree) {
        this._makeTree();
    }
    this.updateTreeData();
};

module.exports = new TreeBridge();
