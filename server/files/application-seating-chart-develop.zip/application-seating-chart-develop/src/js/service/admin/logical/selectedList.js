/**
 * @fileoverview 선택된 좌석의 정보를 그린다.
 * @author FE개발팀
 */

'use strict';

var LogicalIB = require('./logicalIb');

var util = ne.util;

var UIController = ne.tkl.UIController;

/**
 * 선택좌석 정보영역 그리드
 * @constructor
 */
var SelectedList = UIController.extend({
    init: function($el, options) {

        UIController.call(this, options);
        this.setRootElement($el);
        // 선택된 등급이나 할당처가 변경될때 리스트 갱신을 위한 Listen
        this.listen(LogicalIB.EVENT.UPDATED_SEAT_GRADE, this._refresh, this);
        this.listen(LogicalIB.EVENT.UPDATED_SELLING_TYPE, this._refresh, this);
        // todo 선택시 호출된 지정/비지정석 데이터 값을 출력한다.
        this.listen(LogicalIB.EVENT.MAP_SELECTED_SEAT, this._refresh, this);
        this.listen(LogicalIB.EVENT.MAP_DESELECT_ALL_SEAT, this._refreshByDeselectAll, this);
        this.listen(LogicalIB.EVENT.MAP_DESELECT_SEAT, this._refreshByDeselect, this);

        this.attachEvents();
        this._makeGrid();
    },
    /** @lends SelectedList */
    static: {
        /**
         * 저장 너비
         * @type {number[]}
         */
        COLUM_WIDTH: [70, 120, 70, 70, 70, 70, 70, 70],
        /**
         * 그리드 헤더 리스트
         * @type {string[]}
         */
        COLUM_LIST: ['구분', '좌석번호', '좌석등급', '할당처', /*'우선순위',*/ '할당매수', '판매매수', '잔여매수']
    },
    events: {
        'click .btn_detail': 'onClickViewDetail'
    },
    /**
     * 그리드를 만들거나, 업데이트 한다.
     * @param {object} data
     * @private
     */
    _refresh: function(data) {
        var seats = data.selectInfo,
            fresh = this._extractFreshData(seats),
            isPart = ne.util.isNotEmpty(fresh);

        if(isPart) {
            seats = fresh;
            this.orgData = seats.concat(this.orgData);
        } else {
            this.orgData = seats;
        }

        this._makeSelectedGridData(seats);
        this._updateGrid(isPart);

    },
    /**
     * 그리드에 사용될 데이터를 가공한다.
     * @param {(Array|Object)} seats 가공전 데이터
     * @private
     */
    _makeSelectedGridData: function(seats) {

        var item;

        this.gridSeatData = [];
        // 갱신할 데이터를 새로 만든다
        ne.util.forEach(seats, function(el) {
            if(!util.isObject(el)) {
                return;
            }
            item = this._getItemArray(el);
            item.sid = String(el.sid);

            this.gridSeatData.push(item.reverse());
        }, this);

    },
    /**
     * 아이템 포맷에 맞춰 데이터를 돌려준다.
     * @param {object} item
     * @returns {*[]}
     * @private
     */
    _getItemArray: function(item) {
        return [
            item.type,
            item.mapInfo || '-',
            item.grade || '-',
            item.dealer || '-',
            item.ticket || '-',
            item.sold || '-',
            item.available || '-'
        ];
    },
    /**
     * 기존에 존재하지 않은 데이터를 뽑아낸다.
     * @param {{Array|Object)} data 선택좌석 데이터
     * @return  Array
     * @private
     */
    _extractFreshData: function(data) {
        var orgData = this.orgData,
            isExist;

        // 존재하는 데이터가 아닐경우만 필터링
        if(!orgData) {
            return [];
        }
        return ne.util.filter(data, function(el) {
            isExist = true;
            ne.util.forEach(orgData, function(inner) {
                if(el.sid === inner.sid) {
                    isExist = false;
                }
            });
            return isExist;
        });
    },
    /**
     * 선택해제된 좌석 정보를 그리드에서 제거한다.
     * @param {object} data 선택해제 된 좌석정보
     * @private
     */
    _refreshByDeselect: function(data) {
        // data.r, data.n 을 체크하여 this.gridSeatData에 있는 값에서 해당값을 뺀다.
        var rS = data.r,
            nS = data.n,
            isExfire,
            item,
            orgData = this.orgData,
            tempData = [];

        if (util.isEmpty(rS) && util.isEmpty(nS)) {
            return;
        }

        this.gridSeatData = [];
        // gridSeatData를 채움
        ne.util.forEach(orgData, function(el) {
            isExfire = false;
            util.forEach(nS, function(seat) {

                if (String(seat.sid) === String(el.sid)) {
                    isExfire = true;
                }

            }, this);
            util.forEach(rS, function(seat) {

                if (String(seat.sid) === String(el.sid)) {
                    isExfire = true;
                }

            }, this);
            if(!isExfire) {
                tempData.push(el);
                item = this._getItemArray(el);
                item.sid = String(el.sid);
                this.gridSeatData.push(item.reverse());
            }

        }, this);
        this.orgData = tempData;
        this._updateGrid();

    },
    /**
     * 전체해제
     * @private
     */
    _refreshByDeselectAll: function() {
        this.gridSeatData = [];
        this._updateGrid();
        this.orgData = [];
    },
    /**
     * 그리드 생성
     * @parivate
     */
    _makeGrid: function() {

        this._grid = new ne.component.SimpleGrid({
            $el: this.$el.find('.simple_grid'),
            rowHeight: 25,    //line 당 pixel
            displayCount: 20,  //영역에 보여줄 line 갯수
            headerHeight: 27,
            scrollX: true,
            scrollY: true,
            keyEventBubble: false,  //key 입력시 이벤트 버블링 할지 여부
            color: {
                th: '#f5f5f5',
                td: '#FFFFFF',
                selection: 'blue'
            },
            useSelection: false,
            useColumnResize: true,
            hasHeader: true,
            border: 0,
            height: 125,
            columnModelList: this._makeGridColumModelList()
        });

    },
    /**
     * 그리드 칼럼 생성
     * @param {array} labels 그리드 헤더 배열
     * @returns {Array}
     * @private
     */
    _makeGridColumModelList: function() {
        var cmodel = [],
            len = SelectedList.COLUM_LIST.length - 1;

        util.forEach(SelectedList.COLUM_LIST, function(label, idx) {

            cmodel.push({
                columnName:len - idx,
                title:label,
                width: SelectedList.COLUM_WIDTH[idx],
                align: 'center',
                formatter: function(value) {
                    return '<span title="value">' + value + '</span>';
                }
            });

        });
        return cmodel;
    },
    /**
     * 그리드 업데이트
     * @param {boolean} isPart 부분적인 추가여부
     * @prviate
     */
    _updateGrid: function(isPart) {
        var seats = this.gridSeatData;

        if(util.isEmpty(seats) || !util.isExisty(seats)) {
            if(this._grid) {
                this._grid.clear();
            }
        } else {
            if(isPart) {
                this._grid.prepend(seats);
            } else {
                this._grid.setList(seats);
            }
        }
    },
    /**
     * 자세히보기 버튼 이벤트 핸들러
     */
    onClickViewDetail: function() {
        this.emit(LogicalIB.EVENT.SHOW_SELECTED_LIST);
    }
});

module.exports = SelectedList;
