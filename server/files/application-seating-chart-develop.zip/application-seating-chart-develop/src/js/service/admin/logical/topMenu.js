/**
 * @fileoverview 드로잉 영역 상단 메뉴 UI
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */


'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    InteractBroker = tkl.InteractBroker;

var TopMenuUI = UIController.extend({
    rootElement: $('#top_menu'),

    init: function(options) {
        UIController.call(this);

        this.zoomStatus = this.$el.find('#zoom_status');

        this.attachEvents();
        options.IB.listen(InteractBroker.EVENT.ZOOM, ne.util.bind(this._onZoomChanged, this));
        this._onZoomChanged(options.zoom);
    },

    events: {
        'click .change_zoom': '_onClickZoom',
        'click #deselect_all': '_deselectAllSeats'
    },

    _onClickZoom: function(e) {
        var id = $(e.target).attr('id');
        e.preventDefault();

        if (id === 'reset_zoom') {
            this.emit(InteractBroker.EVENT.ZOOM_RESET);
        }

        if (id === 'zoom_in') {
            this.emit(InteractBroker.EVENT.ZOOM_IN);
        }

        if (id === 'zoom_out') {
            this.emit(InteractBroker.EVENT.ZOOM_OUT);
        }
    },

    _deselectAllSeats: function() {
        this.emit(InteractBroker.EVENT.MAP_WORK_DESELECT_ALL_SEAT, true);
    },

    _onZoomChanged: function(newZoom) {
        var diff = newZoom - 3,
            percent = 100 * Math.pow(diff < 0 ? 0.5 : 2, Math.abs(diff));

        this.zoomStatus.text(percent + '%');
    }
});

module.exports = TopMenuUI;
