/**
 * @fileoverview 논리도면 드로잉 영역
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var LogicalIB = require('./logicalIb');

var common = ne.util,
    simplemap = ne.component.SimpleMap,
    TileLayer = simplemap.TileLayer,
    NavigatorControl = simplemap.NavigatorControl;

var tkl = ne.tkl,
    Settings = tkl.Settings,
    SeatingChart = tkl.SeatingChart,
    ZoomReactor = tkl.ZoomReactor,
    RLayer = tkl.RLayer,
    SelectionControl = tkl.SelectionControl,
    SeatInfoTooltipControl = tkl.SeatInfoTooltipControl;

/**
 * 논리도면 클래스
 * @constructor
 * @extends {SeatingChart}
 * @mixes {CustomEvents}
 * @param {HTMLElement} el
 * @param {object} options
 */
function Logical(el, options) {
    var useArea = this.useArea = common.isExisty(common.pick(ne.tkl.data, 'areaData')) && (ne.tkl.data.areaData.length > 0),
        seatBrushMinZoomRange = useArea ? 4 : 3;

    ZoomReactor.CONFIG = common.extend({
        Area: [0, 3],
        Seat: [seatBrushMinZoomRange, 7],
        NSeat: [seatBrushMinZoomRange, 7],
        SelectSeat: [seatBrushMinZoomRange, 7],
        Grade: [seatBrushMinZoomRange, 7],
        SellingType: [seatBrushMinZoomRange + 1, 7],
        Text: [7]
    }, options.toggleBrush);

    this.areaRange = ZoomReactor.CONFIG.Area;

    Settings.setGradeCode(options.gradeCode);
    Settings.setSellingTypeCode(options.sellingTypeCode);
    Settings.setGlobalConfigure({
        isClosedEvent: !!options.closedEvent,
        isReservationSystem: !!options.reservationSystem,
        isSellerSystem: !!options.sellerSystem
    });
    Settings.setUseRSeatPathCache(true);

    SeatingChart.call(this, el, options);

    if (common.isExisty(common.pick(options, 'tile', 'altTiles')) && common.isObject(options.tile.altTiles)) {
        options.tile.altTiles = [options.tile.altTiles];
    }

    if (common.isExisty(common.pick(options, 'navigator', 'altImage')) && common.isObject(options.navigator.altImage)) {
        options.navigator.altImage = [options.navigator.altImage];
    }

    this.addLayer(new TileLayer(options.tile));
    this.addLayer(new RLayer(options));
    this.addControl(new NavigatorControl('navigator', options.navigator));
    this.addControl(new SelectionControl());
    this.addControl(new SeatInfoTooltipControl());



    this.refreshArea();

    this.setController();

    // IB 설정
    this._setIB();
    this._setIBEvents();
    this.setEvents();

    /**
     * 지정석과 비지정석을 동시 선택할 수 없는 상태
     * @type {boolean}
     * @private
     */
    this._cantSelectOneMoreType = false;

    // TODO: 우측 상단 등급별 잔여좌석 정보 option으로 받아 처리해야 함

    this.render();
}

common.inherit(Logical, SeatingChart);

/**********
 * static props
 **********/



/**********
 * override methods
 **********/

Logical.prototype.setEvents = function() {
    SeatingChart.prototype.setEvents.call(this);
    this.on('beforeSelectSeat', this._onBeforeSelectSeat, this);
};

Logical.prototype._setIB = function() {
    this.IB = new LogicalIB();
    this.IB.set('venueID', this.options.venueID);
    this.IB.set('productID', this.options.productId);
    this.IB.set('selectCtrl', this.selectSeatController);
    this.IB.set('nSeatCtrl', this.nSeatController);
};

Logical.prototype._setIBEvents = function() {
    SeatingChart.prototype._setIBEvents.call(this);
    this.IB.listen(LogicalIB.EVENT.MAP_TOGGLE_SELECT_MODE, this._onToggleSelectMode, this);
    this.IB.listen(LogicalIB.EVENT.CHECKED_IMPERFECTION_SEATS, this.checkedImperfectionSeats, this);
    this.IB.listen(LogicalIB.EVENT.UPDATE_SELECTED_SEATSLIST, this.updateSelectedSeatList, this);
    this.IB.listen(LogicalIB.EVENT.WORK_COMPLETED, function() { this.fire('workCompleted'); }, this);
};

/**********
 * prototype
 **********/

Logical.prototype.ERROR = {
    E01: '판매 할당처에서는\n좌석과 비지정석을 함께 선택할 수 없습니다',
    E02: '판매 할당처에서는\n비지정석을 중복 선택할 수 없습니다'
};

/**********
 * private
 **********/

/**
 * hashmap 에서 판매완료된 좌석을 제외한다
 * @param {Array} seats
 * @private
 */
Logical.prototype._spliceSoldoutSeats = function (seats) {
    var result = [];

    common.forEachArray(seats, function (seat) {
        if ('soldout' in seat && !seat.soldout) {
            result.push(seat);
        }
    });

    return result;
};

/**********
 * public methods
 **********/

/**
 * 불충족 조건 체크후, 불충족 갯수 및 리스트(최대 50개)를 받아온다.
 * @param {object} obj api결과값
 */
Logical.prototype.checkedImperfectionSeats = function(obj) {
    this.IB.set('imperfection', obj.result);
};

/**
 * 선택좌석 정보영역을 위한 선택좌석 정보를 IB에 저장한다
 */
Logical.prototype.updateSelectedSeatList = function() {
    this.IB.set('selectedList', this.selectSeatController.seats);
};

/**********
 * event handler
 **********/

Logical.prototype._onToggleSelectMode = function(onOff) {
    this.deselectAllSeats(true);
    this._cantSelectOneMoreType = onOff;
};

/**
 * 좌석 선택 로직 구현
 * @param {object} e
 * @returns {boolean}
 * @private
 */
Logical.prototype._onBeforeSelectSeat = function(e) {
    var selectCtrl = this.selectSeatController,
        rSeatCount,
        nSeatCount;

    if (this.disabled) {
        return false;
    }

    e.r = this._spliceSoldoutSeats(e.r);
    e.n = this._spliceSoldoutSeats(e.n);

    rSeatCount = selectCtrl.rSeatCount + e.r.length;
    nSeatCount = selectCtrl.nSeatCount + e.n.length;

    if (e.r.length + e.n.length === 0) {
        return false;
    }

    if (this._cantSelectOneMoreType) {
        // (비)지정석 동시 선택 불가 모드
        if (nSeatCount > 1) {
            alert(this.ERROR.E02);
            return false;
        }

        if (rSeatCount && nSeatCount) {
            alert(this.ERROR.E01);
            return false;
        }

    }

};

module.exports = Logical;
