/**
 * @fileoverview 물리도면의 좌석 번호 입력을 지원한다.
 * @author FE개발팀 이제인 jein.yi@nhnent.com
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var PhysicalIB = require('./physicalIb');

/**
 * @type {(TreeBridge|exports)}
 */
var TreeBridge = require('./treebridge'); // jshint ignore:line

var common = ne.util;
var tkl = ne.tkl;
var UIController = tkl.UIController;

/**
 * 좌석에 번호를 입력한다.
 * @constructor
 */
var NumberUI = UIController.extend({
    init: function($el, options) {
        UIController.call(this, options);

        this.setRootElement($el);

        this.attachEvents();

        this.listen(PhysicalIB.EVENT.UPDATED_SEAT, this._replaceTree, this);

        this.listen(PhysicalIB.EVENT.DELETED_SEAT, this._replaceTree, this);

        this._processInitializeData(ne.tkl.data.rseats);

        TreeBridge.setTreeSelectedCallback(common.bind(this._sendSelectedSeats, this));
        TreeBridge.setTreeRenamedCallback(common.bind(this._sendRenamedSeats, this));
    },
    /** @lends NumberUI */
    events: {
        'click #input_number': '_onClickInputNumber'
    },
    /**
     * 데이터를 받아 트리를 갱신한다.
     * @param {Array} data 좌석데이터
     * @private
     */
    _replaceTree: function(data) {
        this.emit(PhysicalIB.EVENT.SET_ALLSEATS);
        data = this.IB.get('allSeats');

        var gridSeats = this.IB.cloneSeatHashMap(data[0]),
            selectSeats = this.IB.cloneSeatHashMap(data[1]);

        gridSeats.merge(selectSeats);

        TreeBridge.replaceTreeMap(gridSeats);
        TreeBridge.notify();
    },

    /**
     * 페이지 로딩 시 받은 지정석 전체 데이터를 트리가 사용할 수 있는 구조로 변경한다
     * @param {Array[]} rseats 전체 지정석 정보
     */
    _processInitializeData: function(rseats) {
        var i = 0,
            len = rseats.length,
            seat,
            result = new common.HashMap();

        if (len) {
            for (; i < len; i++) {
                seat = rseats[i];

                result.set(seat[0], {
                    sid: seat[0],
                    mapInfo: seat[1]
                });
            }
        }

        TreeBridge.replaceTreeMap(result);
        TreeBridge.notify();
    },

    /**
     * 선택된 엘리먼트를 데이터로 넘긴다.
     * @param {object} data
     * @private
     */
    _sendSelectedSeats: function(data) {
        this.emit(PhysicalIB.EVENT.SELECT_TREE, data);
    },
    /**
     * 이름이 변경된 엘리먼트를 데이터로 넘긴다.
     * @param {object} data
     * @private
     */
    _sendRenamedSeats: function(data) {
        this.emit(PhysicalIB.EVENT.RENAME_TREE, data);
    },
    /**
     * handler
     * @private
     */
    _onClickInputNumber: function() {
        this.emit(PhysicalIB.EVENT.SET_SEAT_NUMBER);
    }
});

module.exports = NumberUI;
