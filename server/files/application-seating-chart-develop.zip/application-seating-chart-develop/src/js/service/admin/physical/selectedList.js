/**
 * @fileoverview 물리도면 선택 좌석의 정보를 그리드로 보여준다.
 * @author FE개발팀
 */


'use strict';

var PhysicalIB = require('./physicalIb');

var util = ne.util,
    tkl = ne.tkl,
    UIController = tkl.UIController,
    RSeat = tkl.RSeat;

/**
 * 선택좌석 정보영역 그리드
 * @constructor
 */
var SelectedList = UIController.extend({
    init: function($el, options) {
        UIController.call(this, options);
        this.setRootElement($el);
        this.listen(PhysicalIB.EVENT.UPDATED_SEAT, this._refresh, this);
        this.listen(PhysicalIB.EVENT.MAP_SELECTED_SEAT, this._refresh, this);
        this.listen(PhysicalIB.EVENT.DELETED_SEAT, this._refresh, this);
        this.listen(PhysicalIB.EVENT.MAP_DESELECT_ALL_SEAT, this._refreshByDeselectAll, this);
        this.listen(PhysicalIB.EVENT.MAP_DESELECT_SEAT, this._refreshByDeselect, this);
        this._makeGrid();
    },
    /**
     * 선택된 좌석의 해쉬를 반환한다
     * @returns {*}
     * @private
     */
    _getSelectedSeats: function() {
        this.emit(PhysicalIB.EVENT.UPDATE_SELECTED_SEATSLIST);
        return this.IB.get('selectedList');
    },
    /**
     * 그리드를 업데이트 한다.
     * @param {object} data
     * @private
     */
    _refresh: function(data) {
        var seats = ne.util.isExisty(ne.util.pick(data, 'selectedSeats')) && data.selectedSeats.seats,
            isPart;

        if(!seats) {
            seats = this._getSelectedSeats();
            isPart = false;
        } else {
            isPart = ne.util.isNotEmpty(this.orgData);
        }

        this._makeSelectedGridData(seats);
        this._updateGrid(isPart);

    },
    /**
     * 그리드 좌석 데이터를 가공한다.
     * @param {array} seats
     * @private
     */
    _makeSelectedGridData: function(seats) {
        var self = this,
            item;

        this.gridSeatData = [];

        if (ne.util.isUndefined(this.orgData)) {
            this.orgData = [];
        }

        // 갱신할 데이터를 새로 만든다
        ne.util.forEach(seats, function(seat) {
            if(!seat.mapInfo) {
                return;
            }

            self.orgData.push(seat);

            seat = seat.mapInfo;
            item = this._getItemArray(seat);

            item.sid = seat.sid;

            this.gridSeatData.push(item);
        }, this);
    },
    _getItemArray: function(seat) {

        var item;

        if (!seat.join('')) {
            item = {};
            for (var i = 0; i < seat.length; i++ ) {
                item[i] = seat[i];
            }
            item._colSpanBy = 0;
            item[0] = '미 매핑 좌석';
        } else {
            item = seat;
        }

        return item;
    },
    /**
     * 그리드 생성
     * @private
     */
    _makeGrid: function() {
        var mapcode = RSeat.MAP_CODE.slice(0);
        this._grid = new ne.component.SimpleGrid({
            $el: this.$el,
            rowHeight: 25,    //line 당 pixel
            displayCount: 20,  //영역에 보여줄 line 갯수
            headerHeight: 30,
            defaultColumnWidth: 55,
            scrollX: true,
            scrollY: true,
            keyEventBubble: false,  //key 입력시 이벤트 버블링 할지 여부
            color: {
                th: '#f5f5f5',
                td: '#FFFFFF',
                selection: 'blue'
            },
            useSelection: false,
            useColumnResize: true,
            hasHeader: true,
            border: 0,
            height: 178,
            columnModelList: this._makeGridColumModelList(mapcode)
        });

    },
    /**
     * 그리드 칼럼 생성
     * @param {array} labels 그리드 헤더 배열
     * @returns {Array}
     * @private
     */
    _makeGridColumModelList: function(labels) {
        var cmodel = [],
            len = labels.length - 1;

        labels.reverse();

        util.forEach(labels, function(label, idx) {
            cmodel.push(
            {
                columnName:len - idx,
                title:label,
                width: 45,
                align: 'center',
                formatter: function(value) {
                    value = value || '-';
                    return '<span title="' + value + '">' + value + '</span>';
                }
            });
        });
        return cmodel;
    },
    /**
     * 선택해제된 좌석 정보를 그리드에서 제거한다.
     * @param {object} data 선택해제 된 좌석정보
     * @private
     */
    _refreshByDeselect: function(data) {
        // data.r, data.n 을 체크하여 this.gridSeatData에 있는 값에서 해당값을 뺀다.
        var rS = data.r,
            nS = data.n,
            isExfire,
            item,
            orgData = this.orgData,
            tempData = [];

        if (util.isEmpty(rS) && util.isEmpty(nS)) {
            return;
        }

        this.gridSeatData = [];
        ne.util.forEach(orgData, function(el) {
            isExfire = false;
            util.forEach(rS, function(seat) {
                if (String(seat.sid) === String(el.sid)) {
                    isExfire = true;
                }
            });

            if(!isExfire) {
                tempData.push(el);
                item = this._getItemArray(el.mapInfo);
                this.gridSeatData.push(item);
            }

        }, this);
        this.orgData = tempData;
        this._updateGrid();

    },
    /**
     * 전체해제
     * @private
     */
    _refreshByDeselectAll: function() {

        this.gridSeatData = [];
        this._updateGrid();
        this.orgData = [];

    },
    /**
     * 그리드 업데이트
     * @param {boolean} isPart 부분적인 추가여부
     * @prviate
     */
    _updateGrid: function(isPart) {
        var seats = this.gridSeatData;

        if(util.isEmpty(seats) || !util.isExisty(seats)) {
            if(this._grid) {
                this._grid.clear();
            }
        } else {
            if(isPart) {
                this._grid.prepend(seats);
            } else {
                this._grid.setList(seats);
            }
        }
    }
});

module.exports = SelectedList;
