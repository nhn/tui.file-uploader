/**
 * @fileoverview 논리도면에서 지정석/비지정석에 등급, 할당처를 일괄 적용하는 기능을 가진 모듈
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */


'use strict';

var util = ne.util;

/**
 * 지정석 또는 비지정석 배열을 순회하며 할당처를 매핑한다
 * 지정석의 경우 할당매수 옵션은 사용하지 않는다.
 * @param {Array.<Seat>} seats
 * @param {string} code 할당처코드
 * @param {number} [value] 할당매수
 */
function applyDealership(seats, code, value) {
    util.forEachArray(seats, function(seat) {
        if (seat.name === 'RSeat') {
            seat.sellingType = code;
        } else {
            seat.setTicket(code, value);
        }
    });
}

/**
 * 지정석 또는 비지정석의 등급을 매핑한다
 * @param {Array.<Seat>} seats
 * @param {string} code 등급 코드
 */
function applyGrade(seats, code) {
    util.forEachArray(seats, function(seat) {
        seat.grade = code;
    });
}

module.exports = {
    applyDealership: applyDealership,
    applyGrade: applyGrade
};
