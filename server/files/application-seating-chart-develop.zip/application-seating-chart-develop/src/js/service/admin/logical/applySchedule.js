/**
 * @fileoverview 선택영역 전회차 저장, 선택영역 선택회차 저장 UI부분
 */

'use strict';

var LogicalIB = require('./logicalIb');

var UIController = ne.tkl.UIController;

var ApplyScheduleUI = UIController.extend({
    rootElement: $('.apply_schedule'),

    /**
     * @constructs ApplyScheduleUI
     * @extends UIController
     * @param {object} options
     * @param {object} options.IB
     */
    init: function(options) {
        UIController.call(this, options);
        this.attachEvents();
    },

    events: {
        'click .btn_apply_schedule': '_onClickApply',
        'click .btn_apply_all_schedule': '_onClickApplyAll'
    },

    _onClickApply: function(e) {
        e.preventDefault();

        var IB = this.IB;

        if (!this._checkSelection()) {
            return;
        }

        var selectCtrl = IB.get('selectCtrl'),
            seats = this.IB.getSplitedSIDBySeatType(selectCtrl.seats),
            url = '/product/popup/logical-plan/selectCopySchedule.nhn?logicalPlanId=' + IB.get('venueID'),
            param = {
                reservedScheduleId: '',
                searchSeat: seats.r,
                searchZone: seats.n
            };

        ne.util.popup.openPopup(url, {
            popupName: 'applySchedule',
            popupOptionStr: 'top=50,left=50,width=950,height=875',
            method: 'POST',
            param: param
        });
    },

    _onClickApplyAll: function(e) {
        e.preventDefault();
        if (!this._checkSelection()) {
            return;
        }

        if (window.confirm('주의! 설정된 정보가 전 회차에 적용됩니다. 계속 진행하시겠습니까?')) {
            this.emit(LogicalIB.EVENT.APPLY_ALL_SCHEDULE);
        }
    },

    _checkSelection: function() {
        var selectCtrl = this.IB.get('selectCtrl');
        if (selectCtrl.nSeatCount === 0 && selectCtrl.rSeatCount === 0) {
            alert('선택된 좌석이 없습니다');
            return false;
        }
        return true;
    }
});

module.exports = ApplyScheduleUI;
