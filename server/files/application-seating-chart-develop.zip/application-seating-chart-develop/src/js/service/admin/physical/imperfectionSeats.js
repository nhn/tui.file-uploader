/**
 * @fileoverview 물리도면의 조건 불충족 좌석 리스트를 보여주고, 수정가능 탭으로 이동을 지원한다.
 * @author FE개발팀
 */

'use strict';

var PhysicalIB = require('./physicalIb'),
    TabUI = require('./tab');

var common = ne.util;
var UIController = ne.tkl.UIController;

var ImperfectionSeats = UIController.extend({
    init: function($el, options) {
        UIController.call(this, options);
        this.setRootElement($el);
        this.attachEvents();
        /**
         * @param {object} data
         *  {
         *     "result" : false,
         *     "count": "3500",    // 전체 실패 갯수
         *     "failList" : [{    // 실패 좌석 리스트
         *       "sid": 350,
         *       "number": "1층 A구역 1열",
         *       "reason" : {
         *         "CODE1": "동일번호 존재",
         *         "CODE2": "좌석번호 일부부여",
         *         ...
         *       }
         *     }, {}, ..., {}]
         *   }
         */
        this.tabUI = options.tab;
        this.listen(PhysicalIB.EVENT.CHECKED_IMPERFECTION_SEATS, function(data, silent) {
            if (!data.result) {
                if (!silent) {
                    alert('조건불충족 좌석이 존재합니다.');
                }
                if (this.tabUI.current !== TabUI.TABINDEX.IMPERFECTION) {
                    this.tabUI.togglePanel(TabUI.TABINDEX.IMPERFECTION);
                }
            }
            this.updateTotal(data.count);
            this.updateGrid(data.failList);
        }, this);
    },
    events: {
        'click #check_selectedseats': 'checkSelectedSeats',
        'click #check_allseats': 'checkAllSeats',
        'click a': 'moveToResolveTab'
    },
    /**
     * 불충족 좌석 갯수갱신
     * @param {number} count 불충족 좌석 갯수
     */
    updateTotal: function(count) {
        this.$el.find('h5 em').html(count);
    },
    /**
     * 불충족 좌석 리스트 갱신
     * @param {Array} failList 불충족 좌석 리스트(최대 50개)
     */
    updateGrid: function(failList) {
        var html = common.map(failList, function(el) {
            return '<tr>' +
                    '<td>' + (el.number || '-') + '</td>' +
                    '<td sid="' + el.sid + '">' + this._getReason(el.reason) + '</td>' +
                '</tr>';
        }, this);
        this.$el.find('tbody').html(html);
    },
    /**
     * 불충족 좌석 리스트의 불충족이유 부분을 생성해서리턴한다.
     * @param {Objects} reasons
     * @returns {string}
     * @private
     */
    _getReason: function(reasons) {
        var reasonText = '';
        common.forEach(reasons, function(el, index) {
            if (el) {
                reasonText += '<a href="#' + index + '" class="err">' + (el + '</a><br />');
            }
        });
        return reasonText;
    },
    /**
     * 선택좌석 불충족 체크
     */
    checkSelectedSeats: function() {
        this.emit(PhysicalIB.EVENT.CHECK_IMPERFECTION_SEATS, { type : 'selected', silent: true });
    },
    /**
     * 전체좌석 불충족 체크
     */
    checkAllSeats: function() {
        this.emit(PhysicalIB.EVENT.CHECK_IMPERFECTION_SEATS, { type : 'all', silent: true });
    },
    /**
     * 탭이동
     */
    moveToResolveTab: function(e) {
        e.preventDefault();
        var sid = $(e.target).parent().attr('sid');
        $(e.target).removeClass('err').addClass('p_color6');
        // 동일번호 존재, 좌석번호 일부부여, 좌석번호 미부여 -> 좌석번호 미지정탭
        // 연석 미지정 -> 연석지정 탭 -> 현재 연석지정이 존재하지 않음
        // todo 연석지정과 번호를 구분할 수 있는방법 확인
        this.tabUI.togglePanel(TabUI.TABINDEX.NUMBER);
        this.IB.emit(PhysicalIB.EVENT.MAP_WORK_DESELECT_ALL_SEAT, true);
        this.IB.emit(PhysicalIB.EVENT.SELECT_RSEAT, [sid], true);
    }
});

module.exports = ImperfectionSeats;
