/**
 * @fileoverview 현재 등급별 좌석갯수를 나타내고, 총 합을 나타낸다.
 * @author FE개발팀
 */

'use strict';

var LogicalIB = require('./logicalIb');

var UIController = ne.tkl.UIController;

/**
 * 현재 등급별 좌석 갯수
 * @constructor
 */
var SeatStatus = UIController.extend({
    init: function($el, options) {

        UIController.call(this, options);
        this.setRootElement($el);
        this.listen(LogicalIB.EVENT.UPDATE_SEATSTATUS, this.updateTable, this);
        this.updateTable({ gradeInfo: ne.tkl.data.gradeInfo });

    },
    /** @lends SeatStatus */
    /**
     * 그리드를 만들거나, 업데이트 한다.
     * @param {object} data
     * @private
     */
    updateTable: function(data) {

        var seatStatus = data.gradeInfo,
            html = '',
            totalSum = 0,
            availSum = 0;

        ne.util.forEach(seatStatus, function(el) {

            html += '<tr>' +
                '<th>' + el.name + '</th>' +
                '<td>' + el.total + '</td>' +
                '<td>' + el.available + '</td>' +
            '</tr>';
            totalSum = totalSum + parseInt(el.total, 10);
            availSum = availSum + parseInt(el.available, 10);

        });

        this.$el.find('tbody').html(html);
        this.$el.find('tfoot').html('<tr>' +
            '<th>합계</th>' +
            '<td>' + totalSum + '</td>' +
            '<td>' + availSum + '</td>' +
        '</tr>');

    }
});

module.exports = SeatStatus;
