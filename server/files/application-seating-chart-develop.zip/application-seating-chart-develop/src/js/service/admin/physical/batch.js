/**
 * @fileoverview 매핑정보 자동배열 모듈
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */


'use strict';

var common = ne.util;
var RSeat = ne.tkl.RSeat;

var numberR = /^\d+$/;

/**********
 * 문자 순회 기능
 **********/

/**
 * 자동배열 기능을 위한 문자 순회 클래스
 * @constructor
 * @exports CharIterator
 * @class
 */
function CharIterator(start, isReverse, increment) {
    this.charsetName = 'ENG';
    this.value = '';
    this.isNumber = true;
    this.isReverse = false;
    this.increment = 1;
    this.cursor = 0;
    this.originValue = null;

    if (arguments.length > 0) {
        this.start.call(this, start, isReverse, increment);
    }
}

/**********
 * static props
 **********/

CharIterator.CHAR_SET = {
    ENG_LOWER: ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
        'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'],
    ENG: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
        'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
    KOR_SUB: ['ㄱ', 'ㄴ', 'ㄷ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅅ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ'],
    KOR: ['가', '나', '다', '라', '마', '바', '사', '아', '자', '차', '카', '타', '파', '하']
};

var CHAR_SET = CharIterator.CHAR_SET;

/**********
 * private methods
 **********/

/**
 * 인자 문자열이 어느 charset 에 해당되는지 이름 반환
 * @param {(string|number)} char
 * @return {(string|undefined)}
 * @private
 */
CharIterator.prototype._getCharSetName = function(char) {
    var charset = CHAR_SET,
        charsetName = '';

    common.forEachOwnProperties(charset, function(charset, key) {
        if (charset.join('').indexOf(char) > -1) {
            charsetName = key;
            return false;
        }
    });

    return charsetName;
};

/**
 * 문자 순회를 시작하도록 세팅한다
 * @param {(string|number)} char 시작 문자열
 * @param {boolean} [isReverse=false] 역순 여부
 * @param {number} [increment=1] 증감 숫자
 */
CharIterator.prototype.start = function(char, isReverse, increment) {
    this.originValue = char;

    this.isReverse = common.isExisty(isReverse) ? isReverse : false;

    this.setIncrement(increment, isReverse);

    var isNumber = this.isNumber = (common.isNumber(char) || numberR.test(char)),
        charsetName = this.charsetName = this._getCharSetName(char);

    if (isNumber) {
        this.value = parseInt(char, 10);
    } else {
        this.value = char;
        this.cursor = CHAR_SET[charsetName].join('').indexOf(char);
    }
};



/**
 * 다음 문자열을 반환한다
 * @returns {(string|number)}
 */
CharIterator.prototype.next = function() {
    var charset,
        cursor,
        nextChar,
        increment = this.increment * (this.isReverse ? -1 : 1);

    if (this.isNumber) {
        this.value += increment;
    } else {
        cursor = this.cursor += increment;
        charset = CHAR_SET[this.charsetName];
        if (charset[cursor]) {
            nextChar = charset[cursor];
        } else {
            throw new Error('CharIterator: 문자가 사용범위를 초과했습니다');
        }

        this.value = nextChar;
    }

    return this.value;
};

/**
 * 현재 순회 방향을 토글하는 메서드
 */
CharIterator.prototype.reverse = function() {
    this.isReverse = !this.isReverse;
};

/**
 * 순회 시 증감되는 값을 설정할 수 있다
 * @param {number} [num=1] 증감 값으로 숫자만 사용가능
 * @param {boolean} [isReverse=true] 역순 순회 여부
 */
CharIterator.prototype.setIncrement = function(num, isReverse) {
    isReverse = common.isExisty(isReverse) ? isReverse : false;

    if (!common.isExisty(num)) {
        this.increment = 1;
        return;
    }

    this.increment = common.isNumber(num) ? num : 1;
    this.isReverse = isReverse;

    return this;
};

/**
 * 초기 설정값으로 시작 문자를 되돌린다
 */
CharIterator.prototype.reset = function() {
    this.value = this.originValue;
    this.start(this.value, this.isReverse, this.increment);
};


/**********
 * 좌석 열, 번 자동배열 기능
 **********/

/**
 * 좌석 열/번호 자동배열 방법
 * @type {{A: number, B: number, C: number, D: number, E: number, F: number, G: number, H: number}}
 */
var METHOD = {
    'A': 1,
    'B': 2,
    'C': 3,
    'D': 4,
    'E': 5,
    'F': 6,
    'G': 7,
    'H': 8
};

/**
 * 좌석 매핑정보 배열 방향
 * @type {{LEFT: number, RIGHT: number}}
 */
var DIRECTION_TO = {
    RIGHT: 1,
    LEFT: 2
};

function asc(a, b) {
    return a - b;
}

/**
 * 좌석 인스턴스 hashMap을 좌표 기준으로 인덱싱 및 정렬하여 반환한다
 * @param {HashMap} seats
 */
function indexSeatsByPosition(seats) {
    var xPos = {},
        yPos = {},
        colsInRows = [],
        rowsInCols = [],
        keys = {},
        map = {};

    seats.each(function(seat) {
        var pos = seat.position,
        posX = parseInt(pos.x, 10),
        posY = parseInt(pos.y, 10),
        key;

        xPos[posX] = true;
        yPos[posY] = true;

        // 좌표 키 기준 인덱싱
        key = posX + ':' + posY;
        if (!keys[key]) {
            keys[key] = seat;
        } else {
            // 같은 좌표 좌석 존재 시 sid가 높은 좌석을 취함
            if (parseInt(seat.sid, 10) > parseInt(keys[key].sid, 10)) {
                keys[key] = seat;
            }
        }
    });

    xPos = common.map(xPos, function(v, x) { return parseInt(x, 10); }).sort(asc);
    yPos = common.map(yPos, function(v, y) { return parseInt(y, 10); }).sort(asc);

    common.forEachArray(yPos, function(y, iY) {
        colsInRows[iY] = [];
        common.forEachArray(xPos, function(x, iX) {
            if (!rowsInCols[iX]) {
                rowsInCols[iX] = [];
            }

            var coordKey = x + ':' + y;
            map[iX + ':' + iY] = keys[coordKey];

            if (keys[coordKey]) {
                colsInRows[iY].push(x);
                rowsInCols[iX].push(y);
            }
        });
    });

    return {
        keys: keys,
        xPos: xPos,
        yPos: yPos,
        colsInRows : colsInRows,
        rowsInCols: rowsInCols,
        coord: map,
        size: [xPos.length, yPos.length]
    };

}

/**
 * 매핑정보 단위 이름으로 배열에서의 순서를 반환한다
 * ex) ['층', '블록', '열', '번호']
 *
 * findMapCodeIndex('열') => 2
 * @param {string} label
 * @returns {number}
 */
function getMapCodeIndex(label) {
    var mapCode = RSeat.MAP_CODE,
        index = -1;

    if (Array.prototype.indexOf) {
        return mapCode.indexOf(label);
    } else {
        common.forEachArray(mapCode, function(code, i) {
            if (code === label) {
                index = i;
                return false;
            }
        });

        return index;
    }
}

/**
 * 매핑정보의 타입을 반환하는 메서드
 * @param {(string|number)} label
 * @returns {string}
 */
function getMapUnit(label) {
    var index;
    label += '';

    if (!numberR.test(label)) {
        index = getMapCodeIndex(label);
    } else {
        index = parseInt(label, 10);
    }

    return RSeat.MAP_UNIT[index];
}

/**
 * 배열방법에 따른 배열 방향을 반환한다
 * @param {MAPPING_METHOD} method
 * @returns {number}
 */
function getDirection(method) {
    if ([METHOD.A, METHOD.D, METHOD.E, METHOD.H].join('').indexOf(method) > -1) {
        return DIRECTION_TO.RIGHT;
    } else {
        return DIRECTION_TO.LEFT;
    }
}

/**
 * 인덱싱 정보와 배치 방법을 받아 자동배열 매핑을 시작할 첫 좌석을 반환한다
 * @param {object} indexData
 * @param {MAPPING_METHOD} method
 * @returns {*}
 */
function getStartSeat(indexData, method) {
    var firstRow = indexData.yPos[0],
        firstCols = indexData.colsInRows[0],
        colLen = firstCols.length,
        direction = getDirection(method);

    if (direction === DIRECTION_TO.RIGHT) {
        return indexData.keys[firstCols[0] + ':' + firstRow];
    } else {
        return indexData.keys[firstCols[colLen - 1] + ':' + firstRow];
    }
}

function getCoord(iterX, iterY) {
    return iterX.value + ':' + iterY.value;
}

/**
 * 좌석을 좌/우 방향별로 순회하며 반복자를 실행함
 * @param {object} index
 * @param {boolean} toLeft
 * @param {boolean} revertXY
 * @param {function} iteratee
 * @param {function} [onRowChanged]
 */
function iterateSeats(index, toLeft, revertXY, iteratee, onRowChanged) {
    var coord = index.coord,
        colsInRows = index.colsInRows,
        rowsInCols = index.rowsInCols,
        iterX = new CharIterator(toLeft ? (index.size[0] - 1) : 0, toLeft),
        iterY = new CharIterator(0),
        coordKey = getCoord(iterX, iterY),
        isExist = common.isExisty,
        useRowChange = common.isFunction(onRowChanged),
        itemCountInRow = 0;

    do {

        if (useRowChange) {
            if (iterY.isNumber) {
                itemCountInRow = (revertXY ? rowsInCols : colsInRows)[parseInt(iterY.value, 10)].length;
            }
            onRowChanged(iterY.value, itemCountInRow);
        }

        do {
            if (isExist(coord[coordKey])) {
                iteratee.call(coord[coordKey], coordKey);
            }

            if (revertXY) {
                iterY.next();
            } else {
                iterX.next();
            }

            coordKey = getCoord(iterX, iterY);
        } while (coordKey in coord);

        if (revertXY) {
            iterY.reset();
            iterX.next();
        } else {
            iterX.reset();
            iterY.next();
        }

        coordKey = getCoord(iterX, iterY);
    } while (coordKey in coord);

}

/**
 * 좌석 매핑 데이터를 세팅한다
 * @param {HashMap} seats rSeat 인스턴스 hashMap
 * @param {MAPPING_METHOD} method 배열 방법
 * @param {string} mapLabel 업데이트 할 매핑정보 이름
 * @param {(number|string)} char 시작 문자
 * @param {boolean} [notUseIncrement=false] 열 자동배열 여부
 */
function setMappingData(seats, method, mapLabel, char, notUseIncrement) {
    var which = 0,
        unit = 'GENERAL',
        index,
        toLeft,
        iterChar,
        iterRow,
        iterReverse = null,
        revertXY = false;

    if (!seats.length) {
        return;
    }

    which = getMapCodeIndex(mapLabel);

    if (which < 0) {
        return;
    }

    /**********
     * 자동배열 시작
     **********/

    unit = getMapUnit(which);

    if (notUseIncrement) {
        unit = 'GENERAL';
    }

    index = indexSeatsByPosition(seats);
    toLeft = (getDirection(method) === DIRECTION_TO.LEFT);
    iterChar = (unit === 'GENERAL') ? { value: char } : new CharIterator(char);
    iterRow = (unit === 'GENERAL') ? { value: char } : new CharIterator(char);

    if (unit === 'NUMBER') {
        if (!iterChar.isNumber) {
            throw new Error('batch#setMappingData() 번호 자동배열은 숫자만 가능합니다');
        }

        if (method === METHOD.H) {
            toLeft = false;
        }
    }

    revertXY = (method === METHOD.G || method ===  METHOD.H);

    iterateSeats(index, toLeft, revertXY, function() {
        if (unit === 'ROW') {
            this.mapInfo[which] = iterRow.value + '';
        } else if (unit === 'NUMBER') {
            this.mapInfo[which] = (iterReverse ? iterReverse.value : iterChar.value) + '';
            iterChar.next();
            if (iterReverse) {
                iterReverse.next();
            }
        } else {
            this.mapInfo[which] = iterChar.value + '';
        }
    }, function(rowIndex, seatCountInRow) {
        var charValue;

        if (unit === 'ROW') {
            if (rowIndex > 0) {
                iterRow.next();
            }
        } else if (unit === 'NUMBER') {
            if (method === METHOD.C || method === METHOD.D) {
                iterChar.reset();
            }

            if (method === METHOD.E || method === METHOD.F) {
                // 짝수번째 배열은 번호를 뒤집어 배열한다
                if (rowIndex > 0 && rowIndex % 2 !== 0) {
                    charValue = parseInt(iterChar.value, 10);
                    iterReverse = new CharIterator(charValue + (seatCountInRow - 1), true);
                } else {
                    iterReverse = null;
                }
            }
        }
    });
}

module.exports = {
    CharIterator: CharIterator,
    indexSeatsByPosition: indexSeatsByPosition,
    MAPPING_METHOD: METHOD,
    getStartSeat: getStartSeat,
    iterateSeats: iterateSeats,
    setMappingData: setMappingData
};
