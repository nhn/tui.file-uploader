/**
 * @fileoverview 탭 UI 컨트롤러
 * @author minhyeong.kim@nhnent.com
 */

'use strict';

var TabUI = require('../../common/tab'),
    LogicalIB = require('./logicalIb');

var Settings = ne.tkl.Settings;

var LogicalTabUI = TabUI.extend(/** @lends LogicalTabUI */{

    static: /** @lends LogicalTabUI */{
        TABINDEX: {
            GRADE: 0,
            SELLINGTYPE: 1,
            PRIORITY: 2,
            NREASERVED: 3,
            IMPERFECTION: 4
        }
    },

    /**
     * @constructs
     * @extends TabUI
     * @exports LogicalTabUI
     * @class
     * @param {jQuery} $el
     * @param {object} options
     */
    init: function($el, options) {
        TabUI.call(this, $el, options);
        if (Settings.isClosedEvent) {
            this.$el.find('.tab_lst').addClass('tab_lst_4tab');
        }
        if(Settings.isSellerSystem) {
            this.hidePanel();
        }
    },

    /**********
     * public methods
     **********/

    /**
     * 인자 순서의 패널로 토글한다
     * @param {number} index
     */
    togglePanel: function(index) {
        // 판매할당처에서는 지정석과 비지정석을 동시선택 할 수 없고, 비지정석은 한번에 하나만 선택가능
        this.emit(LogicalIB.EVENT.MAP_TOGGLE_SELECT_MODE, index === LogicalTabUI.TABINDEX.SELLINGTYPE);


        if (index === LogicalTabUI.TABINDEX.SELLINGTYPE) {
            this.emit(LogicalIB.EVENT.RESET_SELLINGTAB);
        }

        if (index === LogicalTabUI.TABINDEX.PRIORITY || index === LogicalTabUI.TABINDEX.NREASERVED) {
            alert('준비중입니다');
            return;
        }

        TabUI.prototype.togglePanel.call(this, index);
    },
    /**
     * sellerSystem 일 경우, 탭을 갑춘다.
     */
    hidePanel: function() {
        this.togglePanel(LogicalTabUI.TABINDEX.SELLINGTYPE);
        this.$el.find('.tab_lst').hide();
        this.$el.parent().height(272);
    }
});

module.exports = LogicalTabUI;
