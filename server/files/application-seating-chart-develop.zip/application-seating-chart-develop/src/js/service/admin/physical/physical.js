/**
 * @fileovewview 물리도면 좌석배치도
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var PhysicalIB = require('./physicalIb'),
    batch = require('./batch');

var common = ne.util,
    simplemap = ne.component.SimpleMap,
    domutil = simplemap.domutil,
    TileLayer = simplemap.TileLayer,
    NavigatorControl = simplemap.NavigatorControl;

var tkl = ne.tkl,
    Settings = tkl.Settings,
    SeatingChart = tkl.SeatingChart,
    ZoomReactor = tkl.ZoomReactor,
    RLayer = tkl.RLayer,
    SelectionControl = tkl.SelectionControl,
    SeatInfoTooltipControl = tkl.SeatInfoTooltipControl,
    RSeat = tkl.RSeat,
    SelectSeatController = tkl.SelectSeatController,
    SelectSeatLayer = tkl.SelectSeatLayer;

/**
 * 물리도면 좌석배치도
 * @param {HTMLElement} el
 * @param {Object} options
 * @constructor
 * @extends {SeatingChart}
 * @classdesc
 * 물리도면 좌석배치도 좌석 선택 플로우
 *
 *  - 비 지정석은 선택할 수 없다
 *  - 좌석 선택 시 이전 선택 좌석은 선택해제된다
 *  - shift 키를 누르고 좌석 선택 시 이전 선택 좌석에 누적 선택된다
 *
 *  물리도면 좌석배치도에서는 선택 좌석을 이동할 수 있다
 */
function Physical(el, options) {
    var useArea = this.useArea = common.isExisty(common.pick(ne.tkl.data, 'areaData')) && (ne.tkl.data.areaData.length > 0),
        seatBrushMinZoomRange = useArea ? 4 : 3;

    ZoomReactor.CONFIG = common.extend({
        Area: [0, 3],
        Seat: [seatBrushMinZoomRange, 7],
        NSeat: [seatBrushMinZoomRange, 7],
        SelectSeat: [seatBrushMinZoomRange, 7],
        Grade: [seatBrushMinZoomRange, 7],
        SellingType: [seatBrushMinZoomRange + 1, 7],
        Text: [7]
    }, options.toggleBrush);

    this.areaRange = ZoomReactor.CONFIG.Area;

    SeatingChart.call(this, el, options);

    if (common.isExisty(common.pick(options, 'tile', 'altTiles')) && common.isObject(options.tile.altTiles)) {
        options.tile.altTiles = [options.tile.altTiles];
    }

    if (common.isExisty(options, 'navigator.altImage') && common.isObject(options.navigator.altImage)) {
        options.navigator.altImage = [options.navigator.altImage];
    }

    this.addLayer(new TileLayer(options.tile));
    this.addLayer(new RLayer(options));
    this.addControl(new NavigatorControl('navigator', options.navigator));

    this.addControl(new SelectionControl());
    this.addControl(new SeatInfoTooltipControl());

    this.refreshArea();

    this.setController();

    this._setIB();
    this._setIBEvents();
    this.setEvents();

    /**
     * 좌석배치모드 여부 저장
     * @type {object}
     * @private
     */
    this._isSeating = null;

    /**
     * 좌석 편집 모드 사용 가능 여부
     * @type {boolean}
     * @private
     */
    this.disabled = false;

    Settings.seatDraggable(this);
    Settings.setUseRSeatPathCache(false);

    this.fnKeys.on('shortcut', this._onPhysicalShortCut, this);
    this.setPopupCallback();

    this.render();
}

// 상속
common.inherit(Physical, SeatingChart);

/**********
 * override methods
 **********/

Physical.prototype.setEvents = function() {
    SeatingChart.prototype.setEvents.call(this);
    this.on({
        'beforeSelectSeat': this._onBeforeSelectSeat,
        'beforeSeatInfo': this._onBeforeSeatInfo
    }, this);
};

Physical.prototype._setIB = function() {
    this.IB = new PhysicalIB();
    this.IB.set('venueID', this.options.venueID);
    this.IB.set('selectCtrl', this.selectSeatController);
};

Physical.prototype._setIBEvents = function() {
    SeatingChart.prototype._setIBEvents.call(this);

    this.IB.listen(PhysicalIB.EVENT.ENABLE_SEATING, this.enableSeating, this);
    this.IB.listen(PhysicalIB.EVENT.DISABLE_SEATING, this.disableSeating, this);
    this.IB.listen(PhysicalIB.EVENT.CREATED_SEAT, this._onCreatedSeat, this);
    this.IB.listen(PhysicalIB.EVENT.UPDATED_SEAT, this._onUpdatedSeat, this);
    this.IB.listen(PhysicalIB.EVENT.DELETED_SEAT, this._onDeletedSeat, this);

    this.IB.listen(PhysicalIB.EVENT.SELECT_TREE, this._onSelectTree, this);
    this.IB.listen(PhysicalIB.EVENT.RENAME_TREE, this._onRenameTree, this);

    this.IB.listen(PhysicalIB.EVENT.SET_SEAT_NUMBER, this.setSeatsNumbers, this);

    this.IB.listen(PhysicalIB.EVENT.RENDER_IMMEDIATE_SELECTED, function() {
        this.selectSeatController.update(true);
    }, this);
    this.IB.listen(PhysicalIB.EVENT.ROLLBACK_UPDATE_SEAT, function(originalSeats) {
        this.selectSeatController.replaceAllRSeats(originalSeats);
        this.selectSeatController.update(true);
    }, this);

    this.IB.listen(PhysicalIB.EVENT.UPDATE_SELECTED_SEATSLIST, this.updateSelectedSeatList, this);

    this.IB.listen(PhysicalIB.EVENT.CHECKED_IMPERFECTION_SEATS, this.checkedImperfectionSeats, this);

    this.IB.listen(PhysicalIB.EVENT.SET_ALLSEATS, this.updateAllSeats, this);

    this.IB.listen(PhysicalIB.EVENT.CHANGE_TAB_INDEX, this._onChangeTabIndex, this);

    this.on(Physical.EVENT.MOVE_SEAT, this._onMoveSeat, this);
};

/**********
 * static props
 **********/

Physical.EVENT = {
    MOVE_SEAT: 'moveSeat',
    DELETE_SEAT: 'deleteSeat'
};

/**
 * @readonly
 * @enum {number}
 */
Physical.PLACE_TYPE = {
    SINGLE: 1,  // 낱개 배치
    GROUP: 2    // 그룹 배치
};

Physical.PLACE_MODE = {
    NORMAL: 1,    // 일반
    LEFT: 2,      // 좌측 사선
    RIGHT: 3      // 우측 사선
};

/**********
 * private methods
 **********/

Physical.prototype._onPhysicalShortCut = function(keyCode, str) {
    if (this.disabled) {
        return;
    }

    var selectCtrl = this.selectSeatController,
        sidList,
        diffX = 0,
        diffY = 0,
        currentTabIndex = this.IB.get('currentTabIndex');

    if (str !== 'ESC' && (currentTabIndex !== 0 && currentTabIndex !== 4)) {
        return;
    }

    switch (str) {
        case 'DEL':
            sidList = selectCtrl.seats.keys();

            if (sidList.length && this.invoke('beforeDeleteSeat', sidList)) {
                this.IB.emit(Physical.EVENT.DELETE_SEAT, sidList);
            }
            break;
        case 'ESC':
            if (this._isSeating) {
                this.disableSeating();
            }
            break;
        case 'LEFT': diffX = -1; break;
        case 'UP': diffY = -1; break;
        case 'RIGHT': diffX = +1; break;
        case 'DOWN': diffY = +1; break;
    }

    if (diffX !== 0 || diffY !== 0) {
        this.moveSelectedSeatBy(diffX, diffY);
    }
};

/**
 * 좌석 추가 메서드
 * @param {Point} point
 * @param {object} [place] 그룹 배치 관련 데이터 (행, 열 etc...)
 * @private
 */
Physical.prototype._placeSeats = function(point, place) {
    var half = RSeat.SEAT_SIZE / 2;

    point.x += half;
    point.y += half;

    this.IB.emit(PhysicalIB.EVENT.CREATE_SEAT, point.x, point.y, place);
};

/**********
 * public methods
 **********/

/**
 * 팝업과 데이터를 주고받기 위한 콜백을 세팅한다
 */
Physical.prototype.setPopupCallback = function() {
    var self = this;

    if (!common.isExisty(common.pick(window.ne, 'tkl'))) {
        window.ne.tkl = {};
    }

    if (!common.isExisty(common.pick(window.ne, 'tkl', 'calback'))) {
        window.ne.tkl.callback = {};
    }

    /**
     * 좌석정보 입력 팝업 콜백
     */
    window.ne.tkl.callback.allocSeatMark = function(data) {
        var str = window.decodeURIComponent(data.str),
            startNumber = window.decodeURIComponent(data.startNumber),
            notUseIncrement = data.mappingType === 'BATCH';

        self.updateSeatMappingData(data.mappingMethod, str, startNumber, notUseIncrement);
    };
};

/**
 * 컨테이너에 크로스헤어 아이콘 스타일을 토글한다
 * @param {boolean} isOn
 */
Physical.prototype.togglePlaceCSSClass = function(isOn) {
    domutil[isOn ? 'addClass' : 'removeClass'](this.getContainer(), 'ne-tl-seat-place-mode');
};

/**
 * 좌석 배치 모드를 설정한다
 * @param {Physical.PLACE_TYPE} type
 * @param {object} [data]
 */
Physical.prototype.enableSeating = function(type, data) {
    this.togglePlaceCSSClass(true);

    if (this.hasSelectedSeat()) {
        this.deselectAllSeats(true);
    }

    this._isSeating = {
        isSinglePlaceMode: type === Physical.PLACE_TYPE.SINGLE,
        data: data || null
    };
};

/**
 * 좌석 배치 모드를 해제한다
 */
Physical.prototype.disableSeating = function() {
    this.togglePlaceCSSClass(false);
    this._isSeating = null;
};

/**
 * 좌석 구역 및 번호 지정
 */
Physical.prototype.setSeatsNumbers = function() {
    var selectCtrl = this.selectSeatController;
    if (selectCtrl.seats.length) {
        this.IB.emit(PhysicalIB.EVENT.SET_SEAT_NUMBER_END, { seats : selectCtrl.seats });
    }
};

/**
 * 선택 좌석의 좌표를 인자만큼 이동시키는 메서드
 * @param {number} diffX
 * @param {number} diffY
 */
Physical.prototype.moveSelectedSeatBy = function(diffX, diffY) {
    if (!this.hasSelectedSeat()) {
        return;
    }

    this.IB.emit(PhysicalIB.EVENT.UPDATE_SEAT, SelectSeatController.UPDATE.POSITION, true, diffX, diffY);
    this.selectSeatController.update(true);
};

/**
 * 불충족 조건 체크후, 불충족 갯수 및 리스트(최대 50개)를 받아온다.
 * @param {object} obj api결과값
 */
Physical.prototype.checkedImperfectionSeats = function(obj) {
    this.IB.set('imperfection', obj.result);
};

/**
 * 선택좌석 정보영역을 위한 선택좌석 정보를 IB에 저장한다
 */
Physical.prototype.updateSelectedSeatList = function() {
    var seats = common.map(this.selectSeatController.seats, function(data) {
        return data.mapInfo;
    });
    seats = common.filter(seats, function(data) {
        return data;
    });
    this.IB.set('selectedList', seats);
};

Physical.prototype.updateAllSeats = function() {
    var gridCtrl =  this.gridController,
        selectCtrl = this.selectSeatController,
        allSeats = [].concat(gridCtrl.seats, selectCtrl.seats);

    this.IB.set('allSeats', allSeats);
};

/**********
 * event handlers
 **********/

/**
 * 드로잉 영역 클릭 시 이벤트 핸들러
 *
 * 드로잉 영역 클릭 이벤트가 selectSeat 종류의 이벤트이므로
 *
 * 좌석 배치모드일 때 좌석 배치하는 로직을 이곳에서 정의함.
 *
 * @param {object} e
 * @private
 */
Physical.prototype._onBeforeSelectSeat = function(e) {
    var isSinglePlaceMode;

    if (this.disabled) {
        return false;
    }

    if (this._isSeating) {
        isSinglePlaceMode = this._isSeating.isSinglePlaceMode;

        if (isSinglePlaceMode) {
            this.deselectAllSeats(true);
        } else {
            if (this.hasSelectedSeat()) {
                this.deselectAllSeats(true);
            }
        }

        this._placeSeats(e.range, this._isSeating.data);

        if (!isSinglePlaceMode) {
            this.disableSeating();
        }
    } else if (e.n.length) {
        return false;
    }
};

/**
 * 좌석 등의 모델 인스턴스에 대한 툴팁처리 전 이벤트
 * @param {object[]} models
 * @return {boolean}
 * @private
 */
Physical.prototype._onBeforeSeatInfo = function(models) {
    if (!models.length && !common.isExisty(models[0])) {
        return false;
    }

    var model = models[0];

    if (model.name === 'NSeat' || model.name === 'Area') {
        return false;
    }
};

/**
 * 좌석이 드래그 중 mosueup되었을 때 발생하는 이벤트 핸들러
 * @param {string} type
 * @param {number} diffX X벡터값
 * @param {number} diffY Y벡터값
 * @private
 */
Physical.prototype._onMoveSeat = function(type, diffX, diffY) {
    this.IB.emit(PhysicalIB.EVENT.UPDATE_SEAT, type, false, diffX, diffY);
};

/**********
 * IB event handlers
 **********/

/**
 * 좌석 탭이 클릭되었을 때 선택좌석이 존재할 경우 드래그 기능을 활성화한다
 * @param {number} index 변경된 탭 순서
 * @private
 */
Physical.prototype._onChangeTabIndex = function(index) {
    if (index === 0 && this.hasSelectedSeat()) {
        SelectSeatLayer.DRAGGABLE.init();
    }
};

/**
 * IB를 통해 좌석 생성 API의 호출 결과를 받았을 때 핸들러
 * @param {object} response
 * @private
 */
Physical.prototype._onCreatedSeat = function(response) {
    var seats,
        selectCtrl;

    if (common.isExisty(common.pick(response, 'grids', 'selectedSeats', 'seats'))) {
        selectCtrl = this.selectSeatController;
        seats = response.grids.selectedSeats.seats;

        selectCtrl.setData(seats);
        selectCtrl.update();
    }
};

Physical.prototype._onUpdatedSeat = function(response) {
    var seats = response.seats,
        selectCtrl = this.selectSeatController;

    selectCtrl.seatLayers.get('reserved').constructor.DRAGGABLE.reset();

    selectCtrl.setData(seats);
    selectCtrl.update();
};

Physical.prototype._onDeletedSeat = function() {
    this.selectSeatController.deleteAllSeats();
};

Physical.prototype._onSelectTree = function(selectTreeEvent) {
    if (this.hasSelectedSeat()) {
        this.deselectAllSeats(true);
    }

    this.IB.emit(PhysicalIB.EVENT.SELECT_RSEAT, selectTreeEvent.sids, true);
};

/**
 * 좌석 매핑정보 수정 API요청한다
 * @param {MAPPING_METHOD} [method] 자동배열 시 배열방법
 * @param {string} label 매핑정보명 ("열", "층", "번호"...)
 * @param {string} startNumber 입력값
 * @param {boolean} notUseIncrement true 일 경우 값을 자동 증감하지 않는다
 */
Physical.prototype.updateSeatMappingData = function(method, label, startNumber, notUseIncrement) {
    var seatsToUpdate = this.IB.getSeatsToUpdate(true),
        errorOccurrd = false;

    try {
        batch.setMappingData(seatsToUpdate, batch.MAPPING_METHOD[method], label, startNumber, notUseIncrement);
    } catch(e) {
        window.alert(e.message.replace(/^(.*):/, ''));
        errorOccurrd = true;
    }

    if (!errorOccurrd) {
        this.IB.emit(PhysicalIB.EVENT.UPDATE_SEAT, SelectSeatController.UPDATE.MAPINFO, false, seatsToUpdate);
    }
};

Physical.prototype._onRenameTree = function(renameData) {
    var str = RSeat.MAP_CODE[renameData.map],
        startNumber = renameData.rename;

        this.updateSeatMappingData(null, str, startNumber);
};

module.exports = Physical;
