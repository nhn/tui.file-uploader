/**
 * @fileoverview 조건불충족 좌석의 리스트를 그리고, 리스트를 클릭시 각 항목으로 이동시킨다.
 * @author FE개발팀
 **/

'use strict';

var LogicalIB = require('./logicalIb'),
    TabUI = require('./tab');

var util = ne.util,
    tkl = ne.tkl,
    UIController = tkl.UIController,
    SeatingChart = tkl.SeatingChart;

/**
 * 조건불충족 좌석 리스트를 그린다
 * @constructor
 */
var ImperfectionSeats = UIController.extend({
    init: function($el, options) {

        UIController.call(this, options);
        this.setRootElement($el);
        this.attachEvents();
        /**
         * @param {object} data
         *  {
         *     "result" : false,
         *     "count": "3500",    // 전체 실패 갯수
         *     "failList" : [{    // 실패 좌석 리스트
         *       "sid": 350,
         *       "number": "1층 A구역 1열",
         *       "reason" : {
         *         "CODE1": "등급이 없습니다.",
         *         "CODE2": "할당처 미부여",
         *         ...
         *       }
         *     }, {}, ..., {}]
         *   }
         */
        this.tabUI = options.tab;
        this.listen(LogicalIB.EVENT.CHECKED_IMPERFECTION_SEATS, function(data) {
            this.updateTotal(data.count);
            this.updateGrid(data.failList);
            if (this.IB.get('currentTabIndex') !== 4) {
                this.tabUI.togglePanel(4);
            }
        }, this);

    },
    static: {
    /**
     * 불충족 타입 코드, 이동할 탭의 인덱스를 매칭한다.
     * @type {{CODE1: (LogicalTab.TABINDEX.GRADE|*), CODE2: number, CODE3: number}}
     */
        MOVECODE: {
            CODE1: TabUI.TABINDEX.SELLINGTYPE, // 0
            CODE2: TabUI.TABINDEX.GRADE,
            CODE3: 2
        },
        SEATTYPE: {
            'ZONE' : SeatingChart.SEAT_TYPE.NONRESERVED,
            'SEAT' : SeatingChart.SEAT_TYPE.RESERVED
        }
    },
    /** @lends ImperfectionSeats */
    events: {
        'click #check_selectedseats': 'checkSelectedSeats',
        'click #check_allseats': 'checkAllSeats',
        'click a': 'moveToResolveTab'
    },
    /**
     * 불충족 좌석 갯수갱신
     * @param {number} count 불충족 좌석 갯수
     */
    updateTotal: function(count) {
        this.$el.find('h5 em').html(count);
    },
    /**
     * 불충족 좌석 리스트 갱신
     * @param {Array} failList 불충족 좌석 리스트(최대 50개)
     */
    updateGrid: function(failList) {
        var html = util.map(failList, function(el) {
            return '<tr>' +
                '<td>' + (el.number || '-') + '</td>' +
                '<td sid="' + el.sid + '" seat-type="' + el.type + '">' + this._getReason(el.reason) + '</td>' +
                '</tr>';
        }, this);

        this.$el.find('tbody').html(html);
    },
    /**
     * 불충족 좌석 리스트의 불충족이유 부분을 생성해서리턴한다.
     * @param {Objects} reasons
     * @returns {string}
     * @private
     */
    _getReason: function(reasons) {
        var reasonText = '';

        util.forEach(reasons, function(el, index) {

            if (el) {
                reasonText += '<a href="#' + index + '" class="err">' + (el + '</a><br />');
            }

        });

        return reasonText;
    },
    /**
     * 선택좌석 불충족 체크
     */
    checkSelectedSeats: function() {
        this.emit(LogicalIB.EVENT.CHECK_IMPERFECTION_SEATS, { type : 'selected'});
    },
    /**
     * 전체좌석 불충족 체크
     */
    checkAllSeats: function() {
        this.emit(LogicalIB.EVENT.CHECK_IMPERFECTION_SEATS, { type : 'all'});
    },
    /**
     * 탭이동
     */
    moveToResolveTab: function(e) {
        var self = this,
            target = e.currentTarget,
            sid,
            type,
            code;

        e.preventDefault();

        sid = $(target).parent().attr('sid');
        // 지정/비지정석 타입 확인
        type = ImperfectionSeats.SEATTYPE[$(target).parent().attr('seat-type')];
        code = $(target).attr('href').replace('#', '');
        $(target).removeClass('err').addClass('p_color6');

        // 해당 탭으로 이동한다.
        this.tabUI.togglePanel(ImperfectionSeats.MOVECODE[code]);
        this.IB.emit(LogicalIB.EVENT.MAP_WORK_DESELECT_ALL_SEAT, true);
        if (type === SeatingChart.SEAT_TYPE.RESERVED) {
            this.IB.emit(LogicalIB.EVENT.SELECT_RSEAT, [sid], true);
        } else {
            this.IB.emit(LogicalIB.EVENT.SELECT_NSEAT, [sid]);
        }
    }
});

module.exports = ImperfectionSeats;
