/**
 * @fileoverview 선택된 지정/비지정 좌석들에 등급을 부여한다.
 * @author FE개발팀
 */

'use strict';

var LogicalIB = require('./logicalIb');

var tkl = ne.tkl,
    UIController = tkl.UIController,
    SeatLayer = tkl.SeatLayer,
    Settings = tkl.Settings;

/**
 * 할당처 리스트를 그린다.
 * @contructor
 */
var Grade = UIController.extend({
    init: function($el, options) {

        UIController.call(this, options);
        this.setRootElement($el);
        this.render();

        if (Settings.isClosedEvent || Settings.isReservationSystem) {
            this.lock();
        }

        this.attachEvents();

    },
    /** @lends Grade */
    events: {
        'click .gradeItem': '_onclickGrade'
    },
    static: {
        MSG: {
            EMPTY: '할당매수를 입력하지 않으셨습니다. 확인후 다시 시도해 주세요.',
            NOSEAT: '선택된 좌석이 없습니다.'
        }
    },
    /**
     * 탭 메뉴 렌더링
     */
    render: function() {
        var code = SeatLayer.GRADE_INFO,
            html = '';

        ne.util.forEach(code, function(val, key) {

            html += '<li class="gradeItem" grade="'+ key +'">' +
                        '<a href="#">' +
                        '<span class="color" style="background-color:' + val[1] + '"></span>' +
                        '' + val[0] + '</a>' +
                    '</li>';

        });

        this.$el.find('.warning').hide();
        this.$el.find('.btn_area').show();
        this.$el.find('.stclass_lst').html(html);
    },
    lock: function() {
        this.$el.find('.warning').show();
        this.$el.find('.btn_area').hide();
    },
    /**
     * 선택된 좌석의 해쉬를 반환한다
     * @returns {*}
     * @private
     */
    _getSelectedSeats: function() {
        this.emit(LogicalIB.EVENT.UPDATE_SELECTED_SEATSLIST);
        return this.IB.get('selectedList');
    },
    /**
     * 등급을 클릭했을 때 이벤트 처리
     * @param {MouseEvent} e
     * @private
     */
    _onclickGrade: function(e) {
        e.preventDefault();

        if (Settings.isClosedEvent || Settings.isReservationSystem) {
            alert(this.$el.find('.warning').text());
            return;
        }

        var grade;

        // 선택 좌석 확인
        if(!this._getSelectedSeats().length) {
            alert(Grade.MSG.NOSEAT);
            return;
        }

        if (this.$current) {
            this.$current.removeClass('on');
        }

        this.$current = $(e.currentTarget);

        // 등급부여
        grade = this.$current.addClass('on').attr('grade');
        this.emit(LogicalIB.EVENT.UPDATE_GRADE, grade);
    }
});

module.exports = Grade;
