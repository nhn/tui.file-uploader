/**
 * @fileoverview 탭 UI 컨트롤러
 * @author minhyeong.kim@nhnent.com
 */

'use strict';

var TabUI = require('../../common/tab'),
    PhysicalIB = require('./physicalIb');

var PhysicalTabUI = TabUI.extend(/** @lends PhysicalTabUI.prototype */{

    static: /** @lends PhysicalTabUI */{
        TABINDEX: {
            CREATE: 0,
            NUMBER: 1,
            ARRANGE: 2,
            IMPERFECTION: 3,
            ROTATE: 4
        }
    },

    /**
     * @constructs
     * @extends TabUI
     * @exports PhysicalTabUI
     * @class
     * @param {jQuery} $el
     * @param {object} options
     */
    init: function($el, options) {
        TabUI.call(this, $el, options);
    },

    /**********
     * public methods
     **********/

    /**
     * 인자 순서의 패널로 토글한다
     * @param {number} index
     */
    togglePanel: function(index) {
        if (index === PhysicalTabUI.TABINDEX.ARRANGE) {
            alert('준비중입니다');
            return;
        }

        this.emit(PhysicalIB.EVENT.CHANGE_TAB_INDEX, index);

        TabUI.prototype.togglePanel.call(this, index);
    }
});

module.exports = PhysicalTabUI;
