/**
 * @fileoverview 물리도면 -> 회전 탭 UI 컨트롤러
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var PhysicalIB = require('./physicalIb');

var tkl = ne.tkl,
    UIController = tkl.UIController,
    SelectSeatController = tkl.SelectSeatController;

var RotateUI = UIController.extend({
    rootElement: $('.tab-ui .con5'),

    init: function() {
        UIController.call(this);
        this.attachEvents();
    },

    static: /** @lends RotateUI */ {
        'R_DEG': /^\d+$/
    },

    events: {
        'click #rotate_group_left': '_onRotate',
        'click #rotate_group_right': '_onRotate',
        'click #rotate_left': '_onRotate',
        'click #rotate_right': '_onRotate'
    },

    /**********
     * private methods
     **********/

    _getRotateValue: function($input) {
        var deg = $input.val();

        if (!RotateUI.R_DEG.test(deg)) {
            alert('회전 각도는 숫자만 입력 가능합니다');
            $input.focus().select();
            return;
        }

        deg = parseInt(deg, 10);

        if (deg < 0 || deg > 360) {
            alert('회전 각도는 0° ~ 360° 내에서 입력 가능합니다');
            return;
        }

        return deg;
    },

    /**********
     * event handler
     **********/

    _onRotate: function(clickEvent) {
        var $btn = $(clickEvent.target),
            $parent = $btn.parent(),
            $input = $btn.parent().find('input:text'),
            deg = this._getRotateValue($input),
            method = ($parent.attr('id') === 'rotate_group') ?
                SelectSeatController.ROTATE_METHOD.GROUP : SelectSeatController.ROTATE_METHOD.EACH ;

        if (!deg) {
            $input.val('8');
            return;
        }

        if ($btn.hasClass('lt')) {
            deg *= -1;
        }

        this.emit(PhysicalIB.EVENT.RESERVE_CURRENT_STATUS);
        this.emit(PhysicalIB.EVENT.ROTATE_SEAT, method, deg);
        this.emit(PhysicalIB.EVENT.RENDER_IMMEDIATE_SELECTED);
    }

});

module.exports = RotateUI;
