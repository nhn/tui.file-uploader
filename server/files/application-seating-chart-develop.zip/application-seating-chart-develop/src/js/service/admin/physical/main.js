/**
 * @fileoverview 물리도면 서비스페이지 entry point
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var common = global.ne.util;

var Physical = require('./physical'),
    PhysicalTabUI = require('./tab'),
    FloatingUI = require('../../common/floating'),
    HeaderUI = require('../../common/header'),
    RotateUI = require('./rotate'),
    CreateSeatUI = require('./createSeat'),
    NumberUI = require('./number'),
    SelectedListUI = require('./selectedList'),
    TopMenuUI = require('./topMenu'),
    ImperfectionSeatsUI = require('./imperfectionSeats'),
    SaveUI = require('./save');

function init(options) {
    if (!common.isExisty(options) ||
        !common.isObject(options)) {
        throw Error('도면 기본정보가 없습니다. 관리자에게 문의 바랍니다.');
    }

    var chart = ne.tkl.instance.chart = new Physical('map', options);
    var tab = new PhysicalTabUI('.tab-ui', { IB: chart.IB });

    chart.addUIC(new FloatingUI());
    chart.addUIC(new CreateSeatUI({ IB: chart.IB }));
    chart.addUIC(new TopMenuUI({ IB: chart.IB, zoom: chart.options.zoom }));
    chart.addUIC(new RotateUI({}));
    chart.addUIC(new HeaderUI());
    chart.addUIC(new NumberUI($('.tab-ui .con2'), { IB: chart.IB }));
    chart.addUIC(new SelectedListUI($('.flrseat'), { IB: chart.IB }));
    chart.addUIC(new ImperfectionSeatsUI($('.tab-ui .con4'), { IB: chart.IB, tab: tab }));
    chart.addUIC(new SaveUI());

    return chart;
}

ne.tkl.physical = init;

// 좌석번호지정 팝업
ne.tkl.physical.AllocSeatMarkUI = require('./popup/allocSeatMark');
