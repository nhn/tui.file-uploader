/**
 * @fileoverview 선택된 지정/비지정석에 따른 할당처 폼을 보여주고, 할당처 설정 및, 매수 설정을 할수 있게 한다.
 * @author FE개발팀
 */

'use strict';

var TextPlaceholder = require('../../common/textPlaceholder.js'),
    LogicalIB = require('./logicalIb'),
    TabUI = require('./tab');

var util = ne.util;
var tkl = ne.tkl,
    UIController = tkl.UIController,
    SeatLayer = tkl.SeatLayer,
    Settings = tkl.Settings;

/**
 * 할당처
 * @contructor
 */
var SellingType = UIController.extend({
    init: function($el, options) {

        UIController.call(this, options);
        this.setRootElement($el);
        this.render();

        this.tabUI = options.tab;
        this.listen(LogicalIB.EVENT.MAP_SELECTED_SEAT, this.changeSection, this);
        this.listen(LogicalIB.EVENT.RESET_SELLINGTAB, this.availReserveSellingTab, this);
        this.listen(LogicalIB.EVENT.MAP_DESELECT_SEAT, this.reset, this);
        this.listen(LogicalIB.EVENT.MAP_DESELECT_ALL_SEAT, this.reset, this);
        this.attachEvents();

    },
    static: {
        /**
         * 각 항목에 들어가는 클래스 명
         * @type {{TKL: string, AGENCY: string, FIDLE: string, TICKET: string, POSTPONE: string, CALL: string}}
         */
        KEY: {
            TKL: 'd1',
            AGENCY: 'd2',
            FIELD: 'd3',
            TICKET: 'd4',
            POSTPONE: 'd5',
            CALL: 'd6'
        },
        MSG: {
            EMPTY: '할당매수를 입력하지 않으셨습니다. 확인후 다시 시도해 주세요.',
            NOSEAT: '선택된 좌석이 없습니다.'
        }
    },
    /** @lends SellingType */
    events: {
        'click .selling_item' : 'selectSellingType',
        'click #apply_dealership': 'applyDealerShip'
    },
    /**
     * 리셋 및 렌더링
     *
     */
    reset: function() {
        this.availReserveSellingTab();
        this.render();
    },
    /**
     * 탭 렌더링
     */
    render: function() {

        var code = SeatLayer.SELLING_TYPE_CODE,
            html = '',
            nreservehtml = '',
            idx = 1;


        util.forEach(code, function(val, key) {

            var ico = SellingType.KEY[key];
            html += '<li class="selling_item" selling-key="' + key + '">' +
                        '<a href="#">' +
                        '<span class="sp_flr ' + ico + '"></span>' + val + '' +
                        '</a>' +
                    '</li>';
            nreservehtml += '<li class="noreserve_items">' +
                                '<label for="dis' + idx +'" class="lb_flr">' +
                                    '<span class="sp_flr ' + ico + '"></span>' + val +
                                '</label>' +
                                '<input type="text" selling-key="' + key + '" id="dis' + idx + '" data-placeholder="할당매수 입력" class="inp_flr ne-text-placeholder">장' +
                            '</li>';
            idx = idx + 1;

        });

        this.$el.find('.btn_area').show();
        this.$el.find('.distributor_lst').html(html);
        this.$el.find('.distributor_lst2').html(nreservehtml);

        if (Settings.isClosedEvent || Settings.isReservationSystem) {
            this.lock();
        } else {
            this.$el.find('.warning').hide();
        }

        TextPlaceholder.init({
            fillCSSClass: 'on'
        });
    },
    /**
     * 탭 업데이트
     * @param {string} type 지정석/비지정석 여부
     * @param {Object} selectedInfo 선택좌서 정보를 가져온다.
     */
    update: function(type, selctedInfo) {

        this.render();

        if(type === LogicalIB.SEAT_TYPE.NSEAT) {

            // 비지정석 dealership에 있는 값을 읽어서 각 장수를 적용한다.
            var count = 0,
                self = this;
            $.each(SeatLayer.SELLING_TYPE_CODE, function(key, el) {
                $.each(selctedInfo, function(indx, sel) {
                    if(sel.dealer === el) {
                        self.$el.find('.distributor_lst2 input').eq(count).val(sel.ticket);
                    }
                });
                count++;
            });
        }
    },
    /**
     * 탭을 사용할수 없도록 기능을 잠그고 안내문구를 노출
     */
    lock: function() {
        this.$el.find('.warning').show();
        this.$el.find('.btn_area').hide();
        this.$el.find('.opt_btn').hide();
    },
    /**
     * 지정석 판매처 할당일 경우, 지정석 판매처 할당부분 노출
     */
    availReserveSellingTab: function() {
        this.$el.find('.nonreserved_area').hide();
        this.$el.find('.reserved_area').show();
    },
    /**
     * 비지정석 판매처 할당일 경우, 비지정석 판매처 할당부분 노출
     */
    availNreserveSellingTab: function() {
        // todo 할당되어 있는 매수가 있는지 보고 할당처 input에 세팅한다.
        this.$el.find('.reserved_area').hide();
        this.$el.find('.nonreserved_area').show();
    },
    /**
     * 탭 메뉴(지정석메뉴/비지정석메뉴)를 변경한다.
     */
    changeSection: function(seatData) {
        var selectedList = seatData && seatData.selectInfo;

        if(this.tabUI.current !== TabUI.TABINDEX.SELLINGTYPE) {
            return;
        }

        if(this.isNseat(selectedList)) {
            this.update(LogicalIB.SEAT_TYPE.NSEAT, selectedList);
            this.availNreserveSellingTab();
        } else {
            this.update(LogicalIB.SEAT_TYPE.RSEAT, selectedList);
            this.availReserveSellingTab();
        }

    },
    /**
     * 비지정석인지 확인한다.
     * @returns {*}
     */
    isNseat: function(selectedList) {
        var seats = selectedList,
            isN;

        util.forEach(seats, function(seat) {

            isN = (seat.type === '비지정석');

        });

        return isN;
    },
    /**
     * 선택된 좌석의 해쉬를 반환한다
     * @returns {*}
     * @private
     */
    _getSelectedSeats: function() {
        this.emit(LogicalIB.EVENT.UPDATE_SELECTED_SEATSLIST);
        return this.IB.get('selectedList');
    },
    /**
     * 지정석의 할당처를 선택할 경우 이벤트 핸들러
     * @param {JQueryEvent} e
     */
    selectSellingType: function(e) {
        if (Settings.isClosedEvent || Settings.isReservationSystem) {
            alert(this.$el.find('.warning').text());
            return;
        }

        // 선택 좌석 확인
        if(!this._getSelectedSeats().length) {
            alert(SellingType.MSG.NOSEAT);
            return;
        }

        e.preventDefault();

        if (this.$current) {
            this.$current.removeClass('on');
        }

        this.$current = $(e.currentTarget);
        this.$current.addClass('on');
        this.emit(LogicalIB.EVENT.UPDATE_SELLING_TYPE, LogicalIB.SEAT_TYPE.RSEAT, this.$current.attr('selling-key'));
    },
    /**
     * 비지정석의 할당매수를 입력 한 후, 적용 버튼을 눌렀을때의 이벤트 핸들러
     */
    applyDealerShip: function() {

        TextPlaceholder.sync();

        var dealerSet = {};
        // 비지정석의 할당매수 입력

        this.$el.find('.distributor_lst2 input').each(function(idx, el) {
            dealerSet[$(el).attr('selling-key')] = el.value;
        });

        var isEmpty = true;
        util.forEachOwnProperties(dealerSet, function(v) {
            if (v !== '') {
                isEmpty = false;
                return false;
            }
        });

        if(isEmpty) {
            alert(SellingType.MSG.EMPTY);
        } else {
            this.emit(LogicalIB.EVENT.UPDATE_SELLING_TYPE, LogicalIB.SEAT_TYPE.NSEAT, dealerSet );
        }

        TextPlaceholder.refresh();

    }
});

module.exports = SellingType;
