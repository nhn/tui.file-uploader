'use strict';

var tkl = ne.tkl,
    InteractBroker = tkl.InteractBroker;

/**
 * UserTicketingIB
 * @constructor
 * @class
 * @exports UserTicketingIB
 * @extends {InteractBroker}
 */
function UserTicketingIB() {
    InteractBroker.call(this);
}

ne.util.inherit(UserTicketingIB, InteractBroker);

/**********
 * static props
 **********/

var EVENT = {
    REQUEST_AVAILABLE_DATES: 'RequestAvailableDates',
    AVAILABLE_DATES_LOADED: 'AvailableDatesLoaded',
    DATE_SELECTED: 'DateSelected',
    ROUND_SELECTED: 'RoundSelected',
    ROUND_UNSELECTED: 'RoundUnselected',
    ROUND_LOADED: 'RoundLoaded',
    AVAILABLE_SEATINFO_LOADED: 'AvailSeatLoaded'
};

UserTicketingIB.EVENT = EVENT;
UserTicketingIB.prototype.EVENT = UserTicketingIB.EVENT;

module.exports = UserTicketingIB;
