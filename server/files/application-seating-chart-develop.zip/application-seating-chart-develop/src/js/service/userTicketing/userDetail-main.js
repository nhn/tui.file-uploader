'use strict';

var UserTicketingIB = require('./userTicketingIB'),
    SelectSchedule = require('../ticketing/common/selectSchedule'),
    ScheduleSelectView = require('../ticketing/common/scheduleSelectView'),
    SeatingInfoPerRound = require('../ticketing/common/seatingInfoPerRound');

/**
 * 필요한 UI를 셋팅하는 함수
 * @param {Object} options
 * @param {boolean} options.stopInteraction 클릭과같은 유저이벤트를 막는다.
 * @param {number} options.date DatePicker의 초기 선택 날짜를 결정한다. Timestamp
 * @param {number} options.initialRound 회차선택UI의 초기 선택 회차를 정한다.
 * @param {function} options.onDateClicked DatePicker에서 날짜가 선택되었을때 실행되는 콜백
 * @param {function} options.onRoundClicked 회차선택UI에서 회차가 선택되었을때 실행되는 콜백
 * @returns {SelectSchedule}
 */
function init(options) {
    var IB = new UserTicketingIB();

    IB.set('MSGS', options.messages);

    var selectSchedule = new SelectSchedule({
        IB: IB,
        type: SelectSchedule.TYPE.BASIC,
        stopInteraction: options.stopInteraction,
        date: options.date,
        seatingInfoPerRound: new SeatingInfoPerRound({
            IB: IB,
            type: SeatingInfoPerRound.TYPE.BASIC_FOR_DETAIL,
            stopInteraction: options.stopInteraction
        }),
        scheduleView: new ScheduleSelectView({
            IB: IB,
            stopInteraction: options.stopInteraction,
            initialRound: options.initialRound
        })
    });

    if (options.onDateClicked) {
        IB.listen(IB.EVENT.DATE_SELECTED, options.onDateClicked);
    }

    if (options.onRoundClicked) {
        IB.listen(IB.EVENT.ROUND_SELECTED, options.onRoundClicked);
        IB.listen(IB.EVENT.ROUND_UNSELECTED, options.onRoundClicked);
    }

    selectSchedule.updateDates = function(data) {
        this.IB.fire(IB.EVENT.AVAILABLE_DATES_LOADED, data);
    };

    selectSchedule.updateRounds = function(data) {
        this.IB.fire(IB.EVENT.ROUND_LOADED, data);
    };

    selectSchedule.updateGrades = function(data) {
        this.IB.emit(IB.EVENT.AVAILABLE_SEATINFO_LOADED, data);
    };

    selectSchedule.setDate = function(date) {
        this.setCurrentDateFromStr(date);
    };

    selectSchedule.setRound = function(number) {
        this.scheduleView.setInitialRound(number);
        this.scheduleView.setInitSelectItemIfNeed();
    };

    return selectSchedule;
}

global.ne.tkl.SelectSchedule = init;
