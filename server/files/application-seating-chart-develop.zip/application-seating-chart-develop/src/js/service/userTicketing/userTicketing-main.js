var UserTicketingIB = require('./userTicketingIB'),
    SelectSchedule = require('../ticketing/common/selectSchedule'),
    ScheduleView = require('../ticketing/common/scheduleView'),
    SeatingInfoPerRound = require('../ticketing/common/seatingInfoPerRound');

function init(options) {
    var IB = new UserTicketingIB();

    var selectSchedule = new SelectSchedule({
        IB: IB,
        type: SelectSchedule.TYPE.BASIC,
        stopInteraction: options.stopInteraction,
        date: options.date,
        seatingInfoPerRound: new SeatingInfoPerRound({
            IB: IB,
            type: SeatingInfoPerRound.TYPE.BASIC,
            stopInteraction: options.stopInteraction
        }),
        scheduleView: new ScheduleView({
            IB: IB,
            stopInteraction: options.stopInteraction,
            initialRound: options.initialRound
        })
    });

    if (options.onDateClicked) {
        IB.listen(IB.EVENT.DATE_SELECTED, options.onDateClicked);
    }

    if (options.onRoundClicked) {
        IB.listen(IB.EVENT.ROUND_SELECTED, options.onRoundClicked);
        IB.listen(IB.EVENT.ROUND_UNSELECTED, options.onRoundClicked);
    }

    selectSchedule.updateDates = function(data) {
        this.IB.fire(IB.EVENT.AVAILABLE_DATES_LOADED, data);
    };

    selectSchedule.updateRounds = function(data) {
        this.IB.fire(IB.EVENT.ROUND_LOADED, data);
    };

    selectSchedule.updateGrades = function(data) {
        this.IB.emit(IB.EVENT.AVAILABLE_SEATINFO_LOADED, data);
    };

    selectSchedule.setDate = function(date) {
        this.setCurrentDateFromStr(date);
    };

    selectSchedule.setRound = function(number) {
        this.scheduleView.setInitialRound(number);
        this.scheduleView.setInitSelectItemIfNeed();
    };

    return selectSchedule;
}

global.ne.tkl.SelectSchedule = init;
