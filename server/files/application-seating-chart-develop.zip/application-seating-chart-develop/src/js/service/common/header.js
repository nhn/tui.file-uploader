/**
 * @fileoverview 헤더 영역 컨트롤
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var tkl = ne.tkl,
    InteractBroker = tkl.InteractBroker,
    UIController = tkl.UIController;

var HeaderUI = UIController.extend({
    rootElement: $('.flr_header'),

    /**
     * @constructs HeaderUI
     */
    init: function() {
        UIController.call(this);
        this.attachEvents();
    },

    events: {
        'click .shrtkey': '_onClickShrtKey'
    },

    _onClickShrtKey: function(e) {
        e.preventDefault();
        this.emit(InteractBroker.EVENT.SHOW_SHRT_KEY);
    }
});

module.exports = HeaderUI;
