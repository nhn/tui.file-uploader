/**
 * @fileoverview input:text placeholder polyfill
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var common = ne.util;

function getData(el, key) {
    if (el.dataset) {
        key = key.replace(/\-(\w)/g, function(v) {
            return v[1].toUpperCase();
        });
        return el.dataset[key];
    } else {
        return el.getAttribute('data-' + key);
    }
}

/**
 * value 값과 css class 응용하여 placeholder 를 모사하는 기능을 가진 모듈
 * @param {object} options
 * @param {string} [options.placeholderText] 값이 없을 때 노출시킬 값 input:text 자체에 placeholder 로 사용가능
 * @param {string} options.emptyCSSClass 값이 없을 때 텍스트박스에 할당되는 css class
 * @param {string} options.fillCSSClass 값이 있을 때 텍스트박스에 할당되는 css class
 * @param {number} options.tickInterval 값이 있는지 확인할 때 사용하는 인터벌
 * @param {HTMLDocument} [options.doc]
 * @constructor
 */
function TextPlaceholder(options) {

    this.options = {};

    common.extend(this.options, {
        placeholderText: '',
        emptyCSSClass: 'ne-placeholder-empty',
        fillCSSClass: 'ne-placeholder-fill',
        tickInterval: 100
    }, options);

    /**
     * @type {Array.<HTMLInputElement>}
     */
    this.textboxes = null;

    this.focusEvent = common.bind(this._onFocus, this);
    this.blurEvent = common.bind(this._onBlur, this);

    /**
     * @type {HTMLInputElement}
     */
    this.target = null;

    this.init();

}

/**********
 * static props
 **********/

/**
 * check input:text placeholder features in browser
 * @returns {boolean}
 */
TextPlaceholder.placeholderIsSupperted = function() {
    var test = document.createElement('input');
    return ('placeholder' in test);
};

TextPlaceholder.addEventListerIsSupperted = function() {
    var test = document.createElement('input');
    return ('addEventListener' in test);
};

/**
 * 페이지 내 모든 .ne-placeholder 텍스트박스에 대해 인스턴스 생성
 * @param {object} options
 */
TextPlaceholder.init = function(options) {
    if (!TextPlaceholder.inst) {
        TextPlaceholder.inst = new TextPlaceholder(options);
    } else {
        TextPlaceholder.inst.init();
    }
};

/**
 * 폼 전송 또는 입력값을 받기 전에 placeholder와 같은지 비교하여 값을 동기화하는 메서드
 */
TextPlaceholder.sync = function() {
    if (TextPlaceholder.inst) {
        TextPlaceholder.inst.sync();
    }
};

TextPlaceholder.refresh = function() {
    var inst = TextPlaceholder.inst;
    if (inst) {
        common.forEachArray(inst.textboxes, function(textbox) {
            inst.refreshCSS(textbox);
            inst.refreshPlacehodler(textbox);
        });
    }
};

/**********
 * public methods
 **********/

/**
 * placeholder 기능을 css, value 를 가지고 하므로
 * form 이 전송될 때 placehodler 값이 전달되는 것을 방지하기 위해
 * 실제 값과 sync 하는 메서드
 */
TextPlaceholder.prototype.sync = function() {
    common.forEachArray(this.textboxes, function(textbox) {
        if (this.isEmpty(textbox)) {
            textbox.value = '';
        }
    }, this);
};

/**
 * 초기화
 */
TextPlaceholder.prototype.init = function() {
    var textboxes,
        textbox,
        i,
        len;

    this.textboxes = [];
    textboxes = $('input.ne-text-placeholder');

    for (i = 0, len = textboxes.length; i < len; i += 1) {
        textbox = textboxes[i];
        this.refreshEvent(textbox);
        this.textboxes.push(textboxes[i]);
    }

    this.refreshCSS();
    this.refreshPlacehodler();
};

/**
 * 관리되는 모든 텍스트박스의 focus, blur 이벤트를 다시 등록한다
 * @param {HTMLInputElement} textbox
 */
TextPlaceholder.prototype.refreshEvent = function(textbox) {
    var focusEvent = this.focusEvent,
        blurEvent = this.blurEvent;

    if (TextPlaceholder.addEventListerIsSupperted()) {
        textbox.removeEventListener('focus', focusEvent);
        textbox.removeEventListener('blur', blurEvent);

        textbox.addEventListener('focus', focusEvent);
        textbox.addEventListener('blur', blurEvent);
    } else {
        textbox.detachEvent('onfocus', focusEvent);
        textbox.detachEvent('onblur', blurEvent);

        textbox.attachEvent('onfocus', focusEvent);
        textbox.attachEvent('onblur', blurEvent);
    }
};

/**
 * placeholder 값을 반환
 * @param {HTMLInputElement} textbox
 * @returns {string}
 */
TextPlaceholder.prototype.getPlaceholder = function(textbox) {
    return getData(textbox, 'placeholder') || this.options.placeholderText;
};

/**
 * 텍스트박스의 값이 비었는지 확인 (placeholder와 같은경우도 빈 것으로 판단)
 * @param {(HTMLInputElement|EventTarget)} textbox
 * @returns {boolean}
 */
TextPlaceholder.prototype.isEmpty = function(textbox) {
    var placeholder = this.getPlaceholder(textbox),
        value = textbox.value;

    return (value === '' || value === placeholder);
};

/**
 * TextPlaceholder에서 부여하는 모든 CSS속성을 제거한다
 * @param {(HTMLInputElement|EventTarget)} textbox
 */
TextPlaceholder.prototype.clearCSS = function(textbox) {
    var options = this.options,
        cls = textbox.className,
        fillCSSClass = getData(textbox, 'placeholder-fill') || options.fillCSSClass,
        emptyCSSClass = getData(textbox, 'placeholder-empty') || options.emptyCSSClass;


    textbox.className = cls.
        replace(new RegExp('\\s?' + fillCSSClass + '\\s?', 'g'), '').
        replace(new RegExp('\\s?' + emptyCSSClass + '\\s?', 'g'), '');
};

/**
 * 값이 비었는지 아닌지에 대한 CSS를 토글한다
 * @param {(HTMLInputElement|EventTarget)} textbox
 * @param {boolean} [isEmpty]
 */
TextPlaceholder.prototype.markCSS = function(textbox, isEmpty) {
    var options = this.options,
        fillCSSClass = getData(textbox, 'placeholder-fill') || options.fillCSSClass,
        emptyCSSClass = getData(textbox, 'placeholder-empty') || options.emptyCSSClass;

    if (common.isExisty(isEmpty)) {
        textbox.className += (' ' + (isEmpty ? emptyCSSClass : fillCSSClass));
    } else {
        this.clearCSS(textbox);
        if (this.isEmpty(textbox)) {
            textbox.className += (' ' + emptyCSSClass);
        } else {
            textbox.className += (' ' + fillCSSClass);
        }
    }
};

/**
 * 값 유무 관련 css를 할당할지 말지 처리
 * @param {(HTMLInputElement|EventTarget)} [textbox]
 */
TextPlaceholder.prototype.refreshCSS = function(textbox) {
    var func = common.bind(function(textbox) {
            this.clearCSS(textbox);
            this.markCSS(textbox/*, this.isEmpty(textbox)*/);
        }, this);

    if (textbox) {
        func(textbox);
    } else {
        common.forEachArray(this.textboxes, func);
    }
};

/**
 * placeholder 를 보여줘야 할지 말지 처리
 * @param {(HTMLInputElement|EventTarget)} [textbox]
 */
TextPlaceholder.prototype.refreshPlacehodler = function(textbox) {
    var func = common.bind(function(textbox) {
            if (this.isEmpty(textbox)) {
                textbox.value = this.getPlaceholder(textbox);
            }
        }, this);

    if (textbox) {
        func(textbox);
    } else {
        common.forEachArray(this.textboxes, func);
    }
};

/**********
 * event handlers
 **********/

/**
 * 텍스트박스 포커스 이벤트
 * @param {Event} e
 * @private
 */
TextPlaceholder.prototype._onFocus = function(e) {
    var textboxes = this.textboxes,
        target = e.target || e.srcElement;

    common.forEachArray(textboxes, function(textbox) {
        if (target === textbox) {
            target = this.target = textbox;
            return false;
        }
    }, this);

    if (this.target) {
        this.clearCSS(target);
        this.markCSS(target, false);
        if (this.isEmpty(target)) {
            target.value = '';
        }
    }
};

/**
 * 텍스트박스 블러 이벤트
 * @param {Event} e
 * @private
 */
TextPlaceholder.prototype._onBlur = function(e) {
    var textboxes = this.textboxes,
        target = e.target || e.srcElement,
        found = false;

    common.forEachArray(textboxes, function(textbox) {
        if (target === textbox) {
            found = true;
            return false;
        }
    }, this);

    if (found) {
        target = this.target;

        this.refreshCSS(target);
        this.refreshPlacehodler(target);
    }

    this.target = null;
};

module.exports = TextPlaceholder;
