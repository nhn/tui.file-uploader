/**
 * @fileovewview 특정 div를 z-index속성을 사용해 띄워 보여주는 기능을 가진 모듈
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var common = ne.util;
var tkl = ne.tkl,
    UIController = tkl.UIController,
    InteractBroker = tkl.InteractBroker;

var FloatingUI = UIController.extend({
    rootElement: $('.dimmed_layer'),

    /**
     * @constructs FloatUI
     * @extends UIController
     */
    init: function() {
        UIController.call(this);

        var self = this,
            $el = this.$el;

        /**
         * 화면에 선택적으로 노출할 엘리먼트 관리
         * @type {object.<string, HTMLElement>}
         */
        this.contents = {};

        /**
         * 딤드 레이어 엘리먼트
         */
        this.$dimm = $el.find('div._dimmed_bg');

        /**
         * 선택적으로 보여줄 엘리먼트를 관리하기 위한 엘리먼트
         */
        this.$contents = $el.find('div.dimmed_contents');

        this.$contents.children().each(/** @this HTMLElement */function() {
            var key = $(this).hide().data('dim-contents-name');

            if (key) {
                self.addContents(key, this, false);
            }
        });

        this.$contents.show();

        this.$contents.on('click', '.dimmed_close', function(e) {
            e.preventDefault();
            self.hideAll();
        });
    },

    onSetIB: function() {
        this.listen(InteractBroker.EVENT.SHOW_DIMM_MSG, this.showDimmMessage);
        this.listen(InteractBroker.EVENT.HIDE_DIMM_MSG, this.hideDimmMessage);
        this.listen(InteractBroker.EVENT.SHOW_PRELOADER, this.showPreloader);
        this.listen(InteractBroker.EVENT.HIDE_PRELOADER, this.hideAll);
        this.listen(InteractBroker.EVENT.SHOW_SHRT_KEY, this.showShrtHelp);
        this.listen(InteractBroker.EVENT.HIDE_FLOATING, this.hideAll);
    },

    /**********
     * private props
     **********/

    /**
     * 엘리먼트가 윈도우에 가운데 위치하도록 조정한다
     * @param {HTMLElement} el
     * @private
     */
    _setCenter: function(el) {
        var centerX = $(window).width() / 2,
            centerY = $(window).height() / 2;

        centerX -= ($(el).width() / 2);
        centerY -= ($(el).height() / 2);

        $(el).css({
            left: centerX + 'px',
            top: centerY + 'px'
        });
    },

    /**
     * 컨텐츠 존재 시 함수를 실행한다
     * @param {string} key 컨텐츠 이름
     * @param {function(HTMLElement)} func 함수
     * @private
     */
    _doWhenContentsExist: function(key, func) {
        var target = this.contents[key];

        if (common.isExisty(target)) {
            func.call(this, target);
        }
    },

    /**********
     * application function
     **********/

    /**
     * 딤드 + 메시지를 노출한다.
     * @param {string} msg 보여줄 HTML문자열
     */
    showDimmMessage: function(msg) {
        this._doWhenContentsExist('msg', function(target) {
            target.innerHTML = msg;

            this._setCenter(target);
            this.toggleDimmedLayer(true);
            this.toggleContents('msg', true);
        });
    },

    /**
     * 딤드 + 메시지를 숨긴다
     */
    hideDimmMessage: function() {
        this._doWhenContentsExist('msg', function() {
            this.toggleDimmedLayer(false);
            this.toggleContents('msg', false);
        });
    },

    /**
     * 딤드 + preloader를 노출한다
     */
    showPreloader: function() {
        this._doWhenContentsExist('preloader', function() {
            this.toggleDimmedLayer(true);
            this.toggleContents('preloader', true);
        });
    },

    /**
     * 딤드 + 단축키 도움말 레이어를 노출한다
     */
    showShrtHelp: function() {
        this._doWhenContentsExist('help', function(target) {
            this._setCenter(target);
            this.toggleDimmedLayer(true);
            this.toggleContents('help', true);
        });
    },

    /**********
     * public props
     **********/

    /**
     * 컨텐츠를 추가한다
     * @param {string} key
     * @param {(HTMLElement|jQuery)} contents
     * @param {boolean} [isDetach=true] 엘리먼트를 원래의 위치에서 떼어내어 관리하는지 여부
     */
    addContents: function(key, contents, isDetach) {
        isDetach = !common.isExisty(isDetach) ? true : isDetach;

        if (contents instanceof jQuery) {
            contents = contents[0];
        }

        if (!common.isExisty(contents)) {
            return;
        }

        var ownContents = this.contents;

        if (ownContents[key]) {
            return;
        }

        ownContents[key] = contents;

        $(contents).data('dim-contents-name', key);

        if (isDetach) {
            $(contents).appendTo(this.$contents);
        }
    },

    /**
     * 딤드레이어를 토글한다
     * @param {boolean} showHide
     */
    toggleDimmedLayer: function(showHide) {
        if (showHide) {
            this.$dimm.show();
        } else {
            this.$dimm.hide();
        }
    },

    /**
     * 컨텐츠 엘리먼트를 토글한다
     * @param {(string|HTMLElement)} key
     * @param {boolean} showHide
     */
    toggleContents: function(key, showHide) {
        if (!common.isString(key)) {
            key = $(key).data('dim-contents-name');
        }

        this._doWhenContentsExist(key, function(target) {
            if (showHide) {
                $(target).show();
            } else {
                $(target).hide();
            }
        });
    },

    /**
     * 딤드 + 컨텐츠를 전부 숨긴다
     */
    hideAll: function() {
        //this.$el.hide();
        common.forEachOwnProperties(this.contents, function(el) {
            $(el).hide();
        });
        this.$dimm.hide();
    }

});

module.exports = FloatingUI;
