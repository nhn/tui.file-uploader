/**
 * @fileoverview 탭 UI 컨트롤러
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var UIController = ne.tkl.UIController;

var TabUI = UIController.extend(/** @lends TabUI.prototype */{

    /**
     * @constructs
     * @exports TabUI
     * @class
     * @param {jQuery} $el 탭 UI의 래핑 엘리먼트
     */
    init: function($el, options) {
        if (ne.util.isString($el)) {
            $el = $($el);
        }

        UIController.call(this, options);

        this._tab = $el.find('.tab_lst');
        this._panels = $el.find('.tab_con');
        this.current = null;

        this.setRootElement($el);
        this.attachEvents();

        this.togglePanel(0);
    },

    events: {
        'click .tab_lst': '_onTabClick'
    },

    /**********
     * private methods
     **********/

    /**
     * on class 제거 메서드
     * @protected
     */
    _clearCSSClass: function() {
        this._tab.find('.on').removeClass('on');
    },

    /**
     * 인자 순서에 있는 li에 on css class 할당
     * @param {number} index
     * @private
     */
    _addCSSClass: function(index) {
        this._tab.children().eq(index).addClass('on');
    },

    /**
     * 모든 패널 숨김
     * @private
     */
    _hideAllPanel: function() {
        this._panels.hide();
    },

    /**
     * 인자 순서의 li를 노출함
     * @param {number} index
     * @private
     */
    _showPanel: function(index) {
        this._panels.eq(index).show();
    },

    /**********
     * public methods
     **********/

    /**
     * 인자 순서의 패널로 토글한다
     * @param {number} index
     */
    togglePanel: function(index) {
        if (this.current === index) {
            return;
        }

        this._hideAllPanel();
        this._showPanel(index);
        this._clearCSSClass();
        this._addCSSClass(index);
        this.current = index;

        this.IB.set('currentTabIndex', this.current);
    },

    /**********
     * event handler
     **********/

    /**
     * 탭 버튼 영역의 클릭 이벤트 핸들러
     * @param {MouseEvent} clickEvent
     * @private
     */
    _onTabClick: function(clickEvent) {
        clickEvent.preventDefault();

        var $li = $(clickEvent.target).parent(),
            index = $li.index();

        this.togglePanel(index);
    }

});

module.exports = TabUI;
