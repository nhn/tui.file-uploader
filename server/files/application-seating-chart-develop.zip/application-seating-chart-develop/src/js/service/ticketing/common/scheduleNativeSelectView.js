/**
* @fileoverview ScheduleView
* @author FE개발팀 김성호 sungho-kim@nhnent.com
*
* 회차 선택
* - 현장, 기획사, 예매처
*/

var UIModel = require('../../../ui/model'),
    ScheduleView = require('./scheduleView'),
    tmplSelectOption = require('../../../../tmpl/ticketing/scheduleView/scheduleNativeSelectView_option.html'),
    tmplSelectDefOption = require('../../../../tmpl/ticketing/scheduleView/scheduleNativeSelectView_defaultOption.html');

/**
 * ScheduleModel
 * 회차 정보를 가지고있는 모델
 * @exports ScheduleModel
 * @extends {UIModel}
 * @constructor
 * @class
 **/
var ScheduleModel = UIModel.extend(/** @lends UIModel.prototype */{
    init: function(data) {
        UIModel.call(this, data);
    },
    defaults: {
        scheduleId: null,
        productRound: null,
        time: null,
        isAvailable: null
    }
});

/**
 * ScheduleNativeSelectView
 * 회차선택UI를 Native Select로 제공한다.
 *
 * @exports ScheduleNativeSelectView
 * @extends {ScheduleView}
 * @constructor
 * @class
 **/
var ScheduleNativeSelectView = ScheduleView.extend(/** @lends ScheduleView.prototype */{
    events: {
        'change': '_onChangeRound'
    },
    availableTmpl: tmplSelectOption,
    init: function(options) {
        ScheduleView.call(this, options);
        this.render();
        //this.IB.listen(this.IB.EVENT.ROUND_SELECT, this._selectOption, this);
    },

    /**
     * 뷰를 그린다
     */
    render: function() {
        this.detachEvents();
        this.$el.empty();
        this.renderDefaultItem();
        this.renderItemsIfNeed();
        this.setInitSelectItemIfNeed();
        this._setStatus();
        this.attachEvents();
    },

    /**
     * 디폴트 옵션을 붙인다
     */
    renderDefaultItem: function() {
        var model,
            item;
        model = new ScheduleModel({
            time : '== 회차를 선택해 주십시요 =='
        });
        item = $(this.template(tmplSelectDefOption, model.toJSON())[0]);
        item.data('model', model);
        this.$el.append(item);
    },

    /**
     * 회차가 변경면 발생되는 이벤트 핸들러
     * @override
     * @private
     */
    _onChangeRound: function() {
        if (this.$el.val()) {
            this.setSelectedItem(this.$el.find(':selected'));
        }
    },

    /**
     * ROUND_SELECT 이벤트 발생시 핸들러
     * @param {String} productRound 선택된 회차
     * @private
     */
    _onRoundSelect: function(productRound) {
        this.$el.val(productRound).trigger('change');
    },

    /**
     * 활성/비활성 상태를 결정한다.
     * @private
     */
    _setStatus: function() {
        this.$el.prop('disabled', !this.collection.length);
    },

    /**
     * 렌더링시 첫번째로 보여질 아이템을 선택한다
     * @param {number} number 옵션의 번호
     */
    setInitialRound: function(number) {
        this.initialRound = number+1;
    },

    /**
     * 아이템을 선택한다
     * @param {HTMLElement} target option태그
     */
    setSelectedItem: function(target) {
        var EVENT = this.IB.EVENT,
            jsonData;
        this.selectedItem = $(target);
        jsonData = this.toJSON();
        if(jsonData){
            this.emit(EVENT.ROUND_SELECTED, jsonData);
        } else {
            this.emit(EVENT.ROUND_UNSELECTED);
        }
    },

    /**
     * UI의 표시하는 값을 JSON데이터로 변환한다.
     * @returns {ScheduleModel}
     */
    toJSON: function() {
        return this.selectedItem && this.selectedItem.data('model').get('productRound') && this.selectedItem.data('model').toJSON();
    }
});

module.exports = ScheduleNativeSelectView;
