/**
 * @fileoverview User 예매에 사용할 InteractBroker
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */
'use strict';

var tkl = ne.tkl,
    API = tkl.API,
    TicketingIB = require('../../ticketingIB');

/**********
 * static props
 **********/
var EVENT = {
    REQUEST_PURCHASE_ALL: 'requestPurchaseAll',
    USER_SUBMIT: 'userSubmit',
    USER_SUCCESS_SUBMIT: 'userSuccessSubmit',
    USER_FAIL_SUBMIT: 'userFailSubmit'
};

/**
 * UserIB
 * @constructor
 * @extends {TicketingIB}
 */
function UserIB() {
    TicketingIB.call(this);
    this._isLocked = false;
    this.addOrder(TicketingIB.EVENT.PURCHASE_SEAT, this._purchaseSeat);
    this.addOrder(TicketingIB.EVENT.ZONE_REMAIN_COUNT_LOADED, this._setZoneRemainCount);
    this.addOrder(TicketingIB.EVENT.UPDATE_NON_RESERVED_SEAT_COUNT, this._updateZoneCount);
    this.addOrder(TicketingIB.EVENT.CONTROL_DESELECT_SEAT, null);
    this.addOrder(TicketingIB.EVENT.CONTROL_DESELECT_ALL_SEAT, null);
    this.addOrder(TicketingIB.EVENT.REQUEST_PURCHASE_ALL, this._requestPurchaseAll);
}

ne.util.inherit(UserIB, TicketingIB);
UserIB.EVENT = ne.util.extend(TicketingIB.EVENT, EVENT);
UserIB.prototype.EVENT = UserIB.EVENT;

/**
 * 잔여좌석 정보 렌더링
 *
 * /user/selectSeat/controller.js 에서 호출함.
 */
UserIB.prototype.renderGradeInfo = function() {
    var gradeInfo = ne.tkl.data.gradeInfo;

    this._setPriceTable(gradeInfo);
    this.emit(this.EVENT.AVAILABLE_SEATINFO_LOADED, gradeInfo);
};

/**
 * 좌석 선택
 * @param {object} param
 *      @param {boolean} param.isReserved   지정석 여부
 *      @param {array} param.seats  좌석 정보
 *      @param {number} param.count 비지정석일 경우 선점 좌석 수
 * @override
 * @private
 */
UserIB.prototype._purchaseSeat = function(param) {
    var isReserved = param.isReserved,
        seats = param.seats,
        count = param.count;
    if (!this._isMaxTicketCountExceeded(seats, isReserved, count)) {
        if (isReserved) {
            this.fire(this.EVENT.ADD_SEATS, seats);
        } else {
            this._updateZoneCount(seats[0].seatId, count);
        }
    }
};


/**
 * 맵에서 좌석 선택 해제 시 로직
 * @param {Object} mapData  map 에서 제공하는 해당 좌석 데이터
 * @override
 * @private
 */
UserIB.prototype._onMapDeselected = function(mapData) {
    var seats;
    if (mapData.r.length > 0) {
        seats = this.parseSeats(mapData.r);
        this.fire(this.EVENT.REMOVE_SEATS, ne.util.map(seats, function(seat) {
            return seat.seatId;
        }));
    } else if (mapData.n.length > 0) {
        seats = this.parseSeats(mapData.n);
        this._updateZoneCount(seats[0].seatId, 0);
    }
};

/**
 * zone 정보 업데이트
 * @param {string} zoneId   비지정석의 ID
 * @param {number} count    업데이트 할 정보
 * @param {string} seatId   Grid 에 추가된 item 의 key 값
 * @private
 */
UserIB.prototype._updateZoneCount = function(zoneId, count, seatId) {
    var remainCount = this._getZoneRemainCount(zoneId, count),
        seatData = this.getSeatDataFromMap(zoneId);
    if (remainCount < 0) {
        alert('예매 가능한 매수를 초과하였습니다.');
    } else {
        this.fire(this.EVENT.SET_NON_RESERVED_SEATS, this.parseSeats(seatData.n), count, null, seatId);
        this.emit(this.EVENT.CONTROL_UPDATE_NON_RESERVED_COUNT, zoneId, remainCount);
    }
};

/**
 * 추가 정보 request override
 * @override
 * @private
 */
UserIB.prototype._requestExtraData = function(){
    this._setCurrentParam();
    this._requseTicketLimitCount();
    this.emit(this.EVENT.UPDATE_SEATING_MAP);
};

/**
 * 등급 정보 노출을 위해 data mapping 한다.
 * @param {Array} gradeList 등급정보 리스트
 * @override
 * @private
 */
UserIB.prototype._setPriceTable = function(gradeList) {
    var productGradeId,
        productGradeName,
        priceTable = {};

    ne.util.forEachArray(gradeList, function(item) {
        productGradeId = item.productGradeId;
        productGradeName = item.name;
        priceTable[productGradeId] = priceTable[productGradeId] || {};
        priceTable[productGradeId].productGradeId = productGradeId;
        priceTable[productGradeId].productGradeName = productGradeName;
        priceTable[productGradeId].list = [];
    });
    this.set('priceTable', priceTable);
    this.emit(this.EVENT.PRICE_LIST_CHANGE, priceTable);
};

/**
 * 선점 API 를 호출하지 않기 때문에
 * makeSeatArea 에서 받은 초기 정보를 토대로 잔여좌석 기초 정보를 생성한다.
 * @param {object} zoneRemainCountMap 잔여 좌석 정보가 담긴 데이터
 * @private
 */
UserIB.prototype._setZoneRemainCount = function(zoneRemainCountMap) {
    this.set('zoneRemainCountMap', zoneRemainCountMap);
};

/**
 * 초기 설정한 정보를 기반으로 잔여좌석 수를 반환한다.
 * @param {string} zoneId 비지정석 ID
 * @param {number} count 선택할 비지정석 개수
 * @returns {number}
 * @private
 */
UserIB.prototype._getZoneRemainCount = function(zoneId, count) {
    var zoneRemainCountMap = this.get('zoneRemainCountMap');
    return zoneRemainCountMap[zoneId] - count;
};

/**
 * 현재 선택된 모든 좌석에 대해 선점 시도한다.
 * @private
 */
UserIB.prototype._requestPurchaseAll = function() {
    var self = this,
        ui = this.get('ui'),
        seatData = ui.selectSeat.toJSON() ? ui.selectSeat.toJSON() : {},
        seatMap = seatData.map,
        seatList = [],
        seatIdList,
        zoneList = [],
        callback = function() {
            self.stopListen(self.EVENT.ENABLE_CHART);
            if (!self.get('isPurchased')) {
                self._controlDeselectAll(true);
                alert('이미 선점된 좌석입니다. 다른 좌석을 선택해주세요.');
                self._locationChange();
            } else {
                self._submit();
            }
        };

    ne.util.forEach(seatMap, function(data) {
        seatList = seatList.concat(data.seatList);
        zoneList = zoneList.concat(data.zoneList);
    });

    seatIdList = ne.util.map(seatList, function(seat) {
        return seat.id;
    });

    this.set('isPurchased', true);
    this._requestPurchaseSeat(seatIdList);

    ne.util.forEachArray(zoneList, function(data) {
        var zoneId = data.zoneId,
            count = data.count;
        this._requestPurchaseNonReservedSeat(zoneId, count);
    }, this);

    if (this.isLocked()) {
        this.listen(this.EVENT.ENABLE_CHART, callback, this);
    } else {
        callback();
    }
};

/**
 * 좌석 선택 완료시 사용할 ticketing data를 생성한다.
 * @override
 * @returns {{productId: *, productTypeCode: *, productDate: *, reserveMemberNo: *, loginMemberNo: *, productRound: *, scheduleId: *, logicalPlanId: *, ticketList: Array}}
 */
UserIB.prototype.getTicketingData = function(){
    var ui = this.get('ui'),
        seatData = ui.selectSeat.toJSON() ? ui.selectSeat.toJSON() : {},
        priceTable = this.get('priceTable'),
        ticketList = [],
        ticketingData;

    ne.util.forEach(priceTable, function(priceList, gradeId) {
        if (seatData.map[gradeId]) {
            var gradeName = '';

            if (ne.util.isExisty(ne.util.pick(priceTable, gradeId, 'productGradeName'))) {
                gradeName =  priceTable[gradeId].productGradeName;
            }

            var obj = {
                productGradeName: gradeName,
                productGradeId: gradeId
            };
            ticketList.push(ne.util.extend(obj, seatData.map[gradeId]));
        }
    });

    ticketingData = {
        isFront: true,
        sellingType: this.get('sellingTypeCode'),
        productId: this.get('productId'),
        productTypeCode: this.get('productTypeCode'),
        productDate: this.get('productDate'),
        reserveMemberNo: this.get('reserveMemberNo'),
        loginMemberNo: this.get('loginMemberNo'),
        productRound: this.get('productRound'),
        scheduleId: this.get('scheduleId'),
        logicalPlanId: this.get('logicalPlanId'),
        ticketList: ticketList
    };

    return ticketingData;
};

/**
 * 중복 submit 을 방지하기 위해 lock 을 건다.
 * @private
 */
UserIB.prototype._lock = function() {
    this._isLocked = true;
};

/**
 * 중복 submit 을 방지하기 위한 lock 을 해제 한다.
 * @private
 */
UserIB.prototype._unlock = function() {
    this._isLocked = false;
};

/**
 * submit 한다.
 * @private
 */
UserIB.prototype._submit = function() {

    if (!this._isLocked) {
        var self = this,
            submitData = this.getTicketingData();
        this._lock();
        self.fire(EVENT.USER_SUBMIT, submitData);
        this.requestToAPI(API.URL.RESERVE_COMPLETE, {
            data: submitData,
            type: 'POST',
            dimmImmediate: true,
            success: function (responseData) {
                self.fire(EVENT.USER_SUCCESS_SUBMIT, responseData);
            },
            fail: function(responseData, responseCode) {
                self.fire(EVENT.USER_FAIL_SUBMIT, responseData, responseCode);
            },
            complete: ne.util.bind(this._unlock, this)
        });
    }
};

/**
 * 지정석 선점 request
 * @param {array} seatList 지정석 리스트
 * @override
 * @private
 */
UserIB.prototype._requestPurchaseSeat = function(seatList) {
    var self = this;
    this.requestToAPI(API.URL.RESERVE_PREOCCUPACY_LIST, {
        data: {
            logicalPlanId: this.get('logicalPlanId'),
            preoccupancyMemberNo: this.get('preoccupancyMemberNo'),
            productId: this.get('productId'),
            scheduleId : this.get('scheduleId'),
            selectedSeats: seatList,
            sellingType: this.get('sellingTypeCode')
        },
        type: 'POST',
        success: function(result) {
            if (result.fail && result.fail.length) {
                self.set('isPurchased', false);
            }
        }
    });
};

/**
 * 비지정석 선점 request
 * @param {string} zoneId 비지정석 ID
 * @param {number} count    선점할 좌석 매수
 * @override
 * @private
 */
UserIB.prototype._requestPurchaseNonReservedSeat = function(zoneId, count) {
    var self = this,
        seatData = this.getSeatDataFromMap(zoneId);

    this.requestToAPI(API.URL.RESERVE_PREOCCUPACY_ZONE, {
        data:  {
            preoccupancyMemberNo: this.get('preoccupancyMemberNo'),
            preoccupancyNo: count,
            allotmentCompanyCode: this.get('sellingTypeCode'),
            zoneId: zoneId,
            logicalPlanId: this.get('logicalPlanId'),
            productId: this.get('productId'),
            scheduleId : this.get('scheduleId')
        },
        type: 'POST',
        success: function(responseData) {
            var allotmentPreoccupancy = responseData.allotmentPreoccupancy;
            self.emit(self.EVENT.CONTROL_UPDATE_NON_RESERVED_COUNT, zoneId, responseData.remainCount);
            if (responseData.status) {
                self.fire(self.EVENT.SET_NON_RESERVED_SEATS, self.parseSeats(seatData.n), count, allotmentPreoccupancy);
            } else {
                self.set('isPurchased', false);
            }
        }
    });
};

/**
 * 좌석 초기화하면 페이지 진입 시 세팅된 zone remain data 로 설정한다.
 * @override
 * @private
 */
UserIB.prototype._onMapDeselectAll = function() {
    this.fire(this.EVENT.MAP_DESELECT_ALL_SEAT);
    this.emit(this.EVENT.INIT_ZONE_REMAIN_COUNT);
};

module.exports = UserIB;
