/**
 * @fileoverview 결제 정보 영역 ui controller
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */
'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    etc = require('../../../../etc');

/**
 * 신용카드 영역
 * @type {*}
 */
var CreditUI = UIController.extend({
    /**
     * 생성자 함수
     * @param {Object} options
     */
    init: function(options) {
        UIController.call(this, options);
        this._initializeElements();
    },

    /**
     * 신용카드 영역의 validation 검사.
     * 현재 spec 에서는 validation 할 부분이 없기 때문에 항상 true 반환
     * @returns {boolean}
     */
    validate: function() {
        return true;
    },

    /**
     * 엘리먼트 바인딩
     * @private
     */
    _initializeElements: function() {
        this.$form = this.$el.find('form:first');
        this.$price = this.$el.find('._totalPrice');
    },

    /**
     * 폼데이터를 반환한다.
     * @returns {*|Object}
     */
    getFormData: function() {
        return etc.form.getFormData(this.$form);
    },

    /**
     * 신용카드 영역을 노출한다.
     * @param data  폼데이터
     */
    show: function(data) {
        this.$el.show();
        etc.form.setFormElementValue(this.$form, 'method', 'credit');
        etc.form.setFormData(this.$form, data);
    },

    /**
     * 신용카드 영역을 감춘다
     */
    hide: function() {
        this.$el.hide();
    },

    /**
     * 현재 data 를 반환한다.
     * @returns {*|Object}
     */
    toJSON: function() {
        var formData = this.getFormData(),
            checkList = [
                'cardNumber',
                'year',
                'month',
                'installment',
                'receipt',
                'cutting',
                'name',
                'phoneNumber'
            ],
            jsonData = {};
        ne.util.forEachArray(checkList, function(name) {
            if (name === 'receipt' || name === 'cutting') {
                formData[name] = !!formData[name];
            }
            jsonData[name] = formData[name];
        });
        return jsonData;
    }
});

/**
 * 현금 영역
 * @type {*}
 */
var CashUI = UIController.extend({
    events: {
        'keyup ._cashAmount': '_onKeyUp',
        'blur ._cashAmount': '_onBlur',
        'focus ._cashAmount': '_onFocus',
        'change ._cashReceipt': '_onChangeReceipt'
    },

    /**
     * 생성자 함수
     * @param {Object} options
     */
    init: function(options) {
        UIController.call(this, options);
        this._initializeElements();
        this.attachEvents();
        this.totalPrice = 0;
        this.cashAmount = 0;
        this.changeAmount = 0;
    },

    /**
     * 결제 금액이 충분한지 여부를 계산한다.
     * @returns {boolean}   결제 금액이 충분한지 여부(X) validation 스펙아웃됨
     */
    validate: function() {
        return true;
    },

    /**
     * 엘리먼트 바인딩
     * @private
     */
    _initializeElements: function() {
        this.$form = this.$el.find('form:first');
        this.$price = this.$el.find('._totalPrice');
        this.$amount = this.$el.find('._cashAmount');
        this.$change = this.$el.find('._cashChange');
        this.$cardNumber = this.$el.find('._cardNumber');
        this.$receiptType = etc.form.getFormElement(this.$form, 'receiptType');
        this.$el.find('._cashReceipt').prop('checked', false);
        this.$cardNumber.prop('disabled', true);
        this.$receiptType.prop('disabled', true);

        etc.setInputPattern(this.$cardNumber, /\d/g);
    },

    /**
     * 받은 금액 focus 이벤트 핸들러
     * @private
     */
    _onFocus: function() {
        var amount = this._toNumber(this.$amount.val()) || '';
        this.$amount.val(amount);
    },

    /**
     * 받은 금액 blur 이벤트 핸들러
     * @private
     */
    _onBlur: function() {
        this.$amount.val(etc.formatNumber(this.$amount.val()));
    },

    /**
     * 받은금액 keyup 이벤트 핸들러
     * @private
     */
    _onKeyUp: function() {
        this.setCashChangeAmount();
    },

    /**
     * 현금영수증 체크 상태 변경시
     * @param {event} changeEvent
     * @private
     */
    _onChangeReceipt: function(changeEvent) {
        var $target = $(changeEvent.target),
            isChecked = $target.prop('checked');

        this.$cardNumber.prop('disabled', !isChecked);
        this.$receiptType.prop('disabled', !isChecked);
    },

    /**
     * 거스름돈 계산
     */
    setCashChangeAmount: function() {
        var totalPrice = this.totalPrice = this._getTotalPrice(),
            cashAmount = this.cashAmount = this._toNumber(this.$amount.val()),
            changeAmount = this.changeAmount = cashAmount - totalPrice;
        this.$change.val(etc.formatNumber(changeAmount));
    },

    /**
     * 산술 계산을 위해 1000,000 와 같이 포멧팅된 숫자 문자열을 number 형태로 형변환한다.
     * @param {String} str 숫자 문자열
     * @returns {number} 변경된 결과값
     * @private
     */
    _toNumber: function(str) {
        str = str || '';
        return +str.replace(/\,/g, '') || 0;
    },

    /**
     * 총액을 반환한다.
     * @returns {number} 총액
     * @private
     */
    _getTotalPrice: function() {
        var totalPrice = this._toNumber(this.$price.text());
        return totalPrice;
    },

    /**
     * 폼 데이터를 반환한다.
     * @returns {*|Object}
     */
    getFormData: function() {
        return etc.form.getFormData(this.$form);
    },

    /**
     * 현금 영역을 노출한다
     */
    show: function(data) {
        this.$amount.val('');
        this.$change.val('');
        this.$el.show();
        etc.form.setFormElementValue(this.$form, 'method', 'cash');
        etc.form.setFormData(this.$form, data);
    },

    /**
     * 현금 영역을 감춘다
     */
    hide: function() {
        this.$el.hide();
    },

    /**
     * 현재 data 를 반환한다.
     * @returns {*|Object}
     */
    toJSON: function() {
        var formData = this.getFormData(),
            checkList = [
                'receiptType',
                'cardNumber',
                'cashReceipt',
                'receipt',
                'cutting',
                'name',
                'phoneNumber'
            ],
            jsonData = {};
        ne.util.forEachArray(checkList, function(name) {
            if (name === 'receipt' || name === 'cutting' || name === 'cashReceipt') {
                formData[name] = !!formData[name];
            }
            jsonData[name] = formData[name];
        });
        return jsonData;
    }
});

/**
 * 결제 전체 영역
 * @type {*}
 */
var PaymentUI = UIController.extend({
    events: {
        'change ._method': '_onMethodChange'
    },

    /**
     * 생성자 함수
     * @param {Object} options
     */
    init: function(options) {
        UIController.call(this, options);
        this.view = {};
        this.type = '';
        this.attachEvents();
        this._initializeElements();
        this._setPaymentMethod('credit');
    },

    /**
     * 엘리먼트 바인딩
     * @private
     */
    _initializeElements: function() {
        this.view.cash = new CashUI({
            IB: this.IB,
            rootElement: this.$el.find('._cash')
        });
        this.view.credit = new CreditUI({
            IB: this.IB,
            rootElement: this.$el.find('._credit')
        });
        this.$priceList = this.$el.find('._totalPrice');
        this.totalPrice = 0;
    },

    /**
     * 총액을 노출한다.
     * @param {Number|String} totalPrice    총액
     */
    setTotalPrice: function(totalPrice) {
        this.totalPrice = totalPrice;
        this.$priceList.text(etc.formatNumber(totalPrice));
        this.view.cash.setCashChangeAmount();
    },

    /**
     * 데이터를 반환한다.
     * @returns {*}
     */
    toJSON: function() {
        var type = this.type,
            view = this.view[type],
            jsonData = {
                data: view.toJSON(),
                type: type
            };

        jsonData.data.amount = this.totalPrice;
        return jsonData;
    },

    /**
     * 지불 정보를 설정한다.
     * @param {String} type 현금 또는 신용카드 여부 "cash" "credit"
     * @private
     */
    _setPaymentMethod: function(type) {
        var openTarget,
            closeTarget,
            data;
        if (type === 'cash') {
            openTarget = this.view.cash;
            closeTarget = this.view.credit;
        } else {
            openTarget = this.view.credit;
            closeTarget = this.view.cash;
        }
        this.type = type;
        data = closeTarget.getFormData();
        closeTarget.hide();
        openTarget.show({
            receipt: data.receipt,
            cutting: data.cutting,
            name: data.name,
            phoneNumber: data.phoneNumber
        });
    },

    /**
     * 지불 방식이 변경되었을때 이벤트 핸들러
     * @param {Event} changeEvent
     * @private
     */
    _onMethodChange: function(changeEvent) {
        var $target = $(changeEvent.target),
            type = $target.val();
        this._setPaymentMethod(type);
    },

    /**
     * 관람자 혹은 연락처가 입력되었는지 유효성 검사를 한다.
     * @returns {boolean}
     */
    validate: function() {
        var type = this.type,
            view = this.view[type];

        return view.validate();
    }
});

module.exports = PaymentUI;
