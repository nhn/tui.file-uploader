/**
 * @fileoverview 현장, 기획사, 예매처 컨트롤러
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */

'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    API = tkl.API,
    FloatingUI = require('../../../common/floating'),
    MapController = require('../../common/mapController'),
    SelectSeatUI = require('../../common/selectSeat'),
    SelectTicketUI = require('../../common/selectTicket'),
    SelectAdditionalUI = require('../../common/selectAdditional'),
    LayerUI = require('../../common/layer'),
    NSeatCounter = require('../../common/nSeatCounter'),
    SelectSchedule = require('../../common/selectSchedule'),
    ScheduleNativeSelectView = require('../../common/scheduleNativeSelectView'),
    SeatingInfoPerRound = require('../../common/seatingInfoPerRound'),
    ProductInfoUI = require('../../common/productInfo'),
    DashBoardUI = require('../../common/dashBoard'),
    PaymentUI = require('./payment'),
    UserInfoUI = require('../../common/userInfo'),
    etc = require('../../../../etc'),
    tmplDashBoardRow = require('../../../../../tmpl/ticketing/dashBoard/adminRow.html'),
    tmplSelectTicketMain = require('../../../../../tmpl/ticketing/selectTicket/mainSimple.html'),
    tmplInformation = require('../../../../../tmpl/ticketing/information/system.html');

/**
 * 현장, 기획사, 예매처 컨트롤러
 * @exports Purchase
 * @extends {UIController}
 * @constructor
 * @class
 */
var Purchase = UIController.extend({
    rootElement: $('#content'),
    events: {
        'click .cal': '_onCalClicked',
        'click .calendar': '_stopEventChain',
        'click ._ticketSubmit': '_onClickSubmit',
        'click ._ticketCancel': '_onClickCancel'
    },
    /**
     * 생성자
     * @param {Object} options
     */
    init: function(options) {
        UIController.call(this, options);
        this._isLocked = false;
        this.params = options.params;
        this.mapOptions = options.mapOptions;
        this._initializeElements();
        this._initializeUI();
        this._initializeListeners();
        this._attachExtraEvents();
        this.attachEvents();
        this._renderDateRangeText();
        this._initializeStatus();
    },

    /**
     * event listener 초기화
     * @private
     */
    _initializeListeners: function() {
        this.listen(this.IB.EVENT.CALENDAR_RENDERED, ne.util.bind(this._renderDateRangeText, this));
        this.listen(this.IB.EVENT.DATE_SELECTED, ne.util.bind(this._onDateSelected, this));
        this.listen(this.IB.EVENT.TOTAL_PRICE_CHANGE, ne.util.bind(this._onTotalPriceChange, this));
    },

    /**
     * 전체 가격이 변경되었을때 이벤트 핸들러
     * @private
     */
    _onTotalPriceChange: function() {
        var ui = this.ui,
            totalPrice = ui.selectTicket.toJSON().price + ui.selectAdditional.toJSON().price;
        ui.payment.setTotalPrice(totalPrice);
    },

    /**
     * 엘리먼트 바인딩
     * @private
     */
    _initializeElements: function() {
        this.$dateContainer = this.$el.find('._date');
        this.$selectedDate = this.$el.find('#selectedDate');
    },

    /**
     * UI instance 초기화
     * @private
     */
    _initializeUI: function() {
        var ui = this.ui = {};
        ui.floating =  new FloatingUI('#dimmed');
        ui.floating.setIB(this.IB);
        ui.mapController = new MapController({
            IB: this.IB,
            rootElement: $('body')
        });
        ui.dashBoard = new DashBoardUI({
            IB: this.IB,
            rootElement: $('._dashBoard'),
            template: tmplDashBoardRow
        });
        //상품 정보 영역
        ui.productInfo = new ProductInfoUI({
            IB: this.IB,
            rootElement: $('._productInfo'),
            template: tmplInformation
        });
        //사용자 정보 영역
        ui.userInfo = new UserInfoUI({
            IB: this.IB,
            rootElement: $('._userInfo')
        });
        //날짜선택
        ui.selectSchedule = new SelectSchedule({
            IB: this.IB,
            type: SelectSchedule.TYPE.BASIC,
            //date: new Date(),
            seatingInfoPerRound: new SeatingInfoPerRound({
                IB: this.IB,
                type: SeatingInfoPerRound.TYPE.SELECTABLE
            }),
            scheduleView: new ScheduleNativeSelectView({
                IB: this.IB
            })
        });
        //좌석 선택 영역 UI
        ui.selectSeat = new SelectSeatUI({
            rootElement: $('._selectSeat'),
            IB: this.IB,
            grid: {
                color: {
                    border: '#FFFFFF'
                },
                className: {
                    table: 'seat_list'
                },
                height: 92
            }
        });
        //비지정석 매수입력
        ui.seatCounter = new NSeatCounter({IB: this.IB});
        //레이어 UI
        ui.layer = new LayerUI({
            rootElement: $('._tooltip')
        });
        //티켓 선택 영역 UI
        ui.selectTicket = new SelectTicketUI({
            rootElement: $('._selectTicket'),
            IB: this.IB,
            layer: this.ui.layer,
            templateData: {
                main: tmplSelectTicketMain
            }
        });
        //부가상품 영역 UI
        ui.selectAdditional = new SelectAdditionalUI({
            rootElement: $('._selectAdditional'),
            IB: this.IB
        });
        //결제방법 선택
        ui.payment = new PaymentUI({
            rootElement: $('._payment'),
            IB: this.IB
        });
        this.IB.set('ui', this.ui);
    },

    /**
     * 초기화 파라미터로 넘어온 정보를 토대로 현재 상태를 초기화 한다.
     * @private
     */
    _initializeStatus: function() {
        var params = this.params;
        if (params) {
            this._initializeProductId();
        }
    },

    /**
     * productId 가 설정되어 있다면 UI에 노출한다.
     * @private
     */
    _initializeProductId: function() {
        var params = this.params;
        if (ne.util.isExisty(ne.util.pick(params, 'productId'))) {
            this.IB.emit(this.IB.EVENT.SHOW_PRELOADER);
            if (ne.util.isExisty(ne.util.pick(params, 'productDate'))) {
                this.IB.listen(this.IB.EVENT.AVAILABLE_DATES_LOADED, this._initializeProductDate, this);
            }
            this.IB.emit(this.IB.EVENT.PRODUCT_CHANGE, params.productId);
        } else {
            this.IB.emit(this.IB.EVENT.HIDE_PRELOADER);
        }
    },

    /**
     * productDate 가 설정되어 있다면 UI에 노출한다.
     * @private
     */
    _initializeProductDate: function() {
        this.IB.emit(this.IB.EVENT.SHOW_PRELOADER);
        this.IB.stopListen(this.IB.EVENT.AVAILABLE_DATES_LOADED, this);
        var params = this.params;
        if (ne.util.isExisty(ne.util.pick(params, 'productRound'))) {
            this.IB.listen(this.IB.EVENT.ROUND_LOADED, this._initializeProductRound, this);
        }
        this.IB.emit(this.IB.EVENT.DATE_SELECT, params.productDate);
    },

    /**
     * 회차 정보가 넘어왔다면 회차정보를 업데이트한다.
     * @private
     */
    _initializeProductRound: function() {
        this.IB.emit(this.IB.EVENT.SHOW_PRELOADER);
        this.IB.stopListen(this.IB.EVENT.ROUND_LOADED, this);
        this.IB.emit(this.IB.EVENT.ROUND_SELECT, this.params.productRound);
    },

    /**
     * $el 외부 이벤트 핸들러 바인딩
     * @private
     */
    _attachExtraEvents: function() {
        $('body').on(this.getEventNameWithNamespace('click'), ne.util.bind(this.closeCalendar, this));
    },

    /**
     * 날짜 선택 이벤트 핸들러
     * @private
     */
    _onDateSelected: function() {
        this._renderDateRangeText();
    },

    /**
     * 날짜 정보 표기하는 영역에 날짜정보를 표기한다. 
     * @private
     */
    _renderDateRangeText: function() {
        var dateList = this.ui.selectSchedule.toJSONDate(),
            now = new Date(),
            str;
        if (ne.util.isExisty(this.IB.get('productDate')) && dateList.length > 0) {
            if(dateList.length === 2) {
                str = dateList[0] + ' ~ ' + dateList[1];
            } else {
                str = dateList[0];
            }
        } else {
            str = etc.getDateString(now.getTime());
        }
        this.$selectedDate.html(str.split('-').join('.'));
    },

    /**
     * 캘린더 click 시
     * @param {Event} e 이벤트
     * @private
     */
    _onCalClicked: function(e) {
        e.preventDefault();
        e.stopPropagation();
        if (this.$dateContainer.hasClass('on')) {
            this.closeCalendar();
        } else {
            this.openCalendar();
        }
    },

    /**
     * 이벤트 버블링 방지를 위한 메서드
     * @param {Event} e 이벤트
     * @private
     */
    _stopEventChain: function(e) {
        var $target = $(e.target);
        if ($target.closest('a').length) {
            e.stopPropagation();
        }
    },

    /**
     * 티켓출력 버튼 이벤트 핸들러
     * @private
     */
    _onClickSubmit: function() {
        var submitData = this.IB.getTicketingData(),
            paymentData = this.ui.payment.toJSON();

        submitData.payment = {};
        submitData.payment[paymentData.type] = paymentData.data;

        if (this.IB.validateTicketingData(submitData) && this.ui.payment.validate()) {
            this._submit(submitData);
        }
    },

    /**
     * 중복 submit 을 방지하기 위해 lock 을 건다.
     * @private
     */
    _lock: function() {
        this._isLocked = true;
    },

    /**
     * 중복 submit 을 방지하기 위한 lock 을 해제 한다.
     * @private
     */
    _unlock: function() {
        this._isLocked = false;
    },

    /**
     * submit
     * @param submitData
     * @private
     */
    _submit: function(submitData) {
        if (!this._isLocked) {
            this._lock();
            this.fireEvent('onSubmit', submitData);
            this.IB.requestToAPI(API.URL.RESERVE_COMPLETE, {
                data: submitData,
                type: 'POST',
                dimmImmediate: true,
                success: ne.util.bind(this._onSuccessSubmit, this),
                fail: ne.util.bind(this._onFailSubmit, this),
                complete: ne.util.bind(this._unlock, this)
            });
        }
    },

    /**
     * submit success 이벤트 핸들러
     * @param {object} responseData 응답 데이터
     * @private
     */
    _onSuccessSubmit: function(responseData) {
        this.fireEvent('onSuccessSubmit', responseData);
    },

    /**
     * submit fail 이벤트 핸들러
     * @param {object} responseData 응답 데이터
     * @param {Number}  responseCode 응답 코드
     * @private
     */
    _onFailSubmit: function(responseData, responseCode) {
        this.fireEvent('onFailSubmit', responseData, responseCode);
    },

    /**
     * 취소 버튼 클릭시 이벤트 핸들러
     * @private
     */
    _onClickCancel: function() {
        if (confirm('설정된 정보가 초기화 됩니다.\n계속 진행 하시겠습니까?')) {
            this.IB.emit(this.IB.EVENT.UI_RESET);
        }
    },

    /**
     * 캘린더를 닫는다.
     */
    closeCalendar: function() {
        this.$dateContainer.removeClass('on');
    },

    /**
     * 캘린더를 노출한다.
     */
    openCalendar: function() {
        this.$dateContainer.addClass('on');
    }
});

module.exports = Purchase;
