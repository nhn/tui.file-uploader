/**
 * @fileoverview SelectSchedule
 * @author FE개발팀 김성호 sungho-kim@nhnent.com
 */

'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    UIModel = require('../../../ui/model'),
    UICollection = require('../../../ui/collection'),
    etc = require('../../../etc');

/**
 * 날짜를 표현하는 Model
 * @exports ScheduleDate
 * @extends {UIModel}
 * @constructor
 * @class
 */
var ScheduleDate = UIModel.extend({
    init: function(data) {
        UIModel.call(this, data, {
            parse: true
        });
    },
    defaults: {
        year: null,
        month: null,
        date: null
    },
    parse: function(data) {
        //유효한 날의 모델도 되고 현재날짜의 모델도될수있다.
        var parsedData = this.getParsedTimeDataFromString(data.productDate || data.currentDate);
        return parsedData;
    },

    /**
     * 날짜를 넘겨 현 ScheduleDate와 같은 날짜인지 리턴한다.
     * @param {number} year
     * @param {number} month
     * @param {number} date
     * @returns {boolean}
     */
    isEqualDate: function(year, month, date) {
        if (ne.util.isObject(year)) {
            month = year.month;
            date = year.date;
            year = year.year;
        }
        return this.get('year') === year && this.get('month') === month && this.get('date') === date;
    },

    /**
     * 데이터를 조합하여 스트링형태로 리턴함
     * @returns {string}
     */
    toStr: function() {
        var tmpArr = [],
            dateList;
        tmpArr.push(this.get('year'));
        tmpArr.push(this.get('month'));
        tmpArr.push(this.get('date'));
        dateList = ne.util.map(tmpArr, function(value) {
            return (value > 9 ? '' : '0') + value;
        });
        return dateList.join('.');
    },

    /**
     * 현재 선택된 날짜 정보를 반환한다.
     * @returns {{productDate: string}}
     */
    toJSON: function() {
        if (this.get('year') && this.get('month') && this.get('date')) {
            return {'productDate': this.toStr()};
        }
    },

    /**
     * 날짜 데이터가 셋팅 되어있는지를 체크한다.
     * @returns {boolean}
     */
    isSet: function() {
        return this.get('year') && this.get('month') && this.get('date');
    },

    /**
     * timestamp를 이용해 날짜데이터 객체를 얻어온다.
     * @returns {object}
     */
    getParsedTimeDataFromString: function(dateString) {
        var tmpList = dateString ? dateString.split('.') : [null, null, null],
            parsedData = {};
        parsedData.year = +tmpList[0];
        parsedData.month = +tmpList[1];
        parsedData.date = +tmpList[2];
        return parsedData;
    }
});

var ScheduleDateCollection = UICollection.extend({
    init: function(models) {
        UICollection.call(this, models);
    },
    model: ScheduleDate,
    /**
     * 날짜를 넘겨 해당 날짜가 컬럭션에 존재하는지 비교한다.
     * @param {number} year 년도
     * @param {number} month 월
     * @param {number} date 일
     * @returns {boolean}
     */
    hasEqualDate: function(year, month, date) {
        var res = false;
        this.forEach(function(aDate) {
            if (aDate.isEqualDate(year, month, date)) {
                res = true;
                return false;
            }
        });
        return res;
    }
});
/**
 * SelectSchedule
 * @exports SelectSchedule
 * @extends {UIController}
 * @constructor
 * @class
 * **/
var SelectSchedule = UIController.extend({
    rootElement: $('#calendar'),
    events: {
        'click td a': '_onDateClicked'
    },
    titleNumberTmpl: '<span class="num<%=addClassStr%>"><%=char%></span>',

    /**
     * 생성자
     * @param {Object} options
     * @constructor
     */
    init: function SelectSchedule(options) {
        UIController.call(this, options);
        this._initializeElements();

        this.type = options.type !== undefined ? options.type : SelectSchedule.TYPE.WITHSEATSELECT;

        this.defaultDate = options && options.date;
        this.currentDate = new ScheduleDate();
        this.availableDates = new ScheduleDateCollection();
        this.seatingInfoPerRound = options.seatingInfoPerRound;
        this.scheduleView = options.scheduleView;

        this.IB.listen(this.IB.EVENT.AVAILABLE_DATES_LOADED, this._onScheduleDateCollectionLoaded, this);

        //초기화를 위해 순영 추가.
        this.IB.listen(this.IB.EVENT.DATE_SELECT, this.setCurrentDateFromStr, this);
        this._initCalendar();

        this.render();
    },

    /**
     * 엘리먼트를 변수에 캐싱한다.
     * @private
     */
    _initializeElements: function() {
        this.$calTitle = this.$el.find('.ui-datepicker-title');
        this.$calPrev = this.$el.find('.ui-datepicker-prev');
        this.$calNext = this.$el.find('.ui-datepicker-next');
    },

    /**
     * 새로운 스케쥴이 로드될 경우 내부 콜랙션 데이터를 설정한다.
     * @param {Object} data 서버로 부터 받아온 스케쥴 데이터
     * @private
     */
    _onScheduleDateCollectionLoaded: function(data) {
        this.currentDate.clear();
        this.currentDate = new ScheduleDate();

        if (this.defaultDate) {
            this.setCurrentDateFromStr(this.defaultDate);
        }

        this.setScheduleDateCollections(data);
        this.render();
    },

    /**
     * 캘린더를 인스턴스화하고 각종 이벤트를 셋팅한다.
     */
    _initCalendar: function() {
        this.cal = new ne.component.Calendar({
            bDrawOnload: false
        }, this.$el);
        this.cal.on('afterDraw', this._onCalAfterDraw, this);
        this.cal.on('draw', this._onCalDraw, this);
    },

    /**
     * 캘린더의 afterDraw 발생시 이벤트 핸들러
     * @param {Object} customEvent 캘린더의 커스텀 이벤트
     * @private
     */
    _onCalAfterDraw: function(customEvent) {
        var titleData = this.getTitleNumberData(customEvent.year + '.' + customEvent.month),
            compiledTmpl = this.template(this.titleNumberTmpl, titleData);
        this.$calTitle.html(compiledTmpl);
    },

    /**
     * 캘린더 draw 발생시 이벤트 핸들러
     * @param {Object} customEvent 캘린더의 커스텀 이벤트
     * @private
     */
    _onCalDraw: function(customEvent) {
        var $cDate,
            $date = customEvent.$date,
            year = customEvent.year,
            month = customEvent.month,
            date = customEvent.date;
        if (this.hasEqualScheduleDateCollection(year, month, date)) {
            if (this._isSeasonTicket() || this.isEqualCurrentDate(year, month, date)) {
                $date.addClass('selected');
            }
            $cDate = $('<a href="#">' + date + '</a>');
            $cDate.data('date', {
                year: year,
                month: month,
                date: date
            });
            $date.empty();
            $date.append($cDate);
        }
    },

    /**
     * 날력의 타이틀에 해당하는 이미지넘버를 표현하기위한 데이터생성
     * @returns {object}
     */
    getTitleNumberData: function(yearMonthStr) {
        var data = [];
        ne.util.forEachArray(yearMonthStr.split(''), function(char) {
            data.push({
                addClassStr: char === '.' ? '_dot' : char,
                char: char
            });
        });
        return data;
    },

    /**
     * 랜더링한다.
     */
    render: function() {
        this.detachEvents();
        this.renderCalendar();
        if (!this._isSeasonTicket()) {
            this.attachEvents();
        }
        this.IB.emit(this.IB.EVENT.CALENDAR_RENDERED);
    },

    /**
     * 기간권인지 여부를 반환한다.
     * @return {Boolean}
     * @private
     */
    _isSeasonTicket: function() {
        if (ne.util.isFunction(this.IB.isSeasonTicket)) {
            return this.IB.isSeasonTicket();
        } else {
            return false;
        }
    },

    /**
     * 캘린더를 그린다.
     */
    renderCalendar: function() {
        var calendarDate = this.getInitialCalendarDate();
        if (calendarDate) {
            this.cal.draw(calendarDate.get('year'), calendarDate.get('month'));
        } else {
            this.cal.draw();
        }
    },

    /**
     * 캘린더를의 초기위치에 해당하는 날짜를 리턴해준다.
     * @returns {ScheduleDate}
     */
    getInitialCalendarDate: function() {
        if (this.currentDate.isSet()) {
            return this.currentDate;

        //현재 선택된 날짜가 없으면 가용한 날중 첫번째 날짜의 달로 초기달을 선택한다
        } else if (this.availableDates.length && this.availableDates.at(0).isSet()){
            return this.availableDates.at(0);
        }
    },

    /**
     * API에서 전달된 예약가능한 날짜정보로 모델을 갱신한다.
     * @param {object[]} data 날짜정보
     */
    setScheduleDateCollections: function(data) {
        this.availableDates.set(data);
    },

    /**
     * 해당 날짜 데이터가 선택된(활성화된) 날짜인지 아닌지를 리턴해준다.
     * @param {string} year 년도
     * @param {string} month 월
     * @param {string} date 일
     * @returns {boolean}
     */
    isEqualCurrentDate: function(year, month, date) {
        return this.currentDate.isEqualDate(year, month, date);
    },

    /**
     * 해달 날짜데이터가 예약가능한 날짜 인지 아닌지를 리턴해준다.
     * @param {string} year 년도
     * @param {string} month 월
     * @param {string} date 일
     * @returns {boolean}
     */
    hasEqualScheduleDateCollection: function(year, month, date) {
        return this.availableDates.hasEqualDate(year, month, date);
    },

    /**
     * 날짜 선택 이벤트 핸들러
     */
    _onDateClicked: function(e) {
        var target = $(e.currentTarget),
            targetDate = target.data('date');

        e.preventDefault();

        if (!this.currentDate.isEqualDate(targetDate)) {
            if (ne.util.isFunction(this.IB.confirmResetSeatingList) && !this.IB.confirmResetSeatingList()) {
                return;
            }
            this.dateSelected(targetDate);
        }
    },

    /**
     * 날짜를 선택하고 켈린더를 리로드한다.
     * @param targetDate
     * @param {string} targetDate.year 년도
     * @param {string} targetDate.month 월
     * @param {string} targetDate.date 일
     */
    dateSelected: function(targetDate) {
        this.setCurrentDate(targetDate);
        this.render();
    },

    /**
     * 문자열을 인자로 받아 현재 날짜를 설정한다.
     * @param {String} targetDate   날짜 문자열 - '2015-03-23'
     */
    setCurrentDateFromStr: function(targetDate) {
        var dateList;
        if (targetDate) {
            dateList = targetDate.split('.');
            if (dateList.length === 3) {
                this.dateSelected({
                    year: parseInt(dateList[0], 10),
                    month: parseInt(dateList[1], 10),
                    date: parseInt(dateList[2], 10)
                });
            }
        }
    },

    /**
     * 선택된날(활성화)의 모델을 셋팅하고 이벤트를 발생시킨다.
     * @param targetDate
     * @param {string} targetDate.year 년도
     * @param {string} targetDate.month 월
     * @param {string} targetDate.date 일
     */
    setCurrentDate: function(targetDate) {
        this.currentDate.set(targetDate);
        if (!this._isSeasonTicket()) {
            this.emit(this.IB.EVENT.DATE_SELECTED, this.currentDate.toJSON());
        }
    },

    /**
     * timestamp로 날짜를 선택한다.
     * @param {Number} timestamp    timestamp
     */
    setCurrentDateFromTimestamp: function(timestamp) {
        this.setCurrentDate(this.currentDate.getParsedTimeDataFromString(timestamp));
    },

    /**
     * 외부에서 컴포넌트 형태로 사용할 때 이 메서드를 호출한다.
     * @returns {Object}    날짜 정보
     */
    toJSON: function() {
        var dateData = this.currentDate.toJSON(),
            roundData = this.scheduleView.toJSON();
        return ne.util.extend({}, dateData, roundData);
    },

    /**
     * Array 형태로 현재 선택된 날짜 혹은 범위를 반환한다.
     * @returns {Array} ['2015.03.26'] 혹은 ['2015.03.26', '2015.03.30'] 의 형태로 반환
     */
    toJSONDate: function() {
        var lastIndex,
            returnVal = [];
        if (this._isSeasonTicket() && this.availableDates.length) {
            lastIndex = this.availableDates.length - 1;
            returnVal.push(this.availableDates.at(0).toStr());
            returnVal.push(this.availableDates.at(lastIndex).toStr());
        } else {
            returnVal.push(this.currentDate.toStr());
        }
        return returnVal;
    },

    /**
     * 다음 월 선택 버튼을 활성화 한다.
     */
    enableNext: function() {
        this.$calNext.show();
    },

    /**
     * 이전 월 선택 버튼을 활성화 한다.
     */
    enablePrev: function() {
        this.$calPrev.show();
    },

    /**
     * 다음 월 선택 버튼을 비활성화 한다.
     */
    disableNext: function() {
        this.$calNext.hide();
    },

    /**
     * 이전 월 선택 버튼을 비활성화 한다.
     */
    disablePrev: function() {
        this.$calPrev.hide();
    },
    static: {
        TYPE: {
            BASIC: 0,
            WITHSEATSELECT: 1
        }
    }
});

module.exports = SelectSchedule;
