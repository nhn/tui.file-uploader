/**
 * @fileoverview 사용자 예매의 UI 컨트롤러
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */
'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    FloatingUI = require('../../../common/floating'),
    MapController = require('../../common/mapController'),
    SelectSeatUI = require('../../common/selectSeat'),
    DashBoardUI = require('../../common/dashBoard'),
    nSeatCounterLayer = require('./nSeatCounterLayer'),
    tmplDashBoardRow = require('../../../../../tmpl/ticketing/dashBoard/userRow.html');

/**
 * 사용자 예매 컨트롤러
 * @exports SelectSeatController
 * @extends {UIController}
 * @constructor
 * @class
 */
var SelectSeatController = UIController.extend({
    rootElement: $('body'),
    events: {
        'mouseover ._base': '_showLayer',
        'mouseout ._base': '_hideLayer',
        'click ._prev': '_onClickPrev',
        'click ._next': '_onClickNext'
    },

    /**
     * 생성자
     * @param options
     */
    init: function(options) {
        UIController.call(this, options);
        this.params = options.params;
        this.mapOptions = options.mapOptions;
        this.detachEvents();
        this._initializeElements();
        this._initializeUI();
        this._initializeListeners();
        this.attachEvents();
        this._initializeStatus();
    },

    /**
     * 엘리먼트 초기화
     * @private
     */
    _initializeElements: function() {
        this.$layer = this.$el.find('._layer');
    },

    /**
     * IB 리스너 설정
     * @private
     */
    _initializeListeners: function() {
        this.IB.listen(this.IB.EVENT.USER_SUCCESS_SUBMIT, this._onSuccessSubmit, this);
        this.IB.listen(this.IB.EVENT.USER_FAIL_SUBMIT, this._onFailSubmit, this);
        this.IB.listen(this.IB.EVENT.USER_SUBMIT, this._onSubmit, this);
    },

    /**
     * UI 설정
     * @private
     */
    _initializeUI: function() {
        var ui = this.ui = {};
        ui.floating =  new FloatingUI('#dimmed');
        ui.floating.setIB(this.IB);
        ui.mapController = new MapController({
            IB: this.IB,
            rootElement: $('body')
        });
        ui.dashBoard = new DashBoardUI({
            IB: this.IB,
            rootElement: $('._dashBoard'),
            skipRender: false,
            template: tmplDashBoardRow
        });
        //좌석 선택 영역 UI
        ui.selectSeat = new SelectSeatUI({
            rootElement: $('._selectSeat'),
            IB: this.IB,
            grid: {
                height: 106,
                color: {
                    border: '#d4d4d4'
                },
                columnModelList: [
                    {
                        columnName: 'productGradeName',
                        width: 65,
                        formatter: function(value) {
                            return value;
                        }
                    },
                    {
                        columnName: 'seatAttributeInfo',
                        formatter: function(value) {
                            return value;
                        }
                    }
                ]
            }
        });
        //비지정석 매수입력 레이어
        ui.nSeatCounterLayer = new nSeatCounterLayer({
            rootElement: $('._nSeatCounterLayer'),
            IB: this.IB
        });

        this.IB.renderGradeInfo();
        this.IB.set('ui', this.ui);
    },

    /**
     * 초기 상태 설정
     * @private
     */
    _initializeStatus: function() {
        var params = this.params;
        if (
            ne.util.isExisty(ne.util.pick(params, 'productId')) &&
            ne.util.isExisty(ne.util.pick(params, 'productDate')) &&
            ne.util.isExisty(ne.util.pick(params, 'productRound')) &&
            ne.util.isExisty(ne.util.pick(params, 'logicalPlanId'))
        ) {
            this.IB.set('productId', params.productId);
            this.IB.set('productDate', params.productDate);
            this.IB.emit(this.IB.EVENT.ROUND_SELECTED, {
                productRound: params.productRound,
                logicalPlanId: params.logicalPlanId,
                scheduleId: params.scheduleId
            });
        } else {
            this.IB.emit(this.IB.EVENT.HIDE_PRELOADER);
        }
    },

    /**
     * 이전 버튼 클릭시
     * @private
     */
    _onClickPrev: function() {
        if (this.IB.confirmResetSeatingList()) {
            this.fireEvent('onClickPrev');
        }
    },

    /**
     * 다음 버튼 클릭시
     * @private
     */
    _onClickNext: function() {
        var seatData = this.IB.getSelectedSeats(),
            seatList = seatData.list;
        if (seatList.length) {
            this.IB.emit(this.IB.EVENT.REQUEST_PURCHASE_ALL);
        } else {
            alert('좌석을 선택해주세요.');
        }
    },

    /**
     * 좌석 선택 완료 데이터 요청 시
     * @param {Object} submitData    요청 보낼 데이터
     * @private
     */
    _onSubmit: function(submitData) {
        this.fireEvent('onSubmit', submitData);
    },

    /**
     * 좌석 선택 완료 성공시
     * @param {Object} responseData 응답 데이터
     * @private
     */
    _onSuccessSubmit: function(responseData) {
        this.IB.set('preventUnloadHandler', true);
        this.IB.disableUnloadCheck();
        this.fireEvent('onSuccessSubmit', responseData);
    },

    /**
     * submit fail 이벤트 핸들러
     * @param {object} responseData 응답 데이터
     * @param {Number}  responseCode 응답 코드
     * @private
     */
    _onFailSubmit: function(responseData, responseCode) {
        this.fireEvent('onFailSubmit', responseData, responseCode);
    },

    /**
     * 선점 안내 레이어 노출
     * @private
     */
    _showLayer: function() {
        this.$layer.show();
    },

    /**
     * 선점 안내 레이어 숨김
     * @private
     */
    _hideLayer: function() {
        this.$layer.hide();
    }
});

module.exports = SelectSeatController;
