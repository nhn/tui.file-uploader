/**
 * @fileoverview 좌석 선택 영역
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */

'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    UIModel = require('../../../ui/model'),
    UICollection = require('../../../ui/collection');

/**
 * 비지정석 row 한개당 부여할 unique ID
 * @type {number}
 */
var uniqueNo = 0;

/**
 * seat 모델 정의
 * @type {*}
 */
var SeatModel = UIModel.extend({
    init: function(data) {
        UIModel.call(this, data, {
            parse: true
        });
    },
    idAttribute: 'seatId',
    defaults: {
        seatId: '',
        seatGroupId: '',
        seatAttributeInfo: '비지정석',
        isReserved: true,
        sellingType: null,
        productGradeId: null,
        productGradeName: '-'
    }
});

/**
 * seat 콜렉션 정의
 * @type {*}
 */
var SeatCollection = UICollection.extend({
    init: function(models) {
        UICollection.call(this, models, {
            parse: true
        });
    },
    model: SeatModel
});

/**
 * 좌석 선택 UI
 * @constructor
 */
var SelectSeatUI = UIController.extend({
    events: {
        'click ._reset': 'confirmReset'
    },

    /**
     * 생성자 메서드
     * @param {object} options
     */
    init: function(options) {
        UIController.call(this, options);
        this.options = options || {};
        this.zoneMap = {};
        this._initializeElements();
        this._initializeCollection();
        this._initializeGrid();
        this._initializeCustomEvents();
        this._initializeIBListeners();
        this.attachEvents();
    },

    /**
     * Grid 초기화
     * @private
     */
    _initializeGrid: function() {
        var defaultOption = {
            $el: this.$grid,
            hasHeader: false,
            rowHeight: 22,
            scrollX: true,
            border: 0,
            idAttribute: 'seatId',
            columnModelList: [
                {
                    columnName: 'productGradeName',
                    width: 88,
                    formatter: function(value) {
                        return '<span class="seat_level">' + value + '</span>';
                    }
                },
                {
                    columnName: 'seatAttributeInfo',
                    formatter: function(value) {
                        return '<span class="seat_price">' + value + '</span>';
                    }
                },
                {
                    width: 40,
                    columnName: '_remove',
                    align: 'left',
                    formatter: function() {
                        return '<a href="#"><span class="all_menu_cl"></span></a>';
                    }
                }
            ]
        };
        this.grid = new ne.component.SimpleGrid(ne.util.extend(defaultOption, this.options.grid));
    },

    /**
     * collection 과 grid
     * 너와 나의 연결고리
     * @param {object} collection   연결할 colleciton 객체
     * @param {object} grid         연결할 grid 객체
     */
    linkCollectionGrid: function(collection, grid) {
        collection.on('set', function() {
            var seats = collection.toJSON();
            this.IB.emit(this.IB.EVENT.GRID_SEATING_SET, seats);
            grid.setList(seats);
        }, this);
        collection.on('remove', function(models) {
            var removeList = [],
                idList = [];
            ne.util.forEachArray(models, function(model) {
                removeList.push(model.toJSON());
                idList.push(model.id);
            }, this);
            this.IB.emit(this.IB.EVENT.GRID_SEATING_REMOVED, removeList);
            grid.remove(idList);
        }, this);
        collection.on('add', function(models, parsedModels) {
            var addList = [];
            ne.util.forEachArray(parsedModels, function(model) {
                addList.push(model.toJSON());
            }, this);
            this.IB.emit(this.IB.EVENT.GRID_SEATING_ADDED, addList);
            grid.prepend(addList);
        }, this);
        collection.on('clear', function(collection, model) {
            this.IB.emit(this.IB.EVENT.GRID_SEATING_CLEARED);
            grid.clear();
        }, this);
    },

    /**
     * custom events 연결
     * collection 과 grid 연결, grid 에 click 이벤트 바인딩
     * @private
     */
    _initializeCustomEvents: function() {
        this.linkCollectionGrid(this.collection, this.grid);
        this.collection.on('all', this._setStatus, this);
        this.grid.on('click', function(customEvent) {
            if (customEvent.columnName === '_remove' && customEvent.$target.is('span')) {
                this._onClickRemove(customEvent);
            }
        }, this);
    },

    /**
     * 현재 총 매수와 초기화 버튼의 클래스를 조작한다.
     * @private
     */
    _setStatus: function() {
        this.$count.text(this.collection.length + '매');
        if (this.collection.length) {
            this.$reset.removeClass('disabled');
        } else {
            this.$reset.addClass('disabled');
        }
    },

    /**
     * IB 와 이벤트 핸들러 연결
     * @private
     */
    _initializeIBListeners: function() {
        var self = this;
        this.listen(this.IB.EVENT.UI_RESET, this._reset, this);
        this.listen(this.IB.EVENT.SET_NON_RESERVED_SEATS, this._purchaseZone, this);
        this.listen(this.IB.EVENT.ADD_SEATS, this._add, this);
        this.listen(this.IB.EVENT.REMOVE_SEATS, this._remove, this);
        this.listen(this.IB.EVENT.MAP_DESELECT_ALL_SEAT, this._removeAll, this);
        this.listen(this.IB.EVENT.GRID_GET_SELECTED_SEATS, ne.util.bind(function(callback) {
            callback(self.toJSON());
        }, this));
    },

    /**
     * element 할당
     * @private
     */
    _initializeElements: function() {
        this.$grid = this.$el.find('._simpleGrid');
        this.$reset = this.$el.find('._reset');
        this.$count = this.$el.find('._count');
        this.$count.text('0매');
    },

    /**
     * collection 초기화
     * @private
     */
    _initializeCollection: function() {
        this.collection = new SeatCollection();
    },

    /**
     * reset 질의 후 실제 reset 하는 메서드
     * @returns {boolean}   reset 여부
     */
    confirmReset: function(message) {
        message = (ne.util.isString(message) && message) ? message : '선택하신 좌석이 초기화 됩니다.';

        if (!this.collection.length || confirm(message)) {
            if (this.collection.length) {
                this._reset();
            }
            return true;
        } else {
            return false;
        }
    },

    /**
     * 비지정석에 대한 collection 을 반환한다.
     * @param {string} zoneId 비지정석 id
     * @returns {*} 비지정석 collection
     */
    getZoneCollection: function(zoneId) {
        return this.zoneMap[zoneId] && this.zoneMap[zoneId].collection;
    },

    /**
     * 좌석 선택 초기화 이벤트 발생
     * @private
     */
    _reset: function() {
        this.IB.emit(this.IB.EVENT.CONTROL_DESELECT_ALL_SEAT);
    },

    /**
     * IB 에서 Select 이벤트 발생시 collection 에 add 함
     * @param {Array} seats 좌석 리스트
     * @private
     */
    _add: function(seats) {
        var newSeats = [],
            newSeatIds = [];
        ne.util.forEachArray(seats, function(seat) {
            var seatId = seat.seatId,
                seatModel = this.collection.get(seatId);
            if (!seatModel) {
                newSeats.push(seat);
                newSeatIds.push(seatId);
            }
        }, this);
        this.collection.add(newSeats);
        this.IB.emit(this.IB.EVENT.CONTROL_SELECT_SEAT, {
            r: newSeatIds,
            n: []
        });
    },

    /**
     * 삭제 버튼 클릭시
     * @param {Object} customEvent   Grid 에서 반환하는 이벤트
     *      @param {String|Number} customEvent.rowKey   키값
     * @private
     */
    _onClickRemove: function(customEvent) {
        var rowKey = customEvent.rowKey,
            model = this.collection.get(rowKey),
            seatGroupId = model.get('seatGroupId'),
            collection,
            count = 0;
        if (!model.get('isReserved')) {
            //this._decreaseZone(rowKey);
            collection = this.getZoneCollection(seatGroupId);
            count = collection.length - 1;
            if (!collection.length) {
                this.IB.emit(this.IB.EVENT.CONTROL_DESELECT_SEAT, {
                    r: [],
                    n: [seatGroupId]
                });
            } else {
                this.IB.emit(this.IB.EVENT.UPDATE_NON_RESERVED_SEAT_COUNT, seatGroupId, count, rowKey);
            }
        } else {
            this.IB.emit(this.IB.EVENT.CONTROL_DESELECT_SEAT, {
                r: [rowKey],
                n: []
            });
        }
    },

    /**
     * IB 에서 Deselect 이벤트 발생시 collection 에서 제거함
     * @param {Array} seatIdList 좌석 id 리스트
     * @private
     */
    _remove: function(seatIdList) {
        var removeSeats = [];
        ne.util.forEachArray(seatIdList, function(seatId) {
            var seatModel = this.collection.get(seatId),
                nSeatCollection = this.getZoneCollection(seatId);
            if (nSeatCollection && nSeatCollection.length) {
                this._clearZone(seatId);
            } else {
                if (seatModel) {
                    removeSeats.push(seatModel);
                }
            }
        }, this);
        this.collection.remove(removeSeats);
    },

    /**
     * IB에서 deselect all 이벤트 발생시 핸들러
     * @private
     */
    _removeAll: function() {
        ne.util.forEach(this.zoneMap, function(zoneData) {
            zoneData.collection.clear();
        });
        this.collection.clear();
    },

    /**
     * zone 에 좌석을 할당한다.
     * @param {Array|Object} seats  비지정석
     * @param {Number} count    비지정석에 할당할 매수
     * @param {Object} allotmentPreoccupancy 할당처별 좌석 count 정보
     * @param {String} [seatId]   특정 비지정석 item 만 삭제하기위한 파라미터
     * @private
     */
    _purchaseZone: function(seats, count, allotmentPreoccupancy, seatId) {
        var seat = seats[0],
            seatGroupId = seat.seatId,
            collection = this.getZoneCollection(seatGroupId),
            i,
            length,
            difference,
            newSeat,
            newSeats = [],
            removeSeats = [];
        //count가 0일때 reset 후 DESELECT_SEAT 이벤트를 발생한다.
        if (count === 0) {
            if (collection && collection.length) {
                this.IB.emit(this.IB.EVENT.CONTROL_DESELECT_SEAT, {
                    r: [],
                    n: [seatGroupId]
                });
            }
            this._clearZone(seatGroupId);
        } else {
            //콜렉션이 없는경우 생성한다.
            if (!collection) {
                this.zoneMap[seatGroupId] = {
                    collection: new SeatCollection(),
                    allotmentPreoccupancy: allotmentPreoccupancy
                };
                collection = this.getZoneCollection(seatGroupId);
            } else {
                this.zoneMap[seatGroupId].allotmentPreoccupancy = allotmentPreoccupancy;
            }

            //seatId 가 있는 경우는 Grid 에서 특정 ITEM 만 제거하기 위함이다.
            if (seatId) {
                this._decreaseZone(seatId);
            } else {
                length = collection.length;
                difference = count - length;
                //추가의 경우
                if (difference >= 0) {
                    for (i = length; i < count; i += 1) {
                        newSeat = ne.util.extend({
                            seatGroupId: seatGroupId,
                            isReserved: false
                        }, seat);
                        uniqueNo += 1;
                        newSeat.seatId = seatGroupId + '_' + uniqueNo;
                        newSeats.push(newSeat);
                    }
                    collection.add(newSeats);
                    this.collection.add(newSeats);
                } else {
                    //제거의 경우
                    for (i = length - 1; i >= count; i -= 1) {
                        removeSeats.push(collection.at(i));
                    }
                    this.collection.remove(removeSeats);
                    collection.remove(removeSeats);
                }
            }
            this.IB.emit(this.IB.EVENT.CONTROL_SELECT_SEAT, {
                r: [],
                n: [seatGroupId]
            });
        }
    },

    /**
     * 비지정석 영역에 선점된 좌석을 clear 한다.
     * @param {String|Number} seatGroupId 해당 zoneId
     * @private
     */
    _clearZone: function(seatGroupId) {
        var collection = this.getZoneCollection(seatGroupId),
            removeSeats = [];
        if (collection) {
            collection.forEach(function(model) {
                removeSeats.push(model);
            });
        }
        this.collection.remove(removeSeats);
        if (collection) {
            collection.clear();
        }
        this.zoneMap[seatGroupId] = null;
        delete this.zoneMap[seatGroupId];
    },

    /**
     * seatId 에 해당하는 비지정석 item 을 제거한다.
     * @param {String|Number} seatId    가상으로 생성된 zone 의 seatId
     * @private
     */
    _decreaseZone: function(seatId) {
        var model = this.collection.get(seatId),
            seatGroupId,
            collection;

        if (model) {
            seatGroupId = model.get('seatGroupId');
            if (!model.isReserved) {
                collection = this.getZoneCollection(seatGroupId);
                this.collection.remove(model);
                if (collection) {
                    collection.remove(model);
                }
            }
        }
    },

    /**
     * JSON 데이터 반환
     * @returns {*|string|Object}   서버로 전송할 데이터
     */
    toJSON: function() {
        var map = {};
        this.collection.forEach(function(model) {
            var data = model.toJSON(),
                productGradeId = data.productGradeId;

            map[productGradeId] = map[productGradeId] || { seatList: [], zoneList: []};
            if (data.isReserved) {
                map[productGradeId].seatList.push({
                    id: data.seatId,
                    seatAttributeInfo: data.seatAttributeInfo,
                    allotmentCompanyCode: data.sellingType
                });
            }
        }, this);
        ne.util.forEach(this.zoneMap, function(zoneData, seatGroupId){
            var data,
                collection = zoneData.collection,
                allotmentPreoccupancy = zoneData.allotmentPreoccupancy;
            if (collection && collection.length) {
                data = collection.at(0).toJSON();
                map[data.productGradeId].zoneList.push({
                    zoneId: seatGroupId,
                    zoneName: data.seatAttributeInfo,
                    count: collection.length,
                    allotmentPreoccupancy: allotmentPreoccupancy
                });
            }
        });
        return {
            list: this.collection.toJSON(),
            map: map
        };
    }
});

module.exports = SelectSeatUI;
