/**
 * @fileoverview 예매파트에서 사용되는 맵에서 쓰이는 등급 하이라이트 관리 객체가 정의 되어있다.
 * @author FE개발팀 김성호 sungho-kim@nhnent.com
 */

'use strict';

/**
 * GradeHighlighManager
 * TicketingMa에서 등급하이라이트 기능을 위임받아 처리하는 객체
 * @exports GradeHighlighManager
 * @constructor
 * @class
 **/
function GradeHighlighManager(options) {
    this.IB = options.map.IB;
    this.gridCtr = options.map.gridController;
    this.nSeatCtr = options.map.nSeatController;
    this.currentHLGrade = null;

    this._setIBEvents();
}

/**
 * IB이벤트들을 셋팅한다
 * @private
 */
GradeHighlighManager.prototype._setIBEvents = function() {
    var EVENT = this.IB.EVENT;

    this.IB.listen(EVENT.RSEAT_RENDERED, function() {
        if (this.currentHLGrade) {
            this.highlightGrade(this.currentHLGrade);
        }
    }, this);

    this.IB.listen(EVENT.CONTROL_HIGHLIGHT_SEAT, function(gradeCode) {
        this.IB.emit(EVENT.MAP_BLUR_SEAT);
        if (gradeCode) {
            this.highlightGrade(+gradeCode);
        } else {
            this.clear();
        }
    }, this);
};

/**
 * 하이라이트할 GradeCode를 입력받아 하이라이트시킨다
 * @param {string} gradeCode 하이라이트할 등급코드
 */
GradeHighlighManager.prototype.highlightGrade = function(gradeCode) {
    this.currentHLGrade = gradeCode;
    this._highlighControllers();
    this._updateControllers();
};

/**
 * 하이라이트 상태를 해제한다
 */
GradeHighlighManager.prototype.clear = function() {
    this.currentHLGrade = null;
    this._clearHighlightControllers();
    this._updateControllers();
};

/**
 * 현재 하이라이트 상태인지를 체크한다
 * @returns {boolean}
 */
GradeHighlighManager.prototype.isActive = function() {
    return !!this.currentHLGrade;
};

/**
 * 좌석 목록을 넘겨받아 하이라이트된 좌석만 가려낸다
 * @param {Seat[] | HashMap} seats
 * @returns {Seat[] | HashMap}
 */
GradeHighlighManager.prototype.filterHighlightSeat = function(seats) {
    var result;

    if (seats instanceof ne.util.HashMap) {
        result = this.filterHighlightSeatFromHashMap(seats);
    } else {
        result = this.filterHighlightSeatFromArray(seats);
    }

    return result;
};

/**
 * 좌석의 배열을 넘겨받아 하이라이트된 좌석만 가려낸다
 * @param {Seat[]} seats
 * @returns {Array}
 */
GradeHighlighManager.prototype.filterHighlightSeatFromArray = function(seats) {
    var filteredSeats = [],
        self = this;

    ne.util.forEach(seats, function(seat) {
        if (self.isHighlightSeat(seat)) {
            filteredSeats.push(seat);
        }
    });

    return filteredSeats;
};

/**
 * 좌석 목록을 가지고있는 HashMap을 넘겨받아 하이라이트된 좌석만 가려낸다
 * @param {HashMap} seats
 * @returns {*}
 */
GradeHighlighManager.prototype.filterHighlightSeatFromHashMap = function(seats) {
    var self = this;

    seats.each(function(seat, key) {
        if(!self.isHighlightSeat(seat)){
            seats.remove(key);
        }
    });

    return seats;
};

/**
 * 각 SLC들에게 등급코드로 하이라이트할 브러시를 선택하게 한다
 * @private
 */
GradeHighlighManager.prototype._highlighControllers = function() {
    var gradeCode = this.currentHLGrade;
    this.gridCtr.eachSeatLayer(function(sl) {
        sl.setHlBrushId(gradeCode);
    });
    this.nSeatCtr.eachSeatLayer(function(sl) {
        sl.setHlBrushId(gradeCode);
    });
};

/**
 * 각 SLC들에게 등급코드로 하이라이트된 브러시를 해제 하게 한다
 * @private
 */
GradeHighlighManager.prototype._clearHighlightControllers = function() {
    this.gridCtr.eachSeatLayer(function(sl) {
        sl.clearHlBrushId();
    });
    this.nSeatCtr.eachSeatLayer(function(sl) {
        sl.clearHlBrushId();
    });
};

/**
 * 각 SLC를 다시그린다
 * @private
 */
GradeHighlighManager.prototype._updateControllers = function() {
    this.gridCtr.refreshGridsInViewport();
    this.nSeatCtr.update();
};

/**
 * 좌석을 넘겨받아 하이라이트기준에 맞는 좌석인지 판단한다
 * @param {Seat} seat
 * @returns {boolean}
 */
GradeHighlighManager.prototype.isHighlightSeat = function(seat) {
    return seat.grade === this.currentHLGrade;
};

module.exports = GradeHighlighManager;
