var _adminConfig = {
    'popupUrl': {
        'USER_INFO': '/popup/selectMemberPop.nhn?loadPage=<%=loadPage%>',  //사용자 정보조회 팝업
        'PRODUCT_INFO': '/reserve/make/selectProductPop.nhn?loadPage=<%=loadPage%>',  //상품 조회
        'NOTICE': '/seatZone/popup/notice.nhn?productId=<%=productId%>',  //공지사항
        'PRODUCT_MANAGER_DETAIL': '/seatZone/popup/managerInfo.nhn?productId=<%=productId%>',  //상품 담당자 정보
        'PRODUCT_DETAIL': 'http://beta.ticketlink.co.kr/product/<%=productId%>'  //상품 상세보기
    }
};