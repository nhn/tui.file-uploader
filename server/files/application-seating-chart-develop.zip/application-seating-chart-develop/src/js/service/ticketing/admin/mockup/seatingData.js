(function() {

    var productGradeNameList = ['특별 한정석', 'VIP석', 'R석', 'A석', 'B석', 'C석'],
        productGradeName,
        productDenominationNameList = ['일반', '특별할인', '학생할인', '옆집할인'],
        denominationDescriptionList = ['', '', '학생할인가입니다.', '옆집할인가입니다.'],
        productGradeId,
        seats = [],
        dummy = {};
    for (var i = 0; i < 100; i++) {
        productGradeId = Math.floor((Math.random() * 6));
        productGradeName = productGradeNameList[productGradeId];
        seats.push({
            "logicalSeatId": null,
            "logicalPlanId": 6,
            "scheduleId": 3798,
            "seatId": i,   //id attribute
            "physicalPlanId": null,
            "seatTypeCode": "SEAT",
            "productGradeId": productGradeId,    //id
            "productGradeName": productGradeName, //name
            "allotmentCompanyCode": null,
            "orderOfPriority": null,
            "reserveYn": null,
            "preoccupancyYn": null,
            "lastPreoccupancyDatetime": null,
            "productId": 53,
            "productDate": 1419433200000,
            "productRound": 1,
            "seatAttributeInfo": "1층 A블럭 1열 " + i + "번호 ",
            "markPrice": 200000,
            "salePrice": 200000,
            "attributeValue": null,
            "seatMarkUnitName": null,
            "allotmentName": null,
            "seatNumber": null,
            "searchSeat": null
        });
    }
    var priceList = [],
        produceDenomonationName;
    for (var i = 0; i < productGradeNameList.length; i++) {
        productGradeId = i;
        productGradeName = productGradeNameList[productGradeId];
        var len = Math.floor((Math.random() * 3)) + 1;
        for (var j = 0; j < len; j++) {
            produceDenomonationName = productDenominationNameList[j];
            var temp = Math.floor((Math.random() * 9) + 1);
            priceList.push({
                "productGradeId": productGradeId,
                "productGradeName": productGradeName,
                "productDenominationId": j,
                "productDenominationName": produceDenomonationName,
                "denominationDescription": denominationDescriptionList[j],
                "discountTypeNotation": "원",
                "salePrice": temp * 1000
            });
        }
    }
    dummy.seats = seats;
    dummy.priceList = priceList;
    dummy.additionalProducts = [
        {
            "productId": 53,
            "additionalProductId": 123,
            "additionalProductName": "지킬앤하이드 CD1",
            "additionalProductDescription": null,
            "additionalProductImageFilePath": null,
            "additionalProductPrice": 10000,
            "purchasePossibleCount": 10,
            "totalSaleCount": 1000,
            "perRoundPurchasePossibleCount": 10
        },
        {
            "productId": 53,
            "additionalProductId": 124,
            "additionalProductName": "ジキルANDハイド　特典ディスク1",
            "additionalProductDescription": null,
            "additionalProductImageFilePath": null,
            "additionalProductPrice": 15000,
            "purchasePossibleCount": 10,
            "totalSaleCount": 1000,
            "perRoundPurchasePossibleCount": 10
        }
    ];

    window.ne.tkl.options = dummy;

})();
