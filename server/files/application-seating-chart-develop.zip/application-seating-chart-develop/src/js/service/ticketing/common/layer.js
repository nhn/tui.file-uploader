/**
* @fileoverview 레이어 UI
* @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
*/

var tkl = ne.tkl,
    UIController = tkl.UIController;

/**
 * 레이어 UI
 * @type {*}
 */
var LayerUI = UIController.extend({
    
    /**
     * 생성자
     * @param {Object} options
     */
    init: function(options) {
        UIController.call(this, options);
        this.initializeElement();
    },

    /**
     * 엘리먼트 초기화
     */
    initializeElement: function() {
        this.$title = this.$el.find('._title');
        this.$content = this.$el.find('._content');
        this.hide();
    },

    /**
     * 레이어를 노출한다.
     * @param {jQuery} $base 노출 기준이 될 엘리먼트
     * @param {Object} options
     *      @param {String} [options.title] title 이 있는 레이어의 경우 title 을 설정한다.
     *      @param {String} [options.text]  내용을 설정한다.
     *
     */
    show: function($base, options) {
        if (this.$title.length) {
            this.$title.html(options && options.title || '');
        }
        this.$content.html(options && options.text || '');
        this.$el.show();
        var offset = $base.offset(),
            width = $base.width(),
            height = $base.height(),
            left = offset.left + width,
            top = offset.top + (height - this.$el.height());
        this.$el.css({
            zIndex: 99,
            left: left,
            top: top
        });
    },

    /**
     * 레이어를 숨긴다
     */
    hide: function() {
        this.$el.hide();
    }
});

module.exports = LayerUI;
