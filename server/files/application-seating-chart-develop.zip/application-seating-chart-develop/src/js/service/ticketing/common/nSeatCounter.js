/**
 * @fileoverview NSeatCounter 비지정석 매수입력 UI를 컨트롤한다.
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */
'use strict';
var tkl = ne.tkl,
    UIController = tkl.UIController;

/**
 * NSeatCounter
 * @extends {UIController}
 * @constructor
 * @class
 * **/
var NSeatCounter = UIController.extend({
    rootElement: $('#ne_nSeatCounter'),
    events: {
        'click .nb': '_onKeyPadClicked',
        'click #ne_nSeatCounter_reset': '_onReset',
        'click #ne_nSeatCounter_apply': '_onApply'
    },
    CLASSNAMES: {
        'DISABLE': 'disable'
    },

    /**
     * 생성자
     * @param options
     * @constructor
     */
    init: function NSeatCounter(options) {
        UIController.call(this, options);
        this._initializeListenToIB();
        this.setDefaultStatus(options && options.defaultStatus || false);
        this.selectedSeat = [];
        this.$input = this.$el.find('.ipt_txt');
        this.attachEvents();
        this.disable();
    },

    /**
     * IB 와 이벤트 핸들러 연결
     * @private
     */
    _initializeListenToIB: function() {
        this.listen(this.IB.EVENT.PRODUCT_INFO_LOADED, this._initStatus, this);
        this.listen(this.IB.EVENT.ROUND_SELECTED, this._initStatus, this);
        this.listen(this.IB.EVENT.DATE_SELECTED, this._initStatus, this);
        this.listen(this.IB.EVENT.CONTROL_BLUR_SEAT, this._initStatus, this);
        this.listen(this.IB.EVENT.MAP_BLUR_SEAT, this._initStatus, this);
        this.listen(this.IB.EVENT.MAP_DESELECT_ALL_SEAT, this._initStatus, this);
        this.listen(this.IB.EVENT.NON_RESERVED_FOCUSED, this.enable, this);
    },

    /**
     * default 상태로 초기화 한다. (enable/disable)
     * @private
     */
    _initStatus: function() {
        this.setValue('');

        if (this.IB.isOnlyZone() || this.defaultStatus) {
            this.enable(this.selectedSeats, 0);
        } else {
            this.disable();
        }
    },

    /**
     * default 상태를 지정한다.
     * @param isEnable  default 가 활성화인지 여부
     */
    setDefaultStatus: function(isEnable) {
        this.defaultStatus = !!isEnable;
    },

    /**
     * input 에 값을 설정한다.
     * @param {string} value    input 에 지정할 값
     */
    setValue: function(value) {
        this.$input.val(value);
    },

    /**
     * 현재 enable 인지 여부
     * @returns {boolean} 현재 활성화 상태인지 여부
     * @private
     */
    _isEnable: function() {
        return !this.$el.hasClass(this.CLASSNAMES.DISABLE);
    },

    /**
     * diable 한다.
     */
    disable: function() {
        this.$el.addClass(this.CLASSNAMES.DISABLE);
        this.$input.prop('disabled', true);
        this.setValue('');
    },

    /**
     * enable 한다.
     * @param {Array} seats 비지정석 데이터
     * @param {Number} count 해당 비지정석이 선점된 개수
     */
    enable: function(seats, count) {
        count = ne.util.isUndefined(count) ? 0 : count;
        this.selectedSeats = seats;
        this.$el.removeClass(this.CLASSNAMES.DISABLE);
        this.$input.prop('disabled', false).val(count);
    },

    /**
     * keypad 가 클릭되었을 때 이벤트 핸들러
     * @param {Event} e 이벤트 핸들러
     * @private
     */
    _onKeyPadClicked: function(e) {
        e.preventDefault();
        if (this._isEnable()) {
            this.apply(+e.target.innerHTML);
        }
    },

    /**
     * 숫자만 입력되었는지 여부를 확인한다.
     * @param {string} count
     * @returns {boolean} 숫자만 입력되었는지 여부
     * @private
     */
    _validate: function(count) {
        if (!/^[0-9]+$/.test(count)) {
            alert('숫자만 입력 가능합니다.');
            return false;
        } else {
            return true;
        }
    },

    /**
     * '초기화' 버튼 클릭시 이벤트 핸들러
     * @private
     */
    _onReset: function() {
        if (this._isEnable() && this.selectedSeats) {
            this.setValue('');
            this._deselect();
            this.IB.emit(this.IB.EVENT.CONTROL_BLUR_SEAT);
        }
    },

    /**
     * '적용' 버튼 클릭시 이벤트 핸들러
     * @private
     */
    _onApply: function() {
        var count = this.$input.val();
        this.apply(count);
    },

    /**
     * 해당 메수를 적용한다.
     * @param {number} count 선점할 매수
     */
    apply: function(count) {
        if (this._isEnable() && this.selectedSeats && this._validate(count)) {
            this.setValue(count);
            this._select(count);
        }
    },

    /**
     * 선점 request 를 전송하도록 이벤트를 trigger 한다.
     * @param {number} count 선점할 매수
     * @private
     */
    _select: function(count) {
        count = +count;
        if (this._isEnable() && this.selectedSeats) {
            if (count === 0) {
                this._deselect();
            } else {
                this.IB.emit(this.IB.EVENT.PURCHASE_SEAT, {
                    seats: this.selectedSeats,
                    isReserved: false,
                    count: count
                });
            }
        }
    },

    /**
     * 선점 해제한다.
     * @private
     */
    _deselect: function() {
        if (this._isEnable() && this.selectedSeats) {
            this.IB.emit(this.IB.EVENT.CONTROL_DESELECT_SEAT, {
                n: [this.selectedSeats[0].seatId],
                r: []
            });
        }
    }
});

module.exports = NSeatCounter;
