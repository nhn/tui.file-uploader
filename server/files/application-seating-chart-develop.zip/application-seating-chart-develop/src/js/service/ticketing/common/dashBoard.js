/**
 * @fileoverview 등급 현황표 UI
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */
'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    API = tkl.API;

var etc = require('../../../etc');

/**
 * 등급 현황표 UI
 * @type {*}
 */
var DashBoardUI = UIController.extend(/* @lends DashBoardUI.prototype */{
    events: {
        'click': '_onClick'
    },

    /**
     * 최조 진입시에는 좌석정보를 렌더링하지 않는다
     *
     * 예약좌석, 발권좌석 조회의 성능 이슈로 서버팀에서 요청
     * @type {Boolean}
     */
    skipRender: true,

    /**
     * 생성자
     * @constructs DashBoardUI
     * @param {Object} options options
     * @param {String} options.template    페이지 별 등급 현황표가 개별적이라, template 을 받아 처리한다.
     */
    init: function(options) {
        UIController.call(this, options);
        this.locked = false;
        this._template = options.template;
        this.initializeElement();
        this.listen(this.IB.EVENT.AVAILABLE_SEATINFO_LOADED, this.render, this);
        this.attachEvents();

        this.skipRender = ne.util.isExisty(options.skipRender) ? options.skipRender : true;
    },

    /**
     * 엘리먼트 초기화
     */
    initializeElement: function() {
        this.$list = this.$el.find('._list');
        this.$latestUpdated = this.$el.find('._latest_updated');
    },

    /**
     * 시, 분, 초 를 받아 2자리수로 포멧
     * @param {Number} part hour, minutes, seconds
     * @return {String} formatted value
     */
    _formatTime: function(part) {
        if (part < 10) {
            part = '0' + part;
        }
        return part;
    },

    /**
     * 등급정보 최종 조회시간 렌더링
     */
    _renderCurrentTime: function() {
        var current = new Date(),
            hh = this._formatTime(current.getHours()),
            mm = this._formatTime(current.getMinutes()),
            ss = this._formatTime(current.getSeconds());

        this.$latestUpdated.html([
            '최종 조회시간',
            '<br />',
            [hh, mm, ss].join(':')
        ].join(''));
    },

    /**
     * 랜더링 한다.
     * @param {Array} list  등급 정보 리스트
     */
    render: function(list) {
        var formattedList = [];

        if (this.skipRender) {
            this.skipRender = false;
            return;
        }

        this.detachEvents();
        ne.util.forEachArray(list, function(data) {
            formattedList.push(etc.formatNumberEachObject(data));
        }, this);
        this.$list.html(this.template(this._template, formattedList));
        this.attachEvents();
        this._renderCurrentTime();
    },

    /**
     * 클릭 이벤트 핸들러
     * @param {Event} clickEvent    클릭 이벤트
     * @private
     */
    _onClick: function(clickEvent) {
        var $target = $(clickEvent.target);
        if ($target.hasClass('_refresh')) {
            this._refresh();
        }
    },

    /**
     * 반복 refresh 를 방지하기 위하여 락을 건다.
     * @private
     */
    _lock: function() {
        this.locked = true;
    },

    /**
     * 락을 해제한다.
     * @private
     */
    _unlock: function() {
        this.locked = false;
    },

    /**
     * lock이 걸려있는지 여부를 반환한다.
     * @returns {boolean} lock 이 걸렸는지 여부
     * @private
     */
    _isLocked: function() {
        return this.locked;
    },

    /**
     * 현재 좌석 정보를 업데이트 한다.
     * @private
     */
    _refresh: function() {
        var self = this,
            IB = this.IB,
            param,
            scheduleId = IB.get('scheduleId'),
            logicalPlanId = IB.get('logicalPlanId');

        if (
            (ne.util.isExisty(logicalPlanId) || ne.util.isExisty(scheduleId)) &&
            !this._isLocked()
        ) {
            this._lock();

            if (this.IB.isOnlyZone()) {
                param = {
                    isMap: false,
                    id: scheduleId,
                    sellingType: IB.get('sellingTypeCode')
                };
            } else {
                param = {
                    isMap: true,
                    id: logicalPlanId,
                    sellingType: IB.get('sellingTypeCode')
                };
            }
            this.IB.requestToAPI(API.URL.RESERVE_GRADE, {
                data: param,
                type: 'POST',
                success: ne.util.bind(this._onSuccess, this)
            });
        } else {
            self.render([]);
        }
    },

    /**
     * request 결과 성공시
     * @param {Object} responseData 응답 데이터
     * @private
     */
    _onSuccess: function(responseData) {
        this._unlock();
        responseData = ne.util.isArray(responseData) ? responseData : [responseData];
        this.render(this.IB.sortGrade(responseData));
    }
});

module.exports = DashBoardUI;

