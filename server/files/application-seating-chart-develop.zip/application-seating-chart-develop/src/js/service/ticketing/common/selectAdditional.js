/**
 * @fileoverview 예매 --> 부가상품 영역
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */

'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    UIModel = require('../../../ui/model'),
    UICollection = require('../../../ui/collection'),
    tmplRow = require('../../../../tmpl/ticketing/selectAdditional/row.html'),
    tmplOption = require('../../../../tmpl/ticketing/selectAdditional/option.html'),
    etc = require('../../../etc');

/**
 * 좌석 금액 모델
 * @type {*}
 */
var AdditionalProcuetModel = UIModel.extend({
    init: function(data) {
        UIModel.call(this, data, {
            parse: true
        });
    },
    idAttribute: 'id',
    defaults: {
        id: null,
        text: '',
        quantity: 0,
        price: 0,
        maxCount: 200,
        purchasePossibleCount: 200,
        restSaleCount: 200
    },
    parse: function(data) {
        return {
            id: data.additionalProductId,
            text: data.additionalProductName,
            quantity: data.restSaleCount,
            price: data.additionalProductPrice,
            maxCount: data.perRoundPurchasePossibleCount,
            purchasePossibleCount: data.purchasePossibleCount,
            restSaleCount: data.restSaleCount
        };
    }
});

/**
 * 좌석 금액 콜랙션
 * @type {*}
 */
var AdditionalProcuetCollection = UICollection.extend({
    init: function(models) {
        UICollection.call(this, models, {
            parse: true
        });
    },
    model: AdditionalProcuetModel
});

/**
 * 부가상품 선택 영역 UI
 * @constructor
 */
var SelectAdditionalUI = UIController.extend({
    events: {
        'change select': '_onChange',
        'keydown select': '_onKeydown'
    },
    init: function(options) {
        UIController.call(this, options);
        this._initializeListenToIB();
        this._initializeElements();
        this._initializeCollection();
    },

    /**
     * IB 와 이벤트 핸들러 연결
     * @private
     */
    _initializeListenToIB: function() {
        this.listen(this.IB.EVENT.ADDITIONAL_PRODUCT_LIST_CHANGE, this._setCollection, this);
        this.listen(this.IB.EVENT.ADDITIONAL_COUNT_DATA_LOADED, this._onAdditionalCountDataLoaded, this);

    },

    /**
     * element 바인딩
     * @private
     */
    _initializeElements: function() {
        this.$list = this.$el.find('._list');
        this.$price = this.$el.find('._price');
        this.$quantity = this.$el.find('._quantity');
    },

    /**
     * collection 바인딩
     * @private
     */
    _initializeCollection: function() {
        this.collection = new AdditionalProcuetCollection();
        this.collection.on('all', this.render, this);
    },

    /**
     * collection 데이터 변경 이벤트 발생 시 collection 에 설정한다.
     * @param {Array} list  콜랙션에 들어갈 데이터 list
     * @private
     */
    _setCollection: function(list) {
        this.collection.set(list, {parse: true});
    },

    /**
     * 랜더링한다.
     */
    render: function() {
        this.detachEvents();
        var list = this.collection.toJSON(),
            rows = [];
        ne.util.forEachArray(list, function(item) {
            var i = 0,
                options = [];
            for(; i < item.maxCount + 1; i++) {
                options.push({
                    value: i,
                    text: i
                });
            }
            rows.push(this.template(tmplRow, {
                id: item.id,
                text: item.text,
                quantity: etc.formatNumber(item.quantity),
                formattedPrice: etc.formatNumber(item.price),
                price: item.price,
                options: this.template(tmplOption, options).join('')
            }));
        }, this);
        this.$list.html(rows.join(''));
        this._updateInfo();
        this.attachEvents();
    },

    /**
     * select change 이벤트 핸들러
     * @param {Event} changeEvent
     * @private
     */
    _onChange: function(changeEvent) {
        var $target = $(changeEvent.target),
            IB = this.IB;

        IB.emit(IB.EVENT.ADDITIONAL_COUNT_SELECTED, $target.data('id'));
        this._updateInfo();
    },

    /**
     * keydown 이벤트 핸들러
     * @param {Event} keyDownEvent
     * @private
     */
    _onKeydown: function(keyDownEvent) {
        keyDownEvent.preventDefault();
    },

    /**
     * 부가상품 count 데이터 서버 응답 받았을때 수행 로직
     * @param {Number} additionalProductId  부가상품 ID
     * @param {Object} responseData 응답 데이터
     * @private
     */
    _onAdditionalCountDataLoaded: function(additionalProductId, responseData) {
        var model = this.collection.get(additionalProductId),
            isAlertShown = false,
            countObj,
            $select,
            selectedCount,
            index;

        if (model) {
            index = this.collection.indexOf(model);
            $select = this.$list.find('select:eq(' + index + ')');
            selectedCount = +$select.val();

            if (responseData.length) {
                countObj = responseData[0];
                model.set('restSaleCount', countObj.restSaleCount, {silent: true});
                model.set('quantity', countObj.restSaleCount, {silent: true});
                selectedCount += +countObj.orderCount || 0;
            }

            if (this._isRestSaleCountExceeded(model, selectedCount)) {
                isAlertShown = true;
                this._updateRestSaleCount(index);
                alert('잔여수량이 부족합니다.');
            } else if (this._isPurchasePossibleCountExceeded(model, selectedCount)) {
                isAlertShown = true;
                alert('인당 구매허용개수를 초과하셨습니다.');
            }

            if (isAlertShown) {
                $select.val(0).trigger('change');
            }
        }
    },

    /**
     * 잔여수량 텍스트 정보 업데이트
     * @param {Number} index
     * @private
     */
    _updateRestSaleCount: function(index) {
        var model = this.collection.at(index),
            str = '잔여수량 ' + model.get('quantity');
        this.$list.find('._restSaleCount:eq(' + index + ')').html(str);
    },

    /**
     * 잔여수량이 초과 되었는지 여부
     * @param {Object} model 초과 확인할 데이터 모델
     * @param {Number} selectedCount    잔여 수량 선택 개수
     * @returns {boolean}
     * @private
     */
    _isRestSaleCountExceeded: function(model, selectedCount) {
        return model.get('restSaleCount') < selectedCount;
    },

    /**
     * 구매 가능 횟수가 초가 되었는지 여부
     * @param {Object} model 초과 확인할 데이터 모델
     * @param {Number} selectedCount    잔여 수량 선택 개수
     * @returns {boolean}
     * @private
     */
    _isPurchasePossibleCountExceeded: function(model, selectedCount) {
        return model.get('purchasePossibleCount') < selectedCount;
    },

    /**
     * 하단의 금액과 수량 정보를 업데이트 한다.
     * @private
     */
    _updateInfo: function() {
        var data = this.toJSON();
        this.$price.text(etc.formatNumber(data.price) + '원');
        this.$quantity.text(etc.formatNumber(data.count) + '개');
        this.IB.emit(this.IB.EVENT.TOTAL_PRICE_CHANGE);
    },

    /**
     * 서버로 전송할 JSON 데이터 반환
     * @returns {*|string|Object}
     */
    toJSON: function() {
        var $selectList = this.$el.find('select'),
            totalPrice = 0,
            totalCount = 0,
            list = [];
        ne.util.forEachArray($selectList, function(item, index) {
            var $select = $selectList.eq(index),
                count = +$select.val() || 0,
                id = $select.data('id'),
                model;

            totalPrice += count * $select.data('price') || 0;
            totalCount += count;

            if (count > 0) {
                model = this.collection.get(id);
                list.push({
                    additionalProductCount: count,
                    additionalProductId: id,
                    additionalProductPrice: model.get('price'),
                    additionalProductName: model.get('text')
                });
            }
        }, this);
        return {
            price: totalPrice,
            count: totalCount,
            list: list
        };
    }
});

module.exports = SelectAdditionalUI;
