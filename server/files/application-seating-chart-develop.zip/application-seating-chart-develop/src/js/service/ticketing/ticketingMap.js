/**
* @fileoverview SeatingMap을 상속받아 구현한 예매파트 좌석 도면맵
* @author FE개발팀 김성호 sungho-kim@nhnent.com
*/

'use strict';

var tkl = ne.tkl,
    simplemap = ne.component.SimpleMap,
    TileLayer = simplemap.TileLayer,
    NavigatorControl = simplemap.NavigatorControl,
    SeatingChart = tkl.SeatingChart,
    ZoomReactor = tkl.ZoomReactor,
    RLayer = tkl.RLayer,
    SelectionControl = tkl.SelectionControl,
    SeatInfoTooltipControl = tkl.SeatInfoTooltipControl,
    Settings = tkl.Settings,
    FocusSeatController = require('../../controller/focusSeatController.js'),
    GradeHighlighManager = require('./ghManager'),
    TicketingIB = require('./ticketingIB');

var common = ne.util;

/**
 * 각종 예매, 예약페이지에서 사용되는 좌석배치도
 * @param {HTMLElement} el 좌석도면이 들어가게될 엘리먼트
 * @param {Object} options 좌석도면에 전달되 옵션들
 * @constructor
 * @extends {SeatingChart}
 * @exports TicketingMap
 * @class
 */
function TicketingMap(el, options) {
    var useArea = this.useArea = common.isExisty(ne.util.pick(ne.tkl.data, 'areaData')) && (ne.tkl.data.areaData.length > 0),
        seatBrushMinZoomRange = useArea ? 4 : 3;

    ZoomReactor.CONFIG = ne.util.extend({
        Area: [0, 3],
        Seat: [seatBrushMinZoomRange, 7],
        NSeat: [seatBrushMinZoomRange, 7],
        SelectSeat: [seatBrushMinZoomRange, 7],
        Grade: [seatBrushMinZoomRange, 7],
        SellingType: [seatBrushMinZoomRange + 1, 7],
        Text: [7]
    }, options.toggleBrush);

    Settings.setGradeCode(options.gradeCode);
    Settings.setSellingTypeCode(options.sellingTypeCode);
    Settings.setGlobalConfigure({
        isClosedEvent: !!options.isClosedEvent,
        isReservationSystem: !!options.isReservationSystem
    });
    Settings.setUseRSeatPathCache(true);

    SeatingChart.call(this, el, options);

    if (common.isExisty(common.pick(options, 'tile', 'altTiles')) && common.isObject(options.tile.altTiles)) {
        options.tile.altTiles = [options.tile.altTiles];
    }

    if (common.isExisty(options, 'navigator.altImage') && common.isObject(options.navigator.altImage)) {
        options.navigator.altImage = [options.navigator.altImage];
    }

    this.addLayer(new TileLayer(options.tile));
    this.addLayer(new RLayer(options));
    this.addControl(new NavigatorControl('navigator', options.navigator));
    this.addControl(new SelectionControl());
    this.addControl(new SeatInfoTooltipControl());
    this.useArea = ne.tkl.data.areaData.length;
    this.areaRange = ZoomReactor.CONFIG.Area;
    this.refreshArea();
    this.setController();

    // IB 설정
    this._setIB(options.IB);
    this._setIBEvents();
    this.setEvents();

    /*
     * @type {number}
     * @private
     */
    this._status = TicketingMap.STATUS.NORMAL;

    /**
     * 등급 하일라이트를 관리하는 객체
     * @type {GradeHighlighManager}
     */
    this.ghm = new GradeHighlighManager({map: this});

    this.render();
}

ne.util.inherit(TicketingMap, SeatingChart);

/**********
 * static props
 **********/

/**********
 * override methods
 **********/

TicketingMap.prototype.setController = function() {
    SeatingChart.prototype.setController.call(this);
    this.focusSeatController = new FocusSeatController({
        paper: this.paper,
        zoomLevel: this.getZoom(),
        chart: this
    });
};

TicketingMap.prototype.setEvents = function() {
    SeatingChart.prototype.setEvents.call(this);
    this.on('beforeSelectSeat', this._onBeforeSelectSeat, this);
    this.on('movestart', this._onMoveStart, this);
    this.on('moveend', this._onMoveEnd, this);
};

TicketingMap.prototype._onMoveStart = function() {
    this.IB.emit(this.IB.EVENT.MAP_MOVE_START);
};

/**
 * 셀렉트시키는 핸들러 셀제로 셀렉트 되지 않고 포커스상태로 변경하도록 오버라이드
 * @param {object} seatData
 * @param {object} event
 */
TicketingMap.prototype.onSelectSeats = function(seatData, event) {
    if (this._status === TicketingMap.STATUS.FOCUS && seatData.n.length) {
        if (this.isFocusedSeat(seatData.n)) {
            this.unFocusSeats();
            this.IB.emit(this.IB.EVENT.MAP_BLUR_SEAT);
        }
    } else {
        this.focusSeats(seatData);
        this.IB.emit(this.IB.EVENT.MAP_FOCUS_SEAT, seatData, event);
    }
};

/**
 * IB를 셋팅한다 IB를 넘기지 않으면 TicketingIB로 직접 만든다
 * @param {InteractBroker} IB 셋팅할 IB
 * @private
 */
TicketingMap.prototype._setIB = function(IB) {
    this.IB = IB || new TicketingIB();
};

/**
 * 필요한 IB이벤트들을 셋팅한다
 * @private
 */
TicketingMap.prototype._setIBEvents = function() {
    var EVENT = this.IB.EVENT;

    SeatingChart.prototype._setIBEvents.call(this);

    this.IB.listen(EVENT.CONTROL_DESELECT_SEAT, function(data) {
        this.deselectSeatsByIds(data.n.concat(data.r), true);
        //비지정석이 다시그려지면서 포커스를 덮을수있으므로 포커스를 다시 그린다.
        this.focusSeatController.update(true);
    }, this);

    this.IB.listen(EVENT.CONTROL_DESELECT_ALL_SEAT, function() {
        this.deselectAllSeats(true);
    }, this);

    this.IB.listen(EVENT.CONTROL_SELECT_SEAT, function(e) {
        if (e.n.length) {
            this.unFocusSeats();
            this.IB.emit(this.IB.EVENT.MAP_BLUR_SEAT);
        }
        this.selectSeats(e);
    }, this);

    this.IB.listen(EVENT.CONTROL_BLUR_SEAT, function() {
        this.unFocusSeats();
    }, this);

    this.IB.listen(EVENT.CONTROL_SEARCH_SEAT, function(sidList, callback) {
        callback(this.searchSeats(sidList));
    }, this);

    //TODO: 좌석 모델 수정 부분 API 로만 사용하도록 수정 필요
    this.IB.listen(EVENT.CONTROL_DISABLE_SEAT, function(seatData) {
        var gridCtrl = this.gridController,
            nSeatCtrl = this.nSeatController,
            seatsToSoldout = this.searchSeats(seatData.n.concat(seatData.r));

        if (seatsToSoldout.r.length) {
            ne.util.forEach(seatsToSoldout.r, function(seat) {
                gridCtrl.doWhenSeatLayerExist(seat.slid, function (sl) {
                     sl.dirty();
                });
                seat.soldout = true;
            });
            this.gridController.refreshGridsInViewport(true);
        } else if (seatsToSoldout.n.length) {
            ne.util.forEach(seatsToSoldout.n, function(seat) {
                nSeatCtrl.doWhenSeatLayerExist(seat.slid, function (sl) {
                    sl.dirty();
                });
                seat.soldout = true;
            });
            this.nSeatController.update(true);
        }
    }, this);

    this.IB.listen(EVENT.CONTROL_UPDATE_NON_RESERVED_COUNT, function(sid, count) {
        var nSeat = this.searchSeats(sid).n[0];
        if (nSeat) {
            nSeat.remainCount = count;
        }
    }, this);
};

TicketingMap.prototype._onAfterZoom = function(e) {
    SeatingChart.prototype._onAfterZoom.call(this, e);
    this.focusSeatController.ensureZoom(e.newZoom);
};


TicketingMap.prototype.deselectAllSeats = function(renderImmediate) {
    SeatingChart.prototype.deselectAllSeats.call(this, renderImmediate);

    this.unFocusSeats();
    this.IB.emit(this.IB.EVENT.MAP_BLUR_SEAT);
};

/**********
 * prototype
 **********/
TicketingMap.prototype.ERROR = {
    E01: '지정석과 비지정석은\n동시에 선택할 수 없습니다.',
    E02: '비지정석은 1개만\n선택할 수 있습니다.'
};

TicketingMap.STATUS = {
    NORMAL: 0,
    FOCUS: 1
};

/**********
 * public methods
 **********/

/**
 * 전달된 Seat배열안에 현재 포커스된 죄석이있는지 리턴
 * @param {Seat[]} seats
 * @returns {boolean}
 */
TicketingMap.prototype.isFocusedSeat = function(seats) {
    var seatIds = ne.util.map(seats, function(seat) {
        return seat.sid;
    });

    return this.focusSeatController.seats.has(seatIds);
};

/**
 * SeatData를 전달받아 비지정석이 있으면 Focus상태로 이동시킨다.
 * @param {object} e 좌석 데이터
 */
TicketingMap.prototype.focusSeats = function(e) {
    //여기서 e에 넘어오는 데이터는 실제 모델
    var fSeatCtrl = this.focusSeatController,
        copiedNSeat;

    if (e.n.length) {
        copiedNSeat = e.n[0].clone();
        //비지정석만 Focus상태로 이동.
        fSeatCtrl.addSeat(copiedNSeat);
        fSeatCtrl.update();
        this._status = TicketingMap.STATUS.FOCUS;
    }
};

/**
 * 모든 Focus상태를 해제한다.
 */
TicketingMap.prototype.unFocusSeats = function() {
    var fSeatCtrl = this.focusSeatController;

    fSeatCtrl.removeAllSeat();
    fSeatCtrl.update();

    this._status = TicketingMap.STATUS.NORMAL;
};

/**
 * SeatData를 Select상태로 이동하고 다시 그린다.
 * @param {object} e 좌석 데이터
 */
TicketingMap.prototype.selectSeats = function(e) {
    //여기서 e에 넘어오는 데이터는 모델의 sid
    this.addSeatToSelectController(e);
    this.update();
};

/**
 * SeatData를 이용해서 Select로 이동
 * @param {object} e 좌석 데이터
 */
TicketingMap.prototype.addSeatToSelectController = function(e) {
    //IB의 CONTROL_SELECT_SEAT이벤트 핸들러
    var selectCtrl = this.selectSeatController,
        seatsToSelect = this.searchSeats(e.r.concat(e.n));

    this.IB.set('selectedSeats', selectCtrl.seats);

    seatsToSelect.seats.each(function(seat) {
        seat.soldout = false;
    });
    seatsToSelect.extract();

    selectCtrl.addSeat([].concat(seatsToSelect.r, seatsToSelect.n));
};

/**
 * 선태가능한 좌석만 가려낸다
 * @param {Seat[]} seats
 * @returns {Array}
 */
TicketingMap.prototype.filterSeatIfAvailable = function(seats) {
    var filteredSeats = [];

    ne.util.forEach(seats, function(seat) {
        if (!seat.soldout) {
            filteredSeats.push(seat);
        }
    });
    return filteredSeats;
};

/**
 * 모든 컨트롤러를 업데이트한다.(focus제외)
 */
TicketingMap.prototype.update = function() {
    this.selectSeatController.update();
    this.gridController.refreshGridsInViewport();
    this.nSeatController.update();
};

/**********
 * event handler
 **********/

/**
 * 좌석 선택 로직 구현
 * @param {object} seatData 좌석 데이터
 * @returns {boolean}
 * @private
 */
TicketingMap.prototype._onBeforeSelectSeat = function(seatData) {
    var rSeatCount,
        nSeatCount;

    seatData.r = this.filterSeatIfAvailable(seatData.r);
    seatData.n = this.filterSeatIfAvailable(seatData.n);

    if (this.ghm.isActive()) {
        seatData.r = this.ghm.filterHighlightSeat(seatData.r);
        seatData.n = this.ghm.filterHighlightSeat(seatData.n);
    }

    nSeatCount = seatData.n.length;
    rSeatCount = seatData.r.length;

    if (nSeatCount > 1) {
        alert(this.ERROR.E02);
        return false;
    }

    if (!rSeatCount && !nSeatCount) {
        return false;
    }
};

/**
 * 디셀렉트시 비지정석은 클릭으로 디셀렉트할수 없다.
 * 여기서도 비지정석 지정석 동시 선택이 불가능하고 지정석만 디셀렉트가능하도록 작업
 * @param {object} seatData 좌석 데이터
 * @returns {boolean}
 * @private
 */
TicketingMap.prototype._deselectSeatsIfNeed = function(seatData) {
    var sidToDeselect,
        selectCtrl,
        seats = seatData.seats;

    if (this.ghm.isActive()) {
        this.ghm.filterHighlightSeat(seats);
    }

    if (this.hasSelectedSeat()) {
        // 좌석 선택할 때 이미 선택한 좌석을 다시 선택할때 처리
        sidToDeselect = [];
        selectCtrl = this.selectSeatController;
        selectCtrl.seats.each(function(seat) {
            var sid = seat.sid;
            if (seats.has(sid) && seat.name !== 'NSeat') {
                seats.remove(sid);
                sidToDeselect.push(sid);
            }
        });
        if (sidToDeselect.length) {
            seatData.refresh();
            this.deselectSeatsByIds(sidToDeselect, true);
        }
    }
};

module.exports = TicketingMap;
