/**
 * @fileoverview ScheduleView
 * @author FE개발팀 김성호 sungho-kim@nhnent.com
 *
 * 회차 선택
 * - 콜센터, 사용자 예매 화면에 사용
 */

'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    UIModel = require('../../../ui/model'),
    UICollection = require('../../../ui/collection'),
    tmplList = require('../../../../tmpl/ticketing/scheduleView/scheduleView_list.html');

/**
 * ScheduleModel
 * 회차 정보를 갖고있는 모델
 * @exports ScheduleModel
 * @extends {UIModel}
 * @constructor
 * @class
 **/
var ScheduleModel = UIModel.extend(/** @lends UIModel.prototype */{
    init: function(data) {
        UIModel.call(this, data, {
            parse: true
        });
    },
    defaults: {
        logicalPlanId: null,
        productRound: null,
        time: null,
        scheduleId: null,
        isAvailable: null
    },

    /**
     * 데이터를 파싱해 모델에 맞게 가공한다
     * @param {object} data 가공할 데이터
     * @returns {object}
     */
    parse: function(data) {
        var date = new Date(data.startDatetime),
            parsedData = {},
            hour,
            min;
        parsedData.scheduleId = data.scheduleId;
        parsedData.logicalPlanId = data.logicalPlanId;
        parsedData.productRound = data.productRound;
        parsedData.productDate = date.getFullYear() + '.' + (date.getMonth() + 1) + '.' + date.getDate();
        hour = date.getHours();
        min = date.getMinutes();
        parsedData.time = (hour < 10 ? '0' + hour : hour) + ':' + (min < 10 ? '0' + min : min);
        return parsedData;
    }
});

/**
 * Schedules
 * @exports Schedules
 * @extends {UICollection}
 * @constructor
 * @class
 **/
var Schedules = UICollection.extend(/** @lends UICollection.prototype */{
    init: function(models) {
        UICollection.call(this, models);
    },
    model: ScheduleModel
});

/**
 * ScheduleView
 * 회차 선택 UI
 * @exports ScheduleView
 * @extends {UIController}
 * @constructor
 * @class
 **/
var ScheduleView = UIController.extend(/** @lends UIController.prototype */{
    rootElement:$('#roundSelect'),
    events: {
        'click li': '_onClickRound'
    },
    availableTmpl: tmplList,
    init: function ScheduleView(options) {
        var self = this,
            EVENT;
        UIController.call(this, options);
        EVENT = this.IB.EVENT;
        this.selectedItem = null;
        this.collection = new Schedules();
        this.collection.on('set', function() {
            self.render();
        });
        this.listen(EVENT.ROUND_LOADED, function(data) {
            self.setData(data);
        });
        this.IB.listen(this.IB.EVENT.ROUND_SELECT, this._onRoundSelect, this);
        this.IB.listen(this.IB.EVENT.AVAILABLE_DATES_LOADED, this._clear, this);
        if (ne.util.isTruthy(options.initialRound)) {
            this.setInitialRound(options.initialRound);
        }
    },

    /**
     * collection 정보를 초기화한다.
     * @private
     */
    _clear: function() {
        this.collection.set([]);
    },

    /**
     * 회차정보를 전달한다
     * @param {Object} data 회차 정보
     */
    setData: function(data) {
        this.collection.set(data);
    },

    /**
     * 뷰를 그린다
     */
    render: function() {
        this.detachEvents();
        this.remove();
        this.renderItemsIfNeed();
        this.setInitSelectItemIfNeed();
        this.attachEvents();
    },

    /**
     * 회차를 표현하는 목록 그린다
     */
    renderItemsIfNeed: function() {
        var self = this;
        if (this.collection.length > 0) {
            this.collection.forEach(function(model) {
                var container;
                container = $(self.template(self.availableTmpl, model.toJSON())[0]);
                container.data('model', model);
                self.$el.append(container);
            });
        }
    },

    /**
     * 렌더링할때 디폴트로 선택할 회차의 번호를 입력한다
     * @param {number} number 회차의 번호
     */
    setInitialRound: function(number) {
        this.initialRound = number;
    },

    /**
     * 렌더링시 회차를 선택한다
     */
    setInitSelectItemIfNeed: function() {
        var itemToSelect;
        if (ne.util.isTruthy(this.initialRound)) {
            itemToSelect = this.$el.children()[this.initialRound];
            this.setSelectedItem(itemToSelect);
        }
    },

    /**
     * 회차 선택 이벤트 발생시 핸들러
     * @param {Number} productRound
     * @private
     */
    _onRoundSelect: function(productRound) {
        productRound = +productRound;

        var model,
            $el,
            $liList = this.$el.find('li'),
            index = 0;

        ne.util.forEachArray($liList, function(item, i) {
            model = $liList.eq(i).data('model');
            if (parseInt(model.get('productRound'), 10) === productRound) {
                index = i;
                return false;
            }
        });

        $el = $liList.eq(index);
        this.setSelectedItem($el.get(0));
    },

    /**
     * 회차가 클릭시 이벤트핸들러
     * @param {jQuery.Event} e jQuery 이벤트
     * @private
     */
    _onClickRound: function(e) {
        e.preventDefault();
        this.setSelectedItem(e.currentTarget);
    },

    /**
     * 선택된 엘리먼트가 유효한 엘리먼트인지 판단한다
     * @param {HTMLElement} target 선택된 엘리먼트
     * @returns {boolean}
     */
    isSelectible: function(target) {
        var selectedModel = $(target).data('model');
        return !this.selectedItem || (this.selectedItem.data('model') !== selectedModel);
    },

    /**
     * 선택된 회차를 해제한다.
     */
    clearSelectedItem: function() {
        if (this.selectedItem) {
            this.selectedItem.removeClass('select');
            this.selectedItem = null;
        }
    },

    /**
     * View를 지운다
     */
    remove: function() {
        this.$el.empty();
        this.clearSelectedItem();
    },

    /**
     * UI가 나타내는 값을 JSON으로 리턴한다.
     * @returns {ScheduleModel}
     */
    toJSON: function() {
        return this.selectedItem && this.selectedItem.data('model').toJSON();
    },

    /**
     * 선택된 회차정보를 데이터 형태로 저장한다.
     * @param {HTMLElement} el 선택된 엘리먼트
     */
    setSelectedItem: function(el) {
        var EVENT = this.IB.EVENT;
        if (el && this.isSelectible(el)) {
            this.clearSelectedItem();
            this.selectedItem = $(el);
            this.selectedItem.addClass('select');
            this.emit(EVENT.ROUND_SELECTED, this.toJSON());
        }
    }
});

module.exports = ScheduleView;
