/**
 * @fileoverview 상품 정보 영역
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */
'use strict';
var tkl = ne.tkl,
    UIController = tkl.UIController;

/**
 * 상품 정보 UI
 * @exports ProductInfoUI
 * @extends {UIController}
 * @constructor
 * @class
 * **/
var ProductInfoUI = UIController.extend({
    events: {
        'click': '_onClick'
    },
    
    /**
     * 초기화
     * @param {Object} options
     *      @param {String} options.template    템플릿
     * @constructor
     */
    init: function ProductInfo(options) {
        UIController.call(this, options);
        window.ne.tkl.ticketing.callback.setProductId = ne.util.bind(this.setProductId, this);
        this._urlData = this.IB.get('popupUrl');
        this._template = options.template;
        this.listen(this.IB.EVENT.PRODUCT_INFO_LOADED, this.render, this);
        this.render();
    },

    /**
     * 랜더링한다.
     */
    render: function(productData) {
        var notice = '등록된 공지사항이 없습니다.';

        productData = ne.util.extend({
            productName: '-',
            productText: this._getProductText(productData)
        }, productData);

        productData.notice = productData.notice || notice;

        this.detachEvents();
        this.$el.html(this.template(this._template, productData));
        this.attachEvents();
    },

    /**
     * 서버로 부터 받아온 데이터를 기반으로
     * 노출할 상품 정보 텍스트를 가공하여 반환한다.
     * @param {Object} productData 서버로부터 받아온 데이터
     * @returns {string} 노출할 상품 정보 텍스트
     * @private
     */
    _getProductText: function(productData) {
        var productTextArray = [],
            ticketDeliveryType,
            productText = '-';

        if (ne.util.isExisty(ne.util.pick(productData, 'placeName')) && ne.util.isExisty(ne.util.pick(productData, 'hallName'))) {
            productTextArray.push(productData.placeName);
            productTextArray.push('/');
            productTextArray.push(productData.hallName);
        }

        if (ne.util.isExisty(ne.util.pick(productData, 'ticketDeliveryType'))) {
            if (productData.ticketDeliveryType === 'TICKETLINK') {
                ticketDeliveryType = '티켓링크';
            } else if (productData.ticketDeliveryType === 'AGENCY') {
                ticketDeliveryType = '기획사';
            }

            if (ticketDeliveryType) {
                productTextArray.push('/');
                productTextArray.push('(' + ticketDeliveryType + ')');
            }
        }

        if (productTextArray.length) {
            productText = productTextArray.join(' ');
        }

        return productText;
    },
    
    /**
     * 클릭 이벤트 핸들러
     * @param {Event} clickEvent 클릭 이벤트
     * @private
     */
    _onClick: function(clickEvent) {
        var $target = $(clickEvent.target),
            height = $(document).height();

        if ($target.hasClass('_productSelect')) {
            //상품 조회 팝업
            this._openPopup(this._urlData.PRODUCT_INFO, {
                popupName: 'productInfo',
                param: {
                    loadPage: this.IB.get('sellingTypeCode')
                }
            });
        } else if($target.hasClass('_productDetail')) {
            if (ne.util.isExisty(this.IB.get('productId'))) {
                //상품 상세보기 팝업
                this._openPopup(this._urlData.PRODUCT_DETAIL, {
                    popupName: 'productDetail',
                    popupOptionStr: 'width=1180,height=' + height + ',resizable=yes,scrollbars=yes',
                    param: {
                        productId: this.IB.get('productId')
                    }
                });
            }
        } else if($target.hasClass('_productManagerDetail')) {
            //상품 담당자 정보 팝업
            this._openPopup(this._urlData.PRODUCT_MANAGER_DETAIL, {
                popupName: 'productManagerDetail',
                param: {
                    productId: this.IB.get('productId')
                }
            });
        } else if($target.hasClass('_notice')) {
            //공지사항 팝업
            this._openPopup(this._urlData.NOTICE, {
                popupName: 'notice',
                param: {
                    productId: this.IB.get('productId')
                }
            });
        }
    },

    /**
     * 팝업을 open 한다.
     * @param {String} url 팝업 url
     * @param {Object} options  ne.util.popup.openPopup 의 option 파라미터
     * @private
     */
    _openPopup: function(url, options) {
        url = this.template(url, options.param);
        options = ne.util.extend({
            popupOptionStr: 'width=1000,height=900,resizable=yes,scrollbars=yes',
            method: 'GET'
        }, options);
        options.param = null;
        ne.util.popup.openPopup(url, options);
    },

    /**
     * 상품정보 변경시 이벤트 발생
     */
    setProductId: function(productId) {
        if (this.IB.get('productId') !== productId && ne.util.isFunction(this.IB.confirmResetSeatingList) && this.IB.confirmResetSeatingList()) {
            this.IB.emit(this.IB.EVENT.PRODUCT_CHANGE, productId);
        }
    }
});

module.exports = ProductInfoUI;

