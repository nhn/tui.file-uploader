/**
 * @fileoverview NSeatCounterLayer 비지정석 매수입력 UI를 컨트롤한다.
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */
'use strict';
var tkl = ne.tkl,
    UIController = tkl.UIController;

/**
 * NSeatCounterLayer
 * @exports NSeatCounterLayer
 * @extends {UIController}
 * @constructor
 * @class
 * **/
var NSeatCounterLayer = UIController.extend({
    events: {
        'click': '_onClick',
        'keydown input': '_onKeydown'
    },

    /**
     * 생성자
     * @param {object} options
     *      @param {number} [options.maxCount=10]    최대 티켓 구매 수량
     * @constructor
     */
    init: function NSeatCounter(options) {
        UIController.call(this, options);
        this.selectedSeats = [];
        this.maxCount = options && options.maxCount || 10;
        this._initializeElements();
        this._initializeListenToIB();
        this.close();
    },

    /**
     * 버튼 템플릿
     */
    _template: {
        confirm: '<a href="#" class="btn_text confirm _submit">확인</a>',
        modify: '<a href="#" class="btn_text change _submit">변경</a>' +
        '<a href="#" class="btn_text cancel _clear">전체취소</a>'
    },

    /**
     * IB 와 이벤트 핸들러 연결
     * @private
     */
    _initializeListenToIB: function() {
        this.listen(this.IB.EVENT.MAP_BLUR_SEAT, this.hide, this);
        this.listen(this.IB.EVENT.MAP_DESELECT_ALL_SEAT, this.hide, this);
        this.listen(this.IB.EVENT.NON_RESERVED_FOCUSED, this.show, this);
        this.listen(this.IB.EVENT.MAP_MOVE_START, this.close, this);
    },

    /**
     * 엘리먼트 초기화
     * @private
     */
    _initializeElements: function() {
        this.$button = this.$el.find('._button');
        this.$input = this.$el.find('input:first');
        this.$form = this.$el.find('form:first');
        this.$form.on('submit', this._onSubmit);
    },

    /**
     * submit 이벤트 발생시 이벤트 기본 동작을 막는다.
     * @param {Event} formEvent 폼 이벤트
     * @private
     */
    _onSubmit: function(formEvent) {
        formEvent.preventDefault();
    },

    /**
     * 레이어를 닫는다.
     */
    close: function() {
        this.hide();
        this.IB.emit(this.IB.EVENT.CONTROL_BLUR_SEAT);
    },

    /**
     * 레이어를 띄운다.
     * @param {Array} seats     좌석 데이터
     * @param {number} count    현재 선택한 좌석수
     * @param {event} mouseEvent    레이어의 위치를 잡기위해 mouse event 를 받는다.
     */
    show: function(seats, count, mouseEvent) {
        var type = count > 0 ? 'modify' : 'confirm';
        this.$el.css({
            left: mouseEvent.clientX + 'px',
            top: mouseEvent.clientY + 'px'
        });
        this.selectedSeats = seats;
        this.render(type);
        this.$input.val(count);
        this.$el.show();
        this.$input.focus().select();
    },

    /**
     * 레이어를 숨긴다.
     */
    hide: function() {
        this.$el.hide();
    },

    /**
     * 랜더링한다.
     * @param {String} type 수정 모드인지, 확인 모드인지 여부
     */
    render: function(type) {
        this.detachEvents();
        if (type === 'modify') {
            this.$button.html(this._template.modify);
        } else {
            this.$button.html(this._template.confirm);
        }
        this.attachEvents();
    },

    /**
     * input 에 값을 설정한다.
     * @param {number} value 설정할 매수
     */
    setValue: function(value) {
        this.$input.val(value);
    },

    /**
     * click 이벤트 핸들러
     * @param {event} clickEvent 클릭이벤트
     * @private
     */
    _onClick: function(clickEvent) {
        var $target = $(clickEvent.target);
        if ($target.hasClass('_submit')) {
            this._onApply();
        } else if ($target.hasClass('_increase')) {
            this._increase();
        } else if ($target.hasClass('_decrease')) {
            this._decrease();
        } else if ($target.hasClass('_close')) {
            this.close();
        } else if ($target.hasClass('_clear')) {
            this._onReset();
        }
    },

    /**
     * 매수를 증가시킨다.
     * @private
     */
    _increase: function() {
        var count = +this.$input.val() || 0;
        if (count < this.maxCount) {
            count += 1;
        }
        this.$input.val(count);
    },

    /**
     * 매수를 감소시킨다.
     * @private
     */
    _decrease: function() {
        var count = +this.$input.val() || 0;
        if (count > 0) {
            count -= 1;
        }
        this.$input.val(count);
    },

    /**
     * keyDown 이벤트 핸들러
     * @param {event} keyDownEvent   이벤트
     * @returns {boolean}
     * @private
     */
    _onKeydown: function(keyDownEvent) {
        var count = this.$input.val() || 0;
        keyDownEvent.stopPropagation();
        if (keyDownEvent.keyCode === 13) {
            //ENTER
            keyDownEvent.preventDefault();
            this.apply(count);
            return false;
        } else if (keyDownEvent.keyCode === 27) {
            //ESC
            keyDownEvent.preventDefault();
            this.close();
            return false;
        }
    },

    /**
     * 유효성 검사한다.
     * @param {String|Number} count 입력된 값
     * @returns {boolean}
     * @private
     */
    _validate: function(count) {
        if (!/^[0-9]+$/.test(count)) {
            alert('숫자만 입력 가능합니다.');
            return false;
        } else {
            return true;
        }
    },

    /**
     * 취소 버튼 클릭시
     * @private
     */
    _onReset: function() {
        if (this.selectedSeats) {
            this.setValue('');
            this._deselect();
            this.IB.emit(this.IB.EVENT.CONTROL_BLUR_SEAT);
        }
    },

    /**
     * 반영 버튼 클릭시
     * @private
     */
    _onApply: function() {
        var count = this.$input.val();
        this.apply(count);
    },

    /**
     * 매수를 반영 한다.
     * @param {Number} count 반영할 티켓 매수
     */
    apply: function(count) {
        if (this.selectedSeats && this._validate(count)) {
            this.setValue(count);
            this._select(count);
        }
    },

    /**
     * Map 에 해당 비지정석 영역에 select 표시 한다.
     * @param {Number} count 할당할 매수
     * @private
     */
    _select: function(count) {
        count = +count;
        if (this.selectedSeats) {
            if (count === 0) {
                this._deselect();
            } else {
                this.IB.emit(this.IB.EVENT.PURCHASE_SEAT, {
                    seats: this.selectedSeats,
                    isReserved: false,
                    count: count
                });
            }
        }
    },

    /**
     * Map 에서 해당 비지정석 영역의 Select 표시를 해제한다.
     * @private
     */
    _deselect: function() {
        if (this.selectedSeats) {
            this.IB.emit(this.IB.EVENT.CONTROL_DESELECT_SEAT, {
                n: [this.selectedSeats[0].seatId],
                r: []
            });
        }
        this.hide();
    }
});

module.exports = NSeatCounterLayer;
