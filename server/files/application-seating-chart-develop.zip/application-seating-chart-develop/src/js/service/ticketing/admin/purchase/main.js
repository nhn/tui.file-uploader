/**
 * @fileoverview 현장, 기획사, 예매처 초기 진입점
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */
'use strict';

var TicketingIB = require('../../ticketingIB'),
    Purchase = require('../../admin/purchase/controller'),
    IB;

/**
 * 초기화 함수.
 * 서비스 코드에서 호출할 진입점
 * @param {Object} options
 *      @param {Object} options.mapOptions
 *      @param {Object} options.params
 *          @param {String} options.params.sellingTypeCode  진입점 정보(할당처 기획사 예매처 등)
 *          @param {String} options.params.reserveMemberNo  예매자 정보
 *          @param {String} options.params.loginMemberNo  로그인 사용자 정보
 *      @param {Object} options.callback
 *          @param {function} options.callback.onSubmit     완료 버튼 누를 시점의 콜백
 *          @param {function} options.callback.onSuccessSubmit  완료 응답 이후 콜백
 *          @param {function} options.callback.onFailSubmit 완료 실패 응답 이후 콜백
 */
function init(options) {
    var params = options.params,
        mapOptions = options.mapOptions,
        callback = options.callback || {},
        controller;

    IB = new TicketingIB();

    IB.set('popupUrl', window._adminConfig.popupUrl);
    IB.set('sellingTypeCode', params.sellingTypeCode);
    IB.set('reserveMemberNo', params.reserveMemberNo);
    IB.set('loginMemberNo', params.loginMemberNo);
    IB.set('preoccupancyMemberNo', params.preoccupancyMemberNo);
    IB.set('isSkipRequestPreoccupancy', true);  //선점조회 API 스킵여부
    IB.set('mapOptions', mapOptions);

    controller = new Purchase({
        params: params,
        mapOptions: mapOptions,
        IB: IB
    });

    //public 으로 제공할 인터페이스 콜백을 바인딩한다.
    ne.util.forEach(callback, function(fn, name) {
        controller.on(name, fn);
    });
}

/**
 * 페이지 unload 시 alert 여부를 결정한다.
 * @param {boolean} isUseUnloadCheck alert 여부
 */
function useUnloadCheck(isUseUnloadCheck) {
    isUseUnloadCheck = ne.util.isUndefined(isUseUnloadCheck) ? true : isUseUnloadCheck;
    if (isUseUnloadCheck) {
        IB.enableUnloadCheck();
    } else {
        IB.disableUnloadCheck();
    }
}

/**
 * 페이지를 reload 한다.
 */
function reload() {
    IB.reload();
}

global.ne.tkl.main = {
    init: init,
    useUnloadCheck: useUnloadCheck,
    reload: reload
};

