/**
 * @fileoverview SeatingInfoPerRound
 * @author FE개발팀 김성호 sungho-kim@nhnent.com
 */
'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    UIModel = require('../../../ui/model'),
    UICollection = require('../../../ui/collection'),
    etc = require('../../../etc'),
    tmplItemTypeABasicNormal = require('../../../../tmpl/ticketing/seatingInfoPerRound/itemTypeABasicNormal.html'),
    tmplItemTypeABasicSoldout = require('../../../../tmpl/ticketing/seatingInfoPerRound/itemTypeABasicSoldout.html'),
    tmplItemTypeBBasicNormal = require('../../../../tmpl/ticketing/seatingInfoPerRound/itemTypeBBasicNormal.html'),
    tmplItemTypeBBasicSoldout = require('../../../../tmpl/ticketing/seatingInfoPerRound/itemTypeBBasicSoldout.html'),
    tmplItemTypeBTotalNormal = require('../../../../tmpl/ticketing/seatingInfoPerRound/itemTypeBTotalNormal.html'),
    tmplItemTypeBTotalSoldout = require('../../../../tmpl/ticketing/seatingInfoPerRound/itemTypeBTotalSoldout.html'),
    tmplItemTypeCBasicNormal = require('../../../../tmpl/ticketing/seatingInfoPerRound/itemTypeCBasicNormal.html'),
    tmplItemTypeCBasicSoldout = require('../../../../tmpl/ticketing/seatingInfoPerRound/itemTypeCBasicSoldout.html');


/**
 * SeatInfo
 * @exports SeatInfo
 * @extends {UIModel}
 * @constructor
 * @class
 **/
var SeatInfo = UIModel.extend(/** @lends UIModel.prototype */{
    init: function(data) {
        UIModel.call(this, data);
    },
    defaults: {
        'productGradeId': null,
        'productGradeName': '',
        'priority': 0,
        'gradePrice': 0,
        'totalSeatCount': 0,
        'emptySeatCount': 0,
        'occupySeatCount': 0,
        'reserveSeatCount': 0,
        'colorCode': '#FFF'
    },
    isTotalInfo: function() {
        return this.get('productGradeName') === '전체';
    },
    isSoldout: function() {
        return this.get('seatCountToShow') <= 0;
    }
});

/**
 * SeatInfos
 * @exports SeatInfos
 * @extends {UICollection}
 * @constructor
 * @class
 **/
var SeatInfos = UICollection.extend({
    model: SeatInfo,

    /**
     * 생성자
     * @param {Array} models   초기화 할 데이터 배열
     */
    init: function(models) {
        UICollection.call(this, models, {
            parse: true
        });
    },

    /**
     * 100,000 와 같은 형태의 String 을 number 형태로 변환한다.
     * @param {String} str  숫자 포멧 문자열
     * @return {Number} Number 형 변환 데이터
     * @private
     */
    _toNumber: function(str) {
        str = str || 0;
        var returnVal;
        if (ne.util.isString(str)) {
            returnVal = +str.replace(/\,/g, '');
        } else {
            returnVal = str;
        }
        return returnVal;
    },

    /**
     * collection 에 저장할 데이터를 파싱한다.
     * @param {Object} data 파싱할 서버로부터 받은 데이터
     * @returns {{}[]} 파싱 완료된 데이터
     */
    parse: function(data) {
        var parsedData = [{}],
            totalEmptySeatCount = 0;

        ne.util.forEach(data, function(datum) {
            var converted = {
                'productGradeId': this._toNumber(datum.productGradeId),
                'productGradeName': datum.name,
                'priority': datum.priority,
                'gradePrice': this._toNumber(datum.price),
                'totalSeatCount': this._toNumber(datum.total),
                'emptySeatCount': this._toNumber(datum.available),
                'occupySeatCount': this._toNumber(datum.preoccupancyCount),
                'reserveSeatCount': this._toNumber(datum.reserveCount),
                'colorCode': datum.colorCode
            };
            converted.seatCountToShow = converted.emptySeatCount;
            totalEmptySeatCount += converted.emptySeatCount;
            if (ne.util.isExisty(ne.util.pick(converted, 'priority'))) {
                parsedData[converted.priority] = converted;
            } else {
                parsedData.push(converted);
            }
        }, this);

        parsedData[0] = {
            'productGradeName': '전체',
            'seatCountToShow': totalEmptySeatCount
        };

        return parsedData;
    }
});

/**
 * SeatingInfoPerRoundItem
 * 등급별 좌석정보 UI
 * @exports SeatingInfoPerRoundItem
 * @extends {UIController}
 * @constructor
 * @class
 **/
var SeatingInfoPerRoundItem = UIController.extend(/** @lends UIController.prototype */{
    tagName: 'li',
    init: function SeatingInfoPerRoundItem(options) {
        UIController.call(this, options);
        if (options.model) {
            this.setModel(options.model);
        }
    },

    /**
     * 모델을 셋팅한다
     * @param model
     */
    setModel: function(model) {
        this.model = model;
    },

    /**
     * View를 그린다.
     * @returns {SeatingInfoPerRoundItem}
     */
    render: function() {
        var model = this.model,
            tmpl = this.getTemplateSrc(),
            container,
            data = etc.formatNumberEachObject(ne.util.extend({}, model.toJSON()));

        if (!model.isSoldout()) {
            container = $(this.template(tmpl.normal, data)[0]);
        } else {
            container = $(this.template(tmpl.soldout, data)[0]);
            this.$el.addClass('soldout');
        }
        this.$el.data('model', model);
        this.$el.append(container);
        this.attachEvents();
        return this;
    },

    /**
     * 전체를 표현하는 UI와 구분하기위해 템플릿을 선택한다
     * @returns {string}
     */
    getTemplateSrc: function() {
        return this.model.isTotalInfo() ? this.tmpl.total : this.tmpl.basic;
    }
});

/**
 * SeatingInfoPerRoundItemA
 * http://ui-dev.nhnent.com/svnview/hivelab/ticketlink/web/trunk/02_reserve/reserve_step1.html
 *
 * @exports SeatingInfoPerRoundItemA
 * @extends {SeatingInfoPerRoundItem}
 * @constructor
 * @class
 **/
var SeatingInfoPerRoundItemA = SeatingInfoPerRoundItem.extend(/** @lends SeatingInfoPerRoundItem.prototype */{
    tmpl: {
        basic: {
            normal: tmplItemTypeABasicNormal,
            soldout: tmplItemTypeABasicSoldout
        }
    },
    init: function SeatingInfoPerRoundItemA(options) {
        SeatingInfoPerRoundItem.call(this, options);
        this.tmpl.total = this.tmpl.basic;
    }
});

/**
 * SeatingInfoPerRoundItemB
 * http://ui-dev.nhnent.com/svnview/hivelab/ticketlink/admin/trunk/04_sale/0_popup_reserve.html
 *
 * @exports SeatingInfoPerRoundItemA
 * @extends {SeatingInfoPerRoundItem}
 * @constructor
 * @class
 **/
var SeatingInfoPerRoundItemB = SeatingInfoPerRoundItem.extend(/** @lends SeatingInfoPerRoundItem.prototype */{
    tmpl: {
        basic: {
            normal: tmplItemTypeBBasicNormal,
            soldout: tmplItemTypeBBasicSoldout
        },
        total: {
            normal: tmplItemTypeBTotalNormal,
            soldout: tmplItemTypeBTotalSoldout
        }
    },
    init: function SeatingInfoPerRoundItemB(options) {
        SeatingInfoPerRoundItem.call(this, options);
    }
});

/**
 * SeatingInfoPerRoundItemC
 * http://ui-dev.nhnent.com/svnview/hivelab/ticketlink/web/trunk/01_theater/detail.html
 *
 * @exports SeatingInfoPerRoundItemC
 * @extends {SeatingInfoPerRoundItem}
 * @constructor
 * @class
 **/
var SeatingInfoPerRoundItemC = SeatingInfoPerRoundItem.extend(/** @lends SeatingInfoPerRoundItem.prototype */{
    tmpl: {
        basic: {
            normal: tmplItemTypeCBasicNormal,
            soldout: tmplItemTypeCBasicSoldout
        }
    },
    init: function SeatingInfoPerRoundItemB(options) {
        SeatingInfoPerRoundItem.call(this, options);
        this.tmpl.total = this.tmpl.basic;
    }
});

/**
 * SeatingInfoPerRound
 * 등급별 좌석 정보 목록 UI
 * @exports SeatingInfoPerRound
 * @extends {UIController}
 * @constructor
 * @class
 * **/
var SeatingInfoPerRound = UIController.extend(/** @lends UIController.prototype */{
    rootElement: $('#seatingInfoPerRound'),
    events: {
        'click li': '_onClickGrade'
    },
    init: function SeatingInfoPerRound(options) {
        var self = this,
            EVENT;
        UIController.call(this, options);
        EVENT = this.IB.EVENT;
        this.type = options.type !== undefined ? options.type : SeatingInfoPerRound.TYPE.SELECTABLE;
        this.setItemConstructor();
        this.collection = new SeatInfos();
        this.collection.on('set', function() {
            self.render();
        });
        this.collection.on('clear', function() {
            self.render();
        });
        this.listen(EVENT.AVAILABLE_SEATINFO_LOADED, function(data) {
            self.setData(data);
        });
        this.listen(EVENT.DATE_SELECTED, function() {
            self.collection.clear();
        });
        this.listen(EVENT.ROUND_UNSELECTED, function() {
            self.collection.clear();
        });
    },
    /**
     * 데이터를 셋팅한다
     * @param {object} data
     */
    setData: function(data) {
        var parsedData = this.collection.parse(data);
        this.collection.set(parsedData);
    },
    /**
     * 뷰를 그린다
     */
    render: function() {
        this.detachEvents();
        var self = this,
            ItemConstr = this.ItemConstr,
            EVENT = this.IB.EVENT,
            item;
        this.$el.empty();
        //비지정석 1개인 경우에 랜더링 하지 않도록 메서드 추가
        if (this.IB.isOnlyZone && this.IB.isOnlyZone()) {
            return;
        }
        this.collection.forEach(function(seatInfo) {
            item = new ItemConstr({
                model: seatInfo
            });
            self.$el.append(item.render().$el);
        });
        if (this.isSelectable()) {
            this.attachEvents();
        }
        this.emit(EVENT.SEAT_GRADE_DESELECTED);
    },
    /**
     * 등급 클릭 이벤트 핸들러
     * @param {jQuery.Event} e
     * @private
     */
    _onClickGrade: function(e) {
        var model = $(e.currentTarget).data('model'),
            EVENT = this.IB.EVENT;
        e.preventDefault();
        this.emit(EVENT.SEAT_GRADE_SELECTED, model.get('productGradeId'));
    },
    /**
     * 선택이 가능한 UI인지 확인한다
     * @returns {boolean}
     */
    isSelectable: function() {
        return this.type === SeatingInfoPerRound.TYPE.SELECTABLE;
    },
    /**
     * 타입에 따라 등급별 좌석정보 UI의 종류를 선택한다.
     */
    setItemConstructor: function() {
        var TYPE = SeatingInfoPerRound.TYPE;
        switch (this.type) {
            case TYPE.BASIC:
                this.ItemConstr = SeatingInfoPerRoundItemA;
                break;
            case TYPE.BASIC_FOR_DETAIL:
                this.ItemConstr = SeatingInfoPerRoundItemC;
                break;
            case TYPE.SELECTABLE:
                this.ItemConstr = SeatingInfoPerRoundItemB;
                break;
            default:
                this.ItemConstr = SeatingInfoPerRoundItemA;
        }
    },
    static: {
        TYPE: {
            BASIC: 0,
            BASIC_FOR_DETAIL: 1,
            SELECTABLE: 2
        }
    }
});

module.exports = SeatingInfoPerRound;
