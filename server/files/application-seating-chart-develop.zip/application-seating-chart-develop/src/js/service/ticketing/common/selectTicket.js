/**
 * @fileoverview 예매 --> 권종선택 영역
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */

'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    UIModel = require('../../../ui/model'),
    UICollection = require('../../../ui/collection'),
    etc = require('../../../etc'),
    tmpl = require('../../../../tmpl/ticketing/selectTicket/main.html'),
    tmplMainRow = require('../../../../tmpl/ticketing/selectTicket/rowMain.html'),
    tmplRow = require('../../../../tmpl/ticketing/selectTicket/row.html'),
    tmplIcon = require('../../../../tmpl/ticketing/selectTicket/layerIcon.html');

/**
 * 카드 제약 global 모델
 * @type {*}
 */
var CardLimitModel = UIModel.extend({
    init: function(data) {
        UIModel.call(this, data, {
            parse: true
        });
    },
    defaults: {
        code: ''
    }
});

/**
 * 좌석 금액 모델
 * @type {*}
 */
var SeatingPriceModel = UIModel.extend({
    init: function(data) {
        UIModel.call(this, data, {
            parse: true
        });
    },
    idAttribute: 'productGradeId',
    defaults: {
        productGradeId: 0,
        productGradeName: '',
        count: 1
    }
});

/**
 * 좌석 금액 콜랙션
 * @type {*}
 */
var SeatingPriceCollection = UICollection.extend({
    init: function(models) {
        UICollection.call(this, models, {
            parse: true
        });
    },
    model: SeatingPriceModel
});

/**
 * 권종 선택 영역 중 등급별 좌석 View
 * @constructor
 */
var SeatingPriceView = UIController.extend({
    tagName: 'table',
    events: {
        'change select': '_onSelectChange',
        'mouseover ._desc': '_onMouseOver',
        'mouseout ._desc': '_onMouseOut'
    },

    /**
     * 생성자
     * @param options
     */
    init: function(options) {
        UIController.call(this, options);
        this.templateData = options.templateData;
        this.model = options.model;
        this.priceTable = options.priceTable;
        this.cardLimitModel = options.cardLimitModel;
        this.layer = options.layer;
        this.model.on('change:count', this._updateCount, this);
        this.cardLimitModel.on('change:code', this._setRemainSelect, this);
    },

    /**
     * 최대 선택 가능 개수에 따라 select 옵션 및 티켓금액 업데이트
     * @private
     */
    _updateCount: function() {
        var $selectList = this.$el.find('select'),
            gradeName = this.model.get('productGradeName'),
            count = this.model.get('count'),
            optionList,
            optionStrList,
            $select;

        ne.util.forEachArray($selectList, function(item, index) {
            $select = $selectList.eq(index);
            optionList = this._getOptionList($select);
            optionStrList = [];

            ne.util.forEachArray(optionList, function(value) {
                optionStrList.push(['<option value="', value, '">', value, '</option>'].join(''));
            });

            $select.html(optionStrList.join(''));
        }, this);
        this.$el.find('._guideText').text(gradeName + ' ' + etc.formatNumber(count) + '매');
    },
    $destroy: function() {
        this.cardLimitModel.off(this, this._setRemainSelect);
        this.destroy();
    },
    /**
     * select 엘리먼트 변경시 티켓금액 정보 업데이트를 위해 selectChange 이벤트를 발생한다.
     * @private
     */
    _onSelectChange: function() {
        this._setCurrentCardLimit();
        this._setRemainSelect();
        this.fireEvent('selectChange');
    },
    _setCurrentCardLimit: function() {
        var $selectList = this.$el.find('select'),
            cardLimitCode = '';

        $selectList.each(function() {
            var $select = $(this),
                code = $select.data('card-limit-code');

            if ($select.val() > 0 && code) {
                cardLimitCode = code;
                return false;
            }
        });

        this.cardLimitModel.set('code', cardLimitCode);
    },
    _getOptionList: function($select) {
        var selectedCardLimitCode = this.cardLimitModel.get('code'),
            totalCount = this.model.get('count'),
            optionList = ['0'],
            limitData = $select.data(),
            denominationLimitCount = limitData.denominationLimitCount || 0,
            perMinCount = limitData.perMinCount,
            buyDoubleCount = limitData.buyDoubleCount,
            cardLimitCode = limitData.cardLimitCode;

        var i,
            length;

        // 현재 카드 제약이 존재하지 않거나, 현재 카드와 같은 카드제약일 경우에만 셀렉트 생성
        if (!cardLimitCode || !selectedCardLimitCode || selectedCardLimitCode === cardLimitCode) {
            length = denominationLimitCount ? Math.min(denominationLimitCount, totalCount) : totalCount;
            for (i = 1; i < length + 1; i++) {
                if (i >= perMinCount && (i % buyDoubleCount === 0)) {
                    optionList.push(i);
                }
            }
        }

        return optionList;
    },
    /**
     * 잔여 select option 을 설정한다.
     * @private
     */
    _setRemainSelect: function() {
        var $selectList = this.$el.find('select'),
            $select,
            length = $selectList.length,
            currentCount = 0,
            remainCount,
            totalCount = this.model.get('count'),
            val,
            optionList,
            optionStrList,
            maxCount,
            i;

        for (i = 0; i < length; i++) {
            val = +$selectList.eq(i).val();
            currentCount += val;
        }

        remainCount = totalCount - currentCount;

        var self = this;
        $selectList.each(function() {
            $select = $(this);
            optionList = self._getOptionList($select);
            val = +$select.val();
            optionStrList = [];
            maxCount = val + remainCount;

            ne.util.forEachArray(optionList, function(value) {
                if (value > maxCount) {
                    return false;
                } else {
                    optionStrList.push(['<option value="', value, '">', value, '</option>'].join(''));
                }
            });

            $select.html(optionStrList.join('')).val(val);
        });
    },

    /**
     * priceTable 정보로 부터 Layer 에 출력할 text 를 반환한다.
     * @param {(Number|String)} id 해당 권종 ID
     * @returns {string}    권종 상세 정보
     * @private
     */
    _getLayerText: function(id) {
        id = id.toString();

        var gradeId = this.model.get('productGradeId'),
            desc = '';

        ne.util.forEachArray(this.priceTable[gradeId].list, function(item) {
            item.productDenominationId = item.productDenominationId.toString();
            if (item.productDenominationId === id) {
                desc = item.denominationDescription;
                return false;
            }
        });
        return desc;
    },

    /**
     * mouseover 이벤트 핸들러
     * @param {event} mouseEvent 마우스 이벤트
     * @private
     */
    _onMouseOver: function(mouseEvent) {
        var $target = $(mouseEvent.target);
        this.layer.show($target, {
            text: this._getLayerText($target.data('id'))
        });
    },
    _onMouseOut: function() {
        this.layer.hide();
    },

    /**
     * 랜더링한다.
     * @returns {SeatingPriceView}
     */
    render: function() {
        var gradeName = this.model.get('productGradeName'),
            gradeId = this.model.get('productGradeId'),
            count = this.model.get('count'),
            list = ne.util.isExisty(ne.util.pick(this.priceTable[gradeId], 'list')) ? this.priceTable[gradeId].list : [],
            length = list.length,
            rows = [];
        this.detachEvents();

        ne.util.forEachArray(list, function(item, index) {
            var template = (index === 0) ? this.templateData.mainRow : this.templateData.row,
                hasLayer = !!(item.denominationDescription),
                id = item.productDenominationId,
                text = item.productDenominationName,
                notation = item.discountTypeNotation,
                price = item.salePrice;

            if (hasLayer) {
                text += this.template(tmplIcon, {
                    id: id
                });
            }
            rows.push(this.template(template, {
                rowSpan: length,
                text: text,
                id: id,
                notation: notation,
                gradeName: gradeName,
                gradeId: gradeId,
                formattedValue: etc.formatNumber(price),
                cardLimitCode: item.cardLimitCode,
                denominationLimitCount: item.denominationLimitCount,
                perMinCount: item.perMinCount,
                buyDoubleCount: item.buyDoubleCount,
                value: price
            }));
        }, this);
        this.$el.html(this.template(this.templateData.main, {
            gradeName: gradeName,
            quantity: etc.formatNumber(count),
            rows: rows.join('')
        }));
        this.attachEvents();
        this._updateCount();
        this._onSelectChange();

        return this;
    }
});

/**
 * 권종 선택 영역 UI
 * @constructor
 */
var SelectTicketUI = UIController.extend({
    init: function(options) {
        UIController.call(this, options);
        //temp;
        var defaultTemplate = {
            main: tmpl,
            mainRow: tmplMainRow,
            row: tmplRow,
            icon: tmplIcon
        };
        this.cardLimitModel = new CardLimitModel();
        this.templateData = ne.util.extend(defaultTemplate, options.templateData);
        this.priceTable = this.IB.get('priceTable');
        this.layer = options.layer;
        this.viewList = [];
        this._initializeElements();
        this._initializeCollection();
        this._initializeListenToIB();
    },

    /**
     * IB 와 이벤트 핸들러 연결
     * @private
     */
    _initializeListenToIB: function() {
        this.listen(this.IB.EVENT.PRICE_LIST_CHANGE, this._setPriceTable, this);
        this.listen(this.IB.EVENT.GRID_SEATING_ADDED, this._onSeatingAdded, this);
        this.listen(this.IB.EVENT.GRID_SEATING_REMOVED, this._onSeatingRemoved, this);
        this.listen(this.IB.EVENT.GRID_SEATING_CLEARED, this._onSeatingCleared, this);
    },

    /**
     * element 바인딩
     * @private
     */
    _initializeElements: function() {
        this.$list = this.$el.find('._list');
        this.$price = this.$el.find('._price');
        this.$quantity = this.$el.find('._quantity');
    },

    /**
     * priceTable 을 설정한다.
     * @param {Object} priceTable 가격 정보
     * @private
     */
    _setPriceTable: function(priceTable) {
        this.priceTable = priceTable;
        this._refreshAllView();
    },

    /**
     * collection 바인딩
     * @private
     */
    _initializeCollection: function() {
        this.collection = new SeatingPriceCollection();
        this.collection.on('add', this._addView, this);
        this.collection.on('remove', this._removeView, this);
        this.collection.on('clear', this._clearView, this);
        this.collection.on('all', this._updateInfo, this);
    },

    /**
     * 좌석 정보를 읽고 좌석 등급당 몇개의 seats 가 존재하는지 반환함
     * @param {Array} seats  좌석 리스트
     * @return {{grade: number, grade: number}}
     * @private
     */
    _getGradeMapFromSeats: function(seats) {
        var gradeMap = {};
        ne.util.forEachArray(seats, function(seat) {
            var gradeId = seat.productGradeId,
                gradeName = seat.productGradeName;
            if (ne.util.isUndefined(gradeMap[gradeId])) {
                gradeMap[gradeId] = {
                    count: 1,
                    name: gradeName
                };
            } else {
                gradeMap[gradeId].count += 1;
            }
        });
        return gradeMap;
    },

    /**
     * IB 에서 Select 이벤트 발생시 collection 에 add 함
     * @param {Array} seats 좌석 리스트
     * @private
     */
    _onSeatingAdded: function(seats) {
        var gradeMap = this._getGradeMapFromSeats(seats);
        ne.util.forEach(gradeMap, function(item, gradeId) {
            var gradeModel = this.collection.get(gradeId),
                count = item.count,
                gradeName = item.name;
            if (gradeModel) {
                gradeModel.set('count', gradeModel.get('count') + count);
            } else {
                this.collection.add({productGradeId: gradeId, productGradeName: gradeName ,count: count});
            }
        }, this);
    },

    /**
     * IB 에서 Deselect 이벤트 발생시 collection 에서 제거함
     * @param {Array} seats 좌석 리스트
     * @private
     */
    _onSeatingRemoved: function(seats) {
        var gradeMap = this._getGradeMapFromSeats(seats);
        ne.util.forEach(gradeMap, function(item, gradeId) {
            var gradeModel = this.collection.get(gradeId),
                count = item.count;
            if (gradeModel) {
                if(gradeModel.get('count') <= count) {
                    this.collection.remove(gradeModel);
                } else {
                    gradeModel.set('count', gradeModel.get('count') - count);
                }
            }
        }, this);
    },

    /**
     * IB에서 deselect all 이벤트 발생시 핸들러
     * @private
     */
    _onSeatingCleared: function() {
        this.collection.clear();
    },

    /**
     * 좌석 등급의 가격정보 view 를 추가하고 랜더링한다.
     * @param {Array} models   collection 이벤트로 받은 model
     * @param {Array} parsedModels collection 이벤트로 받은 parsing 된 모델
     * @private
     */
    _addView: function(models, parsedModels) {
        ne.util.forEachArray(parsedModels, function(model) {
            var view = this._createView(model);
            view.on('selectChange', ne.util.bind(this._updateInfo, this));
            this.$list.append(view.render().$el);
        }, this);
    },

    /**
     * view 를 remove 한다.
     * @param {Array} models collection 이벤트로 받은 model 배열
     * @private
     */
    _removeView: function(models) {
        var index = -1;
        ne.util.forEachArray(this.viewList, function(view, i) {
            if (view.model === models[0]) {
                index = i;
                return false;
            }
        });
        this.viewList[index].$destroy();
        this.viewList.splice(index, 1);
    },

    /**
     * 전체 view 를 clear 한다.
     * @private
     */
    _clearView: function() {
        ne.util.forEachArray(this.viewList, function(view) {
            view.$destroy();
        }, this);
        this.viewList = [];
    },

    /**
     * view 를 생성한다.
     * @param model
     * @returns {SeatingPriceView}
     * @private
     */
    _createView: function(model) {

        var view = new SeatingPriceView({
            model: model,
            templateData: this.templateData,
            priceTable: this.priceTable,
            cardLimitModel: this.cardLimitModel,
            layer: this.layer
        });
        this.viewList.push(view);
        return view;
    },

    /**
     * 모든 view 를 다시 랜더링 한다.
     * @private
     */
    _refreshAllView: function() {
        ne.util.forEachArray(this.viewList, function(view) {
            view.render();
        }, this);
    },
    /**
     * 전체 가격 정보 업데이트
     * @private
     */
    _updateInfo: function() {
        var data = this.toJSON();
        this.$price.text(etc.formatNumber(data.price) + '원');
        this.$quantity.text(etc.formatNumber(data.count) + '개');
        this.IB.emit(this.IB.EVENT.TOTAL_PRICE_CHANGE);
    },

    /**
     * JSON 데이터 반환
     * @TODO: 서버 API 스펙 확정된 후 개발
     * @returns {*|string|Object}
     */
    toJSON: function() {
        var $selectList = this.$el.find('select'),
            totalPrice = 0,
            totalCount = 0,
            tempMap = {},
            map = {};
        ne.util.forEachArray($selectList, function(item, index) {
            var $select = $selectList.eq(index),
                data = $select.data(),
                denominationId = data.id,
                gradeId = data.grade,
                count = +$select.val() || 0,
                price = data.price || 0;
            if (ne.util.isExisty(denominationId)) {
                tempMap[gradeId] = tempMap[gradeId] || {};
                tempMap[gradeId][denominationId] = count;
                totalPrice += count * price;
                totalCount += count;
            }
        }, this);
        ne.util.forEach(tempMap, function(gradeItem, gradeId) {
            ne.util.forEach(gradeItem, function(count, denominationId) {
                if (count > 0) {
                    map[gradeId] = map[gradeId] || [];
                    map[gradeId].push({
                        productDenominationId: denominationId,
                        count: count
                    });
                }
            }, this);
        }, this);
        return {
            price: totalPrice,
            count: totalCount,
            map: map
        };
    }
});

module.exports = SelectTicketUI;
