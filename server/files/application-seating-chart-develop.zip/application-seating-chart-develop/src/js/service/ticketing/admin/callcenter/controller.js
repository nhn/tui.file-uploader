/**
 * @fileoverview 콜센터
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */
'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    API = tkl.API,
    FloatingUI = require('../../../common/floating'),
    MapController = require('../../common/mapController'),
    SelectSeatUI = require('../../common/selectSeat'),
    SelectTicketUI = require('../../common/selectTicket'),
    SelectAdditionalUI = require('../../common/selectAdditional'),
    LayerUI = require('../../common/layer'),
    NSeatCounter = require('../../common/nSeatCounter'),
    SelectSchedule = require('../../common/selectSchedule'),
    ScheduleView = require('../../common/scheduleView'),
    SeatingInfoPerRound = require('../../common/seatingInfoPerRound'),
    ProductInfoUI = require('../../common/productInfo'),
    DashBoardUI = require('../../common/dashBoard'),
    etc = require('../../../../etc'),
    tmplDashBoardRow = require('../../../../../tmpl/ticketing/dashBoard/adminRow.html'),
    tmplInformation = require('../../../../../tmpl/ticketing/information/callcenter.html');

/**
 * 콜센터 컨트롤러
 * @exports CallCenterController
 * @extends {UIController}
 * @constructor
 * @class
 */
var CallCenterController = UIController.extend({
    rootElement: $('body'),
    events: {
        'click ._ticketSubmit': '_onClickSubmit',
        'click ._ticketReset': '_onClickReset',
        'click ._ticketCancel': '_onClickCancel'
    },

    /**
     * 생성자
     * @param {Object} options
     */
    init: function(options) {
        UIController.call(this, options);
        this._isLocked = false;
        this.params = options.params;
        this.mapOptions = options.mapOptions;
        this._initializeUI();
        this.attachEvents();
        this._initializeStatus();
    },

    /**
     * UI 컴포넌트 인스턴스 생성
     * @private
     */
    _initializeUI: function() {
        var ui = this.ui = {};
        ui.floating =  new FloatingUI('#dimmed');

        ui.floating.setIB(this.IB);
        ui.mapController = new MapController({
            IB: this.IB,
            rootElement: $('body')
        });
        ui.dashBoard = new DashBoardUI({
            IB: this.IB,
            rootElement: $('._dashBoard'),
            template: tmplDashBoardRow
        });
        //상품영역
        ui.productInfo = new ProductInfoUI({
            IB: this.IB,
            rootElement: $('._productInfo'),
            template: tmplInformation
        });
        //레이어 UI
        ui.layer = new LayerUI({
            rootElement: $('._tooltip')
        });
        //좌석 선택 영역 UI
        ui.selectSeat = new SelectSeatUI({
            rootElement: $('._selectSeat'),
            IB: this.IB,
            grid: {
                color: {
                    border: '#FFFFFF'
                },
                className: {
                    table: 'seat_list'
                },
                height: 106
            }
        });
        //티켓 선택 영역 UI
        ui.selectTicket = new SelectTicketUI({
            rootElement: $('._selectTicket'),
            IB: this.IB,
            layer: this.ui.layer
        });
        //부가상품 영역 UI
        ui.selectAdditional = new SelectAdditionalUI({
            rootElement: $('._selectAdditional'),
            IB: this.IB
        });
        //비지정석 매수입력
        ui.seatCounter = new NSeatCounter({IB: this.IB});
        //날짜선택
        ui.selectSchedule = new SelectSchedule({
            IB: this.IB,
            type: SelectSchedule.TYPE.BASIC,
            seatingInfoPerRound: new SeatingInfoPerRound({
                IB: this.IB,
                type: SeatingInfoPerRound.TYPE.SELECTABLE
            }),
            scheduleView: new ScheduleView({
                IB: this.IB
            })
        });
        this.IB.set('ui', this.ui);
    },

    /**
     * 초기화 파라미터로 넘어온 정보를 토대로 현재 상태를 초기화 한다.
     * @private
     */
    _initializeStatus: function() {
        var params = this.params;
        if (params) {
            this._initializeProductId();
        }
    },

    /**
     * productId 가 설정되어 있다면 UI에 노출한다.
     * @private
     */
    _initializeProductId: function() {
        var params = this.params;
        if (ne.util.isExisty(ne.util.pick(params, 'productId'))) {
            this.IB.emit(this.IB.EVENT.SHOW_PRELOADER);
            if (ne.util.isExisty(ne.util.pick(params, 'productDate'))) {
                this.IB.listen(this.IB.EVENT.AVAILABLE_DATES_LOADED, this._initializeProductDate, this);
            }
            this.IB.emit(this.IB.EVENT.PRODUCT_CHANGE, params.productId);
        } else {
            this.IB.emit(this.IB.EVENT.HIDE_PRELOADER);
        }
    },

    /**
     * productDate 가 설정되어 있다면 UI에 노출한다.
     * @private
     */
    _initializeProductDate: function() {
        this.IB.emit(this.IB.EVENT.SHOW_PRELOADER);
        this.IB.stopListen(this.IB.EVENT.AVAILABLE_DATES_LOADED, this);
        var params = this.params;
        if (ne.util.isExisty(ne.util.pick(params, 'productRound'))) {
            this.IB.listen(this.IB.EVENT.ROUND_LOADED, this._initializeProductRound, this);
        }
        this.IB.emit(this.IB.EVENT.DATE_SELECT, params.productDate);
    },

    /**
     * 회차 정보가 넘어왔다면 회차정보를 업데이트한다.
     * @private
     */
    _initializeProductRound: function() {
        this.IB.emit(this.IB.EVENT.SHOW_PRELOADER);
        this.IB.stopListen(this.IB.EVENT.ROUND_LOADED, this);
        this.IB.emit(this.IB.EVENT.ROUND_SELECT, this.params.productRound);
    },

    /**
     * submit 버튼 클릭시
     * @private
     */
    _onClickSubmit: function() {
        var submitData = this.IB.getTicketingData();
        if (
            this.IB.validateTicketingData(submitData) &&
            this._confirmTodayTicket()
        ) {
            this._submit(submitData);
        }
    },

    /**
     * 당일 예매 여부 confirm
     * @returns {boolean}   당일 예매 여부
     * @private
     */
    _confirmTodayTicket: function() {
        var now = new Date();
        if (etc.getDateString(now.getTime()) === this.IB.get('productDate')) {
            return confirm('당일예매는 취소 및 변경이 불가능합니다. 계속 진행하시겠습니까?');
        } else {
            return true;
        }
    },

    /**
     * 중복 submit 을 방지하기 위해 lock 을 건다.
     * @private
     */
    _lock: function() {
        this._isLocked = true;
    },

    /**
     * 중복 submit 을 방지하기 위한 lock 을 해제 한다.
     * @private
     */
    _unlock: function() {
        this._isLocked = false;
    },

    /**
     * 실제 서버로 전송한다.
     * @param {Object} submitData 서버로 전송할 데이터
     * @private
     */
    _submit: function(submitData) {
        if (!this._isLocked) {
            this._lock();
            this.fireEvent('onSubmit', submitData);
            this.IB.requestToAPI(API.URL.RESERVE_COMPLETE, {
                data: submitData,
                type: 'POST',
                dimmImmediate: true,
                success: ne.util.bind(this._onSuccessSubmit, this),
                fail: ne.util.bind(this._onFailSubmit, this),
                complete: ne.util.bind(this._unlock, this)
            });
        }
    },

    /**
     * submit success 이벤트 핸들러
     * @param {object} responseData 응답 데이터
     * @private
     */
    _onSuccessSubmit: function(responseData) {
        this.fireEvent('onSuccessSubmit', responseData);
    },

    /**
     * submit fail 이벤트 핸들러
     * @param {object} responseData 응답 데이터
     * @param {Number}  responseCode 응답 코드
     * @private
     */
    _onFailSubmit: function(responseData, responseCode) {
        this.fireEvent('onFailSubmit', responseData, responseCode);
    },

    /**
     * 초기화 버튼 클릭시
     * @private
     */
    _onClickReset: function() {
        if (confirm('설정된 정보가 모두 초기화 됩니다.')) {
            this.IB.emit(this.IB.EVENT.UI_RESET_ALL);
        }
    },

    /**
     * 취소 버튼 클릭시
     * @private
     */
    _onClickCancel: function() {
        if (this.IB.confirmResetSeatingList('선택하신 좌석이 초기화 됩니다.')) {
            this.IB.closeWindow();
        }
    }
});

module.exports = CallCenterController;
