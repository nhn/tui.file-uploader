/**
 * @fileoverview 사용자 정보 영역
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */
'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    API = tkl.API,
    UIModel = require('../../../ui/model'),
    tmplUser = require('../../../../tmpl/ticketing/information/systemUser.html'),
    tmplUserAnonymous = require('../../../../tmpl/ticketing/information/systemUserAnonymous.html');

/**
 * User 모델 정의
 * @type {*}
 */
var UserModel = UIModel.extend({
    init: function(data) {
        UIModel.call(this, data, {
            parse: true
        });
    },
    idAttribute: 'seatId',
    defaults: {
        memberName: '-',
        memberTypeName : '-',
        cellPhoneNo : '-',
        birthday : '-'
    }
});

/**
 * UserInfoUI
 * @exports UserInfoUI
 * @extends {UIController}
 * @constructor
 * @class
 * **/
var UserInfoUI = UIController.extend({
    events: {
        'click': '_onClick'
    },

    /**
     * 생성자
     * @param {Object} options
     *      @param {String} options.template    템플릿
     * @constructor
     */
    init: function UserInfoUI (options) {
        UIController.call(this, options);

        //팝업 콜백 바인딩
        window.ne.tkl.ticketing.callback.setMemberNo = ne.util.bind(this.setMemberNo, this);
        
        this._hasUserInfo = (this.IB.get('sellingTypeCode') !== 'TKL');
        this._urlData = this.IB.get('popupUrl');

        this._initializeListener();
        this._initializeModel();
        this._initializeView();
    },

    /**
     * listener 를 초기화한다.
     * @private
     */
    _initializeListener: function() {
        this.listen(this.IB.EVENT.UI_RESET, this._reset, this);
    },

    /**
     * 모델을 초기화한다.
     * @private
     */
    _initializeModel: function() {
        this.model = new UserModel();
        this.model.on('change', this.render, this);
    },

    /**
     * 뷰를 초기화한다.
     * @private
     */
    _initializeView: function() {
        var reserveMemberNo = this.IB.get('reserveMemberNo');
        if (ne.util.isExisty(reserveMemberNo)) {
            this._requestMemberInfo(reserveMemberNo);
        } else {
            this.render();
        }
    },

    /**
     * member no 를 초기화한다.
     * @private
     */
    _reset: function() {
        this.setMemberNo();
    },

    /**
     * 랜더링한다.
     */
    render: function() {
        this.detachEvents();
        this.$el.html(this._getUserInfoMarkup());
        this.attachEvents();
    },

    /**
     * 사용자 정보영역 마크업을 반환한다.
     * @private
     */
    _getUserInfoMarkup: function() {
        var html;
        if (this._hasUserInfo) {
            html = this.template(tmplUser, this.model.toJSON());
        } else {
            html = this.template(tmplUserAnonymous);
        }
        return html;
    },

    /**
     * click 이벤트 핸들러
     * @param {event} clickEvent
     * @private
     */
    _onClick: function(clickEvent) {
        var $target = $(clickEvent.target);
        if($target.hasClass('_userSelect')) {
            //회원 조회
            this._openPopup(this._urlData.USER_INFO, {
                popupName: 'userInfo',
                param: {
                    loadPage: this.IB.get('sellingTypeCode')
                }
            });
        }
    },

    /**
     * popup 을 띄운다.
     * @param {String} url   팝업 url
     * @param {object} options 팝업을 띄울때 함께 전송할 파라미터
     * @private
     */
    _openPopup: function(url, options) {
        url = this.template(url, options.param);
        options = ne.util.extend({
            popupOptionStr: 'width=1000,height=900,resizable=yes,scrollbars=yes',
            method: 'GET'
        }, options);
        options.param = null;
        ne.util.popup.openPopup(url, options);
    },

    /**
     * member no 를 설정한다.
     * @param {String} reserveMemberNo 사용자 number
     */
    setMemberNo: function(reserveMemberNo) {
        var IB = this.IB;
        IB.set('reserveMemberNo', reserveMemberNo);
        IB.emit(IB.EVENT.RESERVE_MEMBER_NO_CHANGE);
        if (ne.util.isExisty(reserveMemberNo)) {
            this._requestMemberInfo(reserveMemberNo);
        } else {
            this._setMemberInfo();
        }

    },

    /**
     * member no 를 전송하여 member 정보를 조회한다.
     * @param {String} reserveMemberNo 사용자 number
     * @private
     */
    _requestMemberInfo: function(reserveMemberNo) {
        var self = this;
        this.IB.requestToAPI(API.URL.RESERVE_GET_MEMBER_INFO, {
            data: {
                memberNo: reserveMemberNo
            },
            type: 'POST',
            success: function(responseData) {
                self._setMemberInfo(responseData);
            }
        });
    },

    /**
     * member 정보를 설정한다.
     * @param {Object} memberInfo
     * @private
     */
    _setMemberInfo: function(memberInfo) {
        var defaultUserInfo = {
            memberName: '-',
            memberTypeName : '-',
            cellPhoneNo : '-',
            birthday : '-'
        };
        this.model.set(ne.util.extend(defaultUserInfo, memberInfo));
    }
});

module.exports = UserInfoUI;