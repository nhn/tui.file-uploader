/**
 * @fileoverview Admin 예매에 사용할 InteractBroker
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */
'use strict';

var tkl = ne.tkl,
    API = tkl.API,
    InteractBroker = tkl.InteractBroker,
    etc = require('../../etc');

/**********
 * static props
 **********/
var EVENT = {
    UI_RESET: 'uiReset',        //좌석정보 및 부가정보 리셋
    UI_RESET_ALL: 'uiResetAll', //상품 정보 제외하고 전체 리셋

    REQUEST_AVAILABLE_DATES: 'RequestAvailableDates',
    PRODUCT_INFO_LOADED: 'ProductInfoLoaded',   //상품정보 로드시
    AVAILABLE_DATES_LOADED: 'AvailableDatesLoaded', //날짜 데이터 응답 받았을 때
    CALENDAR_RENDERED: 'CalendarRendered',  //켈린더가 랜더 되었을 때
    DATE_SELECT: 'DateSelect',          //초기 날짜 선택 로직 수행 트리거
    DATE_SELECTED: 'DateSelected',      //날짜가 선택 되었을 때
    ROUND_SELECT: 'RoundSelect',        //초기 회차 선택 로직 수행 트리거
    ROUND_SELECTED: 'RoundSelected',    //회차 선택 되었을 때
    ROUND_UNSELECTED: 'RoundUnSelected',    //회차 선택 해제 되었을 때
    ROUND_LOADED: 'RoundLoaded',        //회차 데이터 로드 시
    AVAILABLE_SEATINFO_LOADED: 'AvailSeatLoaded',
    SEAT_GRADE_SELECTED: 'SeatGradeSelected',       //등급 손택시
    SEAT_GRADE_DESELECTED: 'SeatGradeDeselected',   //등급 선택 해제시
    PRODUCT_SEASON_LOADED: 'SeasonProductLoaded',   //기간권이 로드되었을때
    PRODUCT_CHANGE: 'productChange',     //상품정보 변경시
    USER_CHANGE: 'userChange',        //회원 변경시
    RESET_PAGE: 'resetPage',    //페이지 내 모든 정보 초기화

    ADDITIONAL_COUNT_SELECTED: 'additionalCountSelected', //부가상품 개수 선택시
    ADDITIONAL_COUNT_DATA_LOADED: 'additionalCountLoaded', //부가상품 count 데이터 LOAD 완료 시

    //control 영역에서 발생시키는 이벤트. Map 에서 listening 한다.
    CONTROL_BLUR_SEAT: 'controlBlurSeat', //비지정석 키패드 UI 에서 확인 혹은 취소 선택 시
    CONTROL_SELECT_SEAT: 'controlSelectSeat', //UI 에서 좌석 추가 되었을 시
    CONTROL_DESELECT_SEAT: 'controlDeselect',    //UI 에서 삭제 버튼 등으로 좌석 선택 해제시
    CONTROL_DESELECT_ALL_SEAT: 'controlDeselectAll', //UI 에서 초기화 버튼 등으로 좌석 선택 전체 해제시
    CONTROL_HIGHLIGHT_SEAT: 'controlHighlightSeat', //UI에서 등급이 선택되었을때..
    CONTROL_DISABLE_SEAT: 'controlDisableSeat', //선점된 좌석 표시
    CONTROL_UPDATE_NON_RESERVED_COUNT: 'controlUpdateNonReservedCount', //비지정석 좌석정보 업데이트
    CONTROL_SEARCH_SEAT: 'controlSearchSeat',       //sid 리스트로 좌석 정보를 가져올 때 사용

    UPDATE_ALL_ZONE_REMAIN_COUNT: 'updateAllZoneRemainCount', //zone remain count 를 업데이트 한다.
    INIT_ZONE_REMAIN_COUNT: 'initZoneRemainCount',  //페이지 진입시 정보로 zone remain count 를 세팅한다.
    RESERVE_MEMBER_NO_CHANGE: 'reserveMemberNoChange',  //예매 회원 정보 변경시


    //Simple Grid 영역에서 발생시키는 이벤트.
    GRID_SEATING_ADDED: 'gridSeatingAdded',     //Grid 에서 발생하는 이벤트. 권종선택 영역과 동기화 위함.
    GRID_SEATING_REMOVED: 'gridSeatingRemoved', //Grid 에서 발생하는 이벤트. 권종선택 영역과 동기화 위함.
    GRID_SEATING_SET: 'gridSeatingSet', //Grid 에서 발생하는 이벤트. 권종선택 영역과 동기화 위함.
    GRID_SEATING_CLEARED: 'gridSeatingCleared', //Grid 에서 발생하는 이벤트. 권종선택 영역과 동기화 위함.
    GRID_GET_SELECTED_SEATS: 'gridGetSelectedSeats', //Grid 로부터 현재 선택좌석 jsondata 정보를 받아온다.

    ZONE_REMAIN_COUNT_LOADED: 'zoneRemainCountLoaded',

    SET_NON_RESERVED_SEATS: 'setNonReservedSeats',  //nonReserved Seat 를 설정한다.
    UPDATE_NON_RESERVED_SEAT_COUNT: 'updateNonReservedSeatCount', //현재 nonReservedSeat count 를 서버에 업데이트한다.
    ADD_SEATS: 'addSeats',
    REMOVE_SEATS: 'removeSeats',
    UPDATE_SEATING_MAP: 'updateSeatingMap',         //도면 상태를 업데이트한다. (show/hide)

    //기타 이벤트
    NON_RESERVED_FOCUSED: 'nonReservedFocused', //비지정석이 focus 되었을 시
    PURCHASE_SEAT: 'purchaseSeats', //좌석 선점 시도
    ADDITIONAL_PRODUCT_LIST_CHANGE: 'additionalProductListChange', //부가정보 데이터 업데이트시
    PRICE_CHANGE: 'priceChange',    //각각의 가격정보 업데이트시
    TOTAL_PRICE_CHANGE: 'totalPriceChange', //전체 가격정보 업데이트 시
    PRICE_LIST_CHANGE: 'priceListChange' //권종정보 업데이트 시
};

/**
 * TicketingIB
 * @constructor
 * @extends {InteractBroker}
 */
function TicketingIB() {
    InteractBroker.call(this);
    this._initializeCallbackNamespace();
    this.set('isMapLoaded', false);

    this.addOrder(EVENT.UI_RESET, this._onUiReset);
    this.addOrder(EVENT.UI_RESET_ALL, this._onUiResetAll);

    this.addOrder(EVENT.PRODUCT_CHANGE, this._onProductChange);
    this.addOrder(EVENT.REQUEST_AVAILABLE_DATES, this._requestAvailableDates);
    this.addOrder(EVENT.DATE_SELECTED, this._dateSelected);
    this.addOrder(EVENT.ROUND_SELECTED, this._roundSelected);
    this.addOrder(EVENT.PURCHASE_SEAT, this._purchaseSeat);
    this.addOrder(EVENT.SEAT_GRADE_SELECTED, this._seatGradeSelected);
    this.addOrder(EVENT.SEAT_GRADE_DESELECTED, this._seatGradeDeselected);
    this.addOrder(EVENT.PRODUCT_SEASON_LOADED, this._onSeasonalProductLoaded);
    this.addOrder(EVENT.CONTROL_DESELECT_SEAT, this._controlDeselect);
    this.addOrder(EVENT.CONTROL_DESELECT_ALL_SEAT, this._controlDeselectAll);
    this.addOrder(EVENT.UPDATE_NON_RESERVED_SEAT_COUNT, this._requestPurchaseNonReservedSeat);
    this.addOrder(EVENT.PRICE_LIST_CHANGE, this._onPriceListChange);
    this.addOrder(EVENT.ADDITIONAL_COUNT_SELECTED, this._requestAdditionalCount);

    this.addOrder(EVENT.AVAILABLE_SEATINFO_LOADED, this._onAvailableSeatInfoLoaded);
    this.addOrder(EVENT.RESERVE_MEMBER_NO_CHANGE, this._requestPriceInfo);

    //map 에서 발생하는 이벤트 listener
    this.addOrder(InteractBroker.EVENT.MAP_DESELECT_SEAT, this._onMapDeselected);
    this.addOrder(InteractBroker.EVENT.MAP_FOCUS_SEAT, this._onMapFocused);
    this.addOrder(InteractBroker.EVENT.MAP_DESELECT_ALL_SEAT, this._onMapDeselectAll);

    //unload 이벤트 바인딩한다.
    window.onunload = ne.util.bind(function() {
        if (!this.get('preventUnloadHandler')) {
            this._controlDeselectAll(false);
        }
    }, this);

    InteractBroker.PROGRESS_DELAY = 200;
}

ne.util.inherit(TicketingIB, InteractBroker);
TicketingIB.EVENT = ne.util.extend(EVENT, InteractBroker.EVENT);
TicketingIB.prototype.EVENT = TicketingIB.EVENT;

/**********
 * order methods
 **********/

/**
 * 지정석 정보를 로드한다.
 * @param {Array} gridIDList Grid ID 리스트
 * @param {Function} callback   로드가 끝난 후 수행할 콜백
 * @private
 */
TicketingIB.prototype._loadRSeat = function(gridIDList, callback) {
    var self = this,
        inProgress = this.get('load-rseat-in-progress');

    if (inProgress) {
        return;
    }

    this.set('load-rseat-in-progress', true);

    this.requestToAPI(API.URL.TICKETING_LOAD_RSEAT, {
        data: {
            logicalPlanId: self.get('venueID'),
            productId: self.get('productId'),
            scheduleId : self.get('scheduleId'),
            sellingType: self.get('sellingTypeCode'),
            isFront: self.get('isFront'),
            areaList: gridIDList
        },
        dimmImmediate: true,
        noPreventCloseWindow: true,
        success: function(result) {
            ne.util.map(result.grids, function(data, name) {
                result.grids[name] = JSON.parse(data);
            });
            self.emit(EVENT.LOAD_RSEAT_COMPLETED, result.grids, result.seatSoldoutMap, gridIDList, ne.util.keys(result.grids));
            callback();
        },
        complete: function() {
            self.set('load-rseat-in-progress', false);
        }
    });
};

/**
 * 리셋 이벤트 발생시 핸들러
 * @private
 */
TicketingIB.prototype._onUiReset = function() {
    this.fire(EVENT.UI_RESET);
    this._locationChange();
};

/**
 * 전부 리셋 이벤트 발생시 핸들러
 * @private
 */
TicketingIB.prototype._onUiResetAll = function() {
    this.fire(EVENT.UI_RESET);

    this.set('productDate', null);
    this.set('productRound', null);
    this.set('logicalPlanId', null);
    this.set('sellingTypeCode', null);

    this._locationChange();
};

/**
 * 팝업 callback 에 대한 name space 를 생성한다.
 * @private
 */
TicketingIB.prototype._initializeCallbackNamespace = function() {
    if (!ne.util.isExisty(ne.util.pick(window.ne, 'tkl'))) {
        window.ne.tkl = {};
    }
    if (!ne.util.isExisty(ne.util.pick(window.ne, 'tkl', 'ticketing'))) {
        window.ne.tkl.ticketing = {};
    }
    if (!ne.util.isExisty(ne.util.pick(window.ne, 'tkl', 'ticketing', 'callback'))) {
        window.ne.tkl.ticketing.callback = {};
    }
};

/**
 * 기간권일경우 추가정보 로드
 * @private
 */
TicketingIB.prototype._requestSeasonExtraData= function() {
    var self = this;
    this.requestToAPI(API.URL.RESERVE_GET_ONLY_ZONE_DATA, {
        data: {
            productId: this.get('productId')
        },
        type: 'POST',
        success: function(responseData) {
            self.set('productGradeId', responseData.gradeId);
            self.set('scheduleId', responseData.scheduleId);
            self._requestExtraData();
            self.emit(EVENT.UPDATE_SEATING_MAP);
        }
    });
};

/**
 * 등급정보와 권종 정보를 로드한다.
 * @private
 */
TicketingIB.prototype._requestExtraData = function() {
    this._setCurrentParam();
    this._requestGrade();
    this._requestPriceInfo();
    this._requseTicketLimitCount();
};

/**
 * 상품 정보 조회
 * @private
 */
TicketingIB.prototype._requestProductInfo = function() {
    var self = this;
    this.set('productDate', null);
    this.set('productRound', null);
    this.requestToAPI(API.URL.RESERVE_PRODUCT, {
        data: {
            productId: this.get('productId')
        },
        type: 'POST',
        success: function(responseData) {
            var productTypeCode = responseData && responseData.productTypeCode;
            //productTypeCode = 'SEASON';
            //일반권|기간권 여부
            self.set('productTypeCode', productTypeCode);
            self.emit(EVENT.PRODUCT_INFO_LOADED, responseData);
            //기간권일 경우
            if (productTypeCode === 'SEASON') {
                self.emit(EVENT.PRODUCT_SEASON_LOADED, responseData);
            } else {
                self.emit(EVENT.REQUEST_AVAILABLE_DATES);
            }
            self.emit(EVENT.UPDATE_SEATING_MAP);
        }
    });
};

/**
 * 상품정보 변경시 이벤트 핸들러
 * @param {Number|String} productId 상품 정보
 * @private
 */
TicketingIB.prototype._onProductChange = function(productId) {
    if (productId) {
        this.set('productId', productId);
        this.set('productDate', null);
        this.set('productRound', null);

        if (this._isMapLoaded() || !ne.util.isExisty(productId)) {
            this._locationChange();
        } else {
            this._requestProductInfo();
            this._requestAdditionalProduct();
            this.emit(EVENT.UPDATE_SEATING_MAP);
        }
    }
};

/**
 * 선택 가능한 날짜 정보를 요청한다.
 * @private
 */
TicketingIB.prototype._requestAvailableDates = function() {
    var self = this;
    this.requestToAPI(API.URL.RESERVE_DATES, {
        data: {
            productId: this.get('productId')
        },
        type: 'POST',
        success: function(responseData) {
            self.fire(EVENT.AVAILABLE_DATES_LOADED, responseData);
        }
    });
};

/**
 * 기관권일 경우 data.nhn 을 호출하지 않기 때문에
 * 상품정보 API 의 결과로부터  날짜 포멧을 생성한다.
 * @param {Number} startTimestamp   시작 timestamp
 * @param {Number} endTimestamp     끝 timestamp
 * @returns {Array} 생성한 날짜 데이터
 * @private
 */
TicketingIB.prototype._getSeasonDates = function(startTimestamp, endTimestamp) {
    //유효한 날의 모델도 되고 현재날짜의 모델도될수있다.
    var startDateObj = etc.getDateObject(startTimestamp),
        endDateObj = etc.getDateObject(endTimestamp),
        endDate = new Date(endDateObj.year, endDateObj.month - 1, endDateObj.date, 23, 59, 59),
        curDate = new Date(startDateObj.year, startDateObj.month - 1, startDateObj.date, 0, 0, 0),
        dataList = [];
    while (curDate < endDate) {
        dataList.push({
            productDate: etc.getDateString(curDate)
        });
        curDate.setDate(curDate.getDate() + 1);
    }
    return dataList;
};

/**
 * 기간권의 경우
 * 시작일, 종료일을 파라미터로 받아
 * 달력에 설정할 timestamp 배열을 가공한 뒤, 비지정석 1개일 경우 추가정보 데이터 request 한다.
 * @param {Object} responseData 서버 응답값
 * @private
 */
TicketingIB.prototype._onSeasonalProductLoaded = function(responseData) {
    var startDate = responseData.startDate,
        endDate = responseData.endDate,
        dateList = this._getSeasonDates(startDate, endDate);
    this.set('productDate', etc.getDateString(endDate));
    this.set('productRound', 1);
    this.fire(EVENT.AVAILABLE_DATES_LOADED, dateList);
    this._requestSeasonExtraData();
};

/**
 * 날짜 선택되었을때 수행 로직
 * @param {object} data 달력 컴포넌트로 전달받은 데이터
 * @private
 */
TicketingIB.prototype._dateSelected = function(data) {
    this.set('productDate', data.productDate);
    this.set('productRound', null);
    if (this._isMapLoaded()) {
        this._locationChange();
    } else {
        this.fire(EVENT.DATE_SELECTED, data);
        this._requestRound();
        this.emit(EVENT.UPDATE_SEATING_MAP);
    }
};

/**
 * 회차정보 request
 * @private
 */
TicketingIB.prototype._requestRound = function() {
    var self = this;
    this.set('productRound', null);
    this.requestToAPI(API.URL.RESERVE_ROUND, {
        data: {
            productId: this.get('productId'),
            productDate: this.get('productDate')
        },
        type: 'POST',
        success: function(responseData) {
            self.fire(EVENT.ROUND_LOADED, responseData);
        }
    });
};

/**
 * 페이지 unload 시 선점해제 request 를 보내기 위한 파라미터를 저장한다.
 * @see TicketingIB.prototype._controlDeselectAll
 * @private
 */
TicketingIB.prototype._setCurrentParam = function() {
    if (ne.util.isExisty(this.get('scheduleId')) || ne.util.isExisty(this.get('logicalPlanId'))) {
        this.set('currentParam', {
            productRound: this.get('productRound'),
            productId: this.get('productId'),
            scheduleId : this.get('scheduleId'),
            logicalPlanId: this.get('logicalPlanId')
        });
    }
};

/**
 * 회차 선택되었을 때 수행로직
 * @param {object} data 회차 선택 컴포넌트를 통해 받아온 데이터
 * @private
 */
TicketingIB.prototype._roundSelected = function(data) {
    //var logicalPlanId = 474 || data.logicalPlanId,
    var logicalPlanId = data.logicalPlanId,
        productRound = data.productRound,
        scheduleId = data.scheduleId,
        currentProductRound = this.get('productRound'),
        isProductRoundChanged = currentProductRound ? (currentProductRound !== data.productRound) : true;

    this._setCurrentParam();

    if (isProductRoundChanged) {
        if (!this.confirmResetSeatingList()) {
            if (currentProductRound) {
                this.set('productRound', currentProductRound);
            }
            this.emit(EVENT.ROUND_SELECT, currentProductRound);
        } else {
            this.set('productRound', productRound);
            this.set('logicalPlanId', logicalPlanId);
            this.set('scheduleId', scheduleId);
            this.set('venueID', logicalPlanId);

            if ((this._isMapLoaded() || logicalPlanId) && this._isParamChanged()) {
                this._locationChange();
            } else {
                this.fire(EVENT.ROUND_SELECTED, data);
                if (this.isSeasonTicket()) {
                    this._requestSeasonExtraData();
                } else {
                    this._requestExtraData();
                }
            }
        }
    }
};

/**
 * 티켓 구매 제한개수 정보 request
 * @private
 */
TicketingIB.prototype._requseTicketLimitCount = function() {
    //구매 매수 제한 기능을 사용하는 경우만 request
    if (this.get('hasMaxCountLimit')) {
        var self = this;
        this.requestToAPI(API.URL.RESERVE_GET_PRODUCT_LIMIT_CNT, {
            data: {
                productId: this.get('productId'),
                scheduleId: this.get('scheduleId'),
                reserveMemberNo: this.get('reserveMemberNo') || 0
            },
            type: 'POST',
            success: function (responseData) {
                self.set('buyCountMaxCount', responseData.buyCountMaxCount);
                self.set('buyCountLimitCount', responseData.buyCountLimitCount);
                self.set('buyCountLimitClassCode', responseData.buyCountLimitClassCode);
            }
        });
    }
};

/**
 * 등급정보 request
 * @private
 */
TicketingIB.prototype._requestGrade = function() {
    var self = this,
        gradeInfo = ne.tkl.data.gradeInfo;

    if (this.isOnlyZone()) {
        this.requestToAPI(API.URL.RESERVE_GRADE, {
            data: {
                isMap: false,
                id: this.get('scheduleId'),
                sellingType: this.get('sellingTypeCode')
            },
            type: 'POST',
            success: function (responseData) {
                self.set('productGradeId', responseData.productGradeId);
                self.emit(EVENT.AVAILABLE_SEATINFO_LOADED, [responseData]);
            }
        });
    } else {
        self.emit(EVENT.AVAILABLE_SEATINFO_LOADED, gradeInfo);
    }
};

/**
 * 잔여 좌석 정보 load 되었을 때  핸들러
 * @param {Array} responseData 서버 응답 데이터
 * @private
 */
TicketingIB.prototype._onAvailableSeatInfoLoaded = function(responseData) {
    this.fire(EVENT.AVAILABLE_SEATINFO_LOADED, this.sortGrade(responseData));
};


/**
 * 등급 정보를 우선 순위에 맞추어 정렬한다.
 * @param {Array} gradeList 등급 정보 리스트
 * @private
 */
TicketingIB.prototype.sortGrade = function(gradeList) {
    return gradeList.length ? gradeList.sort(etc.sort.asc('gradePriority')) : gradeList;
};

/**
 * 좌석 등급이 선택되었을 때
 * @param {String|Number} productGradeId 등급 ID
 * @private
 */
TicketingIB.prototype._seatGradeSelected = function(productGradeId) {
    this.set('productGradeId', productGradeId);
    this.fire(EVENT.SEAT_GRADE_SELECTED, productGradeId);
    this.emit(EVENT.CONTROL_HIGHLIGHT_SEAT, productGradeId);
};

/**
 * 좌석 등급 선택이 해제 되었을 때
 * @param {String|Number} productGradeId 등급 ID
 * @private
 */
TicketingIB.prototype._seatGradeDeselected = function(productGradeId) {
    this.set('productGradeId', null);
    this.fire(EVENT.SEAT_GRADE_DESELECTED, productGradeId);
};

/**
 * 권종선택 정보 request
 * @private
 */
TicketingIB.prototype._requestPriceInfo = function() {
    var self = this;
    if (
        ne.util.isExisty(this.get('productId')) &&
        ne.util.isExisty(this.get('productDate')) &&
        ne.util.isExisty(this.get('productRound'))
    ) {
        this.requestToAPI(API.URL.RESERVE_PRICE, {
            data: {
                productId: this.get('productId'),
                productDate: this.get('productDate'),
                productRound: this.get('productRound'),
                reserveMemberNo: this.get('reserveMemberNo') || 0
            },
            type: 'POST',
            success: function(priceList) {
                self._setPriceTable(priceList);
            }
        });
    }

};

/**
 * 권종 정보 변경시 핸들러
 * @param {Object} priceTable 사용하기 쉽게 가공한 가격 정보
 * @private
 */
TicketingIB.prototype._onPriceListChange = function(priceTable) {
    if (this.isOnlyZone()) {
        this._requestOnlyZonePreoccupancy();
    }
    this.emit(EVENT.UPDATE_SEATING_MAP);
    this.fire(EVENT.PRICE_LIST_CHANGE, priceTable);
};

/**
 * 비지정석 1개일 경우 도면 정보가 없기 때문에 가상 zoneData 를 생성하여 반환한다
 * @returns {{r: Array, n: {sid: *, grade: *}[]}}
 */
TicketingIB.prototype.getOnlyZoneData = function() {
    var scheduleId = this.get('currentParam').scheduleId;

    return {
        r: [],
        n: [{
            sid: scheduleId,
            grade: this.get('productGradeId')
        }]
    };
};

/**
 * 전시 상품 선점 조회 API
 * @private
 */
TicketingIB.prototype._requestOnlyZonePreoccupancy = function() {
    this.requestToAPI(API.URL.RESERVE_GET_ALL_PREOCCUPANCY_ONLY_ZONE, {
        data: {
            scheduleId: this.get('scheduleId'),
            preoccupancyMemberNo: this.get('preoccupancyMemberNo'),
            allotmentCompanyCode: this.get('sellingTypeCode')
        },
        type: 'POST',
        success: ne.util.bind(this._setOnlyZonePreoccupancy, this)
    });
};

/**
 * 전시 상품 선점 API
 * @param {Object} responseData 서버 응답 데이터
 * @private
 */
TicketingIB.prototype._setOnlyZonePreoccupancy = function(responseData) {
    var selectedCount = responseData.selectedCount || 0,
        allotmentPreoccupancy = responseData.allotmentPreoccupancy;
    this.emit(EVENT.SET_NON_RESERVED_SEATS, this.parseSeats(this.getOnlyZoneData().n), selectedCount, allotmentPreoccupancy);
    this._onMapFocused(this.getOnlyZoneData());
};

/**
 * 권종선택 response 의 정보를 토대로  grade 당 priceTable 을 생성한다.
 * @param {Array} priceList 권종 데이터 리스트
 * @private
 */
TicketingIB.prototype._setPriceTable = function(priceList) {
    var priceTable = {},
        productGradeId,
        productGradeName;
    ne.util.forEachArray(priceList, function(item) {
        productGradeId = item.productGradeId;
        productGradeName = item.productGradeName;
        priceTable[productGradeId] = priceTable[productGradeId] || {};
        priceTable[productGradeId].productGradeId = productGradeId;
        priceTable[productGradeId].productGradeName = productGradeName;
        priceTable[productGradeId].list = priceTable[productGradeId].list || [];
        priceTable[productGradeId].list.push(item);
    });
    this.set('priceTable', priceTable);
    this.emit(EVENT.PRICE_LIST_CHANGE, priceTable);
};

/**
 * 부가상품 정보 조회
 * @private
 */
TicketingIB.prototype._requestAdditionalProduct = function() {
    var self = this,
        param = {
            productId: this.get('productId')
        };
    if (ne.util.isExisty(this.get('productId'))) {
        this.requestToAPI(API.URL.RESERVE_ADDITIONAL, {
            data: param,
            type: 'POST',
            success: function(responseData) {
                self.fire(EVENT.ADDITIONAL_PRODUCT_LIST_CHANGE, responseData);
            }
        });
    } else {
        self.fire(EVENT.ADDITIONAL_PRODUCT_LIST_CHANGE, []);
    }
};

/**
 * 부가상품 잔여 개수 조회
 * @param additionalProductId
 * @private
 */
TicketingIB.prototype._requestAdditionalCount = function(additionalProductId) {
    var self = this,
        reserveMemberNo = this.get('reserveMemberNo'),
        productId = this.get('productId');

    if (ne.util.isExisty(productId) && ne.util.isExisty(reserveMemberNo)) {
        this.requestToAPI(API.URL.RESERVE_ADDITIONAL_COUNT, {
            data: {
                productId: productId,
                additionalProductId: additionalProductId,
                reserveMemberNo: reserveMemberNo
            },
            type: 'POST',
            success: function(responseData) {
                self.fire(EVENT.ADDITIONAL_COUNT_DATA_LOADED, additionalProductId, responseData);
            }
        });
    } else {
        this.fire(EVENT.ADDITIONAL_COUNT_DATA_LOADED, additionalProductId, []);
    }
};

/**
 * 파라미터가 변경되었는지 여부 검사
 * @returns {boolean}   변경되었는지 여부
 * @private
 */
TicketingIB.prototype._isParamChanged = function() {
    var params = etc.parseUrl();
    if (etc.toStr(params.productId) === etc.toStr(this.get('productId')) &&
        etc.toStr(params.productDate) === etc.toStr(this.get('productDate')) &&
        etc.toStr(params.productRound) === etc.toStr(this.get('productRound'))) {
        return false;
    } else {
        return true;
    }
};

/**
 * 현재 설정된 정보대로 location 을 변경한다.
 * @private
 */
TicketingIB.prototype._locationChange = function() {
    var callback = ne.util.bind(function() {
        var url = document.location.href.split('?')[0].split('#')[0];
        this.emit(this.EVENT.SHOW_PRELOADER);
        this.preventCloseWindow = false;
        document.location.href = url + '?' + this._generateQueryString();
    }, this);

    //ajax 가 진행중이라면 모든 ajax 가 끝난 이후 callback 을 수행한다.
    if (this.isLocked()) {
        this.listen(this.EVENT.ENABLE_CHART, callback, this);
    } else {
        callback();
    }
};

/**
 * location change 퍼블릭 메서드
 */
TicketingIB.prototype.reload = function() {
    this._locationChange();
};

/**
 * 현재 요청중인 ajax 콜을 모두 완료하고 창을 닫는다.
 */
TicketingIB.prototype.closeWindow = function() {
    var callback = ne.util.bind(function() {
        ne.util.popup.closeAllPopup();
        window.close();
    });
    if (this.isLocked()) {
        this.listen(this.EVENT.ENABLE_CHART, callback, this);
    } else {
        callback();
    }
};

/**
 * 현재 셋팅된 정보를 토대로 queryString 을 생성한다.
 * @returns {string} 쿼리 문자열
 * @private
 */
TicketingIB.prototype._generateQueryString = function() {
    var params = {},
        queryList = [];

    params.productId = this.get('productId');
    params.productDate = this.get('productDate');
    params.productRound = this.get('productRound');
    params.reserveMemberNo = this.get('reserveMemberNo');
    params.loginMemberNo = this.get('loginMemberNo');
    params.sellingTypeCode = this.get('sellingTypeCode');
    params.logicalPlanId = this.get('logicalPlanId');
    params.scheduleId = this.get('scheduleId');

    ne.util.forEach(params, function(value, key) {
        if (ne.util.isExisty(value)) {
            queryList.push(key + '=' + value);
        }
    });
    return queryList.join('&');
};

/**
 * 선택된 좌석이 있을 경우 초기화 confirm 메세지를 노출한다.
 * @returns {boolean} 초기화 가능 여부
 */
TicketingIB.prototype.confirmResetSeatingList = function(message) {
    var ui = this.get('ui');
    return ui.selectSeat && ui.selectSeat.confirmReset(message);
};

/**
 * 좌석 선점 요청한다.
 * @param {object} param
 *      @param {boolean} param.isReserved   지정석 여부
 *      @param {array} param.seats  좌석 정보
 *      @param {number} param.count 비지정석일 경우 선점 좌석 수
 * @private
 */
TicketingIB.prototype._purchaseSeat = function(param) {
    var isReserved = param.isReserved,
        seats = param.seats,
        count = param.count;

    if (!this._isMaxTicketCountExceeded(seats, isReserved, count)) {
        if (isReserved) {
            this._requestPurchaseSeat(seats);
        } else {
            this._requestPurchaseNonReservedSeat(seats[0].seatId, count);
        }
    }
};

/**
 * purchase 하기 전, 현재 maxTicketCount 를 초과했는지 확인한다.
 * @param {Array} seats 좌석정보
 * @param {boolean} isReserved  지정석인지 여부
 * @param {number} count 비지정석일 경우, 선점 요청할 매수
 * @returns {boolean} 초과 여부
 * @private
 */
TicketingIB.prototype._isMaxTicketCountExceeded = function(seats, isReserved, count) {
    if (!this.get('hasMaxCountLimit')) {
        return false;
    }

    if (isReserved) {
        count = seats.length;
    }

    var currentSeatId = seats[0].seatId,
        seatData = this.getSelectedSeats(),
        seatList = seatData.list,
        maxTicketCount = this.get('maxTicketCount'),
        buyCountMaxCount = this.get('buyCountMaxCount'),
        buyCountLimitCount = this.get('buyCountLimitCount'),
        buyCountLimitClassCode = this.get('buyCountLimitClassCode'),
        currentCount = +count,
        isExceeded = false;

    ne.util.forEachArray(seatList, function(seat) {
        if (seat.isReserved) {
            currentCount += 1;
        } else if (seat.seatGroupId !== currentSeatId) {
            currentCount += 1;
        }
    });

    if (ne.util.isNumber(maxTicketCount) && currentCount > maxTicketCount) {
        isExceeded = true;
        alert('예매 당 최대 ' + maxTicketCount + '매 까지\n구매 가능합니다.');
    } else if (ne.util.isNumber(buyCountMaxCount) && currentCount > buyCountMaxCount) {
        isExceeded = true;
        if (buyCountLimitClassCode === 'PRODUCT') {
            alert('상품별 구매 가능 매수는 ' + buyCountLimitCount + '매 입니다.');
        } else if (buyCountLimitClassCode === 'INNING') {
            alert('회차별 구매 가능 매수는 ' + buyCountLimitCount + '매 입니다.');
        }
    }

    return isExceeded;
};

/**
 * 지정석 선점 한다.
 * @param {Array} seats 선점할 지정석 좌석 리스트
 * @private
 */
TicketingIB.prototype._requestPurchaseSeat = function(seats) {
    var self = this,
        url = API.URL.RESERVE_PREOCCUPACY_LIST,
        seatIds = ne.util.map(seats, function(seat) {
            return seat.seatId;
        }),
        seatsMap = {};

    this.requestToAPI(url, {
        data: {
            logicalPlanId: this.get('logicalPlanId'),
            preoccupancyMemberNo: this.get('preoccupancyMemberNo'),
            productId: this.get('productId'),
            scheduleId : this.get('scheduleId'),
            selectedSeats: seatIds,
            sellingType: this.get('sellingTypeCode')
        },
        noDimm: true,
        noDisableChart: true,
        type: 'POST',
        success: function(result) {
            var failSidList,
                successSeatList = [];

            if (result.fail && result.fail.length) {
                ne.util.forEachArray(seats, function(seat) {
                    seatsMap[seat.seatId] = seat;
                });
                ne.util.forEachArray(result.success, function(seatId) {
                    successSeatList.push(seatsMap[seatId]);
                });
                failSidList = ne.util.map(result.fail, function(seatId) {
                    return seatId + '';
                });
                self.fire(EVENT.CONTROL_DISABLE_SEAT, {
                    r: failSidList,
                    n: []
                });
            } else {
                successSeatList = seats;
            }

            if (successSeatList.length) {
                self.fire(EVENT.ADD_SEATS, successSeatList);
            }
            if (result.fail && result.fail.length) {
                if (successSeatList.length) {
                    alert('선택 좌석 중 이미 선점된 좌석을 제외하고 선택 했습니다.');
                } else {
                    alert('이미 선점된 좌석입니다.\n다른 좌석을 선택 해 주세요.');
                }
            }
        }
    });
};

/**
 * 지정석 선점 해제
 * @param {Array} seatIds 선점해제 할 좌석 리스트
 * @param {function} callback   성공시 수행할 콜백 함수
 * @private
 */
TicketingIB.prototype._requestCancelPurchaseSeat = function(seatIds, callback) {
    var url = API.URL.RESERVE_CANCEL_PREOCCUPACY_LIST;

    this.requestToAPI(url, {
        data: {
            logicalPlanId: this.get('logicalPlanId'),
            preoccupancyMemberNo: this.get('preoccupancyMemberNo'),
            productId: this.get('productId'),
            scheduleId : this.get('scheduleId'),
            selectedSeats: seatIds,
            sellingType: this.get('sellingTypeCode')
        },
        noDimm: true,
        noDisableChart: true,
        type: 'POST',
        success: callback
    });
};

/**
 * 비지정석 선점
 * @param {String} zoneId 비지정석 id
 * @param {Number} count 비지정석 선점 매수
 * @private
 */
TicketingIB.prototype._requestPurchaseNonReservedSeat = function(zoneId, count, seatId) {
    zoneId += '';

    var self = this,
        url,
        param,
        seatData;

    // 비지정석 1개인 회차의 경우
    if (this.isOnlyZone()) {
        url = API.URL.RESERVE_PREOCCUPACY_ONLY_ZONE;
        seatData = this.getOnlyZoneData();
        param = {
            scheduleId: this.get('scheduleId'),
            productGradeId: this.get('productGradeId'),
            preoccupancyMemberNo: this.get('preoccupancyMemberNo'),
            preoccupancyNo: count,
            allotmentCompanyCode: this.get('sellingTypeCode')
        };
    } else {
        url = API.URL.RESERVE_PREOCCUPACY_ZONE;
        seatData = this.getSeatDataFromMap(zoneId);
        param = {
            preoccupancyMemberNo: this.get('preoccupancyMemberNo'),
            preoccupancyNo: count,
            allotmentCompanyCode: this.get('sellingTypeCode'),
            zoneId: zoneId,
            productId: this.get('productId'),
            scheduleId : this.get('scheduleId'),
            logicalPlanId: this.get('logicalPlanId')
        };
    }
    this.requestToAPI(url, {
        data: param,
        type: 'POST',
        dimmImmediate: true,
        success: function(responseData) {
            var allotmentPreoccupancy = responseData.allotmentPreoccupancy;
            self.emit(EVENT.CONTROL_UPDATE_NON_RESERVED_COUNT, zoneId, responseData.remainCount);
            if (responseData.status) {
                self.fire(EVENT.SET_NON_RESERVED_SEATS, self.parseSeats(seatData.n), count, allotmentPreoccupancy, seatId);
            } else {
                alert('예매 가능매수가 부족합니다.\n확인 후 다시 시도해주세요.');
            }
        }
    });
};

/**
 * 비지정석 선점 해제
 * @param {string} zoneId   비지정석 zone id
 * @private
 */
TicketingIB.prototype._requestCancelPurchaseNonReservedSeat = function(zoneId) {
    zoneId += '';
    var self = this,
        url,
        param;

    if (this.isOnlyZone()) {
        url = API.URL.RESERVE_CANCEL_PREOCCUPACY_ONLY_ZONE;
        param = {
            scheduleId: this.get('scheduleId'),
            productGradeId: this.get('productGradeId'),
            preoccupancyMemberNo: this.get('preoccupancyMemberNo'),
            allotmentCompanyCode: this.get('sellingTypeCode')
        };
    } else {
        url = API.URL.RESERVE_CANCEL_PREOCCUPACY_ZONE;
        param = {
            scheduleId: this.get('scheduleId'),
            productId: this.get('productId'),
            preoccupancyMemberNo: this.get('preoccupancyMemberNo'),
            allotmentCompanyCode: this.get('sellingTypeCode'),
            zoneId: zoneId,
            logicalPlanId: this.get('logicalPlanId')
        };
    }
    this.requestToAPI(url, {
        data: param,
        type: 'POST',
        success: function(responseData) {
            self.fire(EVENT.REMOVE_SEATS, [zoneId]);
            self.emit(EVENT.CONTROL_UPDATE_NON_RESERVED_COUNT, zoneId, responseData.remainCount);
        }
    });
};

/**
 * seats 를 컴포넌트 및 서버 데이터 양식에 맞게 파싱한다.
 * @param {Array} seats map 으로 부터 넘어온 좌석 데이터
 * @returns {{seats: Array, gradeMap: {}}}
 */
TicketingIB.prototype.parseSeats = function(seats) {
    seats = ne.util.isUndefined(seats) ? [] : ne.util.isArray(seats) ? seats : [seats];

    var priceTable = this.get('priceTable'),
        formattedSeats;

    formattedSeats = ne.util.map(seats, function(seat) {
        var gradeId = seat.grade,
            seatAttributeInfoList = [],
            seatName,
            sellingType,
            gradeName = '-';

        if (ne.util.isExisty(ne.util.pick(priceTable, gradeId, 'productGradeName'))) {
            gradeName =  priceTable[gradeId].productGradeName;
        }

        //비지정석의 경우
        if (this._isZone(seat)) {
            seatName = seat.label || '비지정석';
            seatAttributeInfoList.push(seatName);
        } else {
            sellingType = seat.sellingType;
            ne.util.forEach(seat.getMapInfo(), function(value, suffix) {
                seatAttributeInfoList.push(value + suffix);
            });
        }
        return {
            seatId: seat.sid,
            seatAttributeInfo: seatAttributeInfoList.join(' '),
            productGradeName: gradeName,
            productGradeId: gradeId,
            sellingType: sellingType
        };
    }, this);
    return formattedSeats;
};

/**
 * 비지정석인지 여부
 * @param {Object} seat Map 으로 부터 전달받은 seat 정보
 * @returns {Boolean} 비지정석일경우 true
 * @private
 */
TicketingIB.prototype._isZone = function(seat) {
    return ne.util.isUndefined(seat.getMapInfo);
};

/**
 * map focus 시 이벤트 핸들러
 * @param {{n: Array, r: Array}} mapData focus 된 좌석 데이터 리스트
 * @param {Object} [mapEvent] mouse 이벤트 핸들러
 * @private
 */
TicketingIB.prototype._onMapFocused = function(mapData, mapEvent) {
    var count,
        collection,
        seats,
        ui = this.get('ui');

    if (mapData.n.length === 1) {
        //비지정석일때 처리
        seats = this.parseSeats(mapData.n);
        collection = ui.selectSeat.getZoneCollection(seats[0].seatId);
        count = collection ? collection.length : 0;
        this.fire(EVENT.NON_RESERVED_FOCUSED, seats, count, mapEvent && mapEvent.originalEvent);
    }

    if (mapData.r.length) {
        //지정석 처리
        seats = this.parseSeats(mapData.r);
        this.emit(EVENT.PURCHASE_SEAT, {
            seats: seats,
            isReserved: true
        });
    }
};

/**
 * UI 에서 Map 으로 deselect all 요청시 (초기화)
 * @private
 */
TicketingIB.prototype._controlDeselectAll = function(isAsync, skipFireEvent) {
    isAsync = ne.util.isUndefined(isAsync) ? true : isAsync;

    var self = this,
        seatData = this.getSelectedSeats(),
        currentParam = this.get('currentParam');

    if (seatData.list.length) {
        //비지정석 1개인 회차의 경우
        if (this.isOnlyZone()) {
            this._onMapDeselected(this.getOnlyZoneData());
        } else {
            this.requestToAPI(API.URL.RESERVE_CANCEL_ALL, {
                data: {
                    productId: currentParam.productId,
                    scheduleId : currentParam.scheduleId,
                    logicalPlanId: currentParam.logicalPlanId,
                    preoccupancyMemberNo: this.get('preoccupancyMemberNo'),
                    allotmentCompanyCode: this.get('sellingTypeCode')
                },
                type: 'POST',
                success: function(responseData) {
                    //성공한 경우에만 fire 함.
                    if (!skipFireEvent) {
                        self.fire(EVENT.CONTROL_DESELECT_ALL_SEAT);
                        self.emit(EVENT.UPDATE_ALL_ZONE_REMAIN_COUNT, responseData);
                    }
                },
                async: isAsync
            });
        }
    }
};

/**
 * UI 에서 Map 으로 deselect 요청시
 * @param {{n: array, r: array}} sidData 지정석과 비지정석 sid 리스트
 * @private
 */
TicketingIB.prototype._controlDeselect = function(sidData) {
    if (this.isOnlyZone()) {
        this._onMapDeselected(this.getOnlyZoneData());
    } else {
        this.fire(EVENT.CONTROL_DESELECT_SEAT, sidData);
    }
};

/**
 * map deselect 시 이벤트 핸들러
 * @param {{n: Array, r: Array}} mapData deselect 된 좌석 데이터 리스트
 * @private
 */
TicketingIB.prototype._onMapDeselected = function(mapData) {
    var self = this,
        seatIds,
        seats;
    if (mapData.r.length > 0) {
        seats = mapData.r;
        seatIds = ne.util.map(seats, function(seat) {
            return seat.sid;
        });
        this._requestCancelPurchaseSeat(seatIds, function() {
            self.fire(EVENT.REMOVE_SEATS, seatIds);
        });
    } else if (mapData.n.length > 0) {
        seats = this.parseSeats(mapData.n);
        this._requestCancelPurchaseNonReservedSeat(seats[0].seatId);
    }
};

/**
 * map 에서 전체 선택 해제 이벤트 발생시 핸들러
 * @private
 */
TicketingIB.prototype._onMapDeselectAll = function() {
    this._controlDeselectAll(true, true);
    this.fire(this.EVENT.MAP_DESELECT_ALL_SEAT);
};

/**
 * 현재 selected 된 seat 정보를 반환한다.
 * @returns {{list: array, map: object}}    좌석 정보
 */
TicketingIB.prototype.getSelectedSeats = function() {
    var seatData;
    this.emit(EVENT.GRID_GET_SELECTED_SEATS, function(data) {
        seatData = data;
    });
    return seatData;
};

/**
 * sidList 를 기반으로 map으로부터 seatData를 조회한다.
 * @param {Array} sidList 좌석 id 리스트
 * @returns {{n:array, r:array}}   map으로 부터 조회해온 정보
 */
TicketingIB.prototype.getSeatDataFromMap = function(sidList) {
    sidList = ne.util.isArray(sidList) ? sidList : [sidList];
    var seatData,
        list = ne.util.map(sidList, function(sid) {
            return sid+'';
        });
    this.emit(EVENT.CONTROL_SEARCH_SEAT, list, function(data) {
        seatData = data;
    });
    return seatData;
};

/**
 * 선점조회 시 server 로 받은 data format 을 seatData 형태로 변환하여 반환한다.
 * @param {Object} responseData 서버로 부터 받아온 좌석 데이터
 * @returns {{n: array, r: array}}  map 에서 사용할 수 있는 변경된 데이터 포멧
 */
TicketingIB.prototype.getSeatDataFromServerFormat = function(responseData) {
    var seatIds = [],
        nSeatIds = [];
    if (responseData.seat && responseData.seat.length) {
        seatIds = ne.util.map(responseData.seat, function(seatId) {
            return seatId.toString();
        });
    }
    if (responseData.zone && responseData.zone.length) {
        nSeatIds = ne.util.map(responseData.zone, function(item) {
            return item.zoneId.toString();
        });
    }
    return this.getSeatDataFromMap(seatIds.concat(nSeatIds));
};

/**
 * 기간권 여부 확인
 * @returns {boolean}   기간권 여부
 */
TicketingIB.prototype.isSeasonTicket = function() {
    return this.get('productTypeCode') === 'SEASON';
};

/**
 * 비지정석 한개인지 여부 확인
 * @returns {boolean}   비지정석 한개인지 여부
 */
TicketingIB.prototype.isOnlyZone = function() {
    if (ne.util.isExisty(this.get('logicalPlanId'))) {
        return false;
    } else {
        if (this.isSeasonTicket()) {
            return true;
        } else if (
            ne.util.isExisty(this.get('productId')) &&
            ne.util.isExisty(this.get('productDate')) &&
            ne.util.isExisty(this.get('productRound'))
        ) {
            return true;
        } else {
            return false;
        }
    }
};

/**
 * 발권 요청용 데이터를 반환한다.
 * @returns {{productId: *, productTypeCode: *, productDate: *, reserveMemberNo: *, loginMemberNo: *, productRound: *, scheduleId: *, logicalPlanId: *, ticketCount: *, ticketAmount: *, additionalProuctCount: (*|number), additionalProuctAmount: (*|number), additionalProduct: (*|Array), ticketList: Array}}
 */
TicketingIB.prototype.getTicketingData = function() {
    var ui = this.get('ui'),
        priceTable = this.get('priceTable'),
        seatData = ui.selectSeat.toJSON() ? ui.selectSeat.toJSON() : {},
        ticketData = ui.selectTicket ? ui.selectTicket.toJSON() : {},
        ticketList = [],
        additionalData = ui.selectAdditional ? ui.selectAdditional.toJSON() : {},
        ticketingData;

    ne.util.forEach(ticketData.map, function(list, gradeId) {
        var gradeName = '';

        if (ne.util.isExisty(ne.util.pick(priceTable, gradeId, 'productGradeName'))) {
            gradeName =  priceTable[gradeId].productGradeName;
        }

        var obj = {
            productGradeName: gradeName,
            productGradeId: gradeId,
            productDenominationList: list
        };
        ticketList.push(ne.util.extend(obj, seatData.map[gradeId]));
    });

    ticketingData = {
        sellingType: this.get('sellingTypeCode'),
        productId: this.get('productId'),
        productTypeCode: this.get('productTypeCode'),
        productDate: this.get('productDate'),
        reserveMemberNo: this.get('reserveMemberNo'),
        loginMemberNo: this.get('loginMemberNo'),
        preoccupancyMemberNo: this.get('preoccupancyMemberNo'),
        productRound: this.get('productRound'),
        scheduleId: this.get('scheduleId'),
        logicalPlanId: this.get('logicalPlanId'),
        ticketCount: ticketData.count,
        ticketAmount: ticketData.price,
        additionalProductCount: additionalData.count || 0,
        additionalProductAmount: additionalData.price || 0,
        additionalProduct: additionalData.list || [],
        ticketList: ticketList
    };

    return ticketingData;
};

/**
 * 발권 요청용 데이터의 validation 을 확인한다.
 * @param {object} ticketingData    getTicketingData 메서드를 통해 생성된 데이터
 * @returns {boolean}   validation 을 통과했는지 여부
 */
TicketingIB.prototype.validateTicketingData = function(ticketingData) {
    var ui = this.get('ui'),
        seatData = ui.selectSeat.toJSON() ? ui.selectSeat.toJSON() : {},
        isValid = true;

    if (!seatData.list.length) {
        alert('좌석을 선택해주세요.');
        isValid = false;
    } else if (!ticketingData.ticketList.length) {
        alert('티켓 종류 및 매수를 선택해주세요.');
        isValid = false;
    } else if(!this._isTicketCountMatched(ticketingData)) {
        alert('선택하신 좌석 수와 티켓 수가 일치하지 않습니다.\n티켓매수를 다시 선택 해 주세요.');
        isValid = false;
    }
    return isValid;
};

/**
 * 선택좌석수와 권종 매수가 동일한지 확인한다.
 * @param ticketingData    getTicketingData 메서드를 통해 생성된 데이터
 * @returns {boolean}   동일한지 여부
 * @private
 */
TicketingIB.prototype._isTicketCountMatched = function(ticketingData) {
    var ui = this.get('ui'),
        seatData = ui.selectSeat.toJSON() ? ui.selectSeat.toJSON() : {},
        ticketList = ticketingData.ticketList,
        isValid = true,
        totalSeatCount = seatData.list.length,
        totalTicketCount = 0;

    ne.util.forEachArray(ticketList, function(ticket) {
        var ticketCount = 0,
            seatCount = ticket.seatList.length;
        ne.util.forEachArray(ticket.productDenominationList, function(item) {
            ticketCount += item.count;
        });
        ne.util.forEachArray(ticket.zoneList, function(zone) {
            seatCount += zone.count;
        });

        totalTicketCount += ticketCount;
        if (ticketCount !== seatCount) {
            isValid = false;
            return false;
        }
    });

    if (totalTicketCount !== totalSeatCount) {
        isValid = false;
    }
    return isValid;
};

/**
 * 현재 맵이 load 되었는지 여부 확인
 * @returns {boolean}   현재 map 이 로드 되었는지 여부
 * @private
 */
TicketingIB.prototype._isMapLoaded = function() {
    return this.get('isMapLoaded');
};

/**
 * unloadCheck 을 비활성화 한다.
 */
TicketingIB.prototype.disableUnloadCheck = function() {
    this.preventCloseWindow = false;
};

/**
 * unloadCheck 을 활성화 한다.
 */
TicketingIB.prototype.enableUnloadCheck = function() {
    this.preventCloseWindow = true;
};

module.exports = TicketingIB;
