/**
 * @fileoverview 선발권 컨트롤러
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */

'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    API = tkl.API,
    etc = require('../../../../etc'),
    FloatingUI = require('../../../common/floating'),
    MapController = require('../../common/mapController'),
    SelectSeatUI = require('../../common/selectSeat'),
    SelectTicketUI = require('../../common/selectTicket'),
    LayerUI = require('../../common/layer'),
    NSeatCounter = require('../../common/nSeatCounter'),
    SelectSchedule = require('../../common/selectSchedule'),
    ScheduleView = require('../../common/scheduleView'),
    SeatingInfoPerRound = require('../../common/seatingInfoPerRound'),
    ProductInfoUI = require('../../common/productInfo'),
    DashBoardUI = require('../../common/dashBoard'),
    tmplDashBoardRow = require('../../../../../tmpl/ticketing/dashBoard/adminRow.html'),
    tmplInformation = require('../../../../../tmpl/ticketing/information/prePurchase.html');

/**
 * 선발권 컨트롤러
 * @exports PrePurchaseController
 * @extends {UIController}
 * @constructor
 * @class
 */
var PrePurchaseController = UIController.extend({
    rootElement: $('body'),
    events: {
        'click ._selectAllAllocatedRemainSeats': '_onClickAllAllocated',
        'click ._selectAllRemainSeats': '_onClickAll',
        'click ._ticketSubmit': '_onClickSubmit',
        'click ._ticketCancel': '_onClickCancel'
    },

    /**
     * 초기화 생성자
     * @param options
     */
    init: function(options) {
        UIController.call(this, options);
        this._isLocked = false;
        this.params = options.params;
        this.mapOptions = options.mapOptions;
        this._initializeElements();
        this._initializeUI();
        this._initializeListeners();
        this.attachEvents();
        this._initializeStatus();
    },

    /**
     * 엘리먼트 초기화
     * @private
     */
    _initializeElements: function() {
        this.$btnAllAllocated = this.$el.find('._selectAllAllocatedRemainSeats');
        this.$btnAll = this.$el.find('._selectAllRemainSeats');
        this.$form = this.$el.find('._form');
    },

    /**
     * IB 리스너 할당
     * @private
     */
    _initializeListeners: function() {
        var IB = this.IB;
        IB.listen(IB.EVENT.SEAT_GRADE_SELECTED, this._setStatus, this);
        IB.listen(IB.EVENT.SEAT_GRADE_DESELECTED, this._setStatus, this);
        IB.listen(IB.EVENT.AVAILABLE_SEATINFO_LOADED, this._setStatus, this);
    },

    /**
     * UI 컴포넌트 인스턴스 생성
     * @private
     */
    _initializeUI: function() {
        var ui = this.ui = {};
        ui.floating =  new FloatingUI('#dimmed');
        ui.floating.setIB(this.IB);
        ui.mapController = new MapController({
            IB: this.IB,
            rootElement: $('body')
        });
        ui.dashBoard = new DashBoardUI({
            IB: this.IB,
            rootElement: $('._dashBoard'),
            template: tmplDashBoardRow
        });
        //상품영역
        ui.productInfo = new ProductInfoUI({
            IB: this.IB,
            rootElement: $('._productInfo'),
            template: tmplInformation
        });
        //레이어 UI
        ui.layer = new LayerUI({
            rootElement: $('._tooltip')
        });
        //좌석 선택 영역 UI
        ui.selectSeat = new SelectSeatUI({
            rootElement: $('._selectSeat'),
            IB: this.IB,
            grid: {
                color: {
                    border: '#FFFFFF'
                },
                className: {
                    table: 'seat_list'
                },
                height: 106
            }
        });
        //티켓 선택 영역 UI
        ui.selectTicket = new SelectTicketUI({
            rootElement: $('._selectTicket'),
            IB: this.IB,
            layer: this.ui.layer
        });
        //비지정석 매수입력
        ui.seatCounter = new NSeatCounter({IB: this.IB});
        //날짜선택
        ui.selectSchedule = new SelectSchedule({
            IB: this.IB,
            type: SelectSchedule.TYPE.BASIC,
            seatingInfoPerRound: new SeatingInfoPerRound({
                IB: this.IB,
                type: SeatingInfoPerRound.TYPE.SELECTABLE
            }),
            scheduleView: new ScheduleView({
                IB: this.IB
            })
        });
        this.IB.set('ui', this.ui);
    },

    /**
     * 초기화 파라미터로 넘어온 정보를 토대로 현재 상태를 초기화 한다.
     * @private
     */
    _initializeStatus: function() {
        var params = this.params;
        if (params) {
            this._initializeProductId();
        }
    },

    /**
     * productId 가 설정되어 있다면 UI에 노출한다.
     * @private
     */
    _initializeProductId: function() {
        var params = this.params;
        if (ne.util.isExisty(ne.util.pick(params, 'productId'))) {
            this.IB.emit(this.IB.EVENT.SHOW_PRELOADER);
            if (ne.util.isExisty(ne.util.pick(params, 'productDate'))) {
                this.IB.listen(this.IB.EVENT.AVAILABLE_DATES_LOADED, this._initializeProductDate, this);
            }
            this.IB.emit(this.IB.EVENT.PRODUCT_CHANGE, params.productId);
        } else {
            this.IB.emit(this.IB.EVENT.HIDE_PRELOADER);
        }
    },

    /**
     * productDate 가 설정되어 있다면 UI에 노출한다.
     * @private
     */
    _initializeProductDate: function() {
        this.IB.emit(this.IB.EVENT.SHOW_PRELOADER);
        this.IB.stopListen(this.IB.EVENT.AVAILABLE_DATES_LOADED, this);
        var params = this.params;
        if (ne.util.isExisty(ne.util.pick(params, 'productRound'))) {
            this.IB.listen(this.IB.EVENT.ROUND_LOADED, this._initializeProductRound, this);
        }
        this.IB.emit(this.IB.EVENT.DATE_SELECT, params.productDate);
    },

    /**
     * 회차 정보가 넘어왔다면 회차정보를 업데이트한다.
     * @private
     */
    _initializeProductRound: function() {
        this.IB.emit(this.IB.EVENT.SHOW_PRELOADER);
        this.IB.stopListen(this.IB.EVENT.ROUND_LOADED, this);
        this.IB.emit(this.IB.EVENT.ROUND_SELECT, this.params.productRound);
    },

    /**
     * 등급별 발권할당 잔여좌석 전체선택 이벤트 핸들러
     * @param {Event} clickEvent    클릭이벤트
     * @private
     */
    _onClickAllAllocated: function(clickEvent) {
        var $target = $(clickEvent.target);
        if (!$target.hasClass('disabled')) {
            this._requestRemainingSeats(true);
        }
    },

    /**
     * 등급별 잔여좌석 전체선택 이벤트 핸들러
     * @param {Event} clickEvent    클릭이벤트
     * @private
     */
    _onClickAll: function(clickEvent) {
        var $target = $(clickEvent.target);
        if (!$target.hasClass('disabled')) {
            this._requestRemainingSeats();
        }
    },

    /**
     * 취소 버튼 이벤트 핸들러
     * @private
     */
    _onClickCancel: function() {
        if (confirm('설정된 정보가 모두 초기화 됩니다.')) {
            this.IB.emit(this.IB.EVENT.UI_RESET);
        }
    },

    /**
     * 티켓출력 버튼 이벤트 핸들러
     * @private
     */
    _onClickSubmit: function() {
        var submitData = this.IB.getTicketingData(),
            paymentData = this._getPaymentData();
        submitData.payment = {};
        submitData.payment[paymentData.type] = paymentData.data;

        if (this._validate(submitData)) {
            this._submit(submitData);
        }
    },

    /**
     * 서버로 submit 전에 유효성 검사를 진행한다.
     * @param {Object} submitData 서버로 submit 할 데이터
     * @returns {boolean}   유효성 검사를 통과했는지 여부
     * @private
     */
    _validate: function(submitData) {
        return this.IB.validateTicketingData(submitData);
    },

    /**
     * 중복 submit 을 방지하기 위해 lock 을 건다.
     * @private
     */
    _lock: function() {
        this._isLocked = true;
    },

    /**
     * 중복 submit 을 방지하기 위한 lock 을 해제 한다.
     * @private
     */
    _unlock: function() {
        this._isLocked = false;
    },

    /**
     * 실제 서버로 submit
     * @param {Object} submitData 실제로 submit 할 데이터
     * @private
     */
    _submit: function(submitData) {
        if (!this._isLocked) {
            this._lock();
            this.fireEvent('onSubmit', submitData);
            this.IB.requestToAPI(API.URL.RESERVE_COMPLETE, {
                data: submitData,
                type: 'POST',
                dimmImmediate: true,
                success: ne.util.bind(this._onSuccessSubmit, this),
                fail: ne.util.bind(this._onFailSubmit, this),
                complete: ne.util.bind(this._unlock, this)
            });
        }
    },

    /**
     * submit success 이벤트 핸들러
     * @param {object} responseData 응답 데이터
     * @private
     */
    _onSuccessSubmit: function(responseData) {
        this.fireEvent('onSuccessSubmit', responseData);
    },

    /**
     * submit fail 이벤트 핸들러
     * @param {object} responseData 응답 데이터
     * @param {Number}  responseCode 응답 코드
     * @private
     */
    _onFailSubmit: function(responseData, responseCode) {
        this.fireEvent('onFailSubmit', responseData, responseCode);
    },

    /**
     * submit 에 포함될 티켓 데이터를 받아온다.
     * @returns {{type: string, data: {}}}
     * @private
     */
    _getPaymentData: function() {
        var formData = etc.form.getFormData(this.$form),
            checkList = ['cutting', 'name', 'phoneNumber'],
            jsonData = {};

        ne.util.forEachArray(checkList, function(name) {
            if (name === 'cutting') {
                if (name === 'receipt' || name === 'cutting') {
                    formData[name] = !!formData[name];
                }
            }
            jsonData[name] = formData[name];
        });
        return {
            type: 'ticketing',
            data: jsonData
        };
    },

    /**
     * 등급별 발권할당 잔여좌석, 등급별 잔여좌석 조회 및 선점 request
     * @param {boolean} [isAllocatedOnly=false] 발권할당 좌석 여부
     * @private
     */
    _requestRemainingSeats: function(isAllocatedOnly) {
        var IB = this.IB,
            url,
            param;

        if (IB.isOnlyZone()) {
            param = {
                productGradeId : IB.get('productGradeId'),
                scheduleId: IB.get('scheduleId'),
                preoccupancyMemberNo : IB.get('preoccupancyMemberNo'),
                allotmentCompanyCode : isAllocatedOnly ? 'TICKET': ''
            };
            url = API.URL.RESERVE_EXHIBITION_ALL_SELECT;
        } else {
            param = {
                logicalPlanId: IB.get('venueID'),
                grade: parseInt(IB.get('productGradeId'), 10),
                sellingType: isAllocatedOnly ? 'TICKET': '',
                preoccupancyMemberNo: IB.get('preoccupancyMemberNo')
            };
            url = API.URL.RESERVE_GET_GRADE_REMAIN_ALL_LIST;
        }

        IB.requestToAPI(url, {
            data: param,
            type: 'POST',
            success: ne.util.bind(this._onSuccessRemainingSeats, this)
        });
    },

    /**
     * 등급별 발권할당 잔여좌석, 등급별 잔여좌석 조회 및 선점 request 결과 핸들러
     * @param {Object} responseData 결과값
     * @private
     */
    _onSuccessRemainingSeats: function(responseData) {
        if (this.IB.isOnlyZone()) {
            responseData = this._parseZoneServerData(responseData);
            this._updateOccupancyOnlyZone(responseData);
        } else {
            responseData.zone = this._parseZoneServerData(responseData.zone);
            this.ui.mapController.setOccupancyData(responseData);
        }
        if (!this._isRemainingSeatsExist(responseData)) {
            alert('해당 등급의 잔여좌석이 없습니다.');
        }
    },

    /**
     * 잔여좌석이 남아있는지 여부
     * @param {Object} responseData 서버로부터 응답받은 데이터
     * @returns {boolean}   현재 좌석이 남아있는지 여부
     * @private
     */
    _isRemainingSeatsExist: function(responseData) {
        var data = responseData,
            count = 0;
        if (this.IB.isOnlyZone()) {
            data = {
                seats: [],
                zone: responseData
            };
        }
        ne.util.forEachArray(data.zone, function(zone) {
            count += zone.selectedCount || 0;
        });
        count += data.seats.length || 0;
        return count !== 0;
    },

    /**
     * 비지정석 1개인 회차의 경우 다음과 같이 처리한다.
     * @param {Array} zoneList  서버에서부터 받아온 zoneList
     * @private
     */
    _updateOccupancyOnlyZone: function(zoneList) {
        if (zoneList.length === 1) {
            var IB = this.IB,
                zone = zoneList[0],
                zoneData = IB.getOnlyZoneData(),
                zoneId = zoneData['n'][0].sid,
                allotmentPreoccupancy = zone.allotmentPreoccupancy,
                selectedCount = zone.selectedCount,
                remainCount = zone.remainCount;

            IB.emit(IB.EVENT.SET_NON_RESERVED_SEATS, IB.parseSeats(zoneData.n), selectedCount, allotmentPreoccupancy);
            IB.emit(IB.EVENT.CONTROL_UPDATE_NON_RESERVED_COUNT, zoneId, remainCount);

            if (!selectedCount) {
                alert('해당 등급의 잔여좌석이 없습니다.');
            }
        }
    },

    /**
     * 서버로 부터 받아온 중복된 형태의 zone list 배열을 한 배열당 한개의 유일한 zoneId 로 구성되도록 재 가공한다.
     * @param {Array} zoneList  서버에서부터 받아온 zoneList
     * @returns {Array} 유일한 zoneId 로 가공된 zoneList
     * @private
     */
    _parseZoneServerData: function(zoneList) {
        var zoneMap = {},
            newZoneList = [];

        ne.util.forEachArray(zoneList, function(zone) {
            var zoneId = zone.zoneId,
                allotmentCompanyCode = zone.allotmentCompanyCode,
                selectedCount = zone.selectedCount || 0,
                remainCount = zone.remainCount || 0,
                isZoneExist = !!zoneMap[zoneId];

            if (isZoneExist) {
                zoneMap[zoneId].remainCount += remainCount;
                zoneMap[zoneId].selectedCount += selectedCount;
            } else {
                zoneMap[zoneId] = {
                    zoneId: zoneId,
                    remainCount: remainCount || 0,
                    selectedCount: selectedCount || 0,
                    allotmentPreoccupancy: {}
                };
            }
            zoneMap[zoneId].allotmentPreoccupancy[allotmentCompanyCode] = selectedCount;
        });

        ne.util.forEach(zoneMap, function(zone) {
            newZoneList.push(zone);
        });
        return newZoneList;
    },

    /**
     * 등급별 전체선택 버튼을 비활성화 한다.
     * @private
     */
    _disableSelectAll: function() {
        this.$btnAllAllocated.addClass('disabled');
        this.$btnAll.addClass('disabled');
    },

    /**
     * 등급별 전체선택 버튼을 활성화 한다.
     * @private
     */
    _enableSelectAll: function() {
        this.$btnAllAllocated.removeClass('disabled');
        this.$btnAll.removeClass('disabled');
    },

    /**
     * productGradeId 를 토대로 활성화/비활성화 한다.
     * @private
     */
    _setStatus: function() {
        if (ne.util.isExisty(this.IB.get('productGradeId'))) {
            this._enableSelectAll();
        } else {
            this._disableSelectAll();
        }
    }
});

module.exports = PrePurchaseController;
