/**
 * @fileoverview    Map 의 노출정보를 핸들링하는 컨트롤러
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */

'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    API = tkl.API,
    TicketingMap = require('../ticketingMap'),
    UIModel = require('../../../ui/model'),
    UICollection = require('../../../ui/collection'),
    ZoomButton = require('../../../control/zoomButton');

/**
 * IB 의 priceTable.
 * seat model parse 를 위한 전역 변수
 */
var priceTable;

/**
 * 선점 데이터를 담고 있는 seat 모델 정의
 * @type {*}
 */
var SeatModel = UIModel.extend({
    init: function(data) {
        UIModel.call(this, data, {
            parse: true
        });
    },
    idAttribute: 'seatId',
    defaults: {
        seatId: null,
        seatAttributeInfo: null,
        productGradeName: null,
        productGradeId: null,
        sellingType: null
    },
    parse: function(data) {
        var gradeId = data.gradeId,
            gradeName = '-';

        if (ne.util.isExisty(ne.util.pick(priceTable, gradeId, 'productGradeName'))) {
            gradeName = priceTable[gradeId].productGradeName;
        }

        return {
            seatId: data.sid + '',
            seatAttributeInfo: data.seatAttribute,
            productGradeName: gradeName,
            productGradeId: gradeId
        };
    }
});

/**
 * 선점 데이터를 담고 있는 seat 콜렉션 정의
 * @type {*}
 */
var SeatCollection = UICollection.extend({
    init: function(models) {
        UICollection.call(this, models, {
            parse: true
        });
    },
    model: SeatModel
});


/**
 * MapController
 * @constructor
 */
var MapController = UIController.extend({
    message: {
        /**
         * 일반 메세지
         * @type {String}
         */
        normal: '[안내] <%=which%>를 선택해 주세요!',
        /**
         * 기간권 메세지
         * @type {String}
         */
        season: '[안내] 하나의 비지정석으로만 이루어진 상품입니다.<br>매수 적용 시 해당 상품의 좌석이 추가됩니다.',
        /**
         * 비지정석 메세지
         * @type {String}
         */
        onlyZone: '[안내] 하나의 비지정석으로만 이루어진 상품입니다.<br>날짜/회차 선택 후 매수 적용 시<br>해당 상품의 좌석이 추가됩니다.'
    },
    rootElement: $('body'),

    /**
     * 생성자
     * @param {Object} options
     */
    init: function(options) {
        UIController.call(this, options);
        this.isInit = false;
        this.seatingMap = null;
        this.seatCollection = new SeatCollection();

        this._initializeElements();
        this._initializeEventHandler();
        this._initializeListeners();
        this._bindSeatCollection();
        this.show();
    },

    /**
     * 리스너를 초기화한다.
     * @private
     */
    _initializeListeners: function() {
        this.IB.listen(this.IB.EVENT.UPDATE_SEATING_MAP, this.show, this);
        this.IB.listen(this.IB.EVENT.RSEAT_RENDERED, this._onSeatRendered, this);
        this.IB.listen(this.IB.EVENT.INIT_ZONE_REMAIN_COUNT, this._initializeZoneRemainCount, this);
        this.IB.listen(this.IB.EVENT.UPDATE_ALL_ZONE_REMAIN_COUNT, this._updateOccupancyZones, this);

        this.IB.listen(this.IB.EVENT.ZOOM, ne.util.bind(this._onZoomChanged, this));
    },

    /**
     * 선점을 위한 seat collection 을 바인딩 한다.
     * @private
     */
    _bindSeatCollection: function() {
        this.IB.listen(this.IB.EVENT.CONTROL_DESELECT_SEAT, this._onDeselectSeat, this);
        this.IB.listen(this.IB.EVENT.CONTROL_DESELECT_ALL_SEAT, this._onDeselectAllSeat, this);
    },

    /**
     * controlDeselectSeat 이벤트 발생시
     * @param seatData
     * @private
     */
    _onDeselectSeat: function(seatData) {
        var seatCollection = this.seatCollection,
            removeSeats = [],
            deselectEventData = {
                r: [],
                n: []
            };

        if (seatCollection.length && seatData.r.length) {
            ne.util.forEachArray(seatData.r, function(sid) {
                removeSeats.push(seatCollection.get(sid));
                deselectEventData.r.push({
                    sid: sid
                });
            });
            seatCollection.remove(removeSeats);
            this.IB.emit(this.IB.EVENT.MAP_DESELECT_SEAT, deselectEventData);
        }
    },

    /**
     * controlDeselectAllSeat 이벤트 발생시
     * @private
     */
    _onDeselectAllSeat: function() {
        var seatCollection = this.seatCollection;
        seatCollection.clear();
    },

    /**
     * 이벤트 핸들러를 바인딩한다.
     * @private
     */
    _initializeEventHandler: function() {
        this.$panel.on('click', ne.util.bind(this._onClickPanel, this));
    },

    /**
     * zoom 변경 되었을 때 이벤트 핸들러
     * @param {number} newZoom zoom 레벨 변경시
     * @private
     */
    _onZoomChanged: function(newZoom) {
        var diff = newZoom - 3,
            percent = 100 * Math.pow(diff < 0 ? 0.5 : 2, Math.abs(diff));

        this.$zoomStatus.text(percent + '%');
    },

    /**
     * panel 을 클릭시 이벤트 핸들러
     * @param {event} clickEvent
     * @private
     */
    _onClickPanel: function(clickEvent) {
        var $target = $(clickEvent.target);

        if ($target.hasClass('plus')) {
            this.IB.emit(this.IB.EVENT.ZOOM_IN);
        } else if ($target.hasClass('minus')) {
            this.IB.emit(this.IB.EVENT.ZOOM_OUT);
        } else if ($target.hasClass('small')) {
            this.IB.emit(this.IB.EVENT.ZOOM_RESET);
        }
    },

    /**
     * 엘리먼트 바인딩
     * @private
     */
    _initializeElements: function() {
        this.$panel = this.$el.find('._mapPanel');
        this.$layerMap = this.$el.find('._layerMap');
        this.$layerNav = this.$el.find('._layerNav');
        this.$map = this.$el.find('#navigator');
        this.$nav = this.$el.find('#map');

        this.$zoomStatus = this.$panel.find('.v100');
    },

    /**
     * map 정보 생성에 필요한 데이터가 존재하는지 확인한다.
     * @returns {boolean} 데이터 존재 여부
     * @private
     */
    _isMapDataExist: function() {
        var IB = this.IB;
        if (
            ne.util.isExisty(IB.get('venueID')) &&
            ne.util.isExisty(IB.get('productRound')) &&
            ne.util.isExisty(IB.get('mapOptions'))
        ) {
            return true;
        } else {
            return false;
        }
    },

    /**
     * map 을 생성하여 노출하거나 안내 레이어를 노출한다.
     */
    show: function() {
        var strList = [];
        if (this._isMapDataExist()) {
            this._hideLayer();
            this._createMapInstance();
        } else {
            if (this.IB.isSeasonTicket()) {
                this._showLayer(this.message.season);
            }
            else if (this.IB.isOnlyZone()) {
                this._showLayer(this.message.onlyZone);
            } else {
                if (!ne.util.isExisty(this.IB.get('productId'))) {
                    strList.push('상품');
                }
                if (!ne.util.isExisty(this.IB.get('productDate'))) {
                    strList.push('날짜');
                }
                if (!ne.util.isExisty(this.IB.get('productRound'))) {
                    strList.push('회차');
                }
                this._showLayer(this.message.normal.replace('<%=which%>', strList.join('/')));
            }
        }
    },

    /**
     * 레이어를 노출한다.
     * @param {String} [msg]  노출 메세지
     * @private
     */
    _showLayer: function(msg) {
        msg = msg || this.message.normal;
        this.$map.hide();
        this.$nav.hide();
        this.$panel.hide();
        this.$layerMap.html(msg);
        this.$layerMap.show();
        this.$layerNav.show();
    },

    /**
     * 레이어를 숨긴다.
     * @private
     */
    _hideLayer: function() {
        this.$map.show();
        this.$nav.show();
        this.$panel.show();
        this.$layerMap.hide();
        this.$layerNav.hide();
    },

    /**
     * 맵 instance 를 생성한다.
     * @private
     */
    _createMapInstance: function() {
        this.IB.set('isMapLoaded', true);
        if (!ne.util.isExisty(this.seatingMap)) {
            var defaultOptions = {
                    usePanningLimit: false,
                    useLoadRSeatVertical: false,
                    isClosedEvent: false,
                    isReservationSystem: false,
                    IB: this.IB
                },
                mapOptions = ne.util.extend(defaultOptions, this.IB.get('mapOptions')),
                map,
                zoomButtonAvailable = mapOptions.minZoom != mapOptions.maxZoom;

            this._onZoomChanged(mapOptions.zoom);
            map = this.seatingMap = new TicketingMap('map', mapOptions);

            if (zoomButtonAvailable && this.IB.get('useZoomButtonControl')) {
                map.addControl(new ZoomButton());
            }

            //디버깅을 위해 외부로 레퍼런스 연결함
            ne.tkl.seatingMap = this.seatingMap;
        }
    },

    /**
     * seatRender 이벤트 발생시 이벤트 핸들러
     * @private
     */
    _onSeatRendered: function() {
        var IB = this.IB;
        if (!this.isInit) {
            this.isInit = true;
            this._initializeZoneRemainCount();
            if (!IB.get('isSkipRequestPreoccupancy')) {
                this.IB.requestToAPI(API.URL.RESERVE_GET_ALL_PREOCCUPANCY, {
                    data: {
                        logicalPlanId: IB.get('venueID'),
                        preoccupancyMemberNo: IB.get('preoccupancyMemberNo'),
                        sellingType: IB.get('sellingTypeCode')
                    },
                    type: 'POST',
                    success: ne.util.bind(this.setOccupancyData, this)
                });
            }
        } else {
            this._selectOccupancySeats();
        }
    },

    /**
     * 현재 보이지 않는 영역까지 포함한 선점 데이터를 세팅한다.
     * 선발권의 발권할당 전체좌석 전체 선택과 동일
     * @param responseData
     */
    setOccupancyData: function(responseData) {
        var IB = this.IB,
            seats = responseData.seats;

        priceTable = this.IB.get('priceTable');

        if (ne.util.isArray(seats)) {
            this.seatCollection.set(seats, {parse: true});
        }

        if (this.seatCollection && this.seatCollection.length) {
            IB.emit(IB.EVENT.ADD_SEATS, this.seatCollection.toJSON());
        }

        this._updateOccupancyZones(responseData);
    },

    /**
     * 현재 보이지 않는 영역을 포함한 저장된 선점 좌석들에 대해 map 에 선점 표시를 한다.
     */
    _selectOccupancySeats: function() {
        var IB = this.IB,
            seatCollection = this.seatCollection,
            sidList = seatCollection.map(function(seat) {
                return seat.get('seatId') + '';
            }),
            selectedIdList = [],
            seatData = IB.getSeatDataFromMap(sidList),
            seatId;

        if (ne.util.isExisty(ne.util.pick(seatData, 'r')) && seatData.r.length) {
            ne.util.forEachArray(seatData.r, function(seat) {
                seatId = seat.sid;
                selectedIdList.push(seatId);
                seatCollection.remove(seatCollection.get(seatId));
            });
            //r: reserved seat 지정석
            //n: non-reserved seat 비지정석
            IB.emit(IB.EVENT.CONTROL_SELECT_SEAT, {
                r: selectedIdList,
                n: []
            });
        }
    },

    /**
     * 선점된 zone 에 대한 정보를 업데이트 한다.
     * @param {Object} responseData
     * @private
     */
    _updateOccupancyZones: function(responseData) {
        var IB = this.IB,
            seatData = IB.getSeatDataFromServerFormat(responseData),
            zoneMap = {},
            zoneRemainCountMap = {},
            zoneId,
            zoneData,
            remainCount,
            selectedCount,
            allotmentPreoccupancy;

        if (seatData) {
            ne.util.forEachArray(responseData.zone, function(zone) {
                zoneMap[zone.zoneId] = {
                    remainCount: zone.remainCount,
                    selectedCount: zone.selectedCount,
                    allotmentPreoccupancy: zone.allotmentPreoccupancy
                };
            });

            //비지정석 업데이트
            ne.util.forEachArray(seatData.n, function(nSeat) {
                zoneId = nSeat.sid;
                zoneData = zoneMap[zoneId];
                remainCount = zoneData.remainCount;
                selectedCount = zoneData.selectedCount;
                allotmentPreoccupancy = zoneData.allotmentPreoccupancy;

                IB.emit(IB.EVENT.SET_NON_RESERVED_SEATS, IB.parseSeats([nSeat]), selectedCount, allotmentPreoccupancy);
                IB.emit(IB.EVENT.CONTROL_UPDATE_NON_RESERVED_COUNT, zoneId, remainCount);
                zoneRemainCountMap[zoneId] = remainCount;
            });

            IB.emit(IB.EVENT.ZONE_REMAIN_COUNT_LOADED, zoneRemainCountMap);
        }
    },

    /**
     * 비지정석 잔여 좌석 정보를 초기화 한다.
     * @private
     */
    _initializeZoneRemainCount: function() {
        var IB = this.IB,
            zoneList = ne.tkl.data.nseats,
            zoneRemainCountMap = {},
            zoneId,
            dealershipRemainCount,
            isZoneExist,
            remainCount;

        //zone map 을 생성한다.
        ne.util.forEachArray(zoneList, function(zone) {
            zoneId = zone.sid;
            dealershipRemainCount = zone.dealershipRemainCount || zone.dealership;
            isZoneExist = !!zoneRemainCountMap[zoneId];
            remainCount = 0;

            ne.util.forEach(dealershipRemainCount, function(count) {
                remainCount += count || 0;
            });

            if (isZoneExist) {
                zoneRemainCountMap[zoneId] += remainCount;
            } else {
                zoneRemainCountMap[zoneId] = remainCount;
            }
        });

        //remain count 정보를 업데이트 한다.
        ne.util.forEach(zoneRemainCountMap, function(zoneRemainCount, zoneId) {
            IB.emit(IB.EVENT.CONTROL_UPDATE_NON_RESERVED_COUNT, zoneId, zoneRemainCount);
        });

        //사용자 예매단에서 사용하기 위해 remainCountMap 을 반환한다.
        IB.emit(IB.EVENT.ZONE_REMAIN_COUNT_LOADED, zoneRemainCountMap);
    }
});

module.exports = MapController;
