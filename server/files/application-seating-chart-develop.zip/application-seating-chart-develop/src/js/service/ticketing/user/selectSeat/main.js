/**
 * @fileoverview 사용자 예매 진입점
 * @author FE개발팀 박순영 <soonyoung.park@nhnent.com>
 */
'use strict';

var UserIB = require('./userIB'),
    SelectSeat = require('./controller'),
    IB;

/**
 * 초기화 함수.
 * 서비스 코드에서 호출할 진입점
 * @param {Object} options
 *      @param {Object} options.mapOptions
 *      @param {Object} options.params
 *          @param {String} options.params.sellingTypeCode  진입점 정보(할당처 기획사 예매처 등)
 *          @param {String} options.params.reserveMemberNo  예매자 정보
 *          @param {String} options.params.loginMemberNo  로그인 사용자 정보
 *      @param {Object} options.callback
 *          @param {function} options.callback.onSubmit     완료 버튼 누를 시점의 콜백
 *          @param {function} options.callback.onSuccessSubmit  완료 응답 이후 콜백
 *          @param {function} options.callback.onFailSubmit 완료 실패 응답 이후 콜백
 */
function init(options) {
    var params = options.params,
        mapOptions = ne.util.extend({excludeNotAvailableSeat: true}, options.mapOptions),
        callback = options.callback || {};

    IB = new UserIB();

    IB.set('productId', params.productId);
    IB.set('productDate', params.productDate);
    IB.set('sellingTypeCode', params.sellingTypeCode);
    IB.set('scheduleId', params.scheduleId);
    IB.set('reserveMemberNo', params.reserveMemberNo);
    IB.set('loginMemberNo', params.loginMemberNo);
    IB.set('preoccupancyMemberNo', params.preoccupancyMemberNo);
    IB.set('mapOptions', mapOptions);
    IB.set('useZoomButtonControl', true);

    IB.set('maxTicketCount', 10);       //예매당 구매 매수
    IB.set('hasMaxCountLimit', true);   //티켓 구매개수 제한 체크 여부
    IB.set('isFront', true);            //사용자 예매 인지 여부
    IB.set('isSkipRequestPreoccupancy', true);  //선점조회 API 스킵여부

    var controller = new SelectSeat({
        params: params,
        mapOptions: mapOptions,
        IB: IB
    });

    //public 으로 제공할 인터페이스 콜백을 바인딩한다.
    ne.util.forEach(callback, function(fn, name) {
        controller.on(name, fn);
    });
}

/**
 * 페이지 unload 시 alert 여부를 결정한다.
 * @param {boolean} isUseUnloadCheck alert 여부
 */
function useUnloadCheck(isUseUnloadCheck) {
    isUseUnloadCheck = ne.util.isUndefined(isUseUnloadCheck) ? true : isUseUnloadCheck;
    if (isUseUnloadCheck) {
        IB.enableUnloadCheck();
    } else {
        IB.disableUnloadCheck();
    }
}

/**
 * 페이지를 reload 한다.
 */
function reload() {
    IB.reload();
}

global.ne.tkl.main = {
    init: init,
    useUnloadCheck: useUnloadCheck,
    reload: reload
};

