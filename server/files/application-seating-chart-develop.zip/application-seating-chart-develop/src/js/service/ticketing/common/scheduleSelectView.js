/**
 * @fileoverview ScheduleSelectView
 * @author FE개발팀 김성호 sungho-kim@nhnent.com
 *
 * 회차 선택
 * - 사용자 예매(상품) 상세 페이지
 */

'use strict';

var tkl = ne.tkl,
    UIController = tkl.UIController,
    UIModel = require('../../../ui/model'),
    UICollection = require('../../../ui/collection');

/**
 * ScheduleModel
 * 회차 정보를 갖고있는 모델
 * @exports ScheduleModel
 * @extends {UIModel}
 * @constructor
 * @class
 **/
var ScheduleModel = UIModel.extend(/** @lends UIModel.prototype */{
    init: function(data, options) {
        UIModel.call(this, data, options || {
            parse: true
        });
    },
    defaults: {
        logicalPlanId: null,
        scheduleId: null,
        productRound: null,
        time: null,
        isAvailable: null
    },

    /**
     * 데이터를 파싱해 모델에 맞게 가공한다
     * @param {object} data 가공할 데이터
     * @returns {object}
     */
    parse: function(data) {
        var date = new Date(data.startDatetime),
            parsedData = {},
            hour,
            min;
        parsedData.scheduleId = data.scheduleId;
        parsedData.logicalPlanId = data.logicalPlanId;
        parsedData.productRound = data.productRound;
        parsedData.productDate = date.getFullYear() + '.' + (date.getMonth() + 1) + '.' + date.getDate();
        hour = date.getHours();
        min = date.getMinutes();
        parsedData.time = (hour < 10 ? '0' + hour : hour) + '시 ' + (min < 10 ? '0' + min : min) + '분';
        return parsedData;
    }
});

/**
 * Schedules
 * @exports Schedules
 * @extends {UICollection}
 * @constructor
 * @class
 **/
var Schedules = UICollection.extend(/** @lends UICollection.prototype */{
    model: ScheduleModel,
    init: function(models) {
        UICollection.call(this, models);
    }
});

/**
 * ScheduleSelectView
 * @exports ScheduleSelectView
 * @extends {UIController}
 * @constructor
 * @class
 * **/
var ScheduleSelectView = UIController.extend(/** @lends UIController.prototype */{
    rootElement:$('#roundSelect'),
    events: {
        'click .select': '_onSelectClick',
        'click li': '_onItemClick'
    },
    tmpl: '<li><a href="#"><%=time%></a></li>',
    init: function ScheduleSelectView(options) {
        var self = this,
            EVENT;
        UIController.call(this, options);
        EVENT = this.IB.EVENT;
        this.collection = new Schedules();
        this.$selectList = this.$el.find('.select_list');
        this.$selectButton = this.$el.find('.select');
        this.collection.on('set', function() {
            self.render();
        });
        this.listen(EVENT.ROUND_LOADED, function(data) {
            self.setData(data);
        });
        if (ne.util.isTruthy(options.initialRound)) {
            this.setInitialRound(options.initialRound);
        }
        else {
            this.setEmptySelect();
        }
    },

    /**
     * 회차정보를 전달한다
     * @param {Object} data 회차 정보
     */
    setData: function(data) {
        this.collection.set(data);
    },

    /**
     * 뷰를 그린다
     */
    render: function() {
        this.detachEvents();
        this.remove();
        this.renderDefaultItem();
        this.renderItemsIfNeed();
        this.setInitSelectItemIfNeed();
        this.attachEvents();
    },

    /**
     * 디폴트 아이템을 그린다.
     */
    renderDefaultItem: function() {
        var defaultModel,
            defaultli;
        defaultModel = new ScheduleModel({
            time : this.IB.get('MSGS').EMPTYROUND
        }, {parse: false});
        defaultli = $(this.template(this.tmpl, defaultModel.toJSON())[0]);
        defaultli.data('model', defaultModel);
        this.$selectList.append(defaultli);
    },

    /**
     * 회차를 표현하는 목록 그린다
     */
    renderItemsIfNeed: function() {
        var self = this;
        if (this.collection.length > 0) {
            this.collection.forEach(function(model) {
                var container;
                container = $(self.template(self.tmpl, model.toJSON())[0]);
                container.data('model', model);
                self.$selectList.append(container);
            });
            $('body').on(this.getEventNameWithNamespace('click'), function() {
                self.closeSelectList();
            });
        }
    },

    /**
     * 실렉트버튼 이벤트 핸들러
     * 회차리스트 레이어를 토글한다
     * @param {jQuery.Event} e jquery 이벤트
     * @private
     */
    _onSelectClick: function(e) {
        e.preventDefault();
        e.stopPropagation();
        if (this.$selectList.attr('style')) {
            this.closeSelectList();
        } else {
            this.openSelectList();
        }
    },

    /**
     * 회차 클릭시 이벤트 핸들러
     * @param {jQuery.Event} e jquery 이벤트
     * @private
     */
    _onItemClick: function(e) {
        e.preventDefault();
        e.stopPropagation();
        if (this.isSelectible(e.currentTarget)) {
            this.setSelectedItem(e.currentTarget);
        }
        this.closeSelectList();
    },

    /**
     * 선택된 회차를 디폴트 메세지로 셋팅한다
     */
    setEmptySelect: function() {
        this.$selectButton.html(this.IB.get('MSGS').EMPTYROUND);
    },

    /**
     * 선택된 엘리먼트가 유효한 엘리먼트인지 판단한다
     * @param {HTMLElment} target 선택된 엘리먼트
     * @returns {boolean}
     */
    isSelectible: function(target) {
        var selectedModel = $(target).data('model');
        return !this.selectedItem || (this.selectedItem.data('model') !== selectedModel);
    },

    /**
     * 회차리스트 레이어를 연다
     */
    openSelectList: function() {
        this.$selectList.css('display', 'block');
    },

    /**
     * 회차리스트 레이어를 닫는다
     */
    closeSelectList: function() {
        this.$selectList.removeAttr('style');
    },

    /**
     * 화치를 선택한다
     * @param {HTMLElement} target 선택된 엘리먼트
     */
    setSelectedItem: function(target) {
        var model = $(target).data('model'),
            EVENT = this.IB.EVENT,
            jsonData;
        this.$selectButton.html(model.get('time'));
        this.selectedItem = $(target);
        jsonData = this.toJSON();
        if(jsonData){
            this.emit(EVENT.ROUND_SELECTED, jsonData);
        } else {
            this.emit(EVENT.ROUND_UNSELECTED);
        }
    },

    /**
     * 렌더링할때 디폴트로 선택할 회차의 번호를 입력한다
     * @param {number} number 회차의 번호
     */
    setInitialRound: function(number) {
        this.initialRound = number;
    },

    /**
     * 렌더링시 회차를 선택한다
     */
    setInitSelectItemIfNeed: function() {
        var itemToSelect,
            childs = this.$el.find('ul').children();
        itemToSelect = childs[this.initialRound || 0];
        this.setSelectedItem(itemToSelect);
    },

    /**
     * 선택된 회차를 해제한다
      */
    clearSelectedItem: function() {
        this.selectedItem = null;
    },

    /**
     * 뷰를 지운다
     */
    remove: function() {
        $('body').off(this.getEventNameWithNamespace('click'));
        this.detachEvents();
        this.closeSelectList();
        this.$selectList.empty();
        this.$selectButton.empty();
        this.clearSelectedItem();
    },

    /**
     * UI가 나타내는 값을 JSON으로 리턴한다.
     * @returns {ScheduleModel}
     */
    toJSON: function() {
        return this.selectedItem && this.selectedItem.data('model').get('productRound') && this.selectedItem.data('model').toJSON();
    }
});

module.exports = ScheduleSelectView;
