/**
 * @fileoverview
 * @author FE개발팀 박순영 <soonyong.park@nhnent.com>
 */

var UIModel = require('./ui/model');

/**
 * 제한 없는 세마포어 추가
 * @type {*}
 */
var Semaphore = UIModel.extend({
    init: function(data) {
        UIModel.call(this, data, {
            parse: true
        });
    },
    defaults: {
        count: 0
    },

    /**
     * 세마포어를 획득한다.
     * 카운트가 1이 될 경우 lock 이벤트가 발생한다.
     */
    acquire: function() {
        var count = this.get('count') + 1,
            args = ne.util.toArray(arguments);
        this.set('count', count);
        if (count === 1) {
            args.unshift('lock');
            this.fire.apply(this, args);
        }
    },

    /**
     * 세마포어를 릴리즈한다.
     * 카운트가 0이 될 경우 unlock 이벤트가 발생한다.
     */
    release: function() {
        var count = this.get('count') - 1;
        if (count >= 0) {
            this.set('count', count);
            if (count === 0) {
                this.fire('unlock');
            }
        }
    },

    /**
     * 세마포어 카운트를 초기화한다.
     */
    reset: function() {
        var count = this.get('count');
        this.set('count', 0);
        if (count > 0) {
            this.fire('unlock');
        }
    }
});

module.exports = Semaphore;
