/**
 * @fileoverview 좌석배치도
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var etc = require('./etc'),
    Settings = require('./settings'),
    FnKeys = require('./fnKeys'),
    GridController = require('./controller/gridController'),
    NSeatController = require('./controller/nSeatController'),
    SelectSeatController = require('./controller/selectSeatController'),
    AreaController = require('./controller/areaController'),
    InteractBroker = require('./interactBroker');

var common = ne.util,
    simplemap = ne.component.SimpleMap,
    tUtil = simplemap.util;

var RENDER_DELAY = 400;

/**
 * 사각 좌표를 제공된 인자로 나눈다
 * @param number
 * @returns {simplemap.Rect}
 */
simplemap.Rect.prototype.divideBy = function (number) {
    this.min._divideBy(number);
    this.max._divideBy(number);

    return this;
};

/**
 * 좌석배치도 클래스
 * @param {HTMLElement} el
 * @param {Object} options
 *   @param {!number} options.venueID 물리도면 논리도면에 따라 다른 기본 도면 ID
 *   @param {!number[]} options.center 최초 로드 시 드로잉 영역의 중싱점 위치
 *   @param {number} [options.seatSize=10] 기본 좌석 크기
 *   @param {!number} [options.mapSize=9008] 도면의 최대 크기
 *   @param {!number} [options.zoomLevelInMapSize=4] 도면의 최대 크기가 몇 레벨 기준인지를 나타내는 옵션 ex) 9008은 4레벨 기준임 -> "4"
 *   @param {number} [options.minZoom=3] 최소로 축소할 수 있는 줌 레벨
 *   @param {number} [options.maxZoom=7] 최대로 확대할 수 있는 줌 레벨
 *   @param {number} [options.zoom=3] 최초 로드 시 드로잉 영역의 줌 레벨
 *   @param {boolean} [options.usePanningLimit=true] true시 도면의 최대 크기 바깥으로 드로잉 영역을 패닝할 수 없도록 함
 *   @param {!number} [options.modifyMemberNo]
 *   @param {boolean} [options.useGridCache=false] 지정석 그리드 데이터 캐쉬 사용 여부 (예매파트에서 사용)
 *   @param {string[]} [options.mapDataCode] 매핑정보 단위의 이름 배열 ex) ['층', '블럭', '열', '번호'] (반드시 어드민에서 정의한 순서대로여야 함)
 *   @param {string[]} [options.mapUnitCode] 각 매핑정보의 단위정보 ex) ['GENERAL', 'GENERAL', 'ROW', 'NUMBER'] (매핑정보 단위 순서와 매칭됨)
 *   @param {!Array} [options.sellingTypeCode] 판매 할당처 코드 관련 정보
 *   @param {!Array} [options.gradeCode] 판매등급 코드 및 등급별 색상 정보
 *   @param {number} [options.seatCount] 전체 좌석 수
 *   @param {!object} options.tile 도면 배경의 타일 관련 정보
 *     @param {number} options.tile.tileSize 타일의 크기
 *     @param {!string} options.tile.url 타일 이미지 주소
 *     @param {number[]} options.tile.zoomRange 타일 이미지가 제공되는 줌 레벨 범위 (이 범위가 minZoom, maxZoom과 다를 경우 타일을 강제로 확대/축소하여 사용한다)
 *     @param {!string} options.tile.emptyImageUrl 타일 이미지가 없을 때 (404) 대체되어 제공되는 이미지 url (!필수! EmptyString일 경우 IE에서 브라우저가 멈추는 문제가 발생한다)
 *     @param {object[]} options.tile.altTiles 특정 줌 레벨에서 대체하여 보여줄 타일 정보
 *       @param {number[]} options.tile.altTiles.zoomRange 이 대체 타일이 노출될 줌 레벨 범위
 *       @param {string} options.tile.altTiles.url 대체 타일의 url
 *   @param {!object} options.navigator 네비게이터 관련 정보
 *     @param {string} options.navigator.utl 네비게이터 배경 이미지 url
 *     @param {number} options.navigator.imageSize 네비게이터 이미지 크기
 *     @param {object[]} options.navigator.altImage 특정 줌 레벨에서 대체하여 보여줄 네비게이터 이미지 정보
 *       @param {number[]} options.navigator.zoomRange 이 대체 이미지가 노출될 줌 레벨 범위
 *       @param {string} options.navigator.utl 대체 이미지의 url
 * @constructor
 * @extends Map
 * @exports SeatingChartMap
 * @class
 * @mixes {CustomEvents}
 */
function SeatingChart(el, options) {
    var gridsExistSeat = {};

    options = tUtil.setOptions(this, {
        venueID: 0,
        center: [2048, 2048],
        seatSize: 10,
        mapSize: 4096,
        zoomLevelInMapSize: 4,
        minZoom: 1,
        maxZoom: 8,
        zoom: 1,
        usePanningLimit: false,
        modifyMemberNo: 9999,
        useGridCache: false,
        useLoadRSeatVertical: true,   // 지정석로딩을 더 큰 단위로 할 것인지 여부 설정
        excludeNotAvailableSeat: false,    // true시 선택불가좌석(soldout, disabled)을 렌더링하지 않음
        tile: {
            tileSize: 256,
            url: 'http://119.205.251.218/resources/tiles/lefttop/stadium/tile_{level}_{x}_{y}.png',
            zoomRange: [1, 4],
            emptyImageUrl: '',
            altTiles: [{
                zoomRange: [0, 1],
                url: 'http://119.205.251.218/resources/tiles/lefttop/alt/tile_{level}_{x}_{y}.png'
            }]
        },
        navigator: {
            url: 'http://119.205.251.218/resources/images/ticketlink/navigator_image/stadium_navigator.png',
            imageSize: 160,
            altImage: [{
                zoomRange: [0, 1],
                url: 'http://119.205.251.218/resources/images/ticketlink/navigator_image/stadium_navigator.png'
            }]
        },
        toggleBrush: {}
    }, options);

    if (this.useArea) {
        options.zoom = options.minZoom;
    }

    /*
     설정 값 전달
     */
    if (common.isExisty(ne.tkl.data.gridsExistSeat)) {
        common.forEachArray(ne.tkl.data.gridsExistSeat, function (index) {
            gridsExistSeat[index + ''] = true;
        });
        Settings.setGridsExistSeat(gridsExistSeat);
    }
    Settings.setExcludeNotAvailableSeat(options.excludeNotAvailableSeat);
    Settings.setUseLoadRSeatVertical(options.useLoadRSeatVertical);
    Settings.setUseGridCache(options.useGridCache);
    Settings.setSeatSize(options.seatSize);
    Settings.setMapInfoCode(options.mapDataCode, options.mapUnitCode);
    Settings.MODIFY_MEMBER_NO = options.modifyMemberNo || 9999;


    simplemap.Map.call(this, el, options);

    this._setContaierCSSClass();

    this.addHandler(new simplemap.PanHandler());
    this.addHandler(new simplemap.ZoomHandler());

    /**
    * 영역 렌더링 여부
    * @type {boolean}
    */
    this.isAreaRender = false;

    /**
     * @type {GridController}
     */
    this.gridController = null;

    /**
     * @type {NSeatController}
     */
    this.nSeatController = null;

    /**
     * @type {AreaController}
     */
    this.areaController = null;

    /**
     * @type {SelectSeatController}
     */
    this.selectSeatController = null;

    /**
     * 드로잉 영역 지정석 렌더링 함수 감속을 위한 타이머
     * @type {number}
     */
    this.renderTimerID = 0;

    this.zoomRenderTimerID = 0;

    /**
     * @type {FnKeys}
     */
    this.fnKeys = new FnKeys(this.getContainer());
    this.fnKeys.on('shortcut', this._onDefaultShortCut, this);

    this._setDefaultEvents();
}

// 상속
common.inherit(SeatingChart, simplemap.Map);
// 믹스인
common.CustomEvents.mixin(SeatingChart);

/**********
 * static props
 **********/

/**
 * 좌석 타입
 * @readonly
 * @enum {number}
 */
SeatingChart.SEAT_TYPE = {
    'RESERVED': 1,
    'NONRESERVED': 2
};

/**********
 * private methods
 **********/

/**
 * 드로잉 영역이 사용하는 기본 이벤트 바인딩
 * @private
 */
SeatingChart.prototype._setDefaultEvents = function () {
    var container = this.getContainer();

    simplemap.domevent.on(container, {
        'mouseenter': function(e) {
            this.fire('containerMouseenter', e);
        },
        'mouseleave': function(e) {
            this.fire('containerMouseleave', e);
        }
    }, this);
};

/**
 * 단축키를 눌렀을 때 동작하는 이벤트 핸들러
 * @param {number} code 키 코드
 * @param {string} str 키 코드명
 * @private
 */
SeatingChart.prototype._onDefaultShortCut = function(code, str) {
    if (this.disabled) {
        return;
    }

    switch (str) {
        case 'F':
            this.reset(true);
            break;
        case 'EQUAL':
            this.zoomIn();
            break;
        case 'MINUS':
            this.zoomOut();
            break;
        case 'ESC':
            this.deselectAllSeats(true);
            break;
    }
};

/**
 * 브라우저 계열에 따라 크로스 브라우징 처리를 위한 클래스를 할당한다
 * @private
 */
SeatingChart.prototype._setContaierCSSClass = function() {
    var cssClass = '';
    if (common.browser.msie) {
        cssClass = 'seatingchart-browser-msie seatingchart-browser-' + common.browser.version;
    } else if (common.browser.chrome) {
        cssClass = 'seatingchart-browser-chrome';
    } else {
        cssClass = 'seatingchart-browser-others';
    }
    simplemap.domutil.addClass(this._container, cssClass);
};

/**
 * 기본도면에서 사용할 IB를 만드는 메서드
 */
SeatingChart.prototype._setIB = function() {
    this.IB = new InteractBroker();
};

/**
 * 기본도면의 IB 이벤트 핸들러
 */
SeatingChart.prototype._setIBEvents = function() {
    var IB = this.IB;

    IB.listen(InteractBroker.EVENT.LOAD_RSEAT_COMPLETED, this._loadRSeatCompleted, this);
    IB.listen(InteractBroker.EVENT.SELECT_RSEAT_COMPLETED, this._selectRSeatCompleted, this);

    IB.listen(InteractBroker.EVENT.ENABLE_CHART, function() { this.disabled = false; }, this);
    IB.listen(InteractBroker.EVENT.DISABLE_CHART, function() { this.disabled = true; }, this);
    IB.listen(InteractBroker.EVENT.MAP_SELECTED_SEAT, this._onSeatSelected, this);

    IB.listen(InteractBroker.EVENT.MAP_WORK_DESELECT_ALL_SEAT, function(immediate) { this.deselectAllSeats(immediate); }, this);

    IB.listen(InteractBroker.EVENT.ZOOM_IN, this.zoomIn, this);
    IB.listen(InteractBroker.EVENT.ZOOM_OUT, this.zoomOut, this);
    IB.listen(InteractBroker.EVENT.ZOOM_RESET, function() { this.reset(true); }, this);

    IB.listen(InteractBroker.EVENT.SELECT_NSEAT, function(sidList) {
        var extractor = this.searchSeats(sidList, false, SeatingChart.SEAT_TYPE.NONRESERVED),
            nseatBound = common.pick(extractor, 'n', '0', 'bound');

        if (!nseatBound) {
            return;
        }

        this.setZoom(this.options.zoomLevelInMapSize, nseatBound.getCenter());
        
        IB.emit(InteractBroker.EVENT.MAP_SELECT_SEAT, extractor);
    }, this);
};

/**********
 * public methods
 **********/

/**
 * 사용자의 마우스, 컨트롤을 이용한 패닝과 줌을 막는다
 */
SeatingChart.prototype.disablePanAndZoom = function() {
    this.disablePanning();
    this.disableZoom();
};

/**
 * 마우스, 컨트롤을 이용한 패닝과 줌을 허용한다
 */
SeatingChart.prototype.enablePanAndZoom = function() {
    this.enablePanning();
    this.enableZoom();
};

/**
 * 좌석 컨트롤러 초기화 메서드
 */
SeatingChart.prototype.setController = function() {
    var paper = this.paper,
        defaultOption = {
            paper: paper,
            zoomLevel: this.getZoom(),
            chart : this
        };

    this.gridController = new GridController(defaultOption);
    this.nSeatController = new NSeatController(defaultOption);
    this.selectSeatController = new SelectSeatController(defaultOption);

    if (common.isExisty(ne.tkl.data.nseats)) {
        // 비지정석 존재 시 렌더링
        this.nSeatController.setData(ne.tkl.data.nseats);
        this.nSeatController.update();
    }

    if (this.useArea) {
        this.areaController = new AreaController(defaultOption);
        this.areaController.setData(ne.tkl.data.areaData);
        this.areaController.update(true);
    }
};

/**
 * 내부적으로 필요한 모듈 간 이벤트 관계를 설정하는 메서드
 */
SeatingChart.prototype.setEvents = function() {
    this.on('beforeSelect', this._onBeforeSelect, this);
    this.on('beforeSelectSeat', this._deselectSeatsIfNeed, this);
    this.on('selectSeat', this.onSelectSeats, this);
    this.on('afterZoom', this._onAfterZoom, this);
    this.on('move', this.render, this);
    this.on('moveend', this.render, this);
};

/**
 * 좌석 타입별 좌석 배열 반환
 * @param {(string|string[]|number[])} range 좌석 SID 리스트 또는 단일 x, y좌표 또는  x1, y1, x2, y2좌표
 * @param {SeatLayerController} ctrl
 * @param {(SEAT_TYPE|number)} seatType 좌석 타입
 * @param {boolean} [includeDisabled]
 * @returns {*}
 */
SeatingChart.prototype.getSeats = function(range, ctrl, seatType, includeDisabled) {
    var selectCtrl = this.selectSeatController,
        isArr = common.isArray,
        targetRange = range.slice(0),
        rangeIsCoordinate = isArr(targetRange) && targetRange.length && common.isNumber(targetRange[0]),
        rangeLength,
        seats,
        method;

    if (rangeIsCoordinate) {
        rangeLength = targetRange.length;
        if (rangeLength === 2) {
            method = 'getSeatsContainPoint';
        } else if (rangeLength === 4) {
            method = 'getSeatsInsideRect';
        }
    } else {
        method = 'getSeats';
        targetRange = [targetRange];
    }

    seats = ctrl[method].apply(ctrl, targetRange.concat([includeDisabled]));
    seats = seats.concat(selectCtrl[method].apply(selectCtrl, targetRange.concat([seatType])));

    return seats;
};

/**
 * 지정석, 비지정석 컨트롤러로부터 좌석 배열을 구분지어 반환하는 데이터 구조
 *
 * extract 메서드를 사용하면 좌석배열들을 각 컨트롤러로부터 뽑아낸다
 *
 * seats 데이터를 조작한 후 refresh를 호출하면 r, n이 갱신된다.
 *
 * @typedef {object} Extractor
 * @property {HashMap} seats 찾아낸 좌석 전체의 HashMap
 * @property {RSeat[]} r 지정석 인스턴스 배열
 * @property {NSeat[]} n 비지정석 인스턴스 배열
 * @property {function()} refresh seats를 기준으로 Extractor 자신의 데이터를 갱신하는 메서드
 * @property {function()} getSID Extractor 내 좌석들의 SID만 뽑아냄
 * @property {function()} extract Extractor 내 좌석들을 원래 컨트롤러에게서 뽑아냄
 */

/**
 * 좌석 드로잉 툴 내 만들어진 좌석을 찾는 메서드
 * @param {(string|string[]|number[])} range 좌석 SID 리스트 또는 단일 x, y좌표 또는  x1, y1, x2, y2좌표
 * @param {boolean} [clone=true] 검색된 좌석 반환 시 복제하여 반환 여부
 * @param {(SEAT_TYPE|number)} [seatType] 좌석 타입 (제공시 탐색속도 증가)
 * @param {boolean} [includeDisabled] 비활성화 지정석도 조회
 * @return {Extractor}
 */
SeatingChart.prototype.searchSeats = function(range, clone, seatType, includeDisabled) {
    var gridCtrl = this.gridController,
        nSeatCtrl = this.nSeatController,
        r = [],
        n = [];

    if (seatType) {
        if (seatType === SeatingChart.SEAT_TYPE.RESERVED) {
            r = this.getSeats(range, gridCtrl, SeatingChart.SEAT_TYPE.RESERVED, includeDisabled);
        } else {
            n = this.getSeats(range, nSeatCtrl, SeatingChart.SEAT_TYPE.NONRESERVED, includeDisabled);
        }
    } else {
        r = this.getSeats(range, gridCtrl, SeatingChart.SEAT_TYPE.RESERVED, includeDisabled);
        n = this.getSeats(range, nSeatCtrl, SeatingChart.SEAT_TYPE.NONRESERVED, includeDisabled);
    }

    if (clone) {
        r = common.map(r, function(seat) { return seat.clone(); });
        n = common.map(n, function(seat) { return seat.clone(); });
    }

    var hash = new common.HashMap();
    common.forEachArray(r.concat(n), function(seat) {
        hash.set(seat.sid, seat);
    });

    var extractor = {
        seats: hash,
        r: r,
        n: n,
        refresh: function() {
            extractor.r = [];
            extractor.n = [];
            extractor.seats.each(function(seat) {
                if (seat.name === 'RSeat') {
                    extractor.r.push(seat);
                } else {
                    extractor.n.push(seat);
                }
            });
        },
        getSID: function() {
            var seats = extractor.r.concat(extractor.n);
            return common.map(seats, function(seat) {
                return seat.sid;
            });
        },
        extract: common.bind(function() {
            gridCtrl.removeSeat(extractor.r);
            nSeatCtrl.removeSeat(extractor.n);
        }, this)
    };

    return extractor;
};

/**
 * 현재 화면상에 보이는 지정석 grid와 나머지 컨트롤러를 업데이트한다
 */
SeatingChart.prototype.updateViewport = function() {
    var selectCtrl = this.selectSeatController;

    this.nSeatController.update(true);
    selectCtrl.update();
};

/**
 * 지정석 비지정석을 구분 및 순회하며 함수를 호출
 * @param {Seat[]} seats
 * @param {function(Seat, boolean)} func
 */
SeatingChart.prototype.divideSeat = function(seats, func) {
    common.forEachArray(seats, function(seat) {
        func(seat, seat.name === 'RSeat');
    });
};

/**
 * 좌석을 지정석/비지정석 구분 객체로 반환
 * @param {Seat[]} seats
 * @returns {{r: RSeat[], n: NSeat[]}}
 */
SeatingChart.prototype.splitSeatRN = function(seats) {
    var r = [],
        n = [];

    this.divideSeat(seats, function(seat, isRSeat) {
        if (isRSeat) {
            r.push(seat);
        } else {
            n.push(seat);
        }
    });

    return {
        r: r,
        n: n
    };
};

/**
 * 지정석/비지정석을 원래 컨트롤러에게 돌려줌
 * @param {Seat[]} seats
 */
SeatingChart.prototype.giveBack = function(seats) {
    var gridCtrl = this.gridController,
        nSeatCtrl = this.nSeatController;

    if (!seats.length) {
        return;
    }

    this.divideSeat(seats, function(seat, isRSeat) {
        if (isRSeat) {
            gridCtrl.addSeat(seat);
        } else {
            nSeatCtrl.addSeat(seat);
        }
    });
};

/**
 * 선택 컨트롤러에서 원래 컨트롤러들에게 좌석을 돌려줌
 * @param {(string[]|Seat[])} [sid]
 * @param {boolean} [renderImmediate=false]
 */
SeatingChart.prototype.deselectSeats = function(sid, renderImmediate) {
    var selectCtrl = this.selectSeatController,
        seats;

    if (common.isArray(sid) && sid.length) {
        seats = sid;
    } else {
        seats = selectCtrl.getSeats(sid);
    }

    selectCtrl.removeSeat(seats);
    selectCtrl.updateSeatBound();

    this.giveBack(seats);

    if (renderImmediate) {
        this.updateViewport();
        this.gridController.refreshGridsInViewport();
    }
};

/**
 * 선택되었던 좌석들을 다시 원래 컨트롤러에게 돌려주는 메서드
 * @param {boolean} [renderImmediate=false] 선택 해제 직후 각 컨트롤을 업데이트한다
 */
SeatingChart.prototype.deselectAllSeats = function(renderImmediate) {
    if (this.invoke('beforeDeselectAllSeats')) {
        this.deselectSeats(null, renderImmediate);
        this.IB.emit(InteractBroker.EVENT.MAP_DESELECT_ALL_SEAT);
    }
};

/**
 * 인자로 넘긴 sid의 좌석들을 선택 해제
 * @param {string[]} sid
 * @param {boolean} [renderImmediate=false]
 */
SeatingChart.prototype.deselectSeatsByIds = function(sid, renderImmediate) {
    var selectCtrl = this.selectSeatController,
        seats = selectCtrl.getSeats(sid);

    if (!seats.length) {
        return;
    }

    this.deselectSeats(seats, renderImmediate);
    this.IB.emit(InteractBroker.EVENT.MAP_DESELECT_SEAT, this.splitSeatRN(seats));
};

/**
 * 좌표를 받아 해당 좌표에 있는 좌석의 정보를 메시징한다
 * @param {number} x
 * @param {number} y
 */
SeatingChart.prototype.seatInfo = function(x, y) {
    var extractor,
        seats;

    if (this.useArea && this.isAreaRender) {
        seats = this.areaController.getSeatsContainPoint(x, y);
    } else {
        extractor = this.searchSeats([x, y], false, null, true);
        seats = extractor.r.concat(extractor.n).sort(etc.sort.desc('sid'));
    }

    if (!seats.length) {
        return;
    }

    if (this.invoke('beforeSeatInfo', seats)) {
        this.fire('seatInfo', seats);
    }
};

/**
 * 영역 모델을 받아 그 영역의 중심점으로 확대하며 이동
 * @param {Area} area
 */
SeatingChart.prototype.zoomInArea = function(area) {
    this.setZoom(this.options.zoomLevelInMapSize, simplemap.Point.n(area.center));
};

/**
 * 좌석정보 툴팁 사용여부를 토글
 * @param {boolean} toDisable
 */
SeatingChart.prototype.toggleSeatInfoTooltip = function(toDisable) {
    var ctrl = this.getControl('seat-info-tooltip');

    if (toDisable) {
        ctrl.disable();
    } else {
        ctrl.disabled = false;
    }
};

/**
 * 영역 렌더링 관련 프로퍼티를 재설정한다
 */
SeatingChart.prototype.refreshArea = function() {
    var zoom,
        areaRange;

    if (this.useArea) {
        zoom = this.getZoom();
        areaRange = this.areaRange;

        this.isAreaRender = (areaRange[0] <= zoom && zoom <= areaRange[1]);
    }
};

/**
 * 좌석의 좌표 데이터 모델을 배열로 변환
 * @param {(Point|Rect)} unit
 * @return {number[]}
 */
SeatingChart.prototype.unitToArray = function(unit) {
    if (unit instanceof simplemap.Point) {
        return [unit.x, unit.y];
    } else {
        return [unit.min.x, unit.min.y, unit.max.x, unit.max.y];
    }
};

/**
 * 현재 보이는 영역을 렌더링한다
 */
SeatingChart.prototype.render = function() {
    var gridCtrl;

    this.refreshArea();

    if (this.isAreaRender) {
        return;
    }

    gridCtrl = this.gridController;

    window.clearTimeout(this.renderTimerID);
    this.renderTimerID = window.setTimeout(function() {
        gridCtrl.preloadGrids();
    }, RENDER_DELAY);
};

/**********
 * event handler
 **********/

/**
 * 좌석 선택 이벤트 핸들러
 * @param {Object} beforeSelectEvent
 * @private
 */
SeatingChart.prototype._onBeforeSelect = function(beforeSelectEvent) {
    var range = beforeSelectEvent.range,
        isMultipleSelect = range instanceof simplemap.Rect,
        areaCtrl,
        area;

    if (this.disabled) {
        return;
    }

    if (this.useArea && this.isAreaRender) {
        if (beforeSelectEvent.selectType === 'single') {
            areaCtrl = this.areaController;
            area = areaCtrl.requestAreaContainPoint(range.x, range.y);
            if (area.length) {
                this.zoomInArea(area[0]);
                this.gridController.updateGridsInViewport();
            }
        }

        return;
    }

    var eventData = this.searchSeats.call(this, this.unitToArray(range));
    common.extend(eventData, {
        range: range,
        shiftKey: beforeSelectEvent.shiftKey
    });

    if (!isMultipleSelect) {
        // 지정석 단일선택 시 겹친 좌석이 있을경우 sid가 높은 좌석만 선택되도록 한다
        eventData.r = eventData.r.sort(etc.sort.desc('sid')).splice(0, 1);
    }

    if (this.invoke('beforeSelectSeat', eventData)) {
        this.fire('selectSeat', eventData, beforeSelectEvent);
    }
};

/**
 * 선택좌석 처리
 * 각 도면에 맟게 오버라이딩 되어야 함
 * @virtual
 */
SeatingChart.prototype.onSelectSeats = function(e) {
    this.IB.emit(InteractBroker.EVENT.MAP_SELECT_SEAT, e);
};

/**
 * 드로잉 영역을 확대 또는 축소 시 발생하는 이벤트 핸들러
 * @param {object} e 확대/축소 커스텀 이벤트 객체
 * @private
 */
SeatingChart.prototype._onAfterZoom = function(e) {
    var self = this,
        newZoom = e.newZoom;

    self.gridController.ensureZoom(newZoom);
    self.selectSeatController.ensureZoom(newZoom);
    self.nSeatController.ensureZoom(newZoom);
    if (self.useArea) {
        self.refreshArea();
        self.areaController.ensureZoom(newZoom);
    }

    this.IB.emit(InteractBroker.EVENT.ZOOM, newZoom);

    window.clearTimeout(self.zoomRenderTimerID);
    self.zoomRenderTimerID = window.setTimeout(function() {
        self.render();
    }, RENDER_DELAY);
};

/**
 * 화면상의 모든 엘리먼트들은 4배율 기준의 크기로 그려지므로
 * 다른 배율에서 그릴 경우 이 메서드의 결과 값을 곱해주어야 한다
 * @returns {number}
 */
SeatingChart.prototype.getScaleRatio = function() {
    var zoom = this.getZoom(),
        diff = zoom - this.options.zoomLevelInMapSize;
    return Math.pow((diff < 0 ? 0.5 : 2), Math.abs(diff));
};

SeatingChart.prototype.addUIC = function(uic) {
    uic.setIB(this.IB);

    if (common.isFunction(uic.onSetIB)) {
        uic.onSetIB(this.IB);
    }
};

/**
 * 선택된 좌석 존재 여부 반환
 * @return {boolean}
 */
SeatingChart.prototype.hasSelectedSeat = function() {
    var selectCtrl = this.selectSeatController;

    return selectCtrl.seats.length > 0;
};

/**
 * 선택 좌석 리스트 반환
 * @returns {HashMap}
 */
SeatingChart.prototype.getSelectedSeat = function() {
    return this.selectSeatController.seats;
};

/**
 * 선택 좌석 존재 시 선택좌석들의 중심 좌표로 드로잉 영역을 움직인다
 */
SeatingChart.prototype.panToSelectCenter = function() {
    var selectCtrl = this.selectSeatController,
        scaleRatio = this.getScaleRatio(),
        groupBound = selectCtrl.groupBound;

    if (!common.isExisty(groupBound) || !groupBound.isValid()) {
        return;
    }

    this.panTo(groupBound.getCenter().multiplyBy(scaleRatio));
};

/**********
 * IB event handlers
 **********/

/**
 * 지정석 선택 API호출이 완료되었을 때 호출
 * @param {object} response 서버 API응답결과
 * @param {boolean} [panToCenter=false] 선택좌석의 중심으로 지정석을 움직일것인지 여부
 * @private
 */
SeatingChart.prototype._selectRSeatCompleted = function(response, panToCenter) {
    var seatCoords = common.pick(response, 'selectedSeats', 'seats', '0', 'position');

    if (!seatCoords) {
        return;
    }

    // 화면 이동 후 좌석이 렌더링 완료되었을 때 해당 좌석을 찾아 선택처리
    this.IB.once(InteractBroker.EVENT.RSEAT_RENDERED, function() {
        var sidList = common.map(response.selectedSeats.seats, function(seat) { return String(seat.sid); }),
            extractor = this.searchSeats(sidList);

        if (!extractor.seats.length) {
            return;
        }

        extractor.extract();

        this.IB.emit(InteractBroker.EVENT.MAP_SELECTED_SEAT, response, extractor);
    }, this);

    if (panToCenter) {
        this.setZoom(this.options.zoomLevelInMapSize, simplemap.Point.n(seatCoords));
    }
};

/**
 * gridID 리스트를 받아 서버에서 렌더링 정보를 요청한다
 * @param {string[]} gridIDListToRequest 요청하려는 그리드 id목록
 * @param {function} callback 요청 후 호출되는 콜백
 */
SeatingChart.prototype.loadRSeat = function(gridIDListToRequest, callback) {
    this.IB.emit(InteractBroker.EVENT.LOAD_RSEAT, gridIDListToRequest, callback);
};

/**
 * 지정석 렌더링 정보를 받아오고 난 후 처리
 * @param {object} grids grid 렌더링 정보
 * @param {object} soldoutMap 판매여부 정보
 * @param {string[]} requestedXIndexList 요청했던 grid의 Y index리스트
 * @param {string[]} gridIDList 요청했던 gridID 리스트
 * @private
 */
SeatingChart.prototype._loadRSeatCompleted = function(grids, soldoutMap, requestedXIndexList, gridIDList) {
    var gridCtrl = this.gridController,
        rendered = gridCtrl.rendered,
        fetched = gridCtrl.fetchedGridIDFromServer;

    // 지정석 데이터 초기화
    gridCtrl.setData(grids, soldoutMap);

    common.forEachArray(requestedXIndexList, function (xIndex) {
        // 서버에서 한번 받은 비지정석 그리드를 다시 요청하지 않기 위함
        fetched[xIndex] = true;
    });

    common.forEachArray(gridIDList, function(gridID) {
        gridCtrl.doWhenSeatLayerExist(gridID, function(sl) {
            rendered[gridID] = sl;
            // 서버로부터 받은 그리드는 바로 렌더링한다
            sl.update(true);
        });
    });
};

/**
 * 좌석이 선택 처리되었을 때 발생하는 이벤트 핸들러
 * @param {object} response
 * @param {Extractor} e
 * @private
 */
SeatingChart.prototype._onSeatSelected = function(response, e, slidListToUpdate) {
    var gridCtrl = this.gridController,
        nSeatCtrl = this.nSeatController,
        selectCtrl = this.selectSeatController;

    e.extract();

    if (slidListToUpdate) {
        common.forEachArray(slidListToUpdate, function(slid) {
            gridCtrl.doWhenSeatLayerExist(slid, function(sl) {
                sl.update(true);
            });
        });
    } else {
        gridCtrl.eachGridInViewport(function(grid) {
            grid.update(true);
        });
    }

    //gridCtrl.refreshGridsInViewport();
    nSeatCtrl.update(true);
    selectCtrl.addSeat(e.r.concat(e.n));
    selectCtrl.update();
};

/**
 * 선택좌석 존재 시 선택해제한다
 * @param {object} eventData
 * @private
 */
SeatingChart.prototype._deselectSeatsIfNeed = function(eventData) {
    var sidToDeselect,
        selectCtrl,
        seats = eventData.seats;

    if (this.hasSelectedSeat()) {
        // 좌석 선택할 때 이미 선택한 좌석을 다시 선택할때 처리
        sidToDeselect = [];
        selectCtrl = this.selectSeatController;
        selectCtrl.seats.each(function(seat) {
            var sid = seat.sid;
            if (seats.has(sid)) {
                seats.remove(sid);
                sidToDeselect.push(sid);
            }
        });

        if (sidToDeselect.length) {
            eventData.refresh();
            this.deselectSeatsByIds(sidToDeselect, true);
        }
    }
};

module.exports = SeatingChart;
