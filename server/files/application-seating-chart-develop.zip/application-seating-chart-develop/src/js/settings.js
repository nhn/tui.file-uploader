/**
 * @fileoverview 전역변수로 설정값을 저장하고 있는 모듈
 * @author FE개발팀 김민형 minhyeong.kim@nhnent.com
 */

'use strict';

var RSeat = require('./model/rSeat'),
    SeatBrush = require('./brush/seatBrush'),
    GradeBrush = require('./brush/gradeBrush'),
    NSeatBrush = require('./brush/nSeatBrush'),
    SellingTypeBrush = require('./brush/sellingTypeBrush'),
    SeatLayerController = require('./controller/seatLayerController'),
    SeatLayer = require('./layer/seatLayer'),
    NSeatLayer = require('./layer/nSeatLayer'),
    SelectNSeatLayer = require('./layer/selectNSeatLayer'),
    SeatDraggable = require('./seatDraggable'),
    SelectSeatLayer = require('./layer/selectSeatLayer'),
    GridController = require('./controller/gridController'),
    GridLayer = require('./layer/gridLayer');

var common = ne.util;

/**
 * @constructor
 */
function Settings() {}

/**********
 * public methods
 **********/

/**
 * 지정석 패스 캐시 사용 여부
 * @param {Boolean} onOff
 */
Settings.prototype.setUseRSeatPathCache = function(onOff) {
    SeatBrush.useRSeatPathCache = !!onOff;
};

/**
 * 좌석이 존재하는 그리드만 서버로부터 요청하도록 하는 필터 지정
 *
 * 물리, 논리도면에서는 수직 그리드 단위로 로드하므로 X index만 필요
 *
 * 그 외에서는 X:Y의 배열
 * @param {string[]} gridsExistSeat 좌석이 포함되어있는 그리드의 index
 */
/* istanbul ignore next */
Settings.prototype.setGridsExistSeat = function (gridsExistSeat) {
    GridController.gridsExistSeat = gridsExistSeat;
};

/**
 * 사용불가한(soldout, disabled)좌석을 렌더링할지 여부 설정
 * @param excludeNotAvailableSeat
 */
Settings.prototype.setExcludeNotAvailableSeat = function (excludeNotAvailableSeat) {
    NSeatLayer.excludeNotAvailableSeat = GridLayer.excludeNotAvailableSeat = !!excludeNotAvailableSeat;
};

/**
 * 지정석 분산로딩 시 세로 그리드 단위로 요청 여부 설정
 * @param {(boolean|undefined)} useLoadRSeatVertical true 시 세로 단위로 요청
 */
Settings.prototype.setUseLoadRSeatVertical = function (useLoadRSeatVertical) {
    GridController.useLoadRSeatVertical = !!useLoadRSeatVertical;
};

/**
 * 서버에서 지정석 좌석정보를 json string으로 내려줄 경우 처리를 다르게 하기 위한 설정
 * @param {boolean} useGridCache
 */
/* istanbul ignore next */
Settings.prototype.setUseGridCache = function(useGridCache) {
    if (useGridCache) {
        SeatLayerController.useGridCache = true;
    }
};

/**
 * 매핑정보 코드, 이름 설정 적용
 * @param {Array} mapInfoCode 서버에서 내려주는 매핑정보단위에 대한 이름들
 * @param {Array} mapUnitCode 서버에서 내려주는 매핑정보단위에 대한 단위정보들
 */
Settings.prototype.setMapInfoCode = function(mapInfoCode, mapUnitCode) {
    RSeat.MAP_CODE = mapInfoCode;
    RSeat.MAP_UNIT = mapUnitCode;
};

/**
 * 좌석 사이즈를 설정하는 메서드
 * @param {number} size
 */
/* istanbul ignore next */
Settings.prototype.setSeatSize = function(size) {
    RSeat.SEAT_SIZE = size || RSeat.SEAT_SIZE;
};

/**
 * 좌석등급에 대한 정보와 렌더링 스타일을 각 모듈에게 전달한다
 * @param {object} codeInfo
 * @example
 * Settings.setGradeCode({
 *     "408": [
 *         "대한석",
 *         "#1ED975"
 *     ],
 *     "409": [
 *         "민국석",
 *         "#0FC7FF"
 *     ],
 *     "410": [
 *         "만세석",
 *         "#FFBA19"
 *     ]
 * });
 */
Settings.prototype.setGradeCode = function(codeInfo) {
    var codes = common.keys(codeInfo),
        GradeBrushStyle = GradeBrush.STYLES,
        NSeatBrushStyle = NSeatBrush.STYLES;

    SelectNSeatLayer.GRADE_CODE =  SeatLayer.GRADE_CODE = NSeatLayer.GRADE_CODE = codes;
    SeatLayer.GRADE_INFO = codeInfo;

    common.forEachOwnProperties(codeInfo, function(data, code) {
        GradeBrushStyle[code] = {
            'fill': data[1],
            'stroke-width': 0,
            'cursor': 'pointer'
        };

        NSeatBrushStyle[code] = SelectNSeatLayer[code] = {
            'fill': '#FFFFFF',
            'fill-opacity': 0,
            'stroke': data[1],
            'stroke-width': 3,
            'cursor': 'pointer'
        };
    });
};

/**
 * 레이어에서 사용하는 브러시 코드를 설정하고,
 *
 * 브러시의 스타일을 설정하는 메서드
 * @param {object} code
 */
Settings.prototype.setSellingTypeCode = function(code) {
    SeatLayer.SELLING_TYPE_CODE = code;

    var styles = SellingTypeBrush.STYLES;
    common.forEachOwnProperties(code, function(label, code) {
        styles[code] = {
            'fill': 'none',
            'stroke': '#fff',
            'stroke-width': 1,
            'cursor': 'pointer'
        };
    });
};

/**
 * 좌석 드래그 모듈을 활성화한다
 *
 * 물리도면에서만 사용되어야 한다
 */
/* istanbul ignore next */
Settings.prototype.seatDraggable = function(map) {
    SelectSeatLayer.DRAGGABLE = new SeatDraggable(map, map.paper, map.selectSeatController);
};

/**
 * 도면의 기타 옵션을 설정
 */
/* istanbul ignore next */
Settings.prototype.setGlobalConfigure = function(options) {
    this.isClosedEvent = options.isClosedEvent;
    this.isReservationSystem = options.isReservationSystem;
    this.isSellerSystem = options.isSellerSystem;
};

/**
 * @type {Settings}
 */
var settings;

/* istanbul ignore else */
if (!settings) {
    settings = new Settings();
}

module.exports = settings;
