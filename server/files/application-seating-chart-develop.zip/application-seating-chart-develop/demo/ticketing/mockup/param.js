function getParams() {
    function parseUrl() {
        var params = {},
            token,
            queryString = location.search.substring(1),
            param = queryString.split('&') || [];
        for (var i = 0; i < param.length; i++) {
            token = param[i].split('=');
            if(token.length === 2){
                params[token[0]] = decodeURIComponent(token[1].replace(/\+/gi, '%20'));
            }
        }
        return params;
    }


    var params = parseUrl();
    var mapOptions = {
        venueID: 474,
        productID: 200,
        center: [4204, 804],
        seatSize: 10,
        mapSize: 9008,
        zoomLevelInMapSize: 4,
        minZoom: 3,
        maxZoom: 7,
        zoom: 4,
        usePanningLimit: true,
        mapDataCode: ['층', '블럭', '열', '번호'],
        mapUnitCode: ['GENERAL', 'GENERAL', 'ROW', 'NUMBER'],
        sellingTypeCode: {
            TKL: '티켓링크',
            FIELD: '현장',
            TICKET: '발권',
            POSTPONE: '보류',
            CALL: '콜센터',
            AGENCY: '기획사'
        },
        gradeCode: {
            156: ['A석', '#FAFA48'],
            157: ['S석', '#C7D4FF'],
            158: ['R석', '#FFE2C9']
        },
        tile: {
            tileSize: 563,
            url: 'http://alpha-photo.toast.com/aaaaan/tiles1/잠실종합운동장_지정_비지정_{level}_{x}_{y}.gif',
            zoomRange: [0, 4],
            altTiles: {
                url: 'http://alpha-photo.toast.com/aaaaan/tiles1/잠실종합운동장_영역_{level}_{x}_{y}.gif',
                zoomRange: [0, 2]
            }
        },
        navigator: {
            url: 'http://alpha-photo.toast.com/aaaaan/thumbo/잠실종합운동장_지정_비지정.gif?160x160',
            imageSize: 160,
            altImage: {
                zoomRange: [0, 2],
                url: 'http://alpha-photo.toast.com/aaaaan/thumbo/잠실종합운동장_영역.gif?160x160'
            }
        },
        areaData: [
            {
                points: [[3618, 4112], [4146, 4174], [4100, 4550], [3572, 4486]],
                center: [3856, 4324],
                data: '2F-55'
            }, {
                points: [[4167, 4177], [4697, 4177], [4697, 4555], [4167, 4555]],
                center: [4439, 4359],
                data: '2F-54'
            }
        ],
        closedEvent: true,
        reservationSystem: false
    };
    var options = {
        params: {
            productId: params.productId,
            productDate: params.productDate,
            productRound: params.productRound,
            sellingTypeCode: params.sellingTypeCode || 'TKL',
            reserveMemberNo: params.reserveMemberNo,
            loginMemberNo: params.loginMemberNo || 10,
            logicalPlanId: params.logicalPlanId
        },
        mapOptions: mapOptions
    };

    return options;
}